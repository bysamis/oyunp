// Uzaktan içerik için imza anahtarı üretir (bir kez çalıştırın).
//   node tools/remote-keygen.mjs
// - tools/remote-private.jwk  → GİZLİ anahtar. Kimseyle paylaşmayın, git'e koymayın (.gitignore'da).
// - Ekrana yazılan AÇIK anahtarı src/config.js → REMOTE_PUBLIC_KEY alanına yapıştırın.
import { webcrypto as crypto } from 'node:crypto';
import { writeFileSync, existsSync } from 'node:fs';
const out = new URL('./remote-private.jwk', import.meta.url);
if (existsSync(out) && !process.argv.includes('--force')) { console.error('Anahtar zaten var (tools/remote-private.jwk). Yenisi için --force ekleyin; eski uygulamalar yeni imzayı kabul etmez!'); process.exit(1); }
const kp = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
const priv = await crypto.subtle.exportKey('jwk', kp.privateKey);
const pub = await crypto.subtle.exportKey('jwk', kp.publicKey);
writeFileSync(out, JSON.stringify(priv, null, 2));
const p = { kty: pub.kty, crv: pub.crv, x: pub.x, y: pub.y };
console.log('Gizli anahtar kaydedildi: tools/remote-private.jwk');
console.log('\nsrc/config.js içine yapıştırın:\n');
console.log(`export const REMOTE_PUBLIC_KEY = ${JSON.stringify(p)};`);
