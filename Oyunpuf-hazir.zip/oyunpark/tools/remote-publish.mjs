// remote/config.json'u yayına hazırlar:
//  1) remote/games/ içindeki her oyunun SHA-256 özetini config'e yazar (oyun değiştiyse sürümünü artırır)
//  2) config "version" alanını bir artırır
//  3) config.json'u gizli anahtarla imzalar → remote/config.sig
//   node tools/remote-publish.mjs
// Sonra remote/ klasörünün TAMAMINI sunucunuza yükleyin.
import { webcrypto as crypto, createHash } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
const root = new URL('../remote/', import.meta.url);
const keyFile = new URL('./remote-private.jwk', import.meta.url);
if (!existsSync(keyFile)) { console.error('Önce anahtar üretin: node tools/remote-keygen.mjs'); process.exit(1); }
const cfgFile = new URL('config.json', root);
const cfg = JSON.parse(readFileSync(cfgFile, 'utf8'));
for (const g of cfg.games || []) {
  if (/^https:\/\//.test(g.url)) { if (!g.sha256) console.warn(`! ${g.id}: dış adresli oyunun sha256 alanını elle girin`); continue; }
  const f = new URL(g.url, root);
  if (!existsSync(f)) { console.error(`! ${g.id}: dosya yok → remote/${g.url}`); process.exit(1); }
  const html = readFileSync(f, 'utf8');
  const sha = createHash('sha256').update(html, 'utf8').digest('hex');
  if (g.sha256 && g.sha256 !== sha) g.version = (g.version || 1) + 1;
  g.sha256 = sha;
  console.log(`✓ ${g.id} → ${sha.slice(0, 12)}… (${(html.length / 1024).toFixed(1)} KB, sürüm ${g.version || 1})`);
}
cfg.version = (cfg.version || 0) + 1;
cfg.publishedAt = new Date().toISOString();
const text = JSON.stringify(cfg, null, 2) + '\n';
writeFileSync(cfgFile, text);
const jwk = JSON.parse(readFileSync(keyFile, 'utf8'));
const key = await crypto.subtle.importKey('jwk', jwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, new TextEncoder().encode(text));
writeFileSync(new URL('config.sig', root), Buffer.from(sig).toString('base64') + '\n');
console.log(`\nYayına hazır: config sürüm ${cfg.version}. remote/ klasörünü sunucuya yükleyin.`);
