# 3D model ve doku kredileri

| Dosyalar | Kaynak | Yazar | Lisans |
|---|---|---|---|
| character, coin, block-coin, brick, cloud, flag, grass*, platform*, decoration-*, vehicle-* | Kenney Starter Kits | Kenney (kenney.nl) | MIT (LICENSE-kenney.md) |
| bc-*.glb (oyuncu, futbolcu, kaleci, seyirci) | Blocky Characters 2.0 | Kenney (kenney.nl) | CC0 1.0 |
| kv-blocks.glb, kv-grass.glb (blok ve çim dokuları) | Voxel Pack | Kenney (kenney.nl) | CC0 1.0 |
| gy-zombie, gy-skeleton, gy-ghost (canavarlar) | Graveyard Kit | Kenney (kenney.nl) | CC0 1.0 |
| ma-sword, ma-spear, ma-trophy, ma-banner | Mini Arena | Kenney (kenney.nl) | CC0 1.0 |
| kw-bow, kw-arrow, kw-axe | KayKit Fantasy Weapons | Kay Lousberg (kaylousberg.com) | CC0 1.0 (LICENSE-kaykit.txt) |

CC0 içerikler kamu malıdır; ticari kullanım serbesttir, kredi zorunlu değildir (yine de Ayarlar ekranında gösterilir).
Dönüştürme: dokular GLB içine gömüldü, kullanılmayan animasyonlar ayıklandı, dokular en fazla 256 px'e küçültüldü.
