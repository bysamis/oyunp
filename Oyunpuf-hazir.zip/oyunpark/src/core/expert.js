// Uzman modu: bir oyunun normal zorluk artışı tavana ulaştıktan sonra (cap seviyesi)
// her yeni seviyede biraz daha zorlaştırır. Artış yumuşak ve sınırlı: en fazla +%60 (strength=1).
import { remote } from './remote.js';
// Dönen değer 1'den başlar; süreleri bu sayıya bölmek, hızları çarpmak için kullanılır.
export function expert(L, cap, strength = 1) {
  const e = Math.max(0, L - cap);
  return 1 + 0.6 * strength * remote.expertStrength() * (1 - Math.pow(0.88, e)); // uzaktan güç ayarı (0–2)
}
export const expertSteps = (L, cap) => Math.max(0, L - cap);
