// AdMob sarmalayıcı. Tarayıcıda reklamları taklit eden bir test ekranı gösterir.
import { AdMob, BannerAdSize, BannerAdPosition, MaxAdContentRating, AdmobConsentStatus } from '@capacitor-community/admob';
import { isNative, platform } from './native.js';
import { store } from './store.js';
import { ADMOB, TEST_ADS, AD_POLICY as P } from '../config.js';

let ready = false;
let bannerShown = false;
let gameOverCount = 0;      // bu oturumda son reklamdan beri biten oyun
let lastInterstitial = 0;   // sn
let lastRewarded = 0;       // sn
let playSec = 0;            // son reklamdan beri oyunda geçen süre
let playStart = 0;
const today = () => new Date().toISOString().slice(0, 10);
let rewardedLoaded = false;
let interstitialLoaded = false;

const ids = () => ADMOB[platform] || ADMOB.android;

export const ads = {
  online: () => navigator.onLine !== false,
  async init() {
    // internet geri gelince ya da uygulama öne gelince reklamları önceden yükle (kısa kopmalarda hazır bekler)
    window.addEventListener('online', () => this.preload());
    document.addEventListener('visibilitychange', () => { if (!document.hidden) this.preload(); });
    if (!isNative) { ready = true; return; }
    const child = store.isChild();
    try {
      await AdMob.initialize({
        initializeForTesting: TEST_ADS,
        tagForChildDirectedTreatment: child,
        tagForUnderAgeOfConsent: child,
        maxAdContentRating: child ? MaxAdContentRating.General : MaxAdContentRating.ParentalGuidance,
      });
      // GDPR/KVKK onay formu (gerekiyorsa). Çocuklarda kişiselleştirilmiş reklam zaten kapalı.
      if (!child) {
        try {
          const info = await AdMob.requestConsentInfo();
          if (info.isConsentFormAvailable && info.status === AdmobConsentStatus.REQUIRED) {
            await AdMob.showConsentForm();
          }
        } catch (e) {}
        if (platform === 'ios') {
          try {
            const s = await AdMob.trackingAuthorizationStatus();
            if (s.status === 'notDetermined') await AdMob.requestTrackingAuthorization();
          } catch (e) {}
        }
      }
      ready = true;
      this.preload();
    } catch (e) { console.warn('AdMob init failed', e); }
  },

  preload() {
    if (!isNative || !ready) return;
    if (!rewardedLoaded) {
      AdMob.prepareRewardVideoAd({ adId: ids().rewarded, isTesting: TEST_ADS })
        .then(() => (rewardedLoaded = true)).catch(() => {});
    }
    if (!interstitialLoaded && !store.isVip()) {
      AdMob.prepareInterstitial({ adId: ids().interstitial, isTesting: TEST_ADS })
        .then(() => (interstitialLoaded = true)).catch(() => {});
    }
  },

  async showBanner() {
    if (store.isVip() || bannerShown) return;
    bannerShown = true;
    if (!isNative) { document.body.classList.add('has-banner'); return; }
    try {
      await AdMob.showBanner({
        adId: ids().banner, adSize: BannerAdSize.ADAPTIVE_BANNER,
        position: BannerAdPosition.BOTTOM_CENTER, margin: 0, isTesting: TEST_ADS,
      });
      document.body.classList.add('has-banner');
    } catch (e) { bannerShown = false; }
  },

  async hideBanner() {
    if (!bannerShown) return;
    bannerShown = false;
    document.body.classList.remove('has-banner');
    if (isNative) { try { await AdMob.removeBanner(); } catch (e) {} }
  },

  // Oyun ekranı açılınca / kapanınca: gerçek oynama süresini sayar
  gameStarted() { playStart = Date.now(); },
  gameStopped() { if (playStart) { playSec += (Date.now() - playStart) / 1000; playStart = 0; } },

  // Bu an geçiş reklamı göstermeye uygun mu? (kurallar config.js → AD_POLICY)
  shouldInterstitial({ multiplayer = false } = {}) {
    if (store.isVip()) return false;
    const s = store.get(), now = Date.now() / 1000;
    const total = s.totalGameOvers || 0;
    if (total <= P.graceGames) return false;                                   // yeni oyuncuya ilk oyunlarda reklam yok
    const child = store.isChild();
    const ageDays = (Date.now() - (s.firstLaunch || Date.now())) / 86400000;
    const isNew = ageDays < P.newUserDays;
    const every = multiplayer ? P.mpEvery : child ? P.childEvery : isNew ? P.newUserEvery : P.every;
    const minPlay = child ? P.childMinPlaySec : isNew ? P.newUserMinPlaySec : P.minPlaySec;
    const cap = child ? P.childDailyCap : P.dailyCap;
    const countToday = s.adDay === today() ? s.adCount || 0 : 0;
    if (gameOverCount < every) return false;
    if (playSec < minPlay) return false;
    if (now - lastInterstitial < P.minGapSec) return false;
    if (now - lastRewarded < P.afterRewardedSec) return false;                 // az önce gönüllü reklam izledi
    if (countToday >= cap) return false;
    return true;
  },

  // Oyun bittiğinde çağrılır
  async maybeInterstitial(opts = {}) {
    this.gameStopped();
    const s = store.get();
    store.set({ totalGameOvers: (s.totalGameOvers || 0) + 1 });
    if (store.isVip()) return;
    gameOverCount++;
    if (!this.shouldInterstitial(opts)) { if (playStart === 0) playStart = Date.now(); return; }
    gameOverCount = 0; playSec = 0; lastInterstitial = Date.now() / 1000;
    const countToday = (s.adDay === today() ? s.adCount || 0 : 0) + 1;
    store.set({ adDay: today(), adCount: countToday });
    if (!isNative) await webFakeAd('Geçiş reklamı', 3);
    else {
      try {
        if (!interstitialLoaded) await AdMob.prepareInterstitial({ adId: ids().interstitial, isTesting: TEST_ADS });
        interstitialLoaded = false;
        await AdMob.showInterstitial();
      } catch (e) {}
      this.preload();
    }
    // günde bir kez nazik "reklamsız oyna" teklifi
    if (countToday === P.vipNudgeAfter && s.vipNudgeDay !== today()) { store.set({ vipNudgeDay: today() }); window.dispatchEvent(new CustomEvent('oyunpark:vip-nudge')); }
    playStart = Date.now();
  },

  // Ödüllü reklam: izlenirse true döner. VIP üyeler reklam izlemeden ödülü alır.
  async rewarded() {
    if (store.isVip()) return true;
    if (!isNative) { const ok = await webFakeAd('Ödüllü reklam', 5, true); if (ok) lastRewarded = Date.now() / 1000; return ok; }
    try {
      if (!rewardedLoaded) await AdMob.prepareRewardVideoAd({ adId: ids().rewarded, isTesting: TEST_ADS });
      rewardedLoaded = false;
      const r = await AdMob.showRewardVideoAd();
      this.preload();
      if (r) lastRewarded = Date.now() / 1000;
      return !!r;
    } catch (e) {
      this.preload();
      return false;
    }
  },
};

// Tarayıcı önizlemesi için sahte reklam ekranı
function webFakeAd(label, seconds, rewarded = false) {
  return new Promise((resolve) => {
    const el = document.createElement('div');
    el.className = 'fake-ad';
    el.innerHTML = `<div class="fake-ad-box"><div class="fake-ad-tag">TEST</div><div class="fake-ad-title">${label}</div>
      <div class="fake-ad-sub">Gerçek uygulamada burada AdMob reklamı görünür</div><div class="fake-ad-count">${seconds}</div>
      <button class="btn small ghost fake-ad-close" disabled>Kapat</button></div>`;
    document.body.appendChild(el);
    const countEl = el.querySelector('.fake-ad-count');
    const btn = el.querySelector('.fake-ad-close');
    let left = seconds;
    let done = false;
    const t = setInterval(() => {
      left--; countEl.textContent = Math.max(0, left);
      if (left <= 0) { clearInterval(t); done = true; btn.disabled = false; btn.textContent = rewarded ? 'Ödülü al ✓' : 'Kapat ✕'; }
    }, 1000);
    btn.onclick = () => { clearInterval(t); el.remove(); resolve(done); };
  });
}
if (typeof location !== 'undefined' && location.search.includes('debug')) window.__ads = ads;
