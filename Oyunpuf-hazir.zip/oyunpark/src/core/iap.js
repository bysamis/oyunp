// VIP abonelik — yalnızca App Store / Google Play (cordova-plugin-purchase v13, Capacitor ile çalışır).
// Sunucu yok: aboneliğin bitiş tarihi mağazanın cihaza bildirdiği işlemlerden hesaplanır ve telefonda saklanır,
// böylece VIP internetsizken de çalışır. Tarayıcı önizlemesinde satın alma taklit edilir.
import { isNative, platform } from './native.js';
import { store } from './store.js';
import { VIP_PLANS } from '../config.js';

let cdv = null;
let storePlatform = null;
const prices = {};
let onChange = () => {};
const GRACE_MS = 24 * 3600 * 1000; // yenileme gecikmelerine karşı 1 günlük tolerans

function planOf(id) { return VIP_PLANS.find((p) => p.id === id); }

// Bir abonelik işleminden VIP bitiş zamanını hesapla
function applyTransaction(tx) {
  const ids = (tx.products || []).map((p) => p.id).filter(planOf);
  if (!ids.length) return;
  const plan = planOf(ids[0]);
  let until = 0;
  if (tx.expirationDate) until = new Date(tx.expirationDate).getTime();
  else {
    const base = new Date(tx.lastRenewalDate || tx.purchaseDate || Date.now()).getTime();
    until = base + plan.days * 24 * 3600 * 1000;
  }
  until += GRACE_MS;
  if (until > (store.get().vipUntil || 0)) store.set({ vipUntil: until });
}

function refreshOwned() {
  if (!cdv) return;
  const owned = VIP_PLANS.some((p) => cdv.store.owned({ id: p.id, platform: storePlatform }));
  const was = store.isVip();
  store.set({ vipOwned: owned });
  if (was !== store.isVip()) onChange(store.isVip());
}

export const iap = {
  onChange(fn) { onChange = fn; },

  async init() {
    if (!isNative) return;
    cdv = await waitFor(() => window.CdvPurchase, 5000);
    if (!cdv) { console.warn('CdvPurchase yok'); return; }
    const { store: s, ProductType, Platform } = cdv;
    storePlatform = platform === 'ios' ? Platform.APPLE_APPSTORE : Platform.GOOGLE_PLAY;
    s.register(VIP_PLANS.map((p) => ({ id: p.id, type: ProductType.PAID_SUBSCRIPTION, platform: storePlatform })));
    s.when()
      .productUpdated((prod) => {
        const offer = prod.getOffer?.();
        // deneme süresi varsa ilk fazı atla, düzenli fiyatı göster
        const phases = offer?.pricingPhases || [];
        const regular = phases.find((ph) => ph.priceMicros > 0) || phases[0];
        if (regular?.price) prices[prod.id] = regular.price;
        const trial = phases.find((ph) => ph.priceMicros === 0);
        if (trial) prices[prod.id + ':trial'] = true;
      })
      .approved((tx) => { applyTransaction(tx); tx.verify(); })
      .verified((receipt) => { receipt.transactions?.forEach(applyTransaction); receipt.finish(); refreshOwned(); })
      .receiptUpdated(() => refreshOwned());
    s.error((err) => console.warn('IAP hata', err));
    await s.initialize([storePlatform]);
    await s.update?.();
    // açılışta cihazdaki işlemlerden bitiş tarihini yeniden hesapla
    (s.localTransactions || []).forEach(applyTransaction);
    refreshOwned();
  },

  price(id) { return prices[id] || planOf(id)?.fallbackPrice || ''; },
  hasTrial(id) { return !!prices[id + ':trial']; },

  async buy(id) {
    if (!isNative) {
      // Tarayıcı önizlemesi: aboneliği taklit et
      await new Promise((r) => setTimeout(r, 400));
      store.set({ vipUntil: Date.now() + planOf(id).days * 24 * 3600 * 1000 });
      onChange(true);
      return true;
    }
    if (!cdv) return false;
    const offer = cdv.store.get(id, storePlatform)?.getOffer();
    if (!offer) return false;
    const err = await offer.order();
    return !err;
  },

  async restore() {
    if (!isNative || !cdv) return store.isVip();
    await cdv.store.restorePurchases();
    (cdv.store.localTransactions || []).forEach(applyTransaction);
    refreshOwned();
    return store.isVip();
  },

  // Mağazanın abonelik yönetimi ekranını açar (iptal, plan değiştirme)
  async manage() {
    if (isNative && cdv) return cdv.store.manageSubscriptions(storePlatform);
    window.open(platform === 'ios' ? 'https://apps.apple.com/account/subscriptions' : 'https://play.google.com/store/account/subscriptions', '_blank');
  },
};

function waitFor(fn, ms) {
  return new Promise((resolve) => {
    const start = Date.now();
    const tick = () => { const v = fn(); if (v) return resolve(v); if (Date.now() - start > ms) return resolve(null); setTimeout(tick, 100); };
    tick();
  });
}
