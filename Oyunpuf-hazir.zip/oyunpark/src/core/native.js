// Yerel (iOS/Android) yetenekler; tarayıcıda sessizce yok sayılır
import { Capacitor } from '@capacitor/core';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
import { ScreenOrientation } from '@capacitor/screen-orientation';
import { store } from './store.js';

export const isNative = Capacitor.isNativePlatform();
export const platform = Capacitor.getPlatform(); // 'ios' | 'android' | 'web'

export function haptic(kind = 'light') {
  if (!store.get().haptics) return;
  if (isNative) {
    const style = kind === 'heavy' ? ImpactStyle.Heavy : kind === 'medium' ? ImpactStyle.Medium : ImpactStyle.Light;
    Haptics.impact({ style }).catch(() => {});
  } else if (navigator.vibrate) {
    navigator.vibrate(kind === 'heavy' ? 40 : kind === 'medium' ? 20 : 8);
  }
}

// Ekran yönü: uygulama dikey; bazı oyunlar (Blok Dünyası) açılınca yatay döner
export async function setOrientation(mode) {
  try {
    if (isNative) await ScreenOrientation.lock({ orientation: mode });
    else if (screen.orientation?.lock) await screen.orientation.lock(mode); // tarayıcıda çoğu zaman yalnızca tam ekranda çalışır
  } catch (e) { /* desteklenmiyorsa sessizce geç */ }
}
