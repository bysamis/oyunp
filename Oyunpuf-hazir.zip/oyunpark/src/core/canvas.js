// Ortak canvas + oyun döngüsü yardımcısı
export function createStage(host, { onResize } = {}) {
  const canvas = document.createElement('canvas');
  canvas.className = 'stage';
  host.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  const st = { canvas, ctx, W: 0, H: 0, dpr: 1 };

  function resize(initial) {
    const r = host.getBoundingClientRect();
    st.dpr = Math.min(window.devicePixelRatio || 1, 3);
    st.W = Math.max(1, r.width);
    st.H = Math.max(1, r.height);
    canvas.width = Math.round(st.W * st.dpr);
    canvas.height = Math.round(st.H * st.dpr);
    canvas.style.width = st.W + 'px';
    canvas.style.height = st.H + 'px';
    ctx.setTransform(st.dpr, 0, 0, st.dpr, 0, 0);
    if (initial !== true) onResize?.(st);
  }
  const ro = new ResizeObserver(resize);
  ro.observe(host);
  resize(true); // ilk ölçüm: oyun kendi start() içinde layout yapar

  st.point = (e) => {
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  st.destroy = () => { ro.disconnect(); canvas.remove(); };
  return st;
}

export function loop(update) {
  let raf = 0, last = 0, running = true, paused = false;
  const frame = (t) => {
    if (!running) return;
    const dt = last ? Math.min(0.05, (t - last) / 1000) : 0;
    last = t;
    if (!paused) update(dt, t / 1000);
    raf = requestAnimationFrame(frame);
  };
  raf = requestAnimationFrame(frame);
  return {
    stop() { running = false; cancelAnimationFrame(raf); },
    pause() { paused = true; },
    resume() { paused = false; last = 0; },
    get paused() { return paused; },
  };
}

export function roundRect(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

export function shade(hex, amt) {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) + amt, g = ((n >> 8) & 255) + amt, b = (n & 255) + amt;
  r = Math.max(0, Math.min(255, r)); g = Math.max(0, Math.min(255, g)); b = Math.max(0, Math.min(255, b));
  return '#' + ((r << 16) | (g << 8) | b).toString(16).padStart(6, '0');
}

// Basit parçacık sistemi
export function particles() {
  const list = [];
  return {
    burst(x, y, color, n = 12, speed = 160) {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2;
        const s = speed * (0.4 + Math.random() * 0.8);
        list.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.6 + Math.random() * 0.4, t: 0, color, r: 2 + Math.random() * 3 });
      }
    },
    text(x, y, str, color = '#fff') {
      list.push({ x, y, vx: 0, vy: -60, life: 0.9, t: 0, color, str });
    },
    update(dt) {
      for (let i = list.length - 1; i >= 0; i--) {
        const p = list[i];
        p.t += dt; p.x += p.vx * dt; p.y += p.vy * dt;
        if (!p.str) p.vy += 300 * dt;
        if (p.t >= p.life) list.splice(i, 1);
      }
    },
    draw(ctx) {
      for (const p of list) {
        const a = 1 - p.t / p.life;
        ctx.globalAlpha = a;
        if (p.str) {
          ctx.fillStyle = p.color;
          ctx.font = '800 20px system-ui, sans-serif';
          ctx.textAlign = 'center';
          ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 4;
          ctx.strokeText(p.str, p.x, p.y); ctx.fillText(p.str, p.x, p.y);
        } else {
          ctx.fillStyle = p.color;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r * a + 0.5, 0, Math.PI * 2); ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
    },
    clear() { list.length = 0; },
  };
}
