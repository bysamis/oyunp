// Uzaktan içerik: uygulama güncellemesi olmadan ayar, etkinlik, duyuru ve yeni HTML5 mini oyun ekleme.
//
// Akış: açılışta önbellekteki (daha önce doğrulanmış) yapılandırma hemen uygulanır → arka planda yenisi
// indirilir → ECDSA P-256 imzası doğrulanır → alanlar tek tek kontrol edilir → kaydedilir ve uygulanır.
// Uzaktan oyunların HTML dosyaları SHA-256 özetine göre doğrulanıp cihaza kaydedilir (internetsiz de oynanır).
import { REMOTE_CONFIG_URL, REMOTE_PUBLIC_KEY, APP_VERSION, AD_POLICY, DAILY_REWARDS, WHEEL_PRIZES, WHEEL_WEIGHTS } from '../config.js';

const CACHE_KEY = 'oyunpark_remote_v1';
const SCHEMA = 1;
const listeners = new Set();
let active = null; // uygulanmış yapılandırma

const debugUrl = () => { try { return location.search.includes('debug') ? localStorage.getItem('oyunpark_remote_url') : null; } catch { return null; } };
const debugKey = () => { try { return location.search.includes('debug') ? JSON.parse(localStorage.getItem('oyunpark_remote_pub') || 'null') : null; } catch { return null; } };

// ---------- yardımcılar ----------
const num = (v, lo, hi) => (typeof v === 'number' && isFinite(v) && v >= lo && v <= hi ? v : undefined);
const str = (v, max = 200) => (typeof v === 'string' && v.length <= max ? v : undefined);
const idOk = (v) => typeof v === 'string' && /^[a-z0-9-]{2,32}$/.test(v);
const inWindow = (o, now = Date.now()) => (!o.start || Date.parse(o.start) <= now) && (!o.end || now < Date.parse(o.end));
function cmpVer(a, b) { const x = a.split('.').map(Number), y = b.split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; }
function b64ToBytes(b64) { const s = atob(b64); const a = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; }
async function sha256Hex(text) { const h = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)); return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, '0')).join(''); }

async function verify(text, sigB64) {
  const jwk = debugKey() || REMOTE_PUBLIC_KEY;
  if (!jwk) return false;
  try {
    const key = await crypto.subtle.importKey('jwk', jwk, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    return await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, b64ToBytes(sigB64.trim()), new TextEncoder().encode(text));
  } catch { return false; }
}

// ---------- alan doğrulama: yalnızca bilinen, sınırları içindeki değerler kabul edilir ----------
const AD_LIMITS = { graceGames: [0, 50], every: [1, 20], minPlaySec: [30, 1800], minGapSec: [30, 1800], newUserDays: [0, 30], newUserEvery: [1, 20], newUserMinPlaySec: [30, 1800], childEvery: [1, 20], childMinPlaySec: [30, 1800], childDailyCap: [0, 50], dailyCap: [0, 100], afterRewardedSec: [0, 1800], mpEvery: [1, 20], vipNudgeAfter: [1, 50] };
function sanitize(c) {
  if (!c || typeof c !== 'object' || c.schema !== SCHEMA) return null;
  const out = { schema: SCHEMA, version: num(c.version, 1, 1e9) || 1, minAppVersion: /^\d+\.\d+\.\d+$/.test(c.minAppVersion || '') ? c.minAppVersion : null, updateUrl: str(c.updateUrl, 300) };
  // reklam sıklığı
  out.adPolicy = {};
  for (const k in AD_LIMITS) { const v = num(c.adPolicy?.[k], ...AD_LIMITS[k]); if (v !== undefined) out.adPolicy[k] = v; }
  // ekonomi
  const e = c.economy || {};
  out.economy = {
    coinRate: num(e.coinRate, 0.05, 2),
    dailyRewards: Array.isArray(e.dailyRewards) && e.dailyRewards.length === 7 && e.dailyRewards.every((v) => num(v, 0, 5000) !== undefined) ? e.dailyRewards : undefined,
    wheel: Array.isArray(e.wheelPrizes) && Array.isArray(e.wheelWeights) && e.wheelPrizes.length === 8 && e.wheelWeights.length === 8 && e.wheelPrizes.every((v) => num(v, 0, 10000) !== undefined) && e.wheelWeights.every((v) => num(v, 0, 1000) !== undefined) ? { prizes: e.wheelPrizes, weights: e.wheelWeights } : undefined,
    expertStrength: num(e.expertStrength, 0, 2),
  };
  // zamanlı etkinlikler (örn. hafta sonu 2× coin)
  out.events = (Array.isArray(c.events) ? c.events : []).slice(0, 10).map((ev) => ({ id: idOk(ev.id) ? ev.id : null, title: str(ev.title, 60), coinMultiplier: num(ev.coinMultiplier, 1, 5) || 1, start: str(ev.start, 40), end: str(ev.end, 40) })).filter((ev) => ev.id && ev.title);
  // duyurular
  out.announcements = (Array.isArray(c.announcements) ? c.announcements : []).slice(0, 5).map((a) => ({ id: idOk(a.id) ? a.id : null, title: str(a.title, 60), text: str(a.text, 280), emoji: str(a.emoji, 8) || '📣', game: idOk(a.game) ? a.game : null, start: str(a.start, 40), end: str(a.end, 40) })).filter((a) => a.id && a.title);
  // katalog: sıralama, gizleme, rozet
  const cat = c.catalog || {};
  out.catalog = {
    order: Array.isArray(cat.order) ? cat.order.filter(idOk).slice(0, 200) : [],
    hidden: Array.isArray(cat.hidden) ? cat.hidden.filter(idOk).slice(0, 200) : [],
    badges: Object.fromEntries(Object.entries(cat.badges || {}).filter(([k, v]) => idOk(k) && str(v, 12)).slice(0, 50)),
  };
  // uzaktan HTML5 mini oyunlar
  out.games = (Array.isArray(c.games) ? c.games : []).slice(0, 50).map((g) => ({
    id: idOk(g.id) ? 'r-' + g.id : null, title: str(g.title, 40), emoji: str(g.emoji, 8) || '🎮', color: /^#[0-9a-f]{6}$/i.test(g.color || '') ? g.color : '#7b2cbf',
    desc: str(g.desc, 80) || '', url: typeof g.url === 'string' && /^https:\/\//.test(g.url) ? g.url : (typeof g.url === 'string' && /^[a-z0-9_\-/]+\.html$/i.test(g.url) ? g.url : null),
    sha256: /^[0-9a-f]{64}$/.test(g.sha256 || '') ? g.sha256 : null, age: num(g.age, 0, 18) ?? 4, version: num(g.version, 1, 1e6) || 1,
    targetBase: num(g.targetBase, 1, 1e7) || 100, targetGrowth: num(g.targetGrowth, 1, 3) || 1.35, coinDiv: num(g.coinDiv, 1, 1e5) || 10, coinCap: num(g.coinCap, 0, 1000) ?? 60,
    landscape: !!g.landscape, minAppVersion: /^\d+\.\d+\.\d+$/.test(g.minAppVersion || '') ? g.minAppVersion : null,
  })).filter((g) => g.id && g.title && g.url && g.sha256 && (!g.minAppVersion || cmpVer(APP_VERSION, g.minAppVersion) >= 0));
  return out;
}

// ---------- uzaktan oyun dosyaları (IndexedDB) ----------
function db() {
  return new Promise((res, rej) => { const r = indexedDB.open('oyunpark_remote', 1); r.onupgradeneeded = () => r.result.createObjectStore('games'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
}
async function idbGet(k) { const d = await db(); return new Promise((res) => { const q = d.transaction('games').objectStore('games').get(k); q.onsuccess = () => res(q.result); q.onerror = () => res(undefined); }); }
async function idbPut(k, v) { const d = await db(); return new Promise((res) => { const t = d.transaction('games', 'readwrite'); t.objectStore('games').put(v, k); t.oncomplete = () => res(true); t.onerror = () => res(false); }); }
async function idbKeys() { const d = await db(); return new Promise((res) => { const q = d.transaction('games').objectStore('games').getAllKeys(); q.onsuccess = () => res(q.result || []); q.onerror = () => res([]); }); }
async function idbDel(k) { const d = await db(); return new Promise((res) => { const t = d.transaction('games', 'readwrite'); t.objectStore('games').delete(k); t.oncomplete = () => res(true); }); }

const ready = new Set(); // cihazda doğrulanmış dosyası olan uzaktan oyunlar
async function syncGames(cfg, base) {
  const want = new Set(cfg.games.map((g) => g.id));
  for (const k of await idbKeys().catch(() => [])) if (!want.has(k)) idbDel(k); // kaldırılan oyunlar silinir
  for (const g of cfg.games) {
    const have = await idbGet(g.id).catch(() => null);
    if (have && have.sha256 === g.sha256) { ready.add(g.id); continue; }
    try {
      const url = new URL(g.url, base).href;
      const r = await fetch(url, { cache: 'no-store' }); if (!r.ok) continue;
      const html = await r.text();
      if (html.length > 3e6 || (await sha256Hex(html)) !== g.sha256) { console.warn('[remote] özet tutmadı:', g.id); continue; }
      await idbPut(g.id, { sha256: g.sha256, html }); ready.add(g.id);
    } catch {}
  }
  emit();
}
export async function gameHtml(id) { const r = await idbGet(id).catch(() => null); return r?.html || null; }

// ---------- uygulama ----------
const DEFAULTS = { ad: { ...AD_POLICY }, daily: [...DAILY_REWARDS], prizes: [...WHEEL_PRIZES], weights: [...WHEEL_WEIGHTS] };
function apply(cfg) {
  active = cfg;
  Object.assign(AD_POLICY, DEFAULTS.ad, cfg?.adPolicy || {});
  const e = cfg?.economy || {};
  DAILY_REWARDS.splice(0, 7, ...(e.dailyRewards || DEFAULTS.daily));
  WHEEL_PRIZES.splice(0, 8, ...(e.wheel?.prizes || DEFAULTS.prizes));
  WHEEL_WEIGHTS.splice(0, 8, ...(e.wheel?.weights || DEFAULTS.weights));
  emit();
}
function emit() { listeners.forEach((f) => { try { f(active); } catch {} }); }

export const remote = {
  get config() { return active; },
  onChange(f) { listeners.add(f); return () => listeners.delete(f); },
  coinRate(def) { return active?.economy?.coinRate ?? def; },
  expertStrength() { return active?.economy?.expertStrength ?? 1; },
  activeEvent() { return (active?.events || []).find((ev) => inWindow(ev)) || null; },
  coinMultiplier() { return this.activeEvent()?.coinMultiplier || 1; },
  announcements() { return (active?.announcements || []).filter((a) => inWindow(a)); },
  needsUpdate() { return !!(active?.minAppVersion && cmpVer(APP_VERSION, active.minAppVersion) < 0); },
  catalog() { return active?.catalog || { order: [], hidden: [], badges: {} }; },
  games() { return (active?.games || []).filter((g) => ready.has(g.id)); },

  // açılışta: önce önbellek (anında), sonra ağ (arka planda)
  async init() {
    try {
      const c = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null');
      if (c?.text && c?.sig && (await verify(c.text, c.sig))) { const cfg = sanitize(JSON.parse(c.text)); if (cfg) { apply(cfg); for (const g of cfg.games) if (await idbGet(g.id).then((r) => r?.sha256 === g.sha256).catch(() => false)) ready.add(g.id); emit(); } }
    } catch {}
    this.refresh();
  },
  async refresh() {
    const url = debugUrl() || REMOTE_CONFIG_URL;
    if (!url || typeof fetch === 'undefined' || (typeof navigator !== 'undefined' && navigator.onLine === false)) return false;
    try {
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 6000);
      const [tr, sr] = await Promise.all([fetch(url, { cache: 'no-store', signal: ctl.signal }), fetch(url.replace(/\.json(\?.*)?$/, '.sig'), { cache: 'no-store', signal: ctl.signal })]);
      clearTimeout(t);
      if (!tr.ok || !sr.ok) return false;
      const text = await tr.text(), sig = await sr.text();
      if (!(await verify(text, sig))) { console.warn('[remote] imza geçersiz — yapılandırma reddedildi'); return false; }
      const cfg = sanitize(JSON.parse(text));
      if (!cfg) return false;
      if (active && cfg.version < active.version) return false; // eski sürüme geri dönme saldırısına karşı
      localStorage.setItem(CACHE_KEY, JSON.stringify({ text, sig }));
      apply(cfg);
      syncGames(cfg, url);
      return true;
    } catch { return false; }
  },
};
