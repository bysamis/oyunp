// Dosya gerektirmeyen sentez ses efektleri + basit arka plan müziği
import { store } from './store.js';

let ctx = null;
let master = null;
let musicGain = null;
let musicTimer = null;

function ac() {
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.5;
    master.connect(ctx.destination);
    musicGain = ctx.createGain();
    musicGain.gain.value = 0.12;
    musicGain.connect(master);
  }
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

function tone(freq, dur = 0.12, type = 'sine', vol = 0.5, slide = 0, delay = 0, dest) {
  const c = ac(); if (!c) return;
  const t = c.currentTime + delay;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(dest || master);
  o.start(t); o.stop(t + dur + 0.02);
}

function noise(dur = 0.2, vol = 0.3) {
  const c = ac(); if (!c) return;
  const len = Math.floor(c.sampleRate * dur);
  const buf = c.createBuffer(1, len, c.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const s = c.createBufferSource();
  const g = c.createGain();
  g.gain.value = vol;
  s.buffer = buf; s.connect(g); g.connect(master); s.start();
}

const sounds = {
  tap: () => tone(660, 0.06, 'triangle', 0.3),
  click: () => tone(520, 0.05, 'square', 0.15),
  bounce: () => tone(440, 0.07, 'square', 0.18, 120),
  brick: () => tone(880 + Math.random() * 200, 0.08, 'triangle', 0.3),
  pop: () => { tone(700, 0.09, 'sine', 0.4, 500); },
  combo: (n = 1) => { for (let i = 0; i < 3; i++) tone(520 * Math.pow(1.26, i + n), 0.1, 'triangle', 0.3, 0, i * 0.06); },
  coin: () => { tone(988, 0.08, 'square', 0.18); tone(1319, 0.18, 'square', 0.18, 0, 0.07); },
  slide: () => tone(300, 0.07, 'sine', 0.3, 150),
  swap: () => tone(400, 0.08, 'sine', 0.25, 200),
  wrong: () => tone(200, 0.18, 'sawtooth', 0.15, -80),
  crash: () => { noise(0.4, 0.5); tone(120, 0.4, 'sawtooth', 0.3, -80); },
  lose: () => { [392, 330, 262].forEach((f, i) => tone(f, 0.22, 'triangle', 0.35, 0, i * 0.18)); },
  win: () => { [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.18, 'triangle', 0.35, 0, i * 0.11)); },
  power: () => tone(300, 0.3, 'sine', 0.35, 900),
  lane: () => tone(500, 0.05, 'sine', 0.2, 100),
};

export const sfx = new Proxy({}, {
  get: (_, name) => (...args) => {
    if (!store.get().sound) return;
    try { sounds[name]?.(...args); } catch (e) {}
  },
});

// Neşeli döngüsel melodi (pentatonik)
const melody = [0, 4, 7, 9, 7, 4, 2, 4, 0, 4, 7, 12, 9, 7, 4, 2];
const bass = [0, 0, 5, 5, 7, 7, 5, 5];
export function startMusic() {
  stopMusic();
  if (!store.get().music) return;
  const c = ac(); if (!c) return;
  let step = 0;
  const base = 392; // G4
  musicTimer = setInterval(() => {
    if (!store.get().music || document.hidden) return;
    const n = melody[step % melody.length];
    tone(base * Math.pow(2, n / 12), 0.22, 'triangle', 0.5, 0, 0, musicGain);
    if (step % 2 === 0) {
      const b = bass[(step / 2) % bass.length];
      tone((base / 4) * Math.pow(2, b / 12), 0.35, 'sine', 0.7, 0, 0, musicGain);
    }
    step++;
  }, 260);
}
export function stopMusic() { if (musicTimer) clearInterval(musicTimer); musicTimer = null; }
export function unlockAudio() { ac(); }
