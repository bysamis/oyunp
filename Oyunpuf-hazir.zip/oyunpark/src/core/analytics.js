// Ölçüm (analytics) sarmalayıcı.
// Olaylar her zaman cihazda sayılır (internetsiz de). Firebase Analytics kurulduğunda aynı olaylar oraya da gönderilir:
//   npm i @capacitor-firebase/analytics firebase && npx cap sync
//   + android/app/google-services.json ve ios/App/App/GoogleService-Info.plist dosyalarını ekle (README'ye bak)
//   + aşağıdaki FIREBASE_ENABLED'i true yap
// Yerel eklenti yoksa Firebase JS SDK (web Analytics, config.js → FIREBASE_CONFIG.measurementId) kullanılır.
// 13 yaş altı kullanıcılarda ölçüm gönderilmez (yalnızca cihazda sayılır).
import { Capacitor } from '@capacitor/core';
import { FIREBASE_CONFIG } from '../config.js';
import { store } from './store.js';
const FIREBASE_ENABLED = true;
let web = null; // { logEvent, a }
const KEY = 'oyunpark_stats_v1';
let fb = null;

function local() { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; } }
function saveLocal(d) { try { localStorage.setItem(KEY, JSON.stringify(d)); } catch {} }

export const analytics = {
  async init() {
    if (!FIREBASE_ENABLED) return;
    const y = store.get().birthYear; if (!y || new Date().getFullYear() - y < 13) return; // çocuk kullanıcı: gönderim yok
    try {
      // eklenti kuruluysa Capacitor onu yerel olarak kaydeder
      fb = Capacitor.Plugins?.FirebaseAnalytics || null;
      if (fb) { await fb.setEnabled({ enabled: true }); return; }
    } catch (e) { fb = null; }
    if (!FIREBASE_CONFIG?.measurementId) return;
    try { if (!Capacitor.isNativePlatform() && window.top !== window) return; } catch { return; } // gömülü önizleme (artifact): ağ kapalı
    try {
      const [{ initializeApp, getApps }, an] = await Promise.all([import('firebase/app'), import('firebase/analytics')]);
      if (!(await an.isSupported())) return; // ör. çerezsiz/IndexedDB'siz ortam
      const app = getApps()[0] || initializeApp(FIREBASE_CONFIG);
      const a = an.getAnalytics(app);
      an.setUserProperties?.(a, { platform: Capacitor.getPlatform() });
      web = { a, logEvent: an.logEvent };
    } catch (e) { web = null; }
  },
  // name: snake_case olay adı, params: düz nesne (string/number)
  track(name, params = {}) {
    const d = local();
    d[name] = (d[name] || 0) + 1;
    if (params.game) { d.games = d.games || {}; d.games[params.game] = (d.games[params.game] || 0) + (name === 'game_end' ? 1 : 0); }
    saveLocal(d);
    if (fb) fb.logEvent({ name, params }).catch(() => {});
    else if (web) try { web.logEvent(web.a, name, params); } catch {}
  },
  summary() { return local(); },
};
