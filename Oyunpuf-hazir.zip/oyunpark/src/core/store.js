// Kalıcı oyuncu verisi (coin, rekorlar, ayarlar, satın alımlar)
const KEY = 'oyunpark_save_v1';

const defaults = {
  coins: 100,
  best: {},              // { gameId: score }
  vipUntil: 0,           // VIP bitiş zamanı (ms) — mağaza işlemlerinden hesaplanır
  vipOwned: false,       // mağaza o an aktif abonelik bildiriyor mu
  firstLaunch: 0,
  chest: 0,              // bonus kasası (internetsizken birikir)
  wheelDay: null, wheelFree: 0, wheelAd: 0,
  sound: true,
  music: true,
  haptics: true,
  touchControls: true, // hareketli oyunlarda ekran düğmeleri (gaz, fren, yön…)
  birthYear: null,       // yaş kapısı (çocuk/yetişkin reklam ayarı için)
  carSkin: 'red',
  ownedSkins: ['red'],
  ballSkin: 'white',
  ownedBalls: ['white'],
  puzzleLevel: 1,
  lastDaily: null,       // 'YYYY-MM-DD'
  dailyStreak: 0,
  gamesPlayed: 0,
  unlockedGames: [],
  levels: {},
  mpPlayers: 2,
  onlineName: '',
  mpNames: ['Oyuncu 1', 'Oyuncu 2', 'Oyuncu 3', 'Oyuncu 4'],            // { gameId: zorluk seviyesi }
  allUnlocked: false,
  deliveredTx: [],       // tekrar teslimi önlemek için işlem kimlikleri
};

let data = load();
const listeners = new Set();

function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...structuredClone(defaults), ...JSON.parse(raw) };
  } catch (e) { /* bozuk kayıt: varsayılana dön */ }
  return structuredClone(defaults);
}

function save() {
  try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (e) {}
  listeners.forEach((fn) => fn(data));
}

export const store = {
  get: () => data,
  set(patch) { Object.assign(data, patch); save(); },
  onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); },

  addCoins(n) { data.coins = Math.max(0, data.coins + Math.round(n)); save(); },
  spendCoins(n) {
    if (data.coins < n) return false;
    data.coins -= n; save(); return true;
  },
  submitScore(gameId, score) {
    const prev = data.best[gameId] || 0;
    const isBest = score > prev;
    if (isBest) data.best[gameId] = score;
    data.gamesPlayed++;
    save();
    return { isBest, best: Math.max(prev, score) };
  },
  isVip() { return data.vipOwned || Date.now() < (data.vipUntil || 0); },
  isChild() {
    if (!data.birthYear) return true; // bilinmiyorsa güvenli taraf
    return new Date().getFullYear() - data.birthYear < 13;
  },
  reset() { data = structuredClone(defaults); save(); },
};
