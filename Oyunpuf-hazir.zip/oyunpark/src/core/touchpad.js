// Ekran düğmeleri: hareket gerektiren oyunlarda gaz, fren, yön, zıpla gibi dokunmatik tuşlar.
// Kullanım:
//   const pad = touchpad(host, {
//     left:  [{ id: 'left', icon: '◀' }, { id: 'right', icon: '▶' }],           // sol alt köşe
//     right: [{ id: 'brake', icon: '🛑', label: 'Fren' }, { id: 'gas', icon: '⚡', label: 'Gaz', big: true }],
//     dpad:  true,                                                                // 4 yönlü yön tuşu (sol alt)
//     onPress(id) {}, onRelease(id) {},
//   });
//   pad.held.gas → basılı mı?   pad.destroy()
// Ayarlardan "Ekran düğmeleri" kapatılırsa hiç gösterilmez (pad.held hep boş kalır, kaydırma/sürükleme çalışmaya devam eder).
import { store } from './store.js';

export function touchpad(host, cfg = {}) {
  const held = {};
  const api = { held, el: null, enabled: store.get().touchControls !== false, destroy() { api.el?.remove(); } };
  if (!api.enabled) return api;
  const root = document.createElement('div');
  root.className = 'tpad';
  const mk = (b) => `<button class="tpad-btn ${b.big ? 'big' : ''} ${b.cls || ''}" data-tp="${b.id}" style="${b.color ? `--tc:${b.color}` : ''}" aria-label="${b.label || b.id}">${b.icon || ''}${b.label ? `<small>${b.label}</small>` : ''}</button>`;
  let html = '';
  if (cfg.dpad) html += `<div class="tpad-dpad">${[['up', '▲'], ['left', '◀'], ['right', '▶'], ['down', '▼']].map(([id, ic]) => `<button class="tpad-btn d-${id}" data-tp="${id}" aria-label="${id}">${ic}</button>`).join('')}</div>`;
  else if (cfg.left?.length) html += `<div class="tpad-left">${cfg.left.map(mk).join('')}</div>`;
  if (cfg.right?.length) html += `<div class="tpad-right">${cfg.right.map(mk).join('')}</div>`;
  root.innerHTML = html;
  host.appendChild(root);
  api.el = root;
  // çoklu dokunuş: her parmak kendi düğmesini tutar (gaz + yön aynı anda)
  const owner = new Map(); // pointerId → id
  const press = (id, pid) => {
    owner.set(pid, id);
    if (!held[id]) { held[id] = true; root.querySelector(`[data-tp="${id}"]`)?.classList.add('on'); cfg.onPress?.(id); }
  };
  const release = (pid) => {
    const id = owner.get(pid); if (id === undefined) return; owner.delete(pid);
    if ([...owner.values()].includes(id)) return;
    held[id] = false; root.querySelector(`[data-tp="${id}"]`)?.classList.remove('on'); cfg.onRelease?.(id);
  };
  root.querySelectorAll('[data-tp]').forEach((b) => {
    b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); b.setPointerCapture?.(e.pointerId); press(b.dataset.tp, e.pointerId); });
    const up = (e) => { e.stopPropagation(); release(e.pointerId); };
    b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('lostpointercapture', up);
    b.addEventListener('contextmenu', (e) => e.preventDefault());
  });
  // düğmelerin boşluklarına dokunmak oyuna geçmesin
  root.addEventListener('pointerdown', (e) => { if (e.target === root) return; e.stopPropagation(); });
  return api;
}
