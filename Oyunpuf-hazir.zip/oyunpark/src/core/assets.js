// Hazır 3D modeller (Kenney MIT/CC0, KayKit CC0 — bkz. src/assets/models/CREDITS.md)
// GLB dosyalarının dokuları dosyanın içine gömülüdür; tek dosyalık önizlemede de çalışır.
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { clone as skClone } from 'three/examples/jsm/utils/SkeletonUtils.js';

const URLS = import.meta.glob('../assets/models/*.glb', { query: '?url', import: 'default', eager: true });
const byName = {};
for (const k in URLS) byName[k.split('/').pop().replace('.glb', '')] = URLS[k];

const loader = new GLTFLoader();
// Dokular <img> ile yüklensin (ImageBitmapLoader fetch kullanır; sıkı CSP'li ortamlarda engellenebilir)
loader.register((parser) => { parser.textureLoader = new THREE.TextureLoader(parser.options.manager); return { name: 'op_img_textures' }; });
const cache = {};
// Tek dosyalık önizlemede modeller data: URI olarak gömülür. fetch() ile okumak bazı ortamlarda (CSP connect-src)
// engellendiği için base64 doğrudan çözülüp parse edilir — ağ isteği yapılmaz.
function dataUriToBuffer(uri) {
  const b64 = uri.slice(uri.indexOf(',') + 1), bin = atob(b64), out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out.buffer;
}

function load(name) {
  if (!byName[name]) return Promise.reject(new Error('model yok: ' + name));
  if (!cache[name]) {
    const url = byName[name];
    const onLoad = (res) => (g) => {
      g.scene.traverse((o) => {
        if (o.isMesh) {
          o.castShadow = true; o.receiveShadow = true;
          if (o.isSkinnedMesh) o.frustumCulled = false; // animasyonda sınır kutusu yanlış hesaplanıp karakter kaybolmasın
          if (o.material?.map) { o.material.map.colorSpace = THREE.SRGBColorSpace; o.material.map.magFilter = THREE.NearestFilter; }
        }
      });
      res(g);
    };
    cache[name] = new Promise((res, rej) => {
      if (url.startsWith('data:')) { try { loader.parse(dataUriToBuffer(url), '', onLoad(res), rej); } catch (e) { rej(e); } }
      else loader.load(url, onLoad(res), undefined, rej);
    });
    cache[name].catch((e) => { console.warn('[model]', name, e?.message || e); delete cache[name]; });
  }
  return cache[name];
}

/**
 * Modelin bir kopyasını döndürür.
 * opts.height: model bu yüksekliğe ölçeklenir, tabanı y=0'a, merkezi x/z=0'a oturur.
 * opts.size: en büyük kenarı bu boyuta ölçekler.
 * Dönen nesne bir Group; animasyonlu modellerde group.userData.play(ad) ve update(dt) vardır.
 */
export async function model(name, opts = {}) {
  const g = await load(name);
  const inner = g.animations.length ? skClone(g.scene) : g.scene.clone(true);
  if (opts.glow) inner.traverse((o) => { if (o.isMesh) { o.material = o.material.clone(); o.material.emissive = new THREE.Color(opts.glow); o.material.emissiveIntensity = 0.45; } });
  if (opts.tint) inner.traverse((o) => { if (o.isMesh) { o.material = o.material.clone(); o.material.color.multiply(new THREE.Color(opts.tint)); } });
  const box = new THREE.Box3().setFromObject(inner), sz = new THREE.Vector3(); box.getSize(sz);
  let s = 1;
  if (opts.height) s = opts.height / (sz.y || 1);
  else if (opts.size) s = opts.size / (Math.max(sz.x, sz.y, sz.z) || 1);
  inner.scale.setScalar(s);
  const c = new THREE.Vector3(); box.getCenter(c);
  inner.position.set(-c.x * s, -box.min.y * s, -c.z * s);
  const wrap = new THREE.Group(); wrap.add(inner);
  if (g.animations.length) {
    const mixer = new THREE.AnimationMixer(inner);
    const acts = {}; g.animations.forEach((a) => (acts[a.name] = mixer.clipAction(a)));
    let cur = null;
    wrap.userData.play = (n, fade = 0.15) => {
      const a = acts[n]; if (!a || a === cur) return;
      a.reset().fadeIn(fade).play(); if (cur) cur.fadeOut(fade); cur = a;
    };
    wrap.userData.update = (dt) => mixer.update(dt);
    wrap.userData.has = (n) => !!acts[n];
    wrap.userData.once = (n, back = 'idle', fade = 0.1) => { // tek seferlik animasyon, bitince geri döner
      const a = acts[n]; if (!a) return;
      a.setLoop(THREE.LoopOnce, 1); a.clampWhenFinished = true;
      a.reset().fadeIn(fade).play(); if (cur && cur !== a) cur.fadeOut(fade); cur = a;
      const done = (e) => { if (e.action === a) { mixer.removeEventListener('finished', done); if (cur === a && back) wrap.userData.play(back, 0.2); } };
      mixer.addEventListener('finished', done);
    };
    wrap.userData.play(opts.anim || 'idle', 0);
    if (opts.pose !== undefined) mixer.update(opts.pose); // sabit poz (güncellenmeyen kalabalık için)
  }
  return wrap;
}

/** Yer tutucu grubu hemen döndürür, model yüklenince içine ekler (oyun beklemeden başlar). */
export function modelInto(parent, name, opts = {}, onReady) {
  const holder = new THREE.Group(); parent.add(holder);
  model(name, opts).then((m) => { if (opts.fallback) holder.clear(); holder.add(m); holder.userData.model = m; onReady?.(m); }).catch(() => {});
  if (opts.fallback) holder.add(opts.fallback);
  return holder;
}

/** GLB'nin ham hâli (ör. blok küplerinin geometri ve malzemesini almak için). */
export const loadModel = load;

/** Açılışta arka planda hepsini önden yükler. */
export function preloadModels() { Object.keys(byName).forEach((n) => load(n).catch(() => {})); }
export const MODEL_NAMES = Object.keys(byName);

/** Model yüklenene (ya da yüklenemezse) kadar görünen basit karakter yer tutucusu. */
export function stubFigure(color = 0x3a86ff, h = 1.6) {
  const g = new THREE.Group(), m = new THREE.MeshStandardMaterial({ color, roughness: 0.6 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(h * 0.18, h * 0.42, 4, 10), m); body.position.y = h * 0.4; body.castShadow = true; g.add(body);
  const head = new THREE.Mesh(new THREE.BoxGeometry(h * 0.32, h * 0.32, h * 0.32), new THREE.MeshStandardMaterial({ color: 0xffcf9e })); head.position.y = h * 0.84; head.castShadow = true; g.add(head);
  return g;
}

/**
 * Bir nesneyi modelin bir parçasına (ör. Kenney karakterinde 'arm-right') bağlar; parçanın ucuna (el) yerleştirir.
 * Ölçek telafi edilir: obj dünya biriminde boyutlandırılmış olmalı.
 */
export function attachTo(wrap, partName, obj) {
  const part = wrap.getObjectByName(partName); if (!part) return null;
  wrap.updateMatrixWorld(true);
  const box = new THREE.Box3();
  part.traverse((o) => { if (o.isMesh) { o.geometry.computeBoundingBox(); box.union(o.geometry.boundingBox); } });
  const ws = new THREE.Vector3(); part.getWorldScale(ws);
  const hand = new THREE.Group(); hand.position.set((box.min.x + box.max.x) / 2, box.min.y, (box.min.z + box.max.z) / 2);
  hand.scale.set(1 / ws.x, 1 / ws.y, 1 / ws.z);
  part.add(hand); hand.add(obj);
  return hand;
}
