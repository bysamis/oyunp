// Tribün ve seyirci: Kenney Blocky Characters (CC0) ile basamaklı tribün; sayı/gol olunca seyirci zıplar.
import { THREE, mat } from './three-stage.js';
import { modelInto } from './assets.js';

const FANS = ['bc-fan1', 'bc-fan2', 'bc-fan3', 'bc-fan4', 'bc-fan5', 'bc-fan6', 'bc-red', 'bc-blue', 'bc-green', 'bc-girl'];

/** z: ilk basamağın konumu (tribün -z yönünde yükselir), width: genişlik, rows: basamak sayısı */
export function crowdStands(scene, { z = -10, width = 24, rows = 4, rowD = 1.1, rowH = 0.75, fanH = 1.25, density = 0.85, colors = [0xd62828, 0xf1faee, 0x1d3557], step = 0x8d99ae } = {}) {
  const g = new THREE.Group(); scene.add(g);
  for (let r = 0; r < rows; r++) {
    const s = new THREE.Mesh(new THREE.BoxGeometry(width + 4, rowH * (r + 1), rowD), mat(step, { roughness: 0.9 })); s.position.set(0, rowH * (r + 1) / 2, z - r * rowD); s.receiveShadow = true; g.add(s);
    const seat = new THREE.Mesh(new THREE.BoxGeometry(width + 4, 0.12, 0.4), mat(colors[r % colors.length])); seat.position.set(0, rowH * (r + 1) + 0.06, z - r * rowD + 0.2); g.add(seat);
  }
  const fans = [];
  for (let r = 0; r < rows; r++) for (let x = -width / 2; x <= width / 2; x += 1.1 + Math.random() * 0.7) {
    if (Math.random() > density) continue;
    const f = modelInto(g, FANS[(Math.random() * FANS.length) | 0], { height: fanH, anim: 'idle', pose: Math.random() * 2 });
    f.position.set(x + (Math.random() - 0.5) * 0.3, rowH * (r + 1), z - r * rowD + 0.05); f.userData.ph = Math.random() * 6; fans.push(f);
  }
  let cheerT = 0;
  return {
    group: g, fans,
    cheer(t = 2) { cheerT = t; fans.forEach((f) => f.userData.model?.userData.play('emote-yes', 0.1)); },
    update(dt) {
      if (cheerT <= 0) return;
      cheerT -= dt;
      fans.forEach((f) => { const c = f.children[0]; if (c) c.position.y = Math.max(0, Math.sin(cheerT * 9 + f.userData.ph)) * 0.35; f.userData.model?.userData.update(dt); });
      if (cheerT <= 0) fans.forEach((f) => { if (f.children[0]) f.children[0].position.y = 0; const m = f.userData.model?.userData; if (m) { m.play('idle', 0); m.update(0.3); } });
    },
  };
}
