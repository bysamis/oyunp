// Ortak 3D sahne yardımcısı (Three.js): bütün 3D oyunlar bunu kullanır
import * as THREE from 'three';

export { THREE };

export function mat(color, opts = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.5, metalness: 0.1, ...opts });
}

export function create3D(host, { fov = 55, bg = 0x87ceeb, fog = null, shadows = true, ortho = false, orthoSize = 10 } = {}) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.shadowMap.enabled = shadows;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  const el = renderer.domElement;
  el.className = 'stage'; el.style.touchAction = 'none';
  host.appendChild(el);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(bg);
  if (fog) scene.fog = new THREE.Fog(fog[0], fog[1], fog[2]);
  const camera = ortho ? new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 500) : new THREE.PerspectiveCamera(fov, 1, 0.1, 500);
  const hemi = new THREE.HemisphereLight(0xffffff, 0x556677, 1.0);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xffffff, 1.5);
  sun.position.set(-6, 14, 8); sun.castShadow = shadows;
  sun.shadow.mapSize.set(1024, 1024); sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.02;
  Object.assign(sun.shadow.camera, { left: -16, right: 16, top: 16, bottom: -16, near: 0.5, far: 60 });
  scene.add(sun); scene.add(sun.target);

  const S = { THREE, renderer, scene, camera, sun, hemi, el, w: 1, h: 1 };
  // test yardımı: ?debug ile dünya → ekran koordinatı
  if (typeof location !== 'undefined' && location.search.includes('debug')) {
    window.__S = S;
    window.__screen = (x, y, z) => { const v = new THREE.Vector3(x, y, z).project(camera), r = el.getBoundingClientRect(); return [r.left + (v.x + 1) / 2 * r.width, r.top + (1 - v.y) / 2 * r.height]; };
  }
  const resizers = [];
  S.onResize = (fn) => { resizers.push(fn); fn(S); };
  function resize() {
    const r = host.getBoundingClientRect();
    S.w = Math.max(1, r.width); S.h = Math.max(1, r.height);
    renderer.setSize(S.w, S.h);
    const a = S.w / S.h;
    if (ortho) {
      const sz = S.orthoSize || orthoSize;
      Object.assign(camera, { left: -sz * a, right: sz * a, top: sz, bottom: -sz });
    } else camera.aspect = a;
    camera.updateProjectionMatrix();
    resizers.forEach((fn) => fn(S));
  }
  const ro = new ResizeObserver(resize); ro.observe(host); resize();

  // ekran noktası → 3D düzlem kesişimi
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  S.ndc = (e) => { const r = el.getBoundingClientRect(); ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); return ndc; };
  S.rayPlaneY = (e, y = 0) => {
    ray.setFromCamera(S.ndc(e), camera);
    const p = new THREE.Vector3();
    return ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 1, 0), -y), p) ? p : null;
  };
  S.rayPlaneZ = (e, z = 0) => {
    ray.setFromCamera(S.ndc(e), camera);
    const p = new THREE.Vector3();
    return ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 0, 1), -z), p) ? p : null;
  };
  S.pick = (e, objects) => { ray.setFromCamera(S.ndc(e), camera); return ray.intersectObjects(objects, true)[0] || null; };

  // basit parçacıklar
  const partGeo = new THREE.BoxGeometry(0.18, 0.18, 0.18);
  let parts = [];
  S.burst = (pos, color, n = 12, power = 6, size = 1) => {
    const m = mat(color, { emissive: color, emissiveIntensity: 0.35 });
    for (let i = 0; i < n; i++) {
      const p = new THREE.Mesh(partGeo, m);
      p.position.copy(pos); p.scale.setScalar(size * (0.6 + Math.random() * 0.8));
      p.userData.v = new THREE.Vector3((Math.random() - 0.5) * power, Math.random() * power, (Math.random() - 0.5) * power);
      p.userData.life = 0.6 + Math.random() * 0.5;
      scene.add(p); parts.push(p);
    }
  };
  S.updateParts = (dt, floorY = 0) => {
    parts = parts.filter((p) => {
      p.userData.life -= dt;
      if (p.userData.life <= 0) { scene.remove(p); return false; }
      p.userData.v.y -= 18 * dt; p.position.addScaledVector(p.userData.v, dt);
      if (p.position.y < floorY + 0.1) { p.position.y = floorY + 0.1; p.userData.v.y *= -0.4; p.userData.v.x *= 0.7; p.userData.v.z *= 0.7; }
      p.rotation.x += dt * 6; p.rotation.y += dt * 4;
      p.scale.multiplyScalar(1 - dt * 0.6);
      return true;
    });
  };

  // yüzen yazı (+10 gibi) — DOM katmanı ile
  const label = document.createElement('div');
  label.style.cssText = 'position:absolute;inset:0;pointer-events:none;overflow:hidden';
  host.style.position = 'relative'; host.appendChild(label);
  S.popText = (pos3, text, color = '#fff') => {
    const v = pos3.clone().project(camera);
    const d = document.createElement('div');
    d.textContent = text;
    d.style.cssText = `position:absolute;left:${(v.x + 1) / 2 * S.w}px;top:${(1 - v.y) / 2 * S.h}px;transform:translate(-50%,-50%);color:${color};font:900 20px system-ui;text-shadow:0 2px 4px rgba(0,0,0,.5);transition:all .9s ease-out;opacity:1`;
    label.appendChild(d);
    requestAnimationFrame(() => { d.style.top = `${(1 - v.y) / 2 * S.h - 60}px`; d.style.opacity = '0'; });
    setTimeout(() => d.remove(), 950);
  };

  let raf = 0, last = 0, paused = false, alive = true;
  S.loop = (update) => {
    const frame = (t) => {
      if (!alive) return;
      raf = requestAnimationFrame(frame);
      const dt = last ? Math.min(0.05, (t - last) / 1000) : 0; last = t;
      if (paused) return;
      update(dt, t / 1000);
      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(frame);
    return { pause() { paused = true; }, resume() { paused = false; last = 0; } };
  };
  S.destroy = () => {
    alive = false; cancelAnimationFrame(raf); ro.disconnect();
    scene.traverse((o) => { o.geometry?.dispose(); if (o.material) [].concat(o.material).forEach((m) => m.dispose()); });
    renderer.dispose(); el.remove(); label.remove();
  };
  return S;
}
