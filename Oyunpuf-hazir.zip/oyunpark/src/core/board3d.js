// Tahta/ızgara oyunları için ortak 3D yardımcı: ızgara XZ düzleminde, (0,0) merkezde.
// Satır 0 ekranın üstü (uzak), sütun 0 solda. Kamera tahtayı ekrana sığacak şekilde ayarlanır.
import { THREE, mat } from './three-stage.js';

export function boardKit(S, cols, rows, { cell = 1, tilt = 0.32, pad = 0.04, height = 0.6, extraTop = 0, extraBottom = 0, yaw = 0 } = {}) {
  const { camera } = S;
  const K = { cols, rows, cell };
  K.x = (c) => (c - (cols - 1) / 2) * cell;
  K.z = (r) => (r - (rows - 1) / 2) * cell;
  K.pos = (c, r, y = 0) => new THREE.Vector3(K.x(c), y, K.z(r));
  K.cellAt = (e, y = 0) => {
    const p = S.rayPlaneY(e, y); if (!p) return null;
    const c = Math.round(p.x / cell + (cols - 1) / 2), r = Math.round(p.z / cell + (rows - 1) / 2);
    if (c < 0 || r < 0 || c >= cols || r >= rows) return null;
    return { c, r, p };
  };
  // tilt: 0 = tam tepeden, 0.5 ≈ 45°
  K.fit = () => {
    const hw = (cols * cell) / 2 + cell * 0.5, hd = (rows * cell) / 2 + cell * 0.5;
    const pts = [];
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) for (const y of [0, height]) pts.push(new THREE.Vector3(sx * hw, y, sz * hd + (sz < 0 ? -extraTop : extraBottom)));
    const dir = new THREE.Vector3(Math.sin(yaw) * Math.sin(tilt), Math.cos(tilt), Math.cos(yaw) * Math.sin(tilt)).normalize();
    const center = new THREE.Vector3(0, 0, (extraBottom - extraTop) / 2);
    let lo = 1, hi = 200;
    for (let i = 0; i < 30; i++) {
      const d = (lo + hi) / 2;
      camera.position.copy(center).addScaledVector(dir, d); camera.lookAt(center); camera.updateMatrixWorld(); camera.updateProjectionMatrix();
      const ok = pts.every((p) => { const v = p.clone().project(camera); return Math.abs(v.x) < 1 - pad && Math.abs(v.y) < 1 - pad && v.z < 1; });
      if (ok) hi = d; else lo = d;
    }
    camera.position.copy(center).addScaledVector(dir, hi); camera.lookAt(center);
    S.sun.position.set(-6, 18, 8); S.sun.target.position.copy(center);
    const m = Math.max(hw, hd) + 2;
    Object.assign(S.sun.shadow.camera, { left: -m, right: m, top: m, bottom: -m }); S.sun.shadow.camera.updateProjectionMatrix();
  };
  S.onResize(() => K.fit());
  return K;
}

// Yuvarlatılmış kutu (kare taşlar, karolar için)
export function roundedBox(w, h, d, r = 0.08, seg = 3) {
  const shape = new THREE.Shape();
  const x = -w / 2, y = -d / 2;
  shape.moveTo(x + r, y); shape.lineTo(x + w - r, y); shape.quadraticCurveTo(x + w, y, x + w, y + r);
  shape.lineTo(x + w, y + d - r); shape.quadraticCurveTo(x + w, y + d, x + w - r, y + d);
  shape.lineTo(x + r, y + d); shape.quadraticCurveTo(x, y + d, x, y + d - r);
  shape.lineTo(x, y + r); shape.quadraticCurveTo(x, y, x + r, y);
  const bev = Math.min(r, h / 2.5);
  const g = new THREE.ExtrudeGeometry(shape, { depth: h - bev * 2, bevelEnabled: true, bevelThickness: bev, bevelSize: bev * 0.6, bevelSegments: seg, curveSegments: 4 });
  g.rotateX(-Math.PI / 2); g.translate(0, bev, 0);
  return g; // taban y=0
}

// Basit 3D yazı: canvas dokulu düzlem (sayılar, harfler için)
const texCache = {};
export function textTexture(text, { color = '#fff', bg = null, font = '900 92px system-ui', size = 128 } = {}) {
  const key = [text, color, bg, font, size].join('|');
  if (texCache[key]) return texCache[key];
  const cv = document.createElement('canvas'); cv.width = cv.height = size;
  const c = cv.getContext('2d');
  if (bg) { c.fillStyle = bg; c.fillRect(0, 0, size, size); }
  c.fillStyle = color; c.font = font; c.textAlign = 'center'; c.textBaseline = 'middle';
  c.fillText(text, size / 2, size / 2 + size * 0.04);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return (texCache[key] = t);
}
export function textPlane(text, sizeU = 0.7, opts = {}) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(sizeU, sizeU), new THREE.MeshBasicMaterial({ map: textTexture(text, opts), transparent: true, depthWrite: false }));
  m.rotation.x = -Math.PI / 2;
  return m;
}
export { mat };
