// Uzaktan HTML5 mini oyunları güvenli bir kutuda (sandbox iframe) çalıştırır.
// - iframe "allow-scripts" ile ama "allow-same-origin" OLMADAN açılır: oyun uygulamanın verisine, coinlere,
//   satın alımlara erişemez.
// - İçine konan CSP ağ erişimini kapatır: oyun internete veri gönderemez (gizlilik, Apple 4.7.3).
// - Oyuna telefonun yerel özellikleri (titreşim, reklam, satın alma, kamera…) açılmaz (Apple 4.7.2);
//   yalnızca puan/HUD/ses mesajları gidip gelir. Coin miktarını oyun değil uygulama hesaplar.
import { gameHtml } from './remote.js';
import { SUPPORT_EMAIL } from '../config.js';

const SFX_OK = new Set(['tap', 'click', 'pop', 'coin', 'win', 'lose', 'wrong', 'bounce', 'brick', 'swap', 'crash', 'power', 'slide']);

// oyunun içine otomatik eklenen küçük SDK (oyun yapımcısı window.OyunPark'ı kullanır)
const SDK = `<script>(function(){var h={pause:[],resume:[],restart:[],continue:[]},ready,rp=new Promise(function(r){ready=r});
function send(m){parent.postMessage(Object.assign({__op:1},m),'*')}
window.addEventListener('message',function(e){var m=e.data||{};if(!m.__host)return;
 if(m.op==='init'){OyunPark.level=m.level;OyunPark.child=m.child;OyunPark.lang=m.lang;ready(OyunPark)}
 else if(h[m.op])h[m.op].forEach(function(f){try{f()}catch(_){}})});
window.OyunPark={level:1,child:false,lang:'tr',ready:function(){send({op:'ready'});return rp},
 onPause:function(f){h.pause.push(f)},onResume:function(f){h.resume.push(f)},onRestart:function(f){h.restart.push(f)},onContinue:function(f){h['continue'].push(f)},
 setHud:function(o){send({op:'hud',score:o&&o.score,extra:o&&o.extra})},sfx:function(n){send({op:'sfx',name:n})},
 gameOver:function(o){send({op:'over',score:o&&o.score,win:!!(o&&o.win),canContinue:!!(o&&o.canContinue)})}};})();<\/script>`;
const CSP = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; media-src data: blob:; font-src data:; connect-src 'none'">`;

function wrap(html) {
  const inject = CSP + SDK;
  if (/<head[^>]*>/i.test(html)) return html.replace(/<head[^>]*>/i, (m) => m + inject);
  return inject + html;
}

export function makeRemoteGame(meta) {
  return {
    id: meta.id, title: meta.title, emoji: meta.emoji, color: meta.color, desc: meta.desc,
    remote: true, age: meta.age, landscape: meta.landscape,
    target: (L) => Math.round(meta.targetBase * Math.pow(meta.targetGrowth, L - 1)),
    create(host, api) {
      const box = document.createElement('div'); box.className = 'webgame'; host.appendChild(box);
      const frame = document.createElement('iframe');
      frame.setAttribute('sandbox', 'allow-scripts');
      frame.setAttribute('referrerpolicy', 'no-referrer');
      frame.title = meta.title;
      box.appendChild(frame);
      const report = document.createElement('a');
      report.className = 'webgame-report'; report.textContent = '⚑ Bildir';
      report.href = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent('Oyunpuf oyun bildirimi: ' + meta.title)}&body=${encodeURIComponent('Oyun: ' + meta.id + ' (sürüm ' + meta.version + ')\nSorun: ')}`;
      box.appendChild(report);
      const post = (m) => frame.contentWindow?.postMessage({ __host: 1, ...m }, '*');
      let over = false;
      const onMsg = (e) => {
        if (e.source !== frame.contentWindow) return; // yalnızca kendi kutumuzdan gelen mesajlar
        const m = e.data; if (!m || !m.__op) return;
        if (m.op === 'ready') post({ op: 'init', level: api.level, child: !!api.child, lang: 'tr' });
        else if (m.op === 'hud') api.setHud({ score: Number.isFinite(+m.score) ? Math.max(0, Math.floor(+m.score)) : 0, extra: typeof m.extra === 'string' ? m.extra.slice(0, 60) : '' });
        else if (m.op === 'sfx' && SFX_OK.has(m.name)) api.sfx[m.name]?.();
        else if (m.op === 'over' && !over) {
          over = true;
          const score = Math.max(0, Math.min(1e9, Math.floor(+m.score || 0)));
          api.gameOver({ score, win: !!m.win, canContinue: !!m.canContinue, coins: Math.min(meta.coinCap, Math.floor(score / meta.coinDiv)) });
        }
      };
      window.addEventListener('message', onMsg);
      gameHtml(meta.id).then((html) => {
        if (!html) { box.innerHTML = '<div class="webgame-missing">Bu oyun henüz indirilmedi. İnternete bağlanınca otomatik iner.</div>'; return; }
        frame.srcdoc = wrap(html);
      });
      return {
        pause: () => post({ op: 'pause' }), resume: () => post({ op: 'resume' }),
        restart() { over = false; post({ op: 'restart' }); },
        continue() { over = false; post({ op: 'continue' }); },
        destroy() { window.removeEventListener('message', onMsg); box.remove(); },
      };
    },
  };
}
