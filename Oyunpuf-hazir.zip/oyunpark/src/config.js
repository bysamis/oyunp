// ==== YAYINLAMADAN ÖNCE BURAYI DOLDUR ====
// AdMob hesabındaki gerçek reklam birimi kimliklerini yaz ve TEST_ADS'i false yap.
// Şu an Google'ın resmi TEST kimlikleri kullanılıyor (gerçek gelir getirmez, hesabını riske atmaz).

export const TEST_ADS = false;

export const ADMOB = {
  android: {
    banner: 'ca-app-pub-9867581764768429/2444297446',
    interstitial: 'ca-app-pub-9867581764768429/4097511654',
    rewarded: 'ca-app-pub-9867581764768429/8626562410',
  },
  ios: {
    banner: 'ca-app-pub-9867581764768429/7198086201',
    interstitial: 'ca-app-pub-9867581764768429/1896436875',
    rewarded: 'ca-app-pub-9867581764768429/3140576641',
  },
};

// Geçiş reklamı sıklığı: her N oyun sonunda bir, en az şu kadar saniye arayla
export const INTERSTITIAL_EVERY = 3;        // (eski ayar, AD_POLICY.every ile aynı)
export const INTERSTITIAL_MIN_GAP_SEC = 90;
// Geçiş reklamı sıklığı: oyuncuyu kaçırmadan geliri korumak için kurallar (hepsi buradan ayarlanır)
export const AD_POLICY = {
  graceGames: 5,          // uygulamayı ilk kez açan oyuncu: ilk 5 oyun bitişinde hiç geçiş reklamı yok
  every: 3,               // normalde her 3 oyun bitişinde bir…
  minPlaySec: 150,        // …ve son reklamdan beri en az 2,5 dk oynanmışsa
  minGapSec: 90,          // iki geçiş reklamı arasında en az 90 sn
  newUserDays: 2,         // ilk 2 gün daha seyrek:
  newUserEvery: 4,
  newUserMinPlaySec: 240,
  childEvery: 4,          // 13 yaş altı: daha seyrek ve günlük sınır daha düşük
  childMinPlaySec: 240,
  childDailyCap: 6,
  dailyCap: 12,           // günde en fazla 12 geçiş reklamı
  afterRewardedSec: 180,  // ödüllü reklam izleyen oyuncuya 3 dk geçiş reklamı yok
  mpEvery: 3,             // arkadaşlarla oynarken: her 3 maçta bir (ekranı paylaşan gruba daha az reklam)
  vipNudgeAfter: 4,       // günün 4. reklamından sonra bir kez "reklamsız oyna" teklifi
};

// ==== VIP ABONELİK (tek ödeme yöntemi: App Store / Google Play) ====
// App Store Connect'te bir "Subscription Group" (ör. "Oyunpuf VIP"), Google Play Console'da bir abonelik oluştur.
// Ürün kimlikleri iki mağazada da AYNI olmalı. Deneme süresi / ilk hafta indirimi mağaza panelinden "intro offer" olarak tanımlanır.
export const VIP_PLANS = [
  { id: 'vip_weekly', period: 'week', days: 7, title: 'Haftalık', fallbackPrice: '₺49,99', per: '/ hafta' },
  { id: 'vip_monthly', period: 'month', days: 31, title: 'Aylık', fallbackPrice: '₺149,99', per: '/ ay', tag: 'Popüler' },
  { id: 'vip_yearly', period: 'year', days: 366, title: 'Yıllık', fallbackPrice: '₺999,99', per: '/ yıl', tag: '3 gün ücretsiz', best: true },
];
export const VIP_PERKS = [
  ['🚫', 'Hiç reklam yok', 'Banner ve geçiş reklamları kapanır'],
  ['🎁', 'Ödüller reklamsız', '2 kat coin, devam etme ve kasa reklam izlemeden'],
  ['🪙', 'Coinler 2 kat', 'Her oyunda iki kat coin'],
  ['🎡', 'Günde 3 bedava çark', 'Şans Çarkı her gün 3 kez'],
  ['👑', 'VIP görünümler', 'Altın araba ve gökkuşağı top'],
];
// Başlangıç teklifi: ilk açılıştan sonra bu kadar saat boyunca VIP bandı geri sayımla gösterilir
export const STARTER_OFFER_HOURS = 48;
export const TERMS_URL = 'https://bysamis.github.io/oyunp/kosullar.html';
export const PRIVACY_URL = 'https://bysamis.github.io/oyunp/gizlilik.html';

// ==== ŞANS ÇARKI ve BONUS KASASI ====
export const WHEEL_PRIZES = [10, 25, 15, 50, 20, 100, 30, 300]; // dilimler (coin)
export const WHEEL_WEIGHTS = [20, 14, 18, 7, 16, 3, 12, 1];      // olasılık ağırlıkları
export const WHEEL_AD_SPINS = 2;                                  // reklamla günlük ek çevirme
export const CHEST_RATE = 0.5;   // internetsizken kazanılan coinin bu kadarı ayrıca kasaya birikir
export const CHEST_MAX = 500;    // kasa üst sınırı

// ==== COIN EKONOMİSİ ====
// Oyunlardan kazanılan coin bu oranla çarpılır (1 = tam, 0.4 = %40). Kazancı hızlandırmak/yavaşlatmak için tek ayar.
export const COIN_RATE = 0.4;
export const LEVEL_UP_BONUS = (L) => 3 + L;      // seviye atlama bonusu
export const FREE_AD_COINS = 25;                  // "Bedava coin" reklamı
export const DAILY_REWARDS = [10, 15, 20, 25, 35, 50, 80];

// Bütün oyunlar ücretsiz ve açık. (Kilit eklemek istersen buraya { oyunId: { cond, coins, text } } yaz.)
export const GAME_UNLOCKS = {};

// ==== ONLINE (Firebase) ====
// Firebase konsolu → Project settings → Your apps → Web uygulaması → firebaseConfig nesnesini buraya yapıştır.
// Boş bırakılırsa online bölüm "deneme modunda" çalışır (aynı cihazda iki sekme arasında).
// Not: web apiKey gizli değildir (proje kimliğidir); güvenliği firestore.rules ve Anonymous Auth sağlar.
export const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyDVNvfIxrYha5w2FOvpW426hsMIYaOhN1k',
  authDomain: 'oyunpark-856da.firebaseapp.com',
  projectId: 'oyunpark-856da',
  storageBucket: 'oyunpark-856da.firebasestorage.app',
  messagingSenderId: '463595812610',
  appId: '1:463595812610:web:4634577d494c926f42f41b',
  measurementId: 'G-F1ZTC7GZJK',
};

// ---------- Uzaktan içerik (remote config) ----------
// remote/ klasörünü herhangi bir statik sunucuya yükleyin (GitHub Pages, Firebase Hosting, Netlify…)
// ve config.json adresini buraya yazın. null iken uygulama yalnızca içindeki içerikle çalışır.
export const REMOTE_CONFIG_URL = 'https://bysamis.github.io/oyunp/remote/config.json'; // örn. 'https://kullanici.github.io/oyunpark-icerik/config.json'
// tools/remote-keygen.mjs ile üretilen AÇIK anahtar (gizli anahtar asla uygulamaya konmaz).
// İmzası tutmayan yapılandırma reddedilir; böylece sunucu ele geçirilse bile uygulamaya içerik sokulamaz.
export const REMOTE_PUBLIC_KEY = {"kty":"EC","crv":"P-256","x":"DcvWUxx-QL73EdeLC8naoDkxQguuwNvPaJHh26otBBY","y":"YrpsO_BEP3jM7xGQKvdp1m7GP1bOdjkG1BJ4cP-F_sQ"};
export const APP_VERSION = '1.0.0';
export const SUPPORT_EMAIL = 'stzdijital@gmail.com'; // uzaktan oyun şikâyetleri buraya gelir

// Online takma adlar: serbest yazı yok (çocuk güvenliği). Ad = sıfat + hayvan + sayı (ör. "Neşeli Panda 482")
export const ONLINE_ADJ = ['Mavi','Hızlı','Neşeli','Uçan','Cesur','Minik','Parlak','Gizli','Turbo','Zıpzıp','Sarı','Kızıl','Yeşil','Mor','Altın','Süper','Neon','Usta','Çılgın','Kahraman','Şimşek','Bulut','Roket','Sevimli','Akıllı'];
export const ONLINE_ANIMALS = ['Kaplan','Tilki','Panda','Balina','Aslan','Ejder','Baykuş','Kaplumbağa','Tavşan','Arı','Şahin','Kurbağa','Ahtapot','Balık','Kedi','Köpek','Kuzu','Penguen','Sincap','Fil','Yunus','Fare','Zürafa','Koala','Papağan'];
