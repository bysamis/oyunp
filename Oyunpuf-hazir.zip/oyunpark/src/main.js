import './style.css';
import { store } from './core/store.js';
import { sfx, startMusic, stopMusic, unlockAudio } from './core/audio.js';
import { haptic, isNative, setOrientation } from './core/native.js';
import { ads } from './core/ads.js';
import { iap } from './core/iap.js';
import { GAME_UNLOCKS, COIN_RATE, LEVEL_UP_BONUS, FREE_AD_COINS, DAILY_REWARDS, VIP_PLANS, VIP_PERKS, STARTER_OFFER_HOURS, ONLINE_ADJ, ONLINE_ANIMALS, TERMS_URL, PRIVACY_URL, WHEEL_PRIZES, WHEEL_WEIGHTS, WHEEL_AD_SPINS, CHEST_RATE, CHEST_MAX } from './config.js';
import { analytics } from './core/analytics.js';
import { remote } from './core/remote.js';
import { makeRemoteGame } from './core/webgame.js';
import puzzle from './games/puzzle.js';
import breakout from './games/breakout3d.js';
import match3 from './games/match3_3d.js';
import { CAR_SKINS, drawCar } from './games/racer.js';
import { BALL_SKINS } from './games/breakout.js';
import racer from './games/racer3d.js';
import balloon from './games/balloon3d.js';
import rocket from './games/rocket3d.js';
import snake from './games/snake3d.js';
import memory from './games/memory3d.js';
import g2048 from './games/g2048_3d.js';
import mole from './games/mole3d.js';
import xox from './games/xox3d.js';
import stack from './games/stack3d.js';
import simon from './games/simon3d.js';
import jumper from './games/jumper3d.js';
import mines from './games/mines3d.js';
import colortap from './games/colortap3d.js';
import mathGame from './games/math.js';
import shooter from './games/shooter3d.js';
import catcher from './games/catcher3d.js';
import maze from './games/maze3d.js';
import reflex from './games/reflex3d.js';
import schulte from './games/schulte.js';
import dodge from './games/dodge3d.js';
import lights from './games/lights3d.js';
import blockfit from './games/blockfit3d.js';
import ballsort from './games/ballsort3d.js';
import connect4 from './games/connect4_3d.js';
import checkers from './games/checkers3d.js';
import pyramid from './games/pyramid.js';
import merge from './games/merge3d.js';
import hockey from './games/hockey3d.js';
import runner from './games/runner3d.js';
import helix from './games/helix3d.js';
import basket from './games/basket3d.js';
import penalty from './games/penalty3d.js';
import arrows from './games/arrows3d.js';
import ludo from './games/ludo3d.js';
import quicktap from './games/quicktap.js';
import tug from './games/tug.js';
import rps from './games/rps.js';
import battleship from './games/battleship.js';
import billiards from './games/billiards3d.js';
import voxel from './games/voxel3d.js';
import { preloadModels } from './core/assets.js';
import { net, normCode } from './online/net.js';
import { Share } from '@capacitor/share';

// Açık oyunlar önce, kilitliler açılma sırasıyla (toplam 36 oyun)
const GAMES = [
  runner, penalty, voxel, billiards, balloon, match3, blockfit, ballsort, breakout, memory, xox, snake, catcher, mathGame,
  stack, arrows, helix, basket, ludo, mole, simon, reflex, g2048, colortap, racer, connect4, jumper, merge, maze, pyramid, schulte, dodge, hockey, rocket, shooter, lights, checkers, mines, puzzle,
];
// Yalnızca çok kişilik bölümde görünen oyunlar
const MP_ONLY = [quicktap, tug];
// Yalnızca online bölümde görünen oyunlar
const ONLINE_ONLY = [rps, battleship];
const ALL_GAMES = [...GAMES, ...MP_ONLY, ...ONLINE_ONLY];
// ---------- uzaktan içerik: yeni HTML5 oyunlar, sıralama, gizleme, rozetler ----------
function syncRemoteGames() {
  for (const arr of [GAMES, ALL_GAMES]) for (let i = arr.length - 1; i >= 0; i--) if (arr[i].remote) arr.splice(i, 1);
  for (const meta of remote.games()) { const g = makeRemoteGame(meta); GAMES.push(g); ALL_GAMES.push(g); }
}
const userAge = () => { const y = store.get().birthYear; return y ? new Date().getFullYear() - y : 99; };
// Tek kişilik listesi: uzaktan gizlenenler çıkar, yaş sınırını aşan uzaktan oyunlar gösterilmez (Apple 4.7.5), sıralama uygulanır
function visibleGames() {
  const cat = remote.catalog(), age = userAge();
  const list = GAMES.filter((g) => !cat.hidden.includes(g.id) && !(g.remote && g.age > age));
  if (cat.order.length) { const pos = (g) => { const i = cat.order.indexOf(g.id.replace(/^r-/, '')); const j = cat.order.indexOf(g.id); return i >= 0 ? i : j >= 0 ? j : 999; }; list.sort((a, b) => pos(a) - pos(b)); }
  return list;
}
const badgeOf = (g) => { const b = remote.catalog().badges; return b[g.id] || b[g.id.replace(/^r-/, '')] || ''; };
const ONLINE_GAMES = () => ALL_GAMES.filter((g) => g.online);
const PLAYER_COLORS = ['#ef233c', '#3a86ff', '#2dc653', '#ffc300'];
const app = document.getElementById('app');
const $ = (sel, root = document) => root.querySelector(sel);
const esc = (s) => String(s).replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
const today = () => new Date().toISOString().slice(0, 10);
const DAILY = DAILY_REWARDS;
const CONTINUE_COST = 50;

let current = null; // { game, inst }

// ---------- Ortak UI ----------
function coinPill() {
  return `<button class="coin-pill" data-act="shop"><span class="coin-ico">🪙</span><span class="coin-val">${store.get().coins}</span><span class="coin-plus">+</span></button>`;
}
store.onChange((d) => document.querySelectorAll('.coin-val').forEach((el) => (el.textContent = d.coins)));

function modal(html, { cls = '', onClose, dismissable = true } = {}) {
  const el = document.createElement('div');
  el.className = 'modal-wrap';
  el.innerHTML = `<div class="modal ${cls}">${html}</div>`;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  const close = () => { el.classList.remove('show'); setTimeout(() => el.remove(), 200); onClose?.(); };
  if (dismissable) el.addEventListener('pointerdown', (e) => { if (e.target === el) close(); });
  el.close = close;
  return el;
}

function toast(msg) {
  const el = document.createElement('div');
  el.className = 'toast'; el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.classList.add('show'), 10);
  setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, 2200);
}

function coinRain(n) {
  sfx.coin();
  for (let i = 0; i < Math.min(n, 18); i++) {
    const c = document.createElement('div');
    c.className = 'coin-fly'; c.textContent = '🪙';
    c.style.left = 30 + Math.random() * 40 + '%';
    c.style.animationDelay = i * 0.04 + 's';
    document.body.appendChild(c);
    setTimeout(() => c.remove(), 1400);
  }
}

// Ebeveyn kapısı: çocuk kullanıcılarda satın alma ve dış bağlantılardan önce
function parentGate() {
  if (!store.isChild()) return Promise.resolve(true);
  return new Promise((resolve) => {
    const a = 3 + ((Math.random() * 7) | 0), b = 4 + ((Math.random() * 6) | 0);
    const m = modal(`
      <h2>Ebeveyn Onayı 👨‍👩‍👧</h2>
      <p class="muted">Devam etmek için bir yetişkin şu işlemi çözsün:</p>
      <div class="gate-q">${a} × ${b} = ?</div>
      <input class="gate-in" inputmode="numeric" maxlength="3" autocomplete="off" />
      <div class="row"><button class="btn ghost" data-x>Vazgeç</button><button class="btn" data-ok>Onayla</button></div>`,
      { onClose: () => resolve(false) });
    const inp = $('.gate-in', m);
    setTimeout(() => inp.focus(), 100);
    $('[data-x]', m).onclick = () => m.close();
    $('[data-ok]', m).onclick = () => {
      if (parseInt(inp.value, 10) === a * b) { resolve(true); m.remove(); }
      else { inp.value = ''; inp.classList.add('shake'); sfx.wrong(); setTimeout(() => inp.classList.remove('shake'), 400); }
    };
  });
}

// ---------- Yaş kapısı (ilk açılış, nötr) ----------
function ageGate() {
  const y = new Date().getFullYear();
  let opts = '<option value="" selected disabled>Yıl seç</option>';
  for (let i = y; i >= y - 90; i--) opts += `<option value="${i}">${i}</option>`;
  app.innerHTML = `
    <div class="screen age">
      <div class="logo big">Oyun<span>puf</span></div>
      <div class="card age-card">
        <h2>Hoş geldin! 👋</h2>
        <p>Sana uygun ayarları yapabilmemiz için doğum yılını seç.</p>
        <select class="age-sel">${opts}</select>
        <button class="btn wide" disabled data-go>Başla ▶</button>
      </div>
    </div>`;
  const sel = $('.age-sel'), go = $('[data-go]');
  sel.onchange = () => (go.disabled = !sel.value);
  go.onclick = async () => {
    unlockAudio(); sfx.tap();
    store.set({ birthYear: parseInt(sel.value, 10) });
    await boot();
  };
}

// ---------- Oyun kilitleri ----------
function isUnlocked(id) {
  const s = store.get();
  return !GAME_UNLOCKS[id] || s.allUnlocked || s.unlockedGames.includes(id);
}
function progressOf(id) {
  const u = GAME_UNLOCKS[id]; if (!u) return 1;
  const s = store.get(), c = u.cond;
  const cur = c.type === 'best' ? (s.best[c.game] || 0)
    : c.type === 'played' ? s.gamesPlayed
    : c.type === 'totalLevel' ? GAMES.reduce((a, g) => a + (s.levels[g.id] || 1) - 1, 0)
    : Object.values(s.best).reduce((a, b) => a + b, 0);
  return Math.min(1, cur / c.value);
}
// Şartı sağlanan oyunları aç; yeni açılanları döndür
function checkUnlocks() {
  const fresh = Object.keys(GAME_UNLOCKS).filter((id) => !isUnlocked(id) && progressOf(id) >= 1);
  if (fresh.length) store.set({ unlockedGames: [...store.get().unlockedGames, ...fresh] });
  return fresh;
}
function celebrateUnlock(ids) {
  ids.forEach((id, i) => setTimeout(() => {
    const g = GAMES.find((x) => x.id === id);
    sfx.win(); haptic('heavy');
    const m = modal(`<div class="go-emoji">${g.emoji}</div><h2>Yeni oyun açıldı!</h2>
      <p><b>${g.title}</b> artık oynanabilir 🎉</p>
      <div class="row"><button class="btn ghost" data-x>Sonra</button><button class="btn" data-play>Hemen oyna ▶</button></div>`);
    $('[data-x]', m).onclick = () => m.close();
    $('[data-play]', m).onclick = () => { m.remove(); current?.inst.destroy(); current = null; openGame(id); };
  }, i * 400));
}
function lockedDialog(id) {
  const g = GAMES.find((x) => x.id === id), u = GAME_UNLOCKS[id];
  const pct = Math.floor(progressOf(id) * 100);
  const m = modal(`
    <div class="go-emoji">🔒</div>
    <h2>${g.title}</h2>
    <p class="muted">Bu oyunu açmanın yolları:</p>
    <div class="unlock-goal"><b>🎯 ${u.text}</b><div class="bar"><i style="width:${pct}%"></i></div><small>%${pct} tamamlandı</small></div>
    <div class="col">
      <button class="btn wide gold" data-coins>🪙 ${u.coins} coin ile hemen aç</button>
      <button class="btn wide ghost" data-x>Kapat</button>
    </div>`);
  $('[data-x]', m).onclick = () => m.close();
  $('[data-coins]', m).onclick = () => {
    if (store.spendCoins(u.coins)) {
      store.set({ unlockedGames: [...store.get().unlockedGames, id] });
      m.remove(); coinRain(10); refreshMenu(); celebrateUnlock([id]);
    } else { sfx.wrong(); toast(`${u.coins - store.get().coins} coin daha lazım`); }
  };
}

// ---------- Açılış: tek / çok kişilik seçimi ----------
let mode = 'single';
let onLanding = false;
// o an hangi menü açıksa onu yeniler
function refreshMenu() { if (current) return; onLanding ? landing() : mode === 'multi' ? multiHome() : mode === 'online' ? onlineHome() : home(); }
function landing() {
  current = null; onLanding = true;
  const s = store.get();
  const dailyReady = s.lastDaily !== today();
  app.innerHTML = `
    <div class="screen landing">
      <header class="top">
        ${store.isVip() ? '<div class="vip-crown">👑 VIP</div>' : '<div></div>'}
        <div class="top-right">${coinPill()}<button class="icon-btn" data-act="settings" aria-label="Ayarlar">⚙️</button></div>
      </header>
      <div class="land-center">
        <div class="logo big">Oyun<span>puf</span></div>
        <p class="land-sub">${ALL_GAMES.length} oyun · nasıl oynamak istersin?</p>
        <button class="mode-btn single" data-mode="single"><span class="mode-ico">👤</span><span><b>Tek Kişilik</b><small>Kendi rekorlarını kır, seviye atla</small></span><span class="chev">›</span></button>
        <button class="mode-btn multi" data-mode="multi"><span class="mode-ico">👥</span><span><b>Çok Kişilik</b><small>2–4 kişi aynı telefonda</small></span><span class="chev">›</span></button>
        <button class="mode-btn online" data-mode="online"><span class="mode-ico">🌐</span><span><b>Arkadaşlarla Online</b><small>Oda kur, kodu paylaş, internetten oyna</small></span><span class="chev">›</span></button>
        <div class="extras">
          <button class="extra" data-act="wheel"><span>🎡</span><b>Şans Çarkı</b><small class="wheel-badge">${wheelLeftText()}</small></button>
          <button class="extra" data-act="chest"><span>🧰</span><b>Bonus Kasası</b><small>${s.chest > 0 ? `🪙 ${s.chest} birikti` : 'Boş'}</small></button>
        </div>
        ${(() => { const ev = remote.activeEvent(); return ev ? `<div class="event-chip">🎉 ${esc(ev.title)}${ev.coinMultiplier > 1 ? ` · ${ev.coinMultiplier}× coin` : ''}</div>` : ''; })()}
        ${remote.announcements().filter((a) => !(store.get().seenAnn || []).includes(a.id)).slice(0, 1).map((a) => `<button class="announce" data-ann="${a.id}" data-ann-game="${a.game || ''}"><span class="a-emo">${esc(a.emoji)}</span><span><b>${esc(a.title)}</b>${a.text ? `<small>${esc(a.text)}</small>` : ''}</span></button>`).join('')}
        ${dailyReady ? `<button class="daily small" data-act="daily"><span class="daily-ico">🎁</span><span><b>Günlük ödülün hazır!</b></span><span class="chev">›</span></button>` : ''}
        ${vipBand()}
      </div>
      <nav class="bottom-nav">
        <button data-act="garage"><span>🚗</span>Garaj</button>
        <button data-act="shop" class="accent"><span>👑</span>VIP</button>
        <button data-act="freecoins"><span>📺</span>Bedava Coin</button>
      </nav>
      <div class="banner-slot">${isNative ? '' : 'Banner reklam alanı (test)'}</div>
    </div>`;
  ads.showBanner();
  app.querySelectorAll('[data-mode]').forEach((b) => (b.onclick = () => {
    unlockAudio(); sfx.tap(); haptic();
    mode = b.dataset.mode; mode === 'multi' ? multiHome() : mode === 'online' ? onlineHome() : home();
  }));
  bindActs(app);
  startOfferTimer();
}
let offerTimer = 0;
function offerLeftMs() { return store.get().firstLaunch + STARTER_OFFER_HOURS * 3600e3 - Date.now(); }
function vipBand() {
  if (store.isVip()) return '';
  const left = offerLeftMs();
  return left > 0
    ? `<button class="vip-band offer" data-act="vip"><span>👑</span><span><b>Hoş geldin teklifi: VIP 3 gün ücretsiz</b><small>Kalan süre <span class="offer-left">${fmtLeft(left)}</span></small></span><span class="chev">›</span></button>`
    : `<button class="vip-band" data-act="vip"><span>👑</span><span><b>VIP ol</b><small>Reklamsız, coinler 2 kat, özel görünümler</small></span><span class="chev">›</span></button>`;
}
function fmtLeft(ms) { const s = Math.max(0, Math.floor(ms / 1000)); return `${String(Math.floor(s / 3600)).padStart(2, '0')}:${String(Math.floor((s % 3600) / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; }
function startOfferTimer() {
  clearInterval(offerTimer);
  offerTimer = setInterval(() => { const el = document.querySelector('.offer-left'); if (!el) return clearInterval(offerTimer); el.textContent = fmtLeft(offerLeftMs()); }, 1000);
}

// ---------- Çok kişilik menü ----------
const TURN_EXCLUDE = new Set(['xox', 'connect4', 'checkers', 'hockey', 'ludo', 'billiards', 'voxel']);
function multiHome() {
  current = null; mode = 'multi'; onLanding = false;
  const s = store.get();
  const n = s.mpPlayers;
  const fits = (g) => g.players && n >= g.players.min && n <= g.players.max && (!g.players.allowed || g.players.allowed.includes(n));
  const versus = ALL_GAMES.filter(fits);
  const turns = GAMES.filter((g) => !TURN_EXCLUDE.has(g.id) && isUnlocked(g.id));
  const lockedTurns = GAMES.filter((g) => !TURN_EXCLUDE.has(g.id) && !isUnlocked(g.id)).length;
  app.innerHTML = `
    <div class="screen home multi">
      <header class="top">
        <button class="icon-btn" data-back aria-label="Geri">‹</button>
        <div class="logo small">Çok Kişilik</div>
        <div class="top-right">${coinPill()}</div>
      </header>
      <div class="mp-setup">
        <div class="mp-label">Kaç kişi oynayacak?</div>
        <div class="mp-count">${[2, 3, 4].map((k) => `<button class="${k === n ? 'on' : ''}" data-n="${k}">${k}<small>kişi</small></button>`).join('')}</div>
        <div class="mp-names">${Array.from({ length: n }, (_, i) => `<label style="--pc:${PLAYER_COLORS[i]}"><i></i><input data-name="${i}" maxlength="12" value="${esc(s.mpNames[i] || 'Oyuncu ' + (i + 1))}" /></label>`).join('')}</div>
      </div>
      <h3 class="sec">⚔️ Karşı karşıya <small>${versus.length} oyun</small></h3>
      <div class="grid">${versus.map((g) => card(g, `<div class="gc-best">👥 ${g.players.allowed ? g.players.allowed.join(' / ') : g.players.min === g.players.max ? g.players.min : g.players.min + '–' + g.players.max} kişi</div>`, 'versus')).join('') || '<p class="muted">Bu oyuncu sayısı için karşılıklı oyun yok.</p>'}</div>
      <h3 class="sec">🔄 Sırayla oyna <small>en yüksek puan kazanır</small></h3>
      <div class="grid">${turns.map((g) => card(g, `<div class="gc-best">🔄 ${n} tur</div>`, 'turns')).join('')}</div>
      ${lockedTurns ? `<p class="muted center">🔒 ${lockedTurns} oyun daha tek kişilikte açıldıkça burada çıkar</p>` : ''}
      <div class="banner-slot">${isNative ? '' : 'Banner reklam alanı (test)'}</div>
    </div>`;
  ads.showBanner();
  $('[data-back]').onclick = () => { sfx.tap(); landing(); };
  app.querySelectorAll('[data-n]').forEach((b) => (b.onclick = () => { sfx.tap(); store.set({ mpPlayers: +b.dataset.n }); multiHome(); }));
  app.querySelectorAll('[data-name]').forEach((inp) => (inp.onchange = () => {
    const names = [...store.get().mpNames]; names[+inp.dataset.name] = inp.value.trim() || `Oyuncu ${+inp.dataset.name + 1}`; store.set({ mpNames: names });
  }));
  app.querySelectorAll('[data-game]').forEach((b) => (b.onclick = () => {
    unlockAudio(); sfx.tap(); haptic();
    const names = Array.from({ length: n }, (_, i) => store.get().mpNames[i] || `Oyuncu ${i + 1}`);
    openGame(b.dataset.game, { kind: b.dataset.kind, n, names });
  }));
  app.querySelector('.coin-pill').onclick = () => { sfx.tap(); shop(); };
}
function card(g, footer, kind) {
  return `<button class="game-card" data-game="${g.id}" data-kind="${kind}" style="--c:${g.color}">
    <div class="gc-emoji">${g.emoji}</div><div class="gc-title">${g.title}</div><div class="gc-desc">${g.desc}</div>${footer}</button>`;
}

// ---------- Ana menü (tek kişilik) ----------
function home() {
  current = null; mode = 'single'; onLanding = false;
  const s = store.get();
  const dailyReady = s.lastDaily !== today();
  app.innerHTML = `
    <div class="screen home">
      <header class="top">
        <button class="icon-btn" data-back aria-label="Geri">‹</button>
        <div class="logo small">Tek Kişilik</div>
        <div class="top-right">${coinPill()}<button class="icon-btn" data-act="settings" aria-label="Ayarlar">⚙️</button></div>
      </header>
      ${dailyReady ? `<button class="daily" data-act="daily"><span class="daily-ico">🎁</span><span><b>Günlük ödülün hazır!</b><small>${s.dailyStreak + 1 > 7 ? 7 : s.dailyStreak + 1}. gün · dokun ve al</small></span><span class="chev">›</span></button>` : ''}
      <div class="grid">
        ${visibleGames().map((g) => {
          const open = isUnlocked(g.id), u = GAME_UNLOCKS[g.id];
          return `
          <button class="game-card ${open ? '' : 'locked'}" data-game="${g.id}" style="--c:${g.color}">
            ${badgeOf(g) ? `<div class="gc-badge">${esc(badgeOf(g))}</div>` : ''}
            ${open ? '' : '<div class="lock-badge">🔒</div>'}
            <div class="gc-emoji">${g.emoji}</div>
            <div class="gc-title">${g.title}</div>
            <div class="gc-desc">${open ? g.desc : '🎯 ' + u.text}</div>
            ${open ? (g.sandbox ? '<div class="gc-best">🧱 Serbest inşa + görevler</div>' : `<div class="gc-best">🏆 ${s.best[g.id] || 0} · Sv.${s.levels[g.id] || 1}${expertBadge(g)}</div>`)
              : `<div class="bar"><i style="width:${Math.floor(progressOf(g.id) * 100)}%"></i></div><div class="gc-best">🪙 ${u.coins} ile aç</div>`}
          </button>`; }).join('')}
      </div>
      <nav class="bottom-nav">
        <button data-act="garage"><span>🚗</span>Garaj</button>
        <button data-act="shop" class="accent"><span>👑</span>VIP</button>
        <button data-act="freecoins"><span>📺</span>Bedava Coin</button>
      </nav>
      <div class="banner-slot">${isNative ? '' : 'Banner reklam alanı (test)'}</div>
    </div>`;
  ads.showBanner();
  $('[data-back]').onclick = () => { sfx.tap(); landing(); };
  app.querySelectorAll('[data-game]').forEach((b) => (b.onclick = () => {
    unlockAudio(); sfx.tap(); haptic();
    isUnlocked(b.dataset.game) ? openGame(b.dataset.game) : lockedDialog(b.dataset.game);
  }));
  bindActs(app);
}

function bindActs(root) {
  root.querySelectorAll('[data-act]').forEach((b) => (b.onclick = () => {
    unlockAudio(); sfx.tap();
    ({ shop, vip: shop, settings, garage, daily, freecoins: freeCoins, wheel, chest: openChest }[b.dataset.act])?.();
  }));  root.querySelectorAll('[data-ann]').forEach((b) => (b.onclick = () => {
    unlockAudio(); sfx.tap();
    store.set({ seenAnn: [...(store.get().seenAnn || []), b.dataset.ann].slice(-50) });
    const g = b.dataset.annGame && ALL_GAMES.find((x) => x.id === b.dataset.annGame || x.id === 'r-' + b.dataset.annGame);
    if (g) openGame(g.id); else b.remove();
  }));
}

// ---------- Oyun ekranı ----------
// uzman modu rozeti: oyunun normal zorluk tavanı geçildiyse 🔥
function expertBadge(g) { const L = store.get().levels[g.id] || 1; return g.expertFrom && L >= g.expertFrom ? '<span class="xp" title="Uzman modu">🔥</span>' : ''; }

function openGame(id, mp = null) {
  const game = ALL_GAMES.find((g) => g.id === id);
  // sırayla modunda oyun tek kişilik çalışır, oyuncular arka arkaya oynar
  const versus = mp && mp.kind === 'versus' ? mp : null;
  const turns = mp && mp.kind === 'turns' ? { ...mp, i: 0, scores: [] } : null;
  ads.hideBanner();
  // ekran yönü: her oyun kendi tercihini hatırlar (🔄 düğmesi)
  let orient = (store.get().orient || {})[game.id] || (game.landscape ? 'landscape' : 'portrait');
  app.innerHTML = `
    <div class="screen play ${orient === 'landscape' ? 'landscape' : ''} ${game.sandbox ? 'overlay-hud' : ''}" style="--c:${game.color}">
      <header class="hud">
        <button class="icon-btn" data-pause aria-label="Duraklat">⏸</button>
        <button class="icon-btn rot-btn" data-rot aria-label="Ekranı çevir" title="Yan çevir">🔄</button>
        ${mp?.online ? `<div class="hud-lvl">🌐<b>${mp.n}</b></div>` : turns ? `<div class="hud-lvl turn" style="--pc:${PLAYER_COLORS[0]}">Sıra<b class="turn-name">${esc(turns.names[0])}</b></div>` : versus ? `<div class="hud-lvl">👥<b>${versus.n}</b></div>` : `<div class="hud-lvl">Sv.<b>${store.get().levels[game.id] || 1}</b>${expertBadge(game)}</div>`}
        <div class="hud-mid">
          <div class="hud-score"><small class="hud-label">Puan</small><b class="hud-val">0</b></div>
          <div class="hud-extra"></div>
        </div>
        ${coinPill()}
      </header>
      <div class="stage-host"></div>
      <div class="rotate-hint"><div class="rot-ico">📱</div><b>Telefonunu yan çevir</b><small>Yatay ekran seçildi — telefonu çevirince oyun genişler</small><button class="btn small" data-rot-ok>Böyle devam et</button></div>
    </div>`;
  const applyOrient = () => {
    $('.screen.play').classList.toggle('landscape', orient === 'landscape');
    $('.screen.play').classList.remove('hint-off');
    setOrientation(orient);
    // tuval yeni boyuta uysun
    setTimeout(() => window.dispatchEvent(new Event('resize')), 60);
    setTimeout(() => window.dispatchEvent(new Event('resize')), 400);
  };
  applyOrient();
  $('[data-rot-ok]').onclick = () => $('.screen.play').classList.add('hint-off');
  $('[data-rot]').onclick = () => {
    sfx.tap(); haptic();
    orient = orient === 'landscape' ? 'portrait' : 'landscape';
    store.set({ orient: { ...(store.get().orient || {}), [game.id]: orient } });
    applyOrient();
    toast(orient === 'landscape' ? '↔️ Yatay ekran' : '↕️ Dikey ekran');
  };
  const host = $('.stage-host');
  const api = {
    sfx, haptic,
    get level() { return store.get().levels[game.id] || 1; },
    get child() { return store.isChild(); },
    mp: versus,
    setHud({ score, scoreLabel, extra }) {
      $('.hud-val') && ($('.hud-val').textContent = score);
      if (scoreLabel && $('.hud-label')) $('.hud-label').textContent = scoreLabel;
      if (extra !== undefined && $('.hud-extra')) $('.hud-extra').textContent = extra;
    },
    gameOver: (r) => (versus ? onVersusOver(game, r) : turns ? onTurnOver(game, r) : onGameOver(game, r)),
  };
  // DOM yerleşsin, sonra canvas boyutu doğru ölçülsün
  requestAnimationFrame(() => {
    const inst = game.create(host, api);
    current = { game, inst, continued: false, mp, turns };
    // reklam sıklığı için gerçek oynama süresi: duraklatınca saat durur
    { const p = inst.pause.bind(inst), r = inst.resume.bind(inst); inst.pause = () => { ads.gameStopped(); p(); }; inst.resume = () => { ads.gameStarted(); r(); }; }
    ads.gameStarted();
  });
  $('[data-pause]').onclick = () => { sfx.tap(); pause(); };
  app.querySelector('.coin-pill').onclick = () => { sfx.tap(); pause(); };
}

function pause() {
  if (!current) return;
  current.inst.pause();
  const m = modal(`
    <h2>Duraklatıldı</h2>
    <div class="col">
      <button class="btn wide" data-r>▶ Devam et</button>
      <button class="btn wide ghost" data-again>↻ Baştan başla</button>
      <button class="btn wide ghost" data-home>🏠 Ana menü</button>
    </div>`, { onClose: () => current?.inst.resume() });
  $('[data-r]', m).onclick = () => m.close();
  $('[data-again]', m).onclick = () => { current.inst.restart(); current.continued = false; m.close(); };
  $('[data-home]', m).onclick = () => { m.remove(); leaveGame(); };
}

function leaveGame() {
  ads.gameStopped();
  setOrientation('portrait');
  const wasMp = !!current?.mp, wasOnline = !!current?.mp?.online;
  if (wasOnline) current.mp.room.leave();
  current?.inst.destroy();
  current = null;
  wasOnline ? onlineHome() : wasMp || mode === 'multi' ? multiHome() : home();
}

// ---------- Arkadaşlarla Online ----------
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const newOnlineName = () => `${pick(ONLINE_ADJ)} ${pick(ONLINE_ANIMALS)} ${100 + Math.floor(Math.random() * 900)}`;
// yalnızca listeden üretilmiş adlar gösterilir; başka her şey "Oyuncu" olur
function validName(n) {
  const m = /^(\S+) (\S+) (\d{3})$/.exec(n || '');
  return !!m && ONLINE_ADJ.includes(m[1]) && ONLINE_ANIMALS.includes(m[2]);
}
function myOnlineName() {
  let n = store.get().onlineName;
  if (!validName(n)) { n = newOnlineName(); store.set({ onlineName: n }); }
  return n;
}
const safeName = (n) => (validName(n) ? n : 'Oyuncu');
function onlineHome() {
  current = null; mode = 'online'; onLanding = false;
  const games = ONLINE_GAMES();
  app.innerHTML = `
    <div class="screen home online">
      <header class="top">
        <button class="icon-btn" data-back aria-label="Geri">‹</button>
        <div class="logo small">Online</div>
        <div class="top-right">${coinPill()}</div>
      </header>
      <div class="mp-setup">
        <div class="mp-label">Oyuncu adın</div>
        <div class="mp-names one"><label style="--pc:#3a86ff"><i></i><span data-oname-txt>${esc(myOnlineName())}</span><button class="btn ghost small" data-oname aria-label="Adı değiştir">🔄</button></label></div>
        <button class="btn wide join-btn" data-join>🔑 Arkadaşımın odasına katıl</button>
        ${net.configured() ? '' : '<p class="demo-note">🧪 Deneme modu: Firebase bağlanınca internetten çalışır. Şimdilik aynı telefonda iki sekmeyle denenebilir.</p>'}
      </div>
      <h3 class="sec">➕ Oda kur <small>oyunu seç, kodu arkadaşına gönder</small></h3>
      <div class="grid">${games.map((g) => card(g, `<div class="gc-best">🌐 ${g.online.min === g.online.max ? g.online.min : g.online.min + '–' + g.online.max} kişi</div>`, 'online')).join('')}</div>
      <div class="banner-slot">${isNative ? '' : 'Banner reklam alanı (test)'}</div>
    </div>`;
  ads.showBanner();
  $('[data-back]').onclick = () => { sfx.tap(); landing(); };
  $('[data-oname]').onclick = () => { sfx.tap(); const n = newOnlineName(); store.set({ onlineName: n }); $('[data-oname-txt]').textContent = n; };
  $('[data-join]').onclick = () => { sfx.tap(); joinDialog(); };
  app.querySelectorAll('[data-game]').forEach((b) => (b.onclick = () => { unlockAudio(); sfx.tap(); createRoom(b.dataset.game); }));
  app.querySelector('.coin-pill').onclick = () => { sfx.tap(); shop(); };
}
function needInternet() {
  if (net.configured() && navigator.onLine === false) { toast('Online oyun için internet bağlantısı gerekli 📶'); return true; }
  return false;
}
async function createRoom(gameId) {
  if (needInternet()) return;
  const g = ALL_GAMES.find((x) => x.id === gameId);
  try {
    const t = await net.get();
    const room = await t.createRoom({ game: gameId, name: myOnlineName(), minPlayers: g.online.min, maxPlayers: g.online.max });
    lobby(room, gameId);
  } catch (e) { toast(e.message || 'Oda kurulamadı'); }
}
function joinDialog(prefill = '') {
  const m = modal(`
    <h2>Odaya katıl 🔑</h2>
    <p class="muted">Arkadaşının gönderdiği 5 harfli kodu yaz</p>
    <input class="gate-in code-in" maxlength="5" autocapitalize="characters" autocomplete="off" placeholder="ABCDE" value="${esc(prefill)}" />
    <div class="row"><button class="btn ghost" data-x>Vazgeç</button><button class="btn" data-ok>Katıl</button></div>`);
  const inp = $('.code-in', m); setTimeout(() => inp.focus(), 100);
  inp.oninput = () => (inp.value = normCode(inp.value));
  $('[data-x]', m).onclick = () => m.close();
  $('[data-ok]', m).onclick = async () => {
    const code = normCode(inp.value);
    if (code.length !== 5) { inp.classList.add('shake'); setTimeout(() => inp.classList.remove('shake'), 400); return; }
    if (needInternet()) return;
    try { const t = await net.get(); const room = await t.joinRoom(code, myOnlineName()); m.remove(); lobby(room); }
    catch (e) { toast(e.message || 'Katılınamadı'); sfx.wrong(); }
  };
}
let lobbyOff = null;
function lobby(room, gameId) {
  current = null;
  const g = ALL_GAMES.find((x) => x.id === (room.game || gameId));
  if (!g) { room.leave(); toast('Oyun bulunamadı, uygulamayı güncelle'); onlineHome(); return; }
  app.innerHTML = `
    <div class="screen home lobby" style="--c:${g.color}">
      <header class="top"><button class="icon-btn" data-back aria-label="Çık">‹</button><div class="logo small">${g.emoji} ${g.title}</div><div></div></header>
      <div class="lobby-card">
        <div class="mp-label">Oda kodu</div>
        <div class="room-code">${room.code}</div>
        <button class="btn wide gold" data-share>📤 Arkadaşına gönder</button>
        <div class="mp-label" style="margin-top:14px">Oyuncular <span class="lobby-count"></span></div>
        <div class="turn-list lobby-list"></div>
        <p class="muted lobby-hint"></p>
        <button class="btn wide" data-start hidden>▶ Oyunu başlat</button>
      </div>
    </div>`;
  const render = (meta) => {
    if (!meta) return;
    if (meta.status === 'closed') { toast('Oda kapatıldı'); lobbyOff?.(); onlineHome(); return; }
    $('.lobby-count').textContent = `(${meta.players.length}/${meta.maxPlayers})`;
    $('.lobby-list').innerHTML = meta.players.map((p, i) => `<div style="--pc:${PLAYER_COLORS[i]}"><i></i><span>${esc(safeName(p.name))}${p.uid === room.uid ? ' (sen)' : ''}</span><b>${i === 0 ? '👑 kurucu' : '✓'}</b></div>`).join('')
      + Array.from({ length: meta.maxPlayers - meta.players.length }, () => '<div class="empty"><i></i><span>Bekleniyor…</span><b>⏳</b></div>').join('');
    const enough = meta.players.length >= meta.minPlayers;
    const st = $('[data-start]');
    st.hidden = !room.isHost; st.disabled = !enough;
    $('.lobby-hint').textContent = room.isHost ? (enough ? (meta.maxPlayers > meta.minPlayers ? 'Herkes geldiyse başlat' : 'Başlatılıyor…') : 'Arkadaşının katılmasını bekle') : 'Kurucunun oyunu başlatması bekleniyor…';
    // 2 kişilik oyunlarda oda dolunca otomatik başla
    if (room.isHost && meta.status === 'waiting' && meta.players.length === meta.maxPlayers && meta.maxPlayers === meta.minPlayers) room.start();
    if (meta.status === 'playing') { lobbyOff?.(); startOnline(room); }
  };
  lobbyOff = room.onUpdate(render);
  $('[data-back]').onclick = () => { lobbyOff?.(); room.leave(); onlineHome(); };
  $('[data-start]').onclick = () => { sfx.tap(); room.start(); };
  $('[data-share]').onclick = async () => {
    const text = `Oyunpuf'ta benimle ${g.title} oyna! 🎮 Uygulamayı aç → Arkadaşlarla Online → Odaya katıl → Kod: ${room.code}`;
    try { await Share.share({ title: 'Oyunpuf', text, dialogTitle: 'Arkadaşına gönder' }); }
    catch { try { await navigator.clipboard.writeText(text); toast('Davet kopyalandı 📋'); } catch { toast('Kod: ' + room.code); } }
  };
}
// Oyunu başlat: mesajlar "nesil" (gen) numarasıyla etiketlenir; rövanşta gen artar, eski hamleler yok sayılır
function startOnline(room) {
  let gen = 0, handler = null; const pending = [];
  const names = room.players.map((p) => safeName(p.name));
  const online = {
    me: room.me,
    send: (m) => room.send({ g: gen, m }),
    on: (cb) => { handler = cb; while (pending.length) cb(pending.shift()); },
    rematch: () => { gen++; room.send({ sys: 'restart', g: gen }); current.inst.restart(); },
  };
  const off = room.onMessage(({ from, data }) => {
    if (data.sys === 'leave') { off(); leftDialog(safeName(data.name)); return; }
    if (data.sys === 'restart') { if (data.g > gen) { gen = data.g; document.querySelectorAll('.modal-wrap').forEach((x) => x.remove()); toast('Rövanş! 🔁'); current?.inst.restart(); } return; }
    if (data.g !== gen) return;
    const msg = data.m && typeof data.m === 'object' ? { ...data.m, from } : data.m;
    handler ? handler(msg) : pending.push(msg);
  });
  online.room = room;
  openGame(room.game, { kind: 'versus', online, room, n: names.length, names });
}
function leftDialog(name) {
  if (!current) return;
  current.inst.pause();
  document.querySelectorAll('.modal-wrap').forEach((x) => x.remove());
  const m = modal(`<div class="go-emoji">👋</div><h2>${esc(name || 'Rakip')} oyundan ayrıldı</h2><button class="btn wide" data-home>Online menüye dön</button>`, { dismissable: false });
  $('[data-home]', m).onclick = () => { m.remove(); leaveGame(); };
}

// ---------- Çok kişilik sonuçlar ----------
function onVersusOver(game, r) {
  ads.gameStopped();
  const names = current.mp.names;
  const draw = r.winner === -1 || r.winner === undefined;
  if (!draw) { sfx.win(); haptic('heavy'); }
  store.set({ gamesPlayed: store.get().gamesPlayed + 1 });
  const color = draw ? '#6c757d' : PLAYER_COLORS[r.winner];
  const m = modal(`
    <div class="go-emoji">${draw ? '🤝' : '🏆'}</div>
    <h2>${esc(r.title || (draw ? 'Berabere!' : `${names[r.winner]} kazandı!`))}</h2>
    <div class="winner-chip" style="--pc:${color}">${draw ? 'Kimse kazanamadı' : esc(names[r.winner])}</div>
    <div class="col"><div class="row"><button class="btn ghost" data-home>🏠 Menü</button><button class="btn" data-again>↻ Rövanş</button></div></div>`, { dismissable: false, cls: 'go' });
  $('[data-again]', m).onclick = async () => {
    m.remove(); await ads.maybeInterstitial({ multiplayer: true });
    if (current.mp.online) current.mp.online.rematch(); else current.inst.restart();
  };
  $('[data-home]', m).onclick = async () => { m.remove(); await ads.maybeInterstitial({ multiplayer: true }); leaveGame(); };
}
function onTurnOver(game, r) {
  ads.gameStopped();
  const tr = current.turns;
  tr.scores[tr.i] = r.score || 0;
  store.set({ gamesPlayed: store.get().gamesPlayed + 1 });
  const next = tr.i + 1;
  if (next < tr.n) {
    sfx.coin();
    const m = modal(`
      <div class="go-emoji">${game.emoji}</div>
      <h2>${esc(tr.names[tr.i])}: ${tr.scores[tr.i]} puan</h2>
      <div class="turn-list">${tr.names.map((nm, i) => `<div style="--pc:${PLAYER_COLORS[i]}"><i></i><span>${esc(nm)}</span><b>${i < next ? tr.scores[i] : i === next ? '▶ sıradaki' : '…'}</b></div>`).join('')}</div>
      <p class="muted">Telefonu <b>${esc(tr.names[next])}</b> oyuncusuna ver</p>
      <button class="btn wide" data-go style="background:${PLAYER_COLORS[next]}">${esc(tr.names[next])} hazır ▶</button>`, { dismissable: false, cls: 'go' });
    $('[data-go]', m).onclick = () => {
      m.remove(); tr.i = next;
      const el = $('.turn-name'); if (el) el.textContent = tr.names[next];
      const box = $('.hud-lvl.turn'); if (box) box.style.setProperty('--pc', PLAYER_COLORS[next]);
      current.inst.restart();
    };
    return;
  }
  // herkes oynadı → sıralama
  sfx.win(); haptic('heavy');
  const order = tr.names.map((nm, i) => ({ nm, i, s: tr.scores[i] })).sort((a, b) => b.s - a.s);
  const tie = order.length > 1 && order[0].s === order[1].s;
  const medals = ['🥇', '🥈', '🥉', '4.'];
  const m = modal(`
    <div class="go-emoji">🏆</div>
    <h2>${tie ? 'Berabere!' : `${esc(order[0].nm)} kazandı!`}</h2>
    <div class="turn-list rank">${order.map((o, k) => `<div style="--pc:${PLAYER_COLORS[o.i]}"><span class="medal">${medals[k]}</span><span>${esc(o.nm)}</span><b>${o.s}</b></div>`).join('')}</div>
    <div class="col"><div class="row"><button class="btn ghost" data-home>🏠 Menü</button><button class="btn" data-again>↻ Yeniden</button></div></div>`, { dismissable: false, cls: 'go' });
  $('[data-again]', m).onclick = async () => {
    m.remove(); await ads.maybeInterstitial({ multiplayer: true });
    tr.i = 0; tr.scores = [];
    const el = $('.turn-name'); if (el) el.textContent = tr.names[0];
    const box = $('.hud-lvl.turn'); if (box) box.style.setProperty('--pc', PLAYER_COLORS[0]);
    current.inst.restart();
  };
  $('[data-home]', m).onclick = async () => { m.remove(); await ads.maybeInterstitial({ multiplayer: true }); leaveGame(); };
}

async function onGameOver(game, r) {
  ads.gameStopped();
  const { isBest, best } = store.submitScore(game.id, r.score);
  // coin kazancı merkezi orandan geçer (config.js → COIN_RATE)
  let earned = r.coins > 0 ? Math.max(1, Math.floor(r.coins * remote.coinRate(COIN_RATE) * remote.coinMultiplier())) : 0; // uzaktan ayarlanabilir oran + etkinlik çarpanı
  // Zorluk seviyesi: hedefi geçen bir sonraki (daha zor) seviyeye geçer
  const L = store.get().levels[game.id] || 1;
  const levelUp = game.winBased ? !!r.win : r.score >= game.target(L);
  if (levelUp) store.set({ levels: { ...store.get().levels, [game.id]: L + 1 } });
  const lvlHtml = levelUp
    ? `<div class="lvl-up">⬆️ Seviye ${L + 1} açıldı! Oyun artık daha zor 🔥</div>`
    : `<div class="lvl-goal">Seviye ${L} · ${game.winBased ? 'Seviye atlamak için kazan' : `Sonraki seviye için <b>${game.target(L)}</b> puan`}</div>`;
  if (levelUp) earned += LEVEL_UP_BONUS(L);
  if (store.isVip()) earned *= 2; // VIP: coinler 2 kat
  // internetsizken kazanılanın bir kısmı ayrıca Bonus Kasası'na birikir (internet gelince reklamla açılır)
  let toChest = 0;
  if (!ads.online() && !store.isVip() && earned > 0) {
    toChest = Math.min(CHEST_MAX - store.get().chest, Math.ceil(earned * CHEST_RATE));
    if (toChest > 0) store.set({ chest: store.get().chest + toChest });
  }
  analytics.track('game_end', { game: game.id, score: r.score, level: L, level_up: levelUp ? 1 : 0, online: ads.online() ? 1 : 0 });
  store.addCoins(earned);
  if (earned > 0) coinRain(earned);
  const canCont = r.canContinue && !current.continued;
  const fresh = checkUnlocks();
  if (fresh.length) setTimeout(() => celebrateUnlock(fresh), 1200);
  const m = modal(`
    <div class="go-emoji">${r.win ? '🏆' : isBest ? '🌟' : game.emoji}</div>
    <h2>${esc(r.title || 'Oyun bitti!')}</h2>
    ${isBest ? '<div class="badge">YENİ REKOR!</div>' : ''}
    ${lvlHtml}
    ${toChest > 0 ? `<div class="chest-note">🧰 +${toChest} coin Bonus Kasası'na eklendi (internet gelince aç)</div>` : ''}
    <div class="go-stats">
      <div><small>Puan</small><b>${r.score}</b></div>
      <div><small>En iyi</small><b>${best}</b></div>
      <div><small>Kazanılan</small><b class="go-earned">🪙 ${earned}</b></div>
    </div>
    <div class="col">
      ${earned > 0 ? `<button class="btn wide gold" data-double>${store.isVip() ? '👑 Coinleri 2 katına çıkar' : '📺 Reklam izle → coinleri 2 katına çıkar'}</button>` : ''}
      ${canCont ? `<div class="row"><button class="btn" data-cont-ad>📺 Devam et</button><button class="btn ghost" data-cont-coin>🪙 ${CONTINUE_COST} ile devam</button></div>` : ''}
      <div class="row"><button class="btn ghost" data-home>🏠 Menü</button><button class="btn" data-again>${esc(r.againLabel || '↻ Tekrar oyna')}</button></div>
    </div>`, { dismissable: false, cls: 'go' });

  const doubleBtn = $('[data-double]', m);
  if (doubleBtn) doubleBtn.onclick = async () => {
    doubleBtn.disabled = true;
    if (await ads.rewarded()) {
      store.addCoins(earned); coinRain(earned); earned *= 2;
      $('.go-earned', m).textContent = '🪙 ' + earned;
      doubleBtn.textContent = '✓ 2 katı alındı!';
    } else { doubleBtn.disabled = false; toast('Reklam yüklenemedi, sonra tekrar dene'); }
  };
  const resume = () => { current.continued = true; m.remove(); current.inst.continue(); };
  const ca = $('[data-cont-ad]', m);
  if (ca) ca.onclick = async () => { ca.disabled = true; if (await ads.rewarded()) resume(); else { ca.disabled = false; toast('Reklam yüklenemedi'); } };
  const cc = $('[data-cont-coin]', m);
  if (cc) cc.onclick = () => { if (store.spendCoins(CONTINUE_COST)) { sfx.coin(); resume(); } else { toast('Yeterli coin yok'); sfx.wrong(); } };
  $('[data-again]', m).onclick = async () => {
    m.remove(); await ads.maybeInterstitial();
    current.continued = false; current.inst.restart();
    const lv = $('.hud-lvl b'); if (lv) lv.textContent = store.get().levels[game.id] || 1;
    const hl = $('.hud-lvl'); if (hl && expertBadge(game) && !hl.querySelector('.xp')) hl.insertAdjacentHTML('beforeend', expertBadge(game));
  };
  $('[data-home]', m).onclick = async () => { m.remove(); await ads.maybeInterstitial(); leaveGame(); };
}

// ---------- VIP (abonelik) ekranı ----------
function shop() {
  current?.inst.pause();
  const vip = store.isVip();
  let sel = VIP_PLANS.find((p) => p.best)?.id || VIP_PLANS[0].id;
  const m = modal(`
    <div class="vip-head"><div class="vip-big">👑</div><h2>Oyunpuf VIP</h2>${vip ? `<div class="badge ok">Aktif · ${new Date(Math.max(store.get().vipUntil, Date.now())).toLocaleDateString('tr-TR')} tarihine kadar</div>` : ''}</div>
    <div class="perks">${VIP_PERKS.map(([i, t, d]) => `<div><span>${i}</span><b>${t}</b><small>${d}</small></div>`).join('')}</div>
    ${vip ? '' : `<div class="plans">${VIP_PLANS.map((p) => `<button class="plan ${p.id === sel ? 'on' : ''}" data-plan="${p.id}">${p.tag ? `<span class="ribbon">${p.tag}</span>` : ''}<b>${p.title}</b><span class="pp">${iap.price(p.id)}</span><small>${p.per}</small></button>`).join('')}</div>
    <button class="btn wide gold" data-buy>👑 VIP ol</button>`}
    <button class="shop-item free" data-free><span class="si-ico">📺</span><span class="si-txt"><b>Bedava ${FREE_AD_COINS} coin</b><small>${vip ? 'VIP: reklamsız' : 'Kısa bir reklam izle'}</small></span><span class="si-price">Ücretsiz</span></button>
    <p class="legal">Abonelik, dönem bitmeden en az 24 saat önce iptal edilmezse aynı ücretle otomatik yenilenir. Ödeme, onayınla App Store / Google Play hesabından alınır. Deneme süresi varsa, bitiminde ücretlendirme başlar. Aboneliğini mağaza hesap ayarlarından istediğin zaman yönetebilir ya da iptal edebilirsin.
    <br><a href="${TERMS_URL}" target="_blank">Kullanım Koşulları</a> · <a href="${PRIVACY_URL}" target="_blank">Gizlilik Politikası</a></p>
    <div class="row"><button class="btn ghost small" data-restore>Satın alımları geri yükle</button>${vip ? '<button class="btn ghost small" data-manage>Aboneliği yönet</button>' : ''}<button class="btn small" data-x>Kapat</button></div>`,
    { onClose: () => current?.inst.resume(), cls: 'tall vip-modal' });
  analytics.track('vip_view');
  $('[data-x]', m).onclick = () => m.close();
  $('[data-free]', m).onclick = () => freeCoins();
  $('[data-restore]', m).onclick = async () => { const ok = await iap.restore(); toast(ok ? 'VIP aboneliğin geri yüklendi 👑' : 'Aktif abonelik bulunamadı'); };
  const mg = $('[data-manage]', m); if (mg) mg.onclick = () => iap.manage();
  m.querySelectorAll('[data-plan]').forEach((b) => (b.onclick = () => {
    sel = b.dataset.plan; sfx.tap();
    m.querySelectorAll('[data-plan]').forEach((x) => x.classList.toggle('on', x === b));
  }));
  const buy = $('[data-buy]', m);
  if (buy) buy.onclick = async () => {
    if (!(await parentGate())) return;
    buy.disabled = true; analytics.track('vip_buy_tap', { plan: sel });
    const ok = await iap.buy(sel);
    if (!ok) { buy.disabled = false; toast('Satın alma tamamlanmadı'); }
  };
}

iap.onChange((isVip) => {
  if (!isVip) { refreshMenu(); return; }
  analytics.track('vip_active');
  coinRain(20); sfx.win(); toast('👑 VIP oldun — iyi eğlenceler!');
  ads.hideBanner();
  // VIP görünümleri hediye
  const s = store.get();
  store.set({ ownedSkins: [...new Set([...s.ownedSkins, 'gold'])], ownedBalls: [...new Set([...s.ownedBalls, 'rainbow'])] });
  document.querySelectorAll('.modal-wrap').forEach((m) => m.remove());
  if (!current) refreshMenu(); else current.inst.resume();
});
// Uygulama açılışında da kontrol et (ör. güncelleme sonrası)
setTimeout(() => { const f = checkUnlocks(); if (f.length && !current) { refreshMenu(); celebrateUnlock(f); } }, 500);

// ---------- Şans Çarkı ----------
function wheelState() {
  const s = store.get();
  if (s.wheelDay !== today()) { store.set({ wheelDay: today(), wheelFree: 0, wheelAd: 0 }); }
  const st = store.get(), freeMax = store.isVip() ? 3 : 1;
  return { free: Math.max(0, freeMax - st.wheelFree), ad: store.isVip() ? 0 : Math.max(0, WHEEL_AD_SPINS - st.wheelAd) };
}
function wheelLeftText() { const w = wheelState(); return w.free ? `${w.free} bedava çevirme` : w.ad ? `📺 ${w.ad} çevirme` : 'Yarın tekrar'; }
function wheel() {
  const n = WHEEL_PRIZES.length, cols = ['#ff4d6d', '#ffd60a', '#3a86ff', '#2dc653', '#ff9f1c', '#9d4edd', '#06d6a0', '#ef233c'];
  const m = modal(`
    <h2>Şans Çarkı 🎡</h2>
    <div class="wheel-wrap"><canvas class="wheel" width="560" height="560"></canvas><div class="wheel-pin">▼</div></div>
    <div class="col"><button class="btn wide gold" data-spin></button><button class="btn wide ghost" data-x>Kapat</button></div>`, { onClose: () => refreshMenu() });
  const cv = $('.wheel', m), c = cv.getContext('2d');
  let ang = 0, spinning = false;
  function draw() {
    const R = 270; c.clearRect(0, 0, 560, 560); c.save(); c.translate(280, 280); c.rotate(ang);
    for (let i = 0; i < n; i++) {
      const a0 = (i / n) * Math.PI * 2 - Math.PI / 2 - Math.PI / n, a1 = a0 + (Math.PI * 2) / n;
      c.fillStyle = cols[i % cols.length]; c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, R, a0, a1); c.fill();
      c.strokeStyle = '#fff'; c.lineWidth = 4; c.stroke();
      c.save(); c.rotate((a0 + a1) / 2); c.fillStyle = '#fff'; c.font = '900 40px system-ui'; c.textAlign = 'right'; c.textBaseline = 'middle';
      c.fillText(WHEEL_PRIZES[i] === 300 ? '💎300' : '🪙' + WHEEL_PRIZES[i], R - 20, 0); c.restore();
    }
    c.fillStyle = '#fff'; c.beginPath(); c.arc(0, 0, 44, 0, 7); c.fill(); c.fillStyle = '#241654'; c.font = '900 26px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('ÇEVİR', 0, 2);
    c.restore();
  }
  const btn = $('[data-spin]', m);
  function label() { const w = wheelState(); btn.disabled = !w.free && !w.ad; btn.textContent = w.free ? `🎡 Çevir (${w.free} bedava)` : w.ad ? `📺 Reklam izle → çevir (${w.ad})` : 'Bugünlük bitti, yarın gel'; }
  btn.onclick = async () => {
    if (spinning) return;
    const w = wheelState();
    if (w.free) store.set({ wheelFree: store.get().wheelFree + 1 });
    else if (w.ad) { if (!(await ads.rewarded())) { toast('Reklam yüklenemedi — internet bağlantını kontrol et'); return; } store.set({ wheelAd: store.get().wheelAd + 1 }); }
    else return;
    // ağırlıklı rastgele ödül
    let r = Math.random() * WHEEL_WEIGHTS.reduce((a, b) => a + b, 0), idx = 0;
    for (let i = 0; i < n; i++) { r -= WHEEL_WEIGHTS[i]; if (r <= 0) { idx = i; break; } }
    const target = -(idx / n) * Math.PI * 2 + Math.PI * 2 * 6, start = ang % (Math.PI * 2), t0 = performance.now(), dur = 3200;
    spinning = true; btn.disabled = true; analytics.track('wheel_spin');
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      ang = start + (target - start) * e; draw();
      if (Math.floor(e * 40) !== Math.floor((e - 0.001) * 40)) sfx.click();
      if (k < 1) requestAnimationFrame(step);
      else { spinning = false; const prize = WHEEL_PRIZES[idx]; store.addCoins(prize); coinRain(prize); sfx.win(); toast(`🎉 ${prize} coin kazandın!`); label(); }
    };
    requestAnimationFrame(step);
  };
  $('[data-x]', m).onclick = () => m.close();
  draw(); label();
}

// ---------- Bonus Kasası ----------
function openChest() {
  const amt = store.get().chest;
  const m = modal(`
    <div class="go-emoji">🧰</div><h2>Bonus Kasası</h2>
    ${amt > 0 ? `<p>İnternetsiz oynarken kasanda <b>🪙 ${amt}</b> coin birikti.</p>` : '<p class="muted">Kasan boş. İnternetsiz oynadığında kazandığın coinlerin yarısı burada ayrıca birikir.</p>'}
    <div class="col">${amt > 0 ? `<button class="btn wide gold" data-open>${store.isVip() ? '👑 Kasayı aç' : '📺 Reklam izle → kasayı aç'}</button>` : ''}<button class="btn wide ghost" data-x>Kapat</button></div>`, { onClose: () => refreshMenu() });
  $('[data-x]', m).onclick = () => m.close();
  const o = $('[data-open]', m);
  if (o) o.onclick = async () => {
    o.disabled = true;
    if (await ads.rewarded()) { store.set({ chest: 0 }); store.addCoins(amt); coinRain(amt); sfx.win(); toast(`+${amt} coin! 🧰`); analytics.track('chest_open', { amount: amt }); m.close(); }
    else { o.disabled = false; toast('Kasayı açmak için internete bağlan'); }
  };
}

async function freeCoins() {
  if (await ads.rewarded()) { store.addCoins(FREE_AD_COINS); coinRain(FREE_AD_COINS); toast(`+${FREE_AD_COINS} coin! 🪙`); }
  else toast('Şu an reklam yok, biraz sonra dene');
}

// ---------- Günlük ödül ----------
function daily() {
  const s = store.get();
  if (s.lastDaily === today()) return;
  const yesterday = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
  const streak = s.lastDaily === yesterday ? Math.min(s.dailyStreak + 1, 7) : 1;
  const amount = DAILY[streak - 1];
  const m = modal(`
    <h2>Günlük Ödül 🎁</h2>
    <div class="daily-row">${DAILY.map((v, i) => `<div class="dd ${i < streak - 1 ? 'got' : i === streak - 1 ? 'now' : ''}"><small>${i + 1}. gün</small><b>${v}</b></div>`).join('')}</div>
    <p class="muted">Her gün gel, ödülün büyüsün!</p>
    <div class="col">
      <button class="btn wide gold" data-ad>📺 Reklam izle → ${amount * 2} coin</button>
      <button class="btn wide ghost" data-take>${amount} coin al</button>
    </div>`);
  const claim = (n) => { store.set({ lastDaily: today(), dailyStreak: streak }); store.addCoins(n); coinRain(n); m.remove(); refreshMenu(); };
  $('[data-take]', m).onclick = () => claim(amount);
  $('[data-ad]', m).onclick = async () => { if (await ads.rewarded()) claim(amount * 2); else claim(amount); };
}

// ---------- Garaj (görünümler) ----------
function garage() {
  const render = () => {
    const s = store.get();
    const cars = Object.entries(CAR_SKINS).map(([k, v]) => {
      const owned = s.ownedSkins.includes(k), on = s.carSkin === k;
      const vipOnly = k === 'gold' && !owned;
      return `<button class="skin ${on ? 'on' : ''}" data-car="${k}"><canvas width="80" height="110" data-draw="${v.color}"></canvas>
        <b>${v.name}</b><small>${on ? 'Seçili' : owned ? 'Seç' : vipOnly ? '👑 VIP özel' : `🪙 ${v.price}`}</small></button>`;
    }).join('');
    const balls = Object.entries(BALL_SKINS).map(([k, v]) => {
      const owned = s.ownedBalls.includes(k), on = s.ballSkin === k;
      const bg = v.color === 'rainbow' ? 'conic-gradient(red,orange,yellow,lime,cyan,blue,magenta,red)' : v.color;
      return `<button class="skin ball ${on ? 'on' : ''}" data-ball="${k}"><i style="background:${bg}"></i>
        <b>${v.name}</b><small>${on ? 'Seçili' : owned ? 'Seç' : k === 'rainbow' ? '👑 VIP özel' : `🪙 ${v.price}`}</small></button>`;
    }).join('');
    return `<h2>Garaj 🚗</h2><div class="garage-coins">${coinPill()}</div>
      <h3>Arabalar</h3><div class="skins">${cars}</div>
      <h3>Toplar (Blok Kırma)</h3><div class="skins">${balls}</div>
      <button class="btn wide" data-x>Kapat</button>`;
  };
  const m = modal(render(), { cls: 'tall' });
  const paint = () => {
    m.querySelectorAll('canvas[data-draw]').forEach((cv) => {
      const c = cv.getContext('2d'); c.clearRect(0, 0, 80, 110);
      drawCar(c, 40, 55, 44, 80, cv.dataset.draw, { stripe: true });
    });
  };
  const bind = () => {
    paint();
    $('[data-x]', m).onclick = () => m.close();
    $('.coin-pill', m).onclick = () => { m.remove(); shop(); };
    m.querySelectorAll('[data-car]').forEach((b) => (b.onclick = () => buySkin('car', b.dataset.car)));
    m.querySelectorAll('[data-ball]').forEach((b) => (b.onclick = () => buySkin('ball', b.dataset.ball)));
  };
  const buySkin = (kind, k) => {
    const s = store.get();
    const owned = kind === 'car' ? s.ownedSkins : s.ownedBalls;
    const def = (kind === 'car' ? CAR_SKINS : BALL_SKINS)[k];
    const vipSkin = (kind === 'car' && k === 'gold') || (kind === 'ball' && k === 'rainbow');
    if (owned.includes(k)) { store.set(kind === 'car' ? { carSkin: k } : { ballSkin: k }); sfx.tap(); }
    else if (vipSkin) {
      if (!store.isVip()) { m.remove(); toast('Bu görünüm VIP üyelere özel 👑'); shop(); return; }
      store.set(kind === 'car' ? { ownedSkins: [...owned, k], carSkin: k } : { ownedBalls: [...owned, k], ballSkin: k }); sfx.win();
    }
    else if (store.spendCoins(def.price)) {
      sfx.win(); haptic('medium');
      store.set(kind === 'car' ? { ownedSkins: [...owned, k], carSkin: k } : { ownedBalls: [...owned, k], ballSkin: k });
      toast(`${def.name} açıldı! 🎉`);
    } else { sfx.wrong(); toast(`${def.price - s.coins} coin daha lazım`); return; }
    $('.modal', m).innerHTML = render(); bind();
  };
  bind();
}

// ---------- Ayarlar ----------
function settings() {
  const s = store.get();
  const tg = (k, label) => `<label class="toggle"><span>${label}</span><input type="checkbox" data-k="${k}" ${s[k] ? 'checked' : ''}/><i></i></label>`;
  const m = modal(`
    <h2>Ayarlar ⚙️</h2>
    ${tg('sound', '🔊 Ses efektleri')}${tg('music', '🎵 Müzik')}${tg('haptics', '📳 Titreşim')}${tg('touchControls', '🎮 Ekran düğmeleri (gaz, fren, yön)')}
    <div class="col">
      <button class="btn ghost wide" data-vip>${store.isVip() ? '👑 VIP aboneliğim' : '👑 VIP ol'}</button>
      <button class="btn ghost wide" data-restore>Satın alımları geri yükle</button>
      ${store.isVip() ? '<button class="btn ghost wide" data-manage>Aboneliği yönet / iptal et</button>' : ''}
      <button class="btn ghost wide" data-privacy>Gizlilik politikası</button>
      <details class="credits" style="font-size:11px;color:#888;text-align:center;margin:6px 0 0"><summary style="cursor:pointer">🎨 Asset kredileri</summary>
        <p style="margin:6px 0 0;line-height:1.5">3D modeller ve dokular:<br>
        <b>Kenney</b> (kenney.nl) — Starter Kits: MIT lisansı<br>
        <b>Kenney</b> — Blocky Characters, Voxel Pack, Graveyard Kit, Mini Arena: CC0<br>
        <b>Kay Lousberg / KayKit</b> (kaylousberg.com) — Fantasy Weapons: CC0<br>
        Teşekkürler!</p></details>
      <button class="btn ghost wide danger" data-reset>İlerlemeyi sıfırla</button>
      <button class="btn wide" data-x>Kapat</button>
    </div>
    <p class="muted tiny">Oyunpuf v1.0.0</p>`);
  m.querySelectorAll('[data-k]').forEach((inp) => (inp.onchange = () => {
    store.set({ [inp.dataset.k]: inp.checked });
    if (inp.dataset.k === 'music') inp.checked ? startMusic() : stopMusic();
  }));
  $('[data-x]', m).onclick = () => m.close();
  $('[data-restore]', m).onclick = async () => { const ok = await iap.restore(); toast(ok ? 'VIP aboneliğin geri yüklendi 👑' : 'Aktif abonelik bulunamadı'); };
  $('[data-vip]', m).onclick = () => { m.remove(); shop(); };
  const mg = $('[data-manage]', m); if (mg) mg.onclick = async () => { if (await parentGate()) iap.manage(); };
  $('[data-privacy]', m).onclick = async () => {
    if (await parentGate()) window.open(PRIVACY_URL, '_blank');
  };
  $('[data-reset]', m).onclick = () => {
    if (confirm('Tüm coinler, rekorlar ve görünümler silinsin mi? (Satın alımlar geri yüklenebilir)')) {
      const keep = { vipUntil: store.get().vipUntil, vipOwned: store.get().vipOwned, birthYear: store.get().birthYear, firstLaunch: store.get().firstLaunch };
      store.reset(); store.set(keep); m.remove(); landing();
    }
  };
}

// ---------- Uygulama yaşam döngüsü ----------
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { current?.inst.pause(); stopMusic(); }
  else { startMusic(); if (current && !document.querySelector('.modal-wrap')) pause(); }
});

let booted = false;
async function boot() {
  if (!booted) {
    booted = true;
    syncRemoteGames();
    remote.onChange(() => { syncRemoteGames(); if (!current) refreshMenu(); if (remote.needsUpdate()) updatePrompt(); });
    remote.init();
    // internet gelince yapılandırmayı tazele
    window.addEventListener('online', () => remote.refresh());
    // derin bağlantı: ?game=oyun-id (uzaktan oyun dizini bağlantıları için)
    const deep = new URLSearchParams(location.search).get('game');
    if (deep) setTimeout(() => { const g = ALL_GAMES.find((x) => x.id === deep || x.id === 'r-' + deep); if (g) openGame(g.id); }, 600);
    setOrientation('portrait');
    if (!store.get().firstLaunch) store.set({ firstLaunch: Date.now() });
    ads.init(); iap.init(); analytics.init();
    setTimeout(() => preloadModels(), 1200); analytics.track('app_open', { vip: store.isVip() ? 1 : 0 });
    document.addEventListener('pointerdown', function first() { unlockAudio(); startMusic(); document.removeEventListener('pointerdown', first); }, { once: true });
  }
  landing();
}

// uzaktan "en az şu sürüm olmalı" ayarı: eski sürümdekilere güncelleme isteği
let updateShown = false;
function updatePrompt() {
  if (updateShown) return; updateShown = true;
  const url = remote.config?.updateUrl || (isNative ? '' : '');
  const m = modal(`<div class="go-emoji">⬆️</div><h2>Yeni sürüm hazır!</h2><p class="muted">Yeni oyunlar ve düzeltmeler için Oyunpuf'u güncelle.</p>
    <div class="col">${url ? `<a class="btn" href="${esc(url)}" target="_blank" rel="noopener">Güncelle</a>` : ''}<button class="btn ghost" data-x>Sonra</button></div>`, { cls: 'go' });
  $('[data-x]', m).onclick = () => m.remove();
}

// günün birkaç reklamından sonra bir kez nazik reklamsız teklifi
window.addEventListener('oyunpark:vip-nudge', () => {
  const m = modal(`<div class="go-emoji">👑</div><h2>Reklamsız oynamak ister misin?</h2><p class="muted">VIP ile reklam yok, ödüller anında ve coinler 2 kat.</p>
    <div class="col"><button class="btn" data-vip>VIP'e göz at</button><button class="btn ghost" data-x>Şimdi değil</button></div>`, { cls: 'go' });
  $('[data-vip]', m).onclick = () => { m.remove(); shop(); };
  $('[data-x]', m).onclick = () => m.remove();
});

if (!store.get().birthYear) ageGate();
else boot();
window.__splashDone?.();
