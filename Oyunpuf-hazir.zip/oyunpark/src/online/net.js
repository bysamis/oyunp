// Online oda sistemi. İki taşıyıcı var:
//  - firebase: gerçek internet (config.js → FIREBASE_CONFIG doluysa)
//  - local:    deneme modu — aynı cihazda iki tarayıcı sekmesi arasında çalışır (Firebase bağlanana kadar test için)
// Oyunlar yalnızca Room arayüzünü görür: send(data), onMessage(cb), onUpdate(cb), start(), leave()
import { FIREBASE_CONFIG } from '../config.js';

const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const makeCode = () => Array.from({ length: 5 }, () => ALPHA[(Math.random() * ALPHA.length) | 0]).join('');
export const normCode = (s) => (s || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 5);

class Room {
  constructor(code, uid) {
    this.code = code; this.uid = uid; this.meta = null;
    this._upd = new Set(); this._msg = new Set(); this._unsubs = [];
  }
  get players() { return this.meta?.players || []; }
  get me() { return this.players.findIndex((p) => p.uid === this.uid); }
  get isHost() { return this.meta?.host === this.uid; }
  get status() { return this.meta?.status; }
  get game() { return this.meta?.game; }
  onUpdate(fn) { this._upd.add(fn); if (this.meta) fn(this.meta); return () => this._upd.delete(fn); }
  onMessage(fn) { this._msg.add(fn); return () => this._msg.delete(fn); }
  _emitMeta(meta) { this.meta = meta; this._upd.forEach((f) => f(meta)); }
  _emitMsg(m) { this._msg.forEach((f) => f(m)); }
}

// ---------------- Deneme taşıyıcısı (BroadcastChannel) ----------------
// Oda bilgisini kurucunun sekmesi tutar; katılma isteği kurucuya gider, kurucu listeyi günceller ve herkese yayar.
function localTransport() {
  const uid = sessionStorage.getItem('op_uid') || (() => { const u = 'u' + Math.random().toString(36).slice(2, 10); sessionStorage.setItem('op_uid', u); return u; })();
  const ch = new BroadcastChannel('oyunpark-online');
  const rooms = new Map();      // katıldığım odalar
  const hosted = new Map();     // kurduğum odaların asıl bilgisi
  const waiters = new Map();    // katılma cevabı bekleyenler
  const publish = (code) => { const meta = hosted.get(code); ch.postMessage({ t: 'meta', code, meta }); rooms.get(code)?._emitMeta(structuredClone(meta)); };
  ch.onmessage = ({ data }) => {
    const { code } = data;
    if (data.t === 'join' && hosted.has(code)) {
      const m = hosted.get(code);
      let err = null;
      if (!m.players.some((p) => p.uid === data.uid)) {
        if (m.status !== 'waiting') err = 'Bu odada oyun başlamış';
        else if (m.players.length >= m.maxPlayers) err = 'Oda dolu';
        else m.players.push({ uid: data.uid, name: data.name });
      }
      ch.postMessage({ t: 'joinRes', code, uid: data.uid, err, meta: m });
      if (!err) publish(code);
      return;
    }
    if (data.t === 'start' && hosted.has(code)) { hosted.get(code).status = 'playing'; publish(code); return; }
    if (data.t === 'joinRes' && data.uid === uid) { waiters.get(code)?.(data); return; }
    const r = rooms.get(code); if (!r) return;
    if (data.t === 'meta') r._emitMeta(data.meta);
    if (data.t === 'msg' && data.uid !== uid) r._emitMsg({ from: data.from, data: data.data });
  };
  function wrap(code, meta) {
    const r = new Room(code, uid);
    r.send = (data) => ch.postMessage({ t: 'msg', code, uid, from: r.me, data });
    r.start = () => { if (hosted.has(code)) { hosted.get(code).status = 'playing'; publish(code); } else ch.postMessage({ t: 'start', code }); };
    r.leave = () => {
      try { r.send({ sys: 'leave', name: r.players[r.me]?.name }); } catch {}
      if (hosted.has(code) && hosted.get(code).status === 'waiting') { hosted.get(code).status = 'closed'; publish(code); }
      rooms.delete(code);
    };
    rooms.set(code, r); r._emitMeta(meta);
    return r;
  }
  return {
    mode: 'local', uid,
    async createRoom({ game, name, minPlayers, maxPlayers }) {
      const code = makeCode();
      hosted.set(code, { game, host: uid, status: 'waiting', minPlayers, maxPlayers, players: [{ uid, name }], createdAt: Date.now() });
      return wrap(code, structuredClone(hosted.get(code)));
    },
    joinRoom(code, name) {
      return new Promise((resolve, reject) => {
        const t = setTimeout(() => { waiters.delete(code); reject(new Error('Oda bulunamadı')); }, 2500);
        waiters.set(code, (res) => { clearTimeout(t); waiters.delete(code); res.err ? reject(new Error(res.err)) : resolve(wrap(code, res.meta)); });
        ch.postMessage({ t: 'join', code, uid, name });
      });
    },
  };
}

// ---------------- Firebase taşıyıcısı (Firestore + anonim giriş) ----------------
async function firebaseTransport() {
  const [{ initializeApp, getApps }, { getAuth, signInAnonymously, onAuthStateChanged }, fs] = await Promise.all([
    import('firebase/app'), import('firebase/auth'), import('firebase/firestore'),
  ]);
  const { getFirestore, doc, onSnapshot, collection, addDoc, runTransaction, serverTimestamp, Timestamp, query, orderBy, updateDoc } = fs;
  const app = getApps()[0] || initializeApp(FIREBASE_CONFIG); // Analytics önce başlatmış olabilir
  const auth = getAuth(app);
  const db = getFirestore(app);
  const user = await new Promise((resolve, reject) => {
    const off = onAuthStateChanged(auth, (u) => { if (u) { off(); resolve(u); } });
    signInAnonymously(auth).catch(reject);
  });
  const uid = user.uid;

  async function wrap(code) {
    const r = new Room(code, uid);
    const ref = doc(db, 'rooms', code);
    const msgs = collection(db, 'rooms', code, 'msgs');
    r._unsubs.push(onSnapshot(ref, (snap) => snap.exists() && r._emitMeta(snap.data())));
    // yalnızca katıldıktan sonra gelen mesajlar işlenir
    const since = Timestamp.now();
    r._unsubs.push(onSnapshot(query(msgs, orderBy('at')), (snap) => {
      snap.docChanges().forEach((ch) => {
        if (ch.type !== 'added') return;
        const m = ch.doc.data();
        if (m.uid === uid || !m.at || m.at.toMillis() < since.toMillis() - 2000) return;
        r._emitMsg({ from: m.from, data: m.data });
      });
    }));
    r.send = (data) => addDoc(msgs, { uid, from: r.me, data, at: serverTimestamp() }).catch((e) => console.warn('send', e));
    r.start = () => updateDoc(ref, { status: 'playing' });
    r.leave = () => {
      try { r.send({ sys: 'leave', name: r.players[r.me]?.name }); } catch {}
      if (r.isHost && r.status === 'waiting') updateDoc(ref, { status: 'closed' }).catch(() => {});
      r._unsubs.forEach((u) => u());
    };
    // oda bilgisi (ilk anlık görüntü) gelmeden lobiye geçme: yoksa oyun adı boş kalır
    if (!r.meta) {
      await new Promise((resolve, reject) => {
        const t = setTimeout(() => { off(); reject(new Error('Oda bilgisi alınamadı, tekrar dene')); }, 10000);
        const off = r.onUpdate(() => { clearTimeout(t); off(); resolve(); });
      });
    }
    return r;
  }
  return {
    mode: 'firebase', uid,
    async createRoom({ game, name, minPlayers, maxPlayers }) {
      for (let attempt = 0; attempt < 5; attempt++) {
        const code = makeCode(), ref = doc(db, 'rooms', code);
        const ok = await runTransaction(db, async (tx) => {
          const s = await tx.get(ref);
          if (s.exists() && s.data().status !== 'closed') return false;
          tx.set(ref, {
            game, host: uid, status: 'waiting', minPlayers, maxPlayers,
            players: [{ uid, name }], uids: [uid],
            createdAt: serverTimestamp(), expireAt: Timestamp.fromMillis(Date.now() + 6 * 3600e3), // TTL ile otomatik silinir
          });
          return true;
        });
        if (ok) return wrap(code);
      }
      throw new Error('Oda kurulamadı, tekrar dene');
    },
    async joinRoom(code, name) {
      const ref = doc(db, 'rooms', code);
      await runTransaction(db, async (tx) => {
        const s = await tx.get(ref);
        if (!s.exists() || s.data().status === 'closed') throw new Error('Oda bulunamadı');
        const m = s.data();
        if (m.uids.includes(uid)) return;
        if (m.status !== 'waiting') throw new Error('Bu odada oyun başlamış');
        if (m.players.length >= m.maxPlayers) throw new Error('Oda dolu');
        tx.update(ref, { players: [...m.players, { uid, name }], uids: [...m.uids, uid] });
      });
      return wrap(code);
    },
  };
}

let transport = null;
export const net = {
  configured: () => !!(FIREBASE_CONFIG && FIREBASE_CONFIG.apiKey),
  async get() {
    if (!transport) transport = this.configured() ? await firebaseTransport() : localTransport();
    return transport;
  },
};
