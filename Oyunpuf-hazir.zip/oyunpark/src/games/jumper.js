// 🐸 Zıpla Zıpla: platformlardan zıplayarak yüksel (ekranın sağına/soluna basılı tut)
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

export default {
  id: 'jumper', title: 'Zıpla Zıpla', emoji: '🐸', color: '#80b918',
  desc: 'Platformlarda zıpla, en yükseğe çık!',
  target: (L) => Math.round(1500 * Math.pow(1.4, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let p, plats, camY, maxH, score, over, hold, L, coinsGot;
    const S = () => st.W / 400;

    function start() {
      L = api.level;
      p = { x: st.W / 2, y: st.H - 120, vx: 0, vy: 0, r: 18 * S() };
      plats = []; camY = 0; maxH = 0; score = 0; over = false; hold = 0; coinsGot = 0;
      plats.push({ x: st.W / 2 - 50, y: st.H - 60, w: 100, kind: 'n' });
      let y = st.H - 60;
      while (y > -st.H) { y -= gapFor(0); addPlat(y); }
      hud();
    }
    const gapFor = (h) => Math.min(150, 62 + L * 6 + h / 400) * (st.H / 750);
    function addPlat(y) {
      const h = -y;
      const w = Math.max(48, (90 - L * 4 - h / 300)) * S();
      const r = Math.random();
      const kind = r < Math.min(0.35, 0.05 + L * 0.03 + h / 20000) ? 'move' : r < Math.min(0.55, 0.1 + L * 0.04 + h / 25000) ? 'break' : 'n';
      plats.push({ x: Math.random() * (st.W - w), y, w, kind, dir: Math.random() < 0.5 ? -1 : 1, coin: Math.random() < 0.15 });
    }
    function hud() { api.setHud({ score, scoreLabel: 'Yükseklik', extra: `🪙 ${coinsGot}` }); }

    const onDown = (e) => { hold = st.point(e).x < st.W / 2 ? -1 : 1; };
    const onUp = () => { hold = 0; };
    st.canvas.addEventListener('pointerdown', onDown);
    st.canvas.addEventListener('pointermove', (e) => { if (e.buttons) onDown(e); });
    window.addEventListener('pointerup', onUp);
    const keys = {};
    const kd = (e) => { keys[e.key] = true; }, ku = (e) => { keys[e.key] = false; };
    window.addEventListener('keydown', kd); window.addEventListener('keyup', ku);

    function update(dt) {
      if (!over) {
        const dir = hold || (keys.ArrowLeft ? -1 : keys.ArrowRight ? 1 : 0);
        p.vx += (dir * 420 * S() - p.vx) * Math.min(1, dt * 8);
        p.x += p.vx * dt;
        if (p.x < -p.r) p.x = st.W + p.r; if (p.x > st.W + p.r) p.x = -p.r;
        p.vy += 1500 * (st.H / 750) * dt; p.y += p.vy * dt;
        for (const pl of plats) {
          if (pl.kind === 'move') { pl.x += pl.dir * (60 + L * 15) * S() * dt; if (pl.x < 0 || pl.x + pl.w > st.W) pl.dir *= -1; }
          if (pl.dead) continue;
          if (p.vy > 0 && p.y + p.r > pl.y && p.y + p.r < pl.y + 16 + p.vy * dt && p.x > pl.x - 6 && p.x < pl.x + pl.w + 6) {
            if (pl.kind === 'break') { pl.dead = true; fx.burst(pl.x + pl.w / 2, pl.y - camY, '#a98467', 10); api.sfx.brick(); continue; }
            p.vy = -820 * (st.H / 750); api.sfx.bounce();
            if (pl.coin) { pl.coin = false; coinsGot++; api.sfx.coin(); hud(); }
          }
        }
        // kamera
        const target = p.y - st.H * 0.4;
        if (target < camY) camY = target;
        const h = Math.floor((st.H - 120 - p.y) / 10);
        if (h > maxH) { maxH = h; score = maxH; hud(); }
        // yeni platformlar
        let top = Math.min(...plats.map((q) => q.y));
        while (top > camY - st.H) { top -= gapFor(-top); addPlat(top); }
        plats = plats.filter((q) => q.y < camY + st.H + 50);
        if (p.y - camY > st.H + 40) {
          over = true; api.sfx.lose(); api.haptic('heavy');
          api.gameOver({ score, coins: coinsGot * 5 + Math.floor(score / 60), canContinue: true, title: 'Düştün! 🐸' });
        }
      }
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H);
      const k = Math.min(1, score / 8000);
      g.addColorStop(0, `hsl(${200 + k * 60},70%,${70 - k * 45}%)`); g.addColorStop(1, '#e9f5db');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      for (const pl of plats) {
        if (pl.dead) continue;
        const y = pl.y - camY;
        c.fillStyle = pl.kind === 'move' ? '#4cc9f0' : pl.kind === 'break' ? '#a98467' : '#55a630';
        roundRect(c, pl.x, y, pl.w, 14, 7); c.fill();
        if (pl.kind === 'break') { c.strokeStyle = '#6c584c'; c.lineWidth = 2; c.beginPath(); c.moveTo(pl.x + pl.w * 0.4, y); c.lineTo(pl.x + pl.w * 0.5, y + 14); c.stroke(); }
        if (pl.coin) { c.fillStyle = '#ffd60a'; c.beginPath(); c.arc(pl.x + pl.w / 2, y - 16, 8, 0, 7); c.fill(); }
      }
      // kurbağa
      const y = p.y - camY;
      c.fillStyle = '#38b000'; c.beginPath(); c.ellipse(p.x, y, p.r, p.r * 0.85, 0, 0, 7); c.fill();
      c.fillStyle = '#fff'; c.beginPath(); c.arc(p.x - p.r * 0.45, y - p.r * 0.6, p.r * 0.32, 0, 7); c.arc(p.x + p.r * 0.45, y - p.r * 0.6, p.r * 0.32, 0, 7); c.fill();
      c.fillStyle = '#000'; c.beginPath(); c.arc(p.x - p.r * 0.45 + p.vx * 0.004, y - p.r * 0.6, p.r * 0.14, 0, 7); c.arc(p.x + p.r * 0.45 + p.vx * 0.004, y - p.r * 0.6, p.r * 0.14, 0, 7); c.fill();
      c.strokeStyle = '#1b4332'; c.lineWidth = 2; c.beginPath(); c.arc(p.x, y + p.r * 0.05, p.r * 0.45, 0.2, Math.PI - 0.2); c.stroke();
      fx.draw(c);
      c.fillStyle = 'rgba(255,255,255,.5)'; c.font = '700 13px system-ui'; c.textAlign = 'center';
      if (score < 30) c.fillText('◀ Sola / sağa basılı tut ▶', st.W / 2, st.H - 20);
    }
    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() {
        // oyuncunun altına kurtarma platformu koy
        p.y = camY + st.H * 0.5; p.vy = -900 * (st.H / 750);
        plats.push({ x: p.x - 60, y: p.y + 40, w: 120, kind: 'n' }); over = false;
      },
      restart() { start(); },
      destroy() { lp.stop(); st.destroy(); window.removeEventListener('pointerup', onUp); window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku); },
    };
  },
};
