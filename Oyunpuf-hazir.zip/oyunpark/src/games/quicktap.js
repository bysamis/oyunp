// ⚡ Hızlı Parmak (2–4 kişi, aynı telefon): ışık YEŞİL olunca kendi alanına ilk basan kazanır; erken basan puan kaybeder
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

const COLORS = ['#ef233c', '#3a86ff', '#2dc653', '#ffd60a'];
const WIN = 5;

export default {
  id: 'quicktap', title: 'Hızlı Parmak', emoji: '⚡', color: '#ffd60a',
  desc: 'Işık yeşil olunca ilk basan kazanır!',
  mpOnly: true, players: { min: 2, max: 4 },
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    const n = api.mp?.n || 2, names = api.mp?.names || ['Oyuncu 1', 'Oyuncu 2', 'Oyuncu 3', 'Oyuncu 4'];
    let scores, phase, t, waitFor, decoyAt, decoyOn, roundWinner, over, flash, round;

    function zones() {
      const W = st.W, H = st.H;
      if (n === 2) return [{ x: 0, y: H / 2, w: W, h: H / 2, flip: false }, { x: 0, y: 0, w: W, h: H / 2, flip: true }];
      return [{ x: 0, y: H / 2, w: W / 2, h: H / 2, flip: false }, { x: W / 2, y: 0, w: W / 2, h: H / 2, flip: true },
        { x: W / 2, y: H / 2, w: W / 2, h: H / 2, flip: false }, { x: 0, y: 0, w: W / 2, h: H / 2, flip: true }].slice(0, n);
    }
    function start() { scores = Array(n).fill(0); over = false; round = 0; flash = Array(n).fill(0); nextRound(); }
    function nextRound() {
      round++; phase = 'wait'; t = 0; roundWinner = -1;
      waitFor = 1.4 + Math.random() * 3;
      // 3. turdan sonra sahte renk (yanıltma) çıkabilir
      decoyAt = round >= 3 && Math.random() < 0.55 ? waitFor * (0.3 + Math.random() * 0.5) : -1; decoyOn = 0;
      hud();
    }
    function hud() { api.setHud({ score: scores.join(' - '), scoreLabel: 'Skor', extra: `İlk ${WIN} puan kazanır · Tur ${round}` }); }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = st.point(e);
      const i = zones().findIndex((z) => p.x >= z.x && p.x < z.x + z.w && p.y >= z.y && p.y < z.y + z.h);
      if (i < 0) return;
      if (phase === 'wait') {
        scores[i] = Math.max(0, scores[i] - 1); flash[i] = -0.6; api.sfx.wrong(); api.haptic('medium'); hud();
      } else if (phase === 'go') {
        phase = 'won'; roundWinner = i; scores[i]++; flash[i] = 0.8; api.sfx.coin(); api.haptic('heavy');
        const z = zones()[i]; fx.burst(z.x + z.w / 2, z.y + z.h / 2, COLORS[i], 24, 240); hud();
        if (scores[i] >= WIN) { over = true; api.sfx.win(); setTimeout(() => api.gameOver({ winner: i }), 1200); }
        else setTimeout(nextRound, 1300);
      }
    });
    function update(dt) {
      t += dt;
      if (phase === 'wait') {
        if (decoyAt > 0 && t >= decoyAt && decoyOn === 0) { decoyOn = 0.45; api.sfx.click(); }
        if (decoyOn > 0) decoyOn -= dt;
        if (t >= waitFor) { phase = 'go'; api.sfx.power(); }
      }
      flash = flash.map((f) => (f > 0 ? Math.max(0, f - dt) : Math.min(0, f + dt)));
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx;
      c.fillStyle = '#111'; c.fillRect(0, 0, st.W, st.H);
      zones().forEach((z, i) => {
        c.globalAlpha = 0.85; c.fillStyle = COLORS[i]; roundRect(c, z.x + 4, z.y + 4, z.w - 8, z.h - 8, 18); c.fill(); c.globalAlpha = 1;
        if (flash[i] > 0) { c.fillStyle = `rgba(255,255,255,${flash[i] * 0.6})`; roundRect(c, z.x + 4, z.y + 4, z.w - 8, z.h - 8, 18); c.fill(); }
        if (flash[i] < 0) { c.fillStyle = `rgba(0,0,0,${-flash[i] * 0.7})`; roundRect(c, z.x + 4, z.y + 4, z.w - 8, z.h - 8, 18); c.fill(); }
        c.save(); c.translate(z.x + z.w / 2, z.y + z.h / 2); if (z.flip) c.rotate(Math.PI);
        c.fillStyle = '#fff'; c.textAlign = 'center'; c.textBaseline = 'middle';
        c.font = '900 22px system-ui'; c.fillText(names[i], 0, z.h * 0.22);
        c.font = '900 54px system-ui'; c.fillText(scores[i], 0, z.h * 0.22 + 50);
        if (flash[i] < 0) { c.font = '800 18px system-ui'; c.fillText('ERKEN! −1', 0, z.h * 0.22 - 34); }
        if (roundWinner === i) { c.font = '900 20px system-ui'; c.fillText('⚡ EN HIZLI!', 0, z.h * 0.22 - 34); }
        c.restore();
      });
      // ortadaki ışık
      const r = Math.min(st.W, st.H) * 0.13, cx = st.W / 2, cy = st.H / 2;
      const col = phase === 'go' ? '#38ff6a' : phase === 'won' ? '#ffffff' : decoyOn > 0 ? '#3a86ff' : '#ff2d2d';
      c.shadowColor = col; c.shadowBlur = phase === 'go' ? 50 : 20;
      c.fillStyle = '#222'; c.beginPath(); c.arc(cx, cy, r + 8, 0, 7); c.fill();
      c.fillStyle = col; c.beginPath(); c.arc(cx, cy, r, 0, 7); c.fill(); c.shadowBlur = 0;
      c.fillStyle = '#111'; c.font = `900 ${r * 0.42}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(phase === 'go' ? 'BAS!' : phase === 'won' ? '✓' : 'BEKLE', cx, cy + 2);
      c.textBaseline = 'alphabetic';
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
