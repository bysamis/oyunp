// 🚀 Zıpzıp Roket 3D (dokun → yüksel, asteroid kapılarından geç)
import { create3D, mat, THREE } from '../core/three-stage.js';

const H = 14; // oyun alanı yüksekliği (birim)

export default {
  id: 'rocket', title: 'Zıpzıp Roket 3D', emoji: '🚀', color: '#7b2cbf',
  desc: 'Dokun, roketi uçur, boşluklardan geç!',
  target: (L) => 8 + (L - 1) * 6,
  create(host, api) {
    const S = create3D(host, { fov: 45, bg: 0x10002b, fog: [0x10002b, 30, 70] });
    const { scene, camera, sun, hemi } = S;
    hemi.intensity = 0.7; sun.intensity = 2; sun.position.set(-8, 20, 14);
    Object.assign(sun.shadow.camera, { left: -20, right: 20, top: 16, bottom: -4 });
    // yıldızlar
    const starGeo = new THREE.BufferGeometry(), sp = [];
    for (let i = 0; i < 600; i++) sp.push((Math.random() - 0.5) * 120, Math.random() * 60 - 15, -20 - Math.random() * 40);
    starGeo.setAttribute('position', new THREE.Float32BufferAttribute(sp, 3));
    const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 0.25 })); scene.add(stars);
    // uzak gezegen
    const planet = new THREE.Mesh(new THREE.SphereGeometry(6, 32, 20), mat(0xc77dff, { emissive: 0x5a189a, emissiveIntensity: 0.4 }));
    planet.position.set(14, 12, -35); scene.add(planet);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(9, 0.5, 4, 48), mat(0xe0aaff, { emissive: 0x7b2cbf, emissiveIntensity: 0.5 })); ring.rotation.x = 1.2; planet.add(ring);
    // zemin ve tavan çizgisi
    const ground = new THREE.Mesh(new THREE.BoxGeometry(200, 1, 8), mat(0x3c096c)); ground.position.y = -0.5; ground.receiveShadow = true; scene.add(ground);

    // roket
    const rocket = new THREE.Group(); scene.add(rocket);
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.42, 1.3, 18), mat(0xedf2f4, { metalness: 0.3 })); body.castShadow = true; rocket.add(body);
    const nose = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.7, 18), mat(0xef233c)); nose.position.y = 1; rocket.add(nose);
    const win = new THREE.Mesh(new THREE.SphereGeometry(0.17, 12, 8), mat(0x3a86ff, { emissive: 0x3a86ff, emissiveIntensity: 0.5 })); win.position.set(0, 0.2, 0.36); rocket.add(win);
    [0, 1, 2].forEach((i) => { const f = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.5, 0.45), mat(0xef233c)); const a = (i / 3) * Math.PI * 2; f.position.set(Math.sin(a) * 0.42, -0.5, Math.cos(a) * 0.42); f.rotation.y = a; rocket.add(f); });
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.8, 12), new THREE.MeshBasicMaterial({ color: 0xff9f1c })); flame.rotation.x = Math.PI; flame.position.y = -1.05; rocket.add(flame);
    const glow = new THREE.PointLight(0xff9f1c, 3, 5); glow.position.y = -1.2; rocket.add(glow);

    const wallGroup = new THREE.Group(); scene.add(wallGroup);
    const rockMat = (hue) => mat(new THREE.Color().setHSL(hue / 360, 0.55, 0.5), { flatShading: true, roughness: 0.9 });
    let rk, walls, score, state, spawnX, halfW = 8, trail = [];
    const RX = () => -halfW * 0.45;

    function makeColumn(y0, y1, hue) {
      const g = new THREE.Group(), m = rockMat(hue), h = y1 - y0;
      const core = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.6, h, 8), m); core.position.y = y0 + h / 2; core.castShadow = true; g.add(core);
      for (let y = y0 + 0.4; y < y1; y += 0.9) {
        const r = new THREE.Mesh(new THREE.DodecahedronGeometry(0.55 + Math.random() * 0.25, 0), m);
        r.position.set((Math.random() - 0.5) * 0.4, y, (Math.random() - 0.5) * 0.4); r.rotation.set(Math.random() * 3, Math.random() * 3, 0); r.castShadow = true; g.add(r);
      }
      return g;
    }
    function start() {
      rk = { y: H * 0.45, vy: 0, r: 0.4 };
      wallGroup.clear(); walls = []; score = 0; state = 'ready'; spawnX = 0;
      rocket.visible = true; hud();
    }
    function hud() { api.setHud({ score, extra: state === 'ready' ? 'Başlamak için dokun' : 'Kapı geç, puan kazan!' }); }
    const speed = () => (170 + api.level * 22 + Math.min(score, 50) * 4) / 50;
    const gap = () => Math.max(115, 235 - api.level * 12 - score * 2.2) / 50;

    function flap() {
      if (state === 'over') return;
      if (state === 'ready') { state = 'play'; hud(); }
      rk.vy = 6.6; api.sfx.tap();
      S.burst(new THREE.Vector3(RX(), rk.y - 0.8, 0), 0xff9f1c, 4, 3, 0.6);
    }
    const onKey = (e) => { if (e.key === ' ' || e.key === 'ArrowUp') flap(); };
    S.el.addEventListener('pointerdown', flap);
    window.addEventListener('keydown', onKey);

    function crash() {
      state = 'over'; api.sfx.crash(); api.haptic('heavy');
      const p = new THREE.Vector3(RX(), rk.y, 0);
      S.burst(p, 0xff9f1c, 30, 8); S.burst(p, 0xffffff, 14, 6);
      rocket.visible = false;
      setTimeout(() => api.gameOver({ score, coins: score * 2, canContinue: true, title: 'Roket çarptı! 💫' }), 700);
    }
    S.onResize(() => {
      // tüm yükseklik görünsün
      const vfov = (camera.fov * Math.PI) / 180, dist = (H / 2 + 1) / Math.tan(vfov / 2);
      camera.position.set(0, H / 2, dist); camera.lookAt(0, H / 2, 0);
      halfW = Math.tan(vfov / 2) * dist * (S.w / S.h);
    });

    const lp = S.loop((dt, t) => {
      stars.position.x -= dt * (state === 'play' ? 1.5 : 0.3); if (stars.position.x < -60) stars.position.x += 60;
      planet.rotation.y += dt * 0.1;
      if (state === 'ready') rk.y = H * 0.45 + Math.sin(t * 3) * 0.2;
      if (state === 'play') {
        rk.vy -= 18 * dt; rk.y += rk.vy * dt;
        spawnX -= speed() * dt;
        if (spawnX <= 0) {
          const g = gap(), cy = g / 2 + 0.8 + Math.random() * (H - g - 1.6), hue = (score * 37) % 360;
          const grp = new THREE.Group(); grp.position.x = halfW + 1.5; wallGroup.add(grp);
          grp.add(makeColumn(-1, cy - g / 2, hue)); grp.add(makeColumn(cy + g / 2, H + 2, hue));
          const ringG = new THREE.Mesh(new THREE.TorusGeometry(g / 2, 0.06, 6, 32), new THREE.MeshBasicMaterial({ color: 0xffd60a, transparent: true, opacity: 0.35 }));
          ringG.position.y = cy; ringG.rotation.y = Math.PI / 2; grp.add(ringG);
          walls.push({ grp, x: grp.position.x, top: cy + g / 2, bot: cy - g / 2, passed: false, ringG });
          spawnX = 4.6;
        }
        for (let i = walls.length - 1; i >= 0; i--) {
          const w = walls[i];
          w.x -= speed() * dt; w.grp.position.x = w.x;
          if (!w.passed && w.x + 0.6 < RX()) { w.passed = true; score++; api.sfx.coin(); w.ringG.material.opacity = 0.9; S.popText(new THREE.Vector3(RX(), rk.y + 1, 0), '+1', '#ffd60a'); hud(); }
          if (w.x < -halfW - 3) { wallGroup.remove(w.grp); walls.splice(i, 1); continue; }
          const inX = Math.abs(w.x - RX()) < 0.6 + rk.r * 0.8;
          if (state === 'play' && inX && (rk.y + rk.r * 0.8 > w.top || rk.y - rk.r * 0.8 < w.bot)) crash();
        }
        if (state === 'play' && (rk.y < rk.r || rk.y > H - rk.r)) crash();
      }
      walls.forEach((w) => w.grp.children.forEach((c, i) => { if (i < 2) c.rotation.y += dt * 0.3; }));
      // roket görünümü: yatay uçar, hıza göre burnu yukarı/aşağı
      const ang = Math.max(-0.6, Math.min(0.5, rk.vy / 12));
      rocket.position.set(RX(), rk.y, 0);
      rocket.rotation.z = -Math.PI / 2 + ang;
      rocket.rotation.x = Math.sin(t * 2) * 0.15;
      flame.scale.set(1, 0.8 + Math.sin(t * 40) * 0.25 + (rk.vy > 3 ? 0.5 : 0), 1);
      S.updateParts(dt, 0);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() {
        walls = walls.filter((w) => { if (w.x < RX() + 3) { wallGroup.remove(w.grp); return false; } return true; });
        rk.y = H * 0.45; rk.vy = 0; state = 'ready'; rocket.visible = true; hud();
      },
      restart() { start(); },
      destroy() { S.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
