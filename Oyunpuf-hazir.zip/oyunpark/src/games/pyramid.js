// 🃏 Piramit Kart: toplamı 13 eden iki açık kartı eşle (K tek başına gider)
import { createStage, loop, roundRect, particles } from '../core/canvas.js';
import { expert, expertSteps } from '../core/expert.js';

const SUITS = [['♥', '#d00000'], ['♦', '#d00000'], ['♠', '#111'], ['♣', '#111']];
const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

export default {
  id: 'pyramid', title: 'Piramit Kart', emoji: '🂡', color: '#2a9d8f',
  desc: 'Toplamı 13 olan kart çiftlerini bul!',
  // seviye arttıkça piramidin tamamen temizlenmesine yaklaşmak gerekir
  expertFrom: 12,
  target: (L) => Math.min(300, 90 + (L - 1) * 30),
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let pyr, stock, waste, sel, score, passes, over, L, timeLeft, removed;

    function start() {
      L = api.level;
      const deck = [];
      for (const s of SUITS) for (let v = 1; v <= 13; v++) deck.push({ v, s });
      deck.sort(() => Math.random() - 0.5);
      pyr = []; let k = 0;
      for (let row = 0; row < 7; row++) for (let i = 0; i <= row; i++) pyr.push({ ...deck[k++], row, i, gone: false });
      stock = deck.slice(k); waste = [];
      // Zorluk: deste tekrar sayısı 3 → 0, 4. seviyeden sonra süre sınırı
      passes = Math.max(0, 3 - (L - 1));
      timeLeft = L >= 4 ? Math.max(70, 200 - (L - 4) * 18) / expert(L, 11, 0.6) : Infinity; // uzman: süre kısalır
      sel = null; score = 0; over = false; removed = 0; hud();
    }
    function hud() { api.setHud({ score, extra: `Deste: ${stock.length} · Tekrar: ${passes}` + (timeLeft < Infinity ? ` · ⏱ ${Math.ceil(timeLeft)}` : '') }); }
    const at = (row, i) => pyr.find((c) => c.row === row && c.i === i);
    const exposed = (c) => !c.gone && (c.row === 6 || (at(c.row + 1, c.i).gone && at(c.row + 1, c.i + 1).gone));
    function geo() {
      const cw = Math.min(46, (st.W - 20) / 7.4), ch = cw * 1.4;
      return { cw, ch, top: 20, rowH: ch * 0.6 };
    }
    function cardPos(c) { const { cw, rowH, top } = geo(); return { x: st.W / 2 + (c.i - c.row / 2) * (cw + 3) - cw / 2, y: top + c.row * rowH }; }
    function stockPos() { const { cw, ch, top, rowH } = geo(); const y = top + 6 * rowH + ch + 40; return { sx: st.W / 2 - cw - 20, wx: st.W / 2 + 20, y }; }

    function remove(cards) {
      const { cw, ch } = geo();
      cards.forEach((c) => {
        c.gone = true;
        const p = c.row !== undefined ? cardPos(c) : { x: stockPos().wx, y: stockPos().y };
        fx.burst(p.x + cw / 2, p.y + ch / 2, c.s[1] === '#111' ? '#555' : '#ff4d6d', 10);
        if (c.row === undefined) waste.splice(waste.indexOf(c), 1);
      });
      removed += cards.filter((c) => c.row !== undefined).length;
      score += cards.length * 5; api.sfx.pop(); api.haptic('light');
      if (pyr.every((c) => c.gone)) {
        score += 100 + Math.max(0, Math.round(timeLeft < Infinity ? timeLeft : 0)) + stock.length * 3;
        return end(true);
      }
      hud(); checkStuck();
    }
    function checkStuck() {
      if (stock.length || passes > 0) return;
      const open = pyr.filter(exposed).concat(waste.length ? [waste[waste.length - 1]] : []);
      const can = open.some((a) => a.v === 13 || open.some((b) => b !== a && a.v + b.v === 13));
      if (!can) end(false);
    }
    function end(win) {
      over = true; win ? api.sfx.win() : api.sfx.lose(); hud();
      setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 25), win, title: win ? 'Piramit bitti! 🏆' : 'Hamle kalmadı 🃏' }), 700);
    }
    function pick(card) {
      if (card.v === 13) { sel = null; remove([card]); return; }
      if (!sel) { sel = card; api.sfx.click(); return; }
      if (sel === card) { sel = null; return; }
      if (sel.v + card.v === 13) { const a = sel; sel = null; remove([a, card]); }
      else { sel = card; api.sfx.wrong(); }
    }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = st.point(e), { cw, ch } = geo(), sp = stockPos();
      for (let k = pyr.length - 1; k >= 0; k--) {
        const c = pyr[k]; if (!exposed(c)) continue;
        const q = cardPos(c);
        if (p.x > q.x && p.x < q.x + cw && p.y > q.y && p.y < q.y + ch) return pick(c);
      }
      if (p.y > sp.y && p.y < sp.y + ch) {
        if (p.x > sp.sx && p.x < sp.sx + cw) {
          sel = null;
          if (stock.length) { waste.push(stock.pop()); api.sfx.slide(); }
          else if (passes > 0) { passes--; stock = waste.reverse(); waste = []; api.sfx.swap(); }
          else api.sfx.wrong();
          hud(); checkStuck(); return;
        }
        if (p.x > sp.wx && p.x < sp.wx + cw && waste.length) return pick(waste[waste.length - 1]);
      }
      sel = null;
    });
    function update(dt) {
      if (!over && timeLeft < Infinity) {
        const b = Math.ceil(timeLeft); timeLeft -= dt;
        if (Math.ceil(timeLeft) !== b) hud();
        if (timeLeft <= 0) { timeLeft = 0; end(false); }
      }
      fx.update(dt); draw();
    }
    function card(c, x, y, cw, ch, cd, open = true, hi = false, dim = false) {
      c.fillStyle = 'rgba(0,0,0,.25)'; roundRect(c, x + 2, y + 3, cw, ch, 6); c.fill();
      roundRect(c, x, y, cw, ch, 6);
      if (!open) { c.fillStyle = '#e63946'; c.fill(); c.strokeStyle = '#fff'; c.lineWidth = 2; roundRect(c, x + 3, y + 3, cw - 6, ch - 6, 4); c.stroke(); return; }
      c.fillStyle = dim ? '#cfd8dc' : '#fff'; c.fill();
      if (hi) { c.strokeStyle = '#ffd60a'; c.lineWidth = 4; c.stroke(); }
      c.fillStyle = cd.s[1]; c.textAlign = 'center';
      c.font = `900 ${cw * 0.38}px system-ui`; c.fillText(RANKS[cd.v - 1], x + cw / 2, y + ch * 0.42);
      c.font = `${cw * 0.42}px system-ui`; c.fillText(cd.s[0], x + cw / 2, y + ch * 0.82);
    }
    function draw() {
      const c = st.ctx, { cw, ch } = geo();
      c.fillStyle = '#2a6f4f'; c.fillRect(0, 0, st.W, st.H);
      const g = c.createRadialGradient(st.W / 2, st.H / 2, 50, st.W / 2, st.H / 2, st.H * 0.7); g.addColorStop(0, 'rgba(255,255,255,.08)'); g.addColorStop(1, 'rgba(0,0,0,.25)');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      for (const cd of pyr) { if (cd.gone) continue; const p = cardPos(cd); card(c, p.x, p.y, cw, ch, cd, true, sel === cd, !exposed(cd)); }
      const sp = stockPos();
      if (stock.length) card(c, sp.sx, sp.y, cw, ch, null, false);
      else { roundRect(c, sp.sx, sp.y, cw, ch, 6); c.strokeStyle = 'rgba(255,255,255,.4)'; c.lineWidth = 2; c.stroke(); c.fillStyle = '#fff'; c.font = '800 20px system-ui'; c.textAlign = 'center'; c.fillText(passes ? '↻' : '✕', sp.sx + cw / 2, sp.y + ch / 2 + 7); }
      if (waste.length) { const w = waste[waste.length - 1]; card(c, sp.wx, sp.y, cw, ch, w, true, sel === w); }
      c.fillStyle = 'rgba(255,255,255,.75)'; c.font = '700 13px system-ui'; c.textAlign = 'center';
      c.fillText('Toplamı 13 olan iki kart · A=1 J=11 Q=12 K=13 (tek başına)', st.W / 2, sp.y + ch + 30);
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
