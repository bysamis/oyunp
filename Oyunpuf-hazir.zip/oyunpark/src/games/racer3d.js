// 🏎️ Araba Yarışı — 3D (Three.js). Seviye, coin, garaj rengi ve devam etme 2D sürümle aynı.
import * as THREE from 'three';
import { touchpad } from '../core/touchpad.js';
import { store } from '../core/store.js';
import { CAR_SKINS } from './racer.js';
import { model } from '../core/assets.js';

const LANES = [-2.3, 0, 2.3];
const TRAFFIC = [0x06d6a0, 0x118ab2, 0xef476f, 0xffd166, 0x8338ec, 0xfb8500, 0xadb5bd, 0xffffff];
const SPAWN_Z = -170, DESPAWN_Z = 14;

// Seviyeye göre ortam: gündüz → gün batımı → gece → neon gece
const THEMES = [
  { sky: 0x8fd3ff, fog: 0xbfe6ff, ground: 0x57cc99, sun: 1.6, amb: 0.9, night: false },
  { sky: 0xff9e6d, fog: 0xffc09f, ground: 0x6a994e, sun: 1.2, amb: 0.7, night: false },
  { sky: 0x1b1f4b, fog: 0x2a2f6b, ground: 0x264653, sun: 0.35, amb: 0.45, night: true },
  { sky: 0x10002b, fog: 0x240046, ground: 0x1b0033, sun: 0.25, amb: 0.4, night: true },
];

function mat(color, opts = {}) { return new THREE.MeshStandardMaterial({ color, roughness: 0.55, metalness: 0.15, ...opts }); }

// Kutulardan sevimli bir araba modeli
function buildCar(color, { truck = false, player = false } = {}) {
  const g = new THREE.Group();
  const body = mat(color, { metalness: 0.35, roughness: 0.35 });
  const dark = mat(0x1d1d2c, { roughness: 0.2, metalness: 0.5 });
  const tire = mat(0x111111, { roughness: 0.9 });
  const box = (w, h, d, m, x, y, z) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
    mesh.position.set(x, y, z); mesh.castShadow = true; mesh.receiveShadow = true; g.add(mesh); return mesh;
  };
  if (truck) {
    box(1.7, 1.9, 3.6, mat(0xe9ecef), 0, 1.35, 0.6);           // kasa
    box(1.7, 1.3, 1.4, body, 0, 1.05, -1.9);                   // kabin
    box(1.5, 0.5, 0.05, dark, 0, 1.35, -2.62);                 // ön cam
    [[-0.85, -1.9], [0.85, -1.9], [-0.85, 1.6], [0.85, 1.6]].forEach(([x, z]) => {
      const w = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.35, 14), tire);
      w.rotation.z = Math.PI / 2; w.position.set(x, 0.42, z); w.castShadow = true; g.add(w);
    });
    g.userData.len = 4.8;
  } else {
    box(1.6, 0.55, 3.0, body, 0, 0.55, 0);                      // gövde
    box(1.3, 0.5, 1.5, body, 0, 1.05, 0.15);                    // tavan
    box(1.22, 0.42, 0.05, dark, 0, 1.05, -0.62);                // ön cam
    box(1.22, 0.38, 0.05, dark, 0, 1.05, 0.92);                 // arka cam
    box(0.05, 0.36, 1.2, dark, 0.66, 1.05, 0.15);               // yan camlar
    box(0.05, 0.36, 1.2, dark, -0.66, 1.05, 0.15);
    const wheels = [];
    [[-0.82, -0.95], [0.82, -0.95], [-0.82, 0.95], [0.82, 0.95]].forEach(([x, z]) => {
      const w = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.3, 16), tire);
      w.rotation.z = Math.PI / 2; w.position.set(x, 0.34, z); w.castShadow = true; g.add(w); wheels.push(w);
    });
    g.userData.wheels = wheels;
    const lamp = mat(0xfff6b0, { emissive: 0xfff6b0, emissiveIntensity: 1.2 });
    box(0.32, 0.16, 0.05, lamp, -0.52, 0.62, -1.51);            // farlar
    box(0.32, 0.16, 0.05, lamp, 0.52, 0.62, -1.51);
    const tail = mat(0xff2244, { emissive: 0xff0022, emissiveIntensity: 1.0 });
    box(0.34, 0.14, 0.05, tail, -0.52, 0.66, 1.51);             // stop lambaları
    box(0.34, 0.14, 0.05, tail, 0.52, 0.66, 1.51);
    if (player) {
      box(1.5, 0.08, 0.35, dark, 0, 1.0, 1.45);                 // spoiler
      box(0.08, 0.3, 0.08, dark, -0.55, 0.85, 1.45);
      box(0.08, 0.3, 0.08, dark, 0.55, 0.85, 1.45);
      box(0.28, 0.02, 3.02, mat(0xffffff), 0, 0.835, 0);       // yarış şeridi
      box(0.28, 0.02, 1.52, mat(0xffffff), 0, 1.305, 0.15);
    }
    g.userData.len = 3.0;
  }
  return g;
}

export default {
  id: 'racer', title: 'Araba Yarışı 3D', emoji: '🏎️', color: '#ff9f1c',
  desc: 'Şerit değiştir, arabalardan kaç, altınları topla!',
  target: (L) => Math.round(400 * Math.pow(1.35, L - 1)),
  create(host, api) {
    // --- Sahne kurulumu
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.domElement.className = 'stage';
    renderer.domElement.style.touchAction = 'none';
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(62, 1, 0.1, 400);
    const hemi = new THREE.HemisphereLight(0xffffff, 0x445533, 0.9);
    scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xffffff, 1.6);
    sun.position.set(-8, 18, 6);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    Object.assign(sun.shadow.camera, { left: -14, right: 14, top: 14, bottom: -30, near: 1, far: 60 });
    scene.add(sun); scene.add(sun.target);

    // Zemin + yol
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(400, 400), mat(0x57cc99, { roughness: 1 }));
    ground.rotation.x = -Math.PI / 2; ground.position.z = -150; ground.receiveShadow = true; scene.add(ground);
    const road = new THREE.Mesh(new THREE.PlaneGeometry(8.2, 400), mat(0x3d434b, { roughness: 0.85 }));
    road.rotation.x = -Math.PI / 2; road.position.set(0, 0.01, -150); road.receiveShadow = true; scene.add(road);

    // Hareketli dekor (geri dönüşümlü): şerit çizgileri, bordürler, ağaçlar, lambalar
    const deco = [];
    const dashGeo = new THREE.BoxGeometry(0.16, 0.02, 2.4), dashMat = mat(0xffffff, { roughness: 0.5 });
    for (let i = 0; i < 40; i++) for (const x of [-1.15, 1.15]) {
      const m = new THREE.Mesh(dashGeo, dashMat); m.position.set(x, 0.02, -i * 5); scene.add(m); deco.push({ m, span: 200 });
    }
    const curbGeo = new THREE.BoxGeometry(0.4, 0.18, 2.5);
    const curbA = mat(0xef233c), curbB = mat(0xffffff);
    for (let i = 0; i < 80; i++) for (const x of [-4.3, 4.3]) {
      const m = new THREE.Mesh(curbGeo, i % 2 ? curbA : curbB); m.position.set(x, 0.09, -i * 2.5); m.receiveShadow = true; scene.add(m); deco.push({ m, span: 200 });
    }
    const trunkGeo = new THREE.CylinderGeometry(0.22, 0.3, 1.4, 8), leafGeo = new THREE.ConeGeometry(1.3, 2.8, 9);
    const trunkMat = mat(0x6f4518), leafMats = [mat(0x2d6a4f), mat(0x40916c), mat(0x52b788)];
    for (let i = 0; i < 34; i++) {
      const t = new THREE.Group();
      const tr = new THREE.Mesh(trunkGeo, trunkMat); tr.position.y = 0.7; tr.castShadow = true; t.add(tr);
      const lf = new THREE.Mesh(leafGeo, leafMats[i % 3]); lf.position.y = 2.6; lf.castShadow = true; t.add(lf);
      const side = i % 2 ? 1 : -1;
      t.position.set(side * (6.5 + Math.random() * 7), 0, -i * 6 - Math.random() * 3);
      t.scale.setScalar(0.8 + Math.random() * 0.6);
      scene.add(t); deco.push({ m: t, span: 204 });
    }
    const poleMat = mat(0x8d99ae, { metalness: 0.6 });
    const bulbMat = mat(0xfff3b0, { emissive: 0xfff3b0, emissiveIntensity: 0 });
    for (let i = 0; i < 10; i++) {
      const p = new THREE.Group();
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 4.5, 6), poleMat); pole.position.y = 2.25; pole.castShadow = true; p.add(pole);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.08, 0.08), poleMat); arm.position.set(-0.55, 4.45, 0); p.add(arm);
      const bulb = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 0.3), bulbMat); bulb.position.set(-1.05, 4.38, 0); p.add(bulb);
      p.position.set(5.0, 0, -i * 20); scene.add(p); deco.push({ m: p, span: 200 });
    }

    // Uzak manzara: dağlar, güneş/ay, bulutlar (sabit, derinlik hissi verir)
    const far = new THREE.Group(); scene.add(far);
    const mtnMats = [mat(0x6c8ebf, { roughness: 1, flatShading: true }), mat(0x8aa8d6, { roughness: 1, flatShading: true })];
    for (let i = 0; i < 18; i++) {
      const h = 18 + Math.random() * 26;
      const m = new THREE.Mesh(new THREE.ConeGeometry(14 + Math.random() * 12, h, 5), mtnMats[i % 2]);
      const side = i % 2 ? 1 : -1;
      m.position.set(side * (25 + Math.random() * 90), h / 2 - 1, -190 - Math.random() * 40);
      m.rotation.y = Math.random() * 3; far.add(m);
      if (h > 30) { const cap = new THREE.Mesh(new THREE.ConeGeometry(4.5, 7, 5), mat(0xffffff, { flatShading: true })); cap.position.set(m.position.x, h - 4.5, m.position.z); cap.rotation.y = m.rotation.y; far.add(cap); }
    }
    const orb = new THREE.Mesh(new THREE.SphereGeometry(9, 24, 16), new THREE.MeshBasicMaterial({ color: 0xfff1a8, fog: false }));
    orb.position.set(-60, 55, -260); scene.add(orb);
    const clouds = [];
    const cloudMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, transparent: true, opacity: 0.95 });
    for (let i = 0; i < 9; i++) {
      const c = new THREE.Group();
      for (let k = 0; k < 4; k++) { const b = new THREE.Mesh(new THREE.SphereGeometry(3 + Math.random() * 2.5, 10, 8), cloudMat); b.position.set(k * 3.6 - 5, Math.random() * 1.5, Math.random() * 2); c.add(b); }
      c.position.set((Math.random() - 0.5) * 160, 28 + Math.random() * 18, -120 - Math.random() * 100);
      scene.add(c); clouds.push(c);
    }
    // Hız çizgileri (yüksek hızda görünür)
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0 });
    const speedLines = [];
    for (let i = 0; i < 26; i++) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.04, 3 + Math.random() * 3), lineMat);
      m.position.set((Math.random() < 0.5 ? -1 : 1) * (2 + Math.random() * 5), 0.5 + Math.random() * 4, -Math.random() * 60);
      scene.add(m); speedLines.push(m);
    }
    const stars = new THREE.Points(
      new THREE.BufferGeometry().setAttribute('position', new THREE.Float32BufferAttribute(Array.from({ length: 900 }, (_, i) => i % 3 === 0 ? (Math.random() - 0.5) * 500 : i % 3 === 1 ? 40 + Math.random() * 150 : -150 - Math.random() * 150), 3)),
      new THREE.PointsMaterial({ color: 0xffffff, size: 1.2, fog: false }));
    scene.add(stars);

    // Oyuncu arabası
    let skinKey = null, player = null;
    function makePlayer() {
      const k = store.get().carSkin;
      if (player && skinKey === k) return;
      if (player) scene.remove(player);
      skinKey = k;
      player = buildCar(new THREE.Color((CAR_SKINS[k] || CAR_SKINS.red).color).getHex(), { player: true });
      scene.add(player);
    }

    // Parçacıklar (kaza ve coin)
    const partGeo = new THREE.BoxGeometry(0.25, 0.25, 0.25);
    let parts = [];
    function burst(pos, color, n, power = 8) {
      const m = mat(color, { emissive: color, emissiveIntensity: 0.4 });
      for (let i = 0; i < n; i++) {
        const p = new THREE.Mesh(partGeo, m);
        p.position.copy(pos);
        p.userData.v = new THREE.Vector3((Math.random() - 0.5) * power, Math.random() * power, (Math.random() - 0.5) * power);
        p.userData.life = 0.8 + Math.random() * 0.5;
        scene.add(p); parts.push(p);
      }
    }

    const coinGeo = new THREE.CylinderGeometry(0.45, 0.45, 0.1, 20);
    const coinMat = mat(0xffd60a, { metalness: 0.8, roughness: 0.25, emissive: 0x7a5c00, emissiveIntensity: 0.4 });

    // --- Oyun durumu
    let L, lane, px, objs, speed, maxSpeed, accel, dist, coins, spawnIn, state, invuln, shake, tilt, theme;

    function applyTheme() {
      theme = THEMES[Math.min(THEMES.length - 1, Math.floor((L - 1) / 3))];
      scene.background = new THREE.Color(theme.sky);
      scene.fog = new THREE.Fog(theme.fog, 40, 150);
      ground.material.color.setHex(theme.ground);
      sun.intensity = theme.sun; hemi.intensity = theme.amb;
      bulbMat.emissiveIntensity = theme.night ? 2.2 : 0;
      stars.visible = theme.night;
      orb.material.color.setHex(theme.night ? 0xe8ecff : L > 3 ? 0xffb36b : 0xfff1a8);
      orb.position.y = theme.night ? 70 : L > 3 ? 18 : 55;
      cloudMat.opacity = theme.night ? 0.25 : 0.95;
      mtnMats.forEach((m, i) => m.color.setHex(theme.night ? (i ? 0x2b2f5b : 0x23264d) : L > 3 ? (i ? 0xb5838d : 0x9d6b7a) : (i ? 0x8aa8d6 : 0x6c8ebf)));
    }

    function clearObjs() { objs?.forEach((o) => scene.remove(o.mesh)); objs = []; }

    function start() {
      L = api.level;
      applyTheme(); makePlayer(); clearObjs();
      lane = 1; px = LANES[1]; tilt = 0;
      // Zorluk: seviye arttıkça başlangıç hızı, azami hız ve ivme artar
      speed = 18 + (L - 1) * 2.2;
      maxSpeed = 46 + L * 3.5;
      accel = 0.5 + L * 0.11;
      dist = 0; coins = 0; spawnIn = 1.2; state = 'play'; invuln = 0; shake = 0;
      player.visible = true; player.position.set(px, 0, 0); player.rotation.set(0, 0, 0);
      hud();
    }
    function hud() { api.setHud({ score: Math.floor(dist), scoreLabel: 'Metre', extra: `🪙 ${coins}  ·  ${Math.round(speed * 3.6)} km/s` }); }

    // hazır kamyon modelleri (Kenney); yüklenene kadar kutu kamyon görünür
    const TRUCKS = ['vehicle-truck-red', 'vehicle-truck-yellow', 'vehicle-truck-green', 'vehicle-truck-purple'];
    const truckTpl = {};
    TRUCKS.forEach((n) => model(n, { size: 4.8 }).then((m) => { m.rotation.y = Math.PI; truckTpl[n] = m; }).catch(() => {}));
    function kenneyTruck() {
      const n = TRUCKS[(Math.random() * TRUCKS.length) | 0];
      if (!truckTpl[n]) return buildCar(TRAFFIC[(Math.random() * TRAFFIC.length) | 0], { truck: true });
      const g = new THREE.Group(); g.add(truckTpl[n].clone()); g.userData.len = 4.8; return g;
    }
    function spawn() {
      const free = (Math.random() * 3) | 0;
      const dbl = Math.random() < Math.min(0.72, 0.15 + L * 0.06 + dist / 6000);
      const lanes = [0, 1, 2].filter((l) => l !== free).sort(() => Math.random() - 0.5).slice(0, dbl ? 2 : 1);
      for (const l of lanes) {
        const truck = Math.random() < 0.22;
        const mesh = truck ? kenneyTruck() : buildCar(TRAFFIC[(Math.random() * TRAFFIC.length) | 0], { truck });
        mesh.position.set(LANES[l], 0, SPAWN_Z - Math.random() * 6);
        scene.add(mesh);
        // trafik de ileri gidiyor: göreli hız oyuncudan yavaş
        objs.push({ kind: 'car', lane: l, mesh, len: mesh.userData.len, own: 8 + Math.random() * 8 });
      }
      // Yüksek seviyede şerit değiştiren arabalar
      if (L >= 4 && Math.random() < Math.min(0.35, (L - 3) * 0.06)) {
        const o = objs[objs.length - 1];
        if (o && o.kind === 'car') { o.swerve = Math.random() < 0.5 ? -1 : 1; o.swerveAt = -40 - Math.random() * 30; }
      }
      if (Math.random() < 0.6) {
        for (let i = 0; i < 4; i++) {
          const mesh = new THREE.Mesh(coinGeo, coinMat);
          mesh.rotation.x = Math.PI / 2; mesh.position.set(LANES[free], 0.8, SPAWN_Z - i * 3.2); mesh.castShadow = true;
          scene.add(mesh); objs.push({ kind: 'coin', lane: free, mesh, len: 0.9 });
        }
      }
      spawnIn = Math.max(0.3, 1.0 - L * 0.05 - dist / 7000) * (0.85 + Math.random() * 0.3) * (24 / Math.max(24, speed * 0.75));
    }

    function setLane(l) {
      if (state !== 'play') return;
      const nl = Math.max(0, Math.min(2, l));
      if (nl !== lane) { tilt = (nl - lane) * 1; lane = nl; api.sfx.lane(); api.haptic('light'); }
    }
    let downX = null;
    const el = renderer.domElement;
    const onDown = (e) => { downX = e.clientX; };
    const onUp = (e) => {
      if (downX === null) return;
      const r = el.getBoundingClientRect(), dx = e.clientX - downX;
      if (Math.abs(dx) > 30) setLane(lane + Math.sign(dx));
      else setLane(lane + (e.clientX - r.left < r.width / 2 ? -1 : 1));
      downX = null;
    };
    // ekran düğmeleri: ◀ ▶ şerit, ⚡ gaz (basılı tut: hızlan, daha çok metre), 🛑 fren (yavaşla, kaçmak için)
    const pad = touchpad(host, {
      left: [{ id: 'left', icon: '◀' }, { id: 'right', icon: '▶' }],
      right: [{ id: 'brake', icon: '🛑', label: 'Fren', cls: 'brake' }, { id: 'gas', icon: '⚡', label: 'Gaz', cls: 'gas', big: true }],
      onPress(id) { if (id === 'left') setLane(lane - 1); if (id === 'right') setLane(lane + 1); },
    });
    const keyHeld = {};
    const onKey = (e) => { if (e.key === 'ArrowLeft') setLane(lane - 1); if (e.key === 'ArrowRight') setLane(lane + 1); if (e.key === 'ArrowUp') keyHeld.gas = true; if (e.key === 'ArrowDown') keyHeld.brake = true; };
    const onKeyUp = (e) => { if (e.key === 'ArrowUp') keyHeld.gas = false; if (e.key === 'ArrowDown') keyHeld.brake = false; };
    window.addEventListener('keyup', onKeyUp);
    el.addEventListener('pointerdown', onDown);
    el.addEventListener('pointerup', onUp);
    window.addEventListener('keydown', onKey);

    function crash() {
      state = 'over'; shake = 0.6;
      api.sfx.crash(); api.haptic('heavy');
      const p = player.position.clone(); p.y = 0.8;
      burst(p, new THREE.Color(CAR_SKINS[skinKey]?.color || '#ff3b3b').getHex(), 18, 10);
      burst(p, 0xff9f1c, 14, 8);
      burst(p, 0x444444, 10, 6);
      player.visible = false;
      const m = Math.floor(dist);
      setTimeout(() => api.gameOver({ score: m, coins: coins + Math.floor(m / 40), canContinue: true, title: 'Kaza yaptın! 💥' }), 800);
    }

    // --- Döngü
    let raf = 0, last = 0, paused = false, alive = true, hudT = 0;
    function frame(t) {
      if (!alive) return;
      raf = requestAnimationFrame(frame);
      const dt = last ? Math.min(0.05, (t - last) / 1000) : 0; last = t;
      if (paused) return;
      step(dt, t / 1000);
      renderer.render(scene, camera);
    }

    function step(dt, time) {
      if (state === 'play') {
        // gaz/fren: düğmeler açıkken gazsız araç seyir hızında gider; gaz tam hıza çıkarır, fren yavaşlatır
        const gas = pad.held.gas || keyHeld.gas, brake = pad.held.brake || keyHeld.brake;
        const manual = pad.enabled || keyHeld.gas !== undefined;
        if (brake) speed = Math.max(maxSpeed * 0.3, speed - 34 * dt);
        else if (gas || !manual) speed = Math.min(maxSpeed, speed + accel * (gas ? 2.2 : 1) * dt);
        else { const cruise = maxSpeed * 0.68; speed += (speed < cruise ? accel : -accel * 1.5) * dt; }
        player.userData.brakeT = brake ? 1 : 0;
        dist += speed * dt;
        spawnIn -= dt; if (spawnIn <= 0) spawn();
        if (invuln > 0) invuln -= dt;
        px += (LANES[lane] - px) * Math.min(1, dt * 12);
        tilt *= Math.pow(0.02, dt);
        player.position.x = px;
        player.rotation.y = -(LANES[lane] - px) * 0.18;
        player.rotation.z = (LANES[lane] - px) * 0.05;
        player.position.y = Math.abs(Math.sin(time * 30)) * 0.02 * (speed / 30);
        player.visible = !(invuln > 0 && Math.floor(time * 12) % 2);
        player.userData.wheels?.forEach((w) => (w.rotation.x += speed * dt * 2.5));

        for (let i = objs.length - 1; i >= 0; i--) {
          const o = objs[i];
          const rel = o.kind === 'car' ? speed - o.own : speed;
          o.mesh.position.z += rel * dt;
          if (o.kind === 'coin') o.mesh.rotation.z += dt * 5;
          if (o.swerve && o.mesh.position.z > o.swerveAt) {
            const nl = Math.max(0, Math.min(2, o.lane + o.swerve));
            o.lane = nl; o.swerve = 0;
          }
          if (o.kind === 'car') {
            o.mesh.position.x += (LANES[o.lane] - o.mesh.position.x) * Math.min(1, dt * 3);
            o.mesh.userData.wheels?.forEach((w) => (w.rotation.x += o.own * dt * 2.5));
          }
          if (o.mesh.position.z > DESPAWN_Z) { scene.remove(o.mesh); objs.splice(i, 1); continue; }
          const dx = Math.abs(o.mesh.position.x - px), dz = Math.abs(o.mesh.position.z);
          if (o.kind === 'coin' && dx < 1.1 && dz < 1.6) {
            scene.remove(o.mesh); objs.splice(i, 1); coins++; api.sfx.coin();
            burst(o.mesh.position, 0xffd60a, 6, 4);
          } else if (o.kind === 'car' && invuln <= 0 && dx < 1.45 && dz < (o.len + 3.0) / 2 * 0.92) {
            crash(); break;
          }
        }
        hudT -= dt; if (hudT <= 0) { hud(); hudT = 0.15; }
      }
      // dekor akışı
      const move = state === 'play' ? speed * dt : 0;
      for (const d of deco) { d.m.position.z += move; if (d.m.position.z > 12) d.m.position.z -= d.span; }
      for (const c of clouds) { c.position.x += dt * 1.2; if (c.position.x > 90) c.position.x = -90; }
      const spd = Math.min(1, Math.max(0, (speed - 30) / 30));
      lineMat.opacity = state === 'play' ? spd * 0.55 : 0;
      for (const m of speedLines) { m.position.z += (state === 'play' ? speed * 2.2 : 0) * dt; if (m.position.z > 10) m.position.z -= 70; }
      // parçacıklar
      parts = parts.filter((p) => {
        p.userData.life -= dt;
        if (p.userData.life <= 0) { scene.remove(p); return false; }
        p.userData.v.y -= 22 * dt; p.position.addScaledVector(p.userData.v, dt);
        if (p.position.y < 0.12) { p.position.y = 0.12; p.userData.v.y *= -0.4; p.userData.v.x *= 0.7; p.userData.v.z *= 0.7; }
        p.rotation.x += dt * 6; p.rotation.y += dt * 4;
        return true;
      });
      // kamera: arabayı takip eder, hızlandıkça görüş açısı genişler
      const sp = Math.min(1, (speed - 18) / 50);
      camera.fov = 60 + sp * 16; camera.updateProjectionMatrix();
      camera.position.set(px * 0.6, 5.0 - sp * 0.7, 9.2 - sp * 1.4);
      if (shake > 0) { shake -= dt; camera.position.x += (Math.random() - 0.5) * shake; camera.position.y += (Math.random() - 0.5) * shake; }
      camera.lookAt(px * 0.4, 0.6, -14);
      camera.rotation.z += -tilt * 0.02;
      sun.position.set(px - 8, 18, 6); sun.target.position.set(px, 0, -8);
    }

    function resize() {
      const r = host.getBoundingClientRect();
      const w = Math.max(1, r.width), h = Math.max(1, r.height);
      renderer.setSize(w, h);
      camera.aspect = w / h;
      // dar ekranlarda üç şeridin de görünmesi için kamerayı biraz geri al
      camera.zoom = Math.min(1, (w / h) / 0.62);
      camera.updateProjectionMatrix();
    }
    const ro = new ResizeObserver(resize); ro.observe(host); resize();

    start();
    raf = requestAnimationFrame(frame);

    return {
      pause() { paused = true; },
      resume() { paused = false; last = 0; },
      continue() {
        objs.filter((o) => o.mesh.position.z > -30).forEach((o) => { scene.remove(o.mesh); objs.splice(objs.indexOf(o), 1); });
        state = 'play'; invuln = 2.5; speed = Math.max(18, speed * 0.8); player.visible = true; hud();
      },
      restart() { start(); },
      destroy() {
        alive = false; cancelAnimationFrame(raf); ro.disconnect();
        window.removeEventListener('keydown', onKey); window.removeEventListener('keyup', onKeyUp); pad.destroy();
        scene.traverse((o) => { o.geometry?.dispose(); if (o.material) [].concat(o.material).forEach((m) => m.dispose()); });
        renderer.dispose(); renderer.domElement.remove();
      },
    };
  },
};
