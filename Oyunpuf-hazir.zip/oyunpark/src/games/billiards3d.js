// 🎱 Bilardo 3D (8 top): tek kişilik bilgisayara karşı, aynı telefonda 2 kişi, online 2 kişi
// Kontrol: parmağını beyaz topun gerisine doğru çek (sapan gibi) → bırak. Ne kadar çekersen o kadar sert.
import { create3D, mat, THREE } from '../core/three-stage.js';

const TW = 9, TD = 4.5, R = 0.11, POCKET_R = 0.24, FRICTION = 0.985, CUSHION = 0.78, DT = 1 / 240;
const POCKETS = [[-TW / 2, -TD / 2], [0, -TD / 2 - 0.04], [TW / 2, -TD / 2], [-TW / 2, TD / 2], [0, TD / 2 + 0.04], [TW / 2, TD / 2]];
const COLORS = { 1: '#f7d002', 2: '#1d4ed8', 3: '#dc2626', 4: '#7c3aed', 5: '#f97316', 6: '#15803d', 7: '#7f1d1d', 8: '#111111' };
const colorOf = (n) => COLORS[n > 8 ? n - 8 : n];
const groupOf = (n) => (n >= 1 && n <= 7 ? 'solid' : n >= 9 ? 'stripe' : n === 8 ? 'eight' : 'cue');

function ballTexture(n) {
  const cv = document.createElement('canvas'); cv.width = 256; cv.height = 128;
  const c = cv.getContext('2d');
  c.fillStyle = n === 0 ? '#fffdf5' : n > 8 ? '#fffdf5' : colorOf(n); c.fillRect(0, 0, 256, 128);
  if (n > 8) { c.fillStyle = colorOf(n); c.fillRect(0, 34, 256, 60); }
  if (n > 0) {
    [64, 192].forEach((x) => { c.fillStyle = '#fff'; c.beginPath(); c.arc(x, 64, 22, 0, 7); c.fill(); c.fillStyle = '#111'; c.font = 'bold 26px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(n, x, 66); });
  }
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export default {
  id: 'billiards', title: 'Bilardo 3D', emoji: '🎱', color: '#15803d',
  desc: 'Topları deliklere sok, 8 numarayı en son at!',
  winBased: true, landscape: true, players: { min: 2, max: 2 }, online: { min: 2, max: 2 },
  create(host, api) {
    const S = create3D(host, { fov: 42, bg: 0x1a1a2e });
    const { scene, camera, sun } = S;
    const ON = api.mp?.online, LOCAL2 = api.mp && !ON;
    const names = api.mp ? api.mp.names : ['Sen', 'Bilgisayar'];
    // kamera masayı üstten-eğik görür; dar ekranda masa dikey döner
    let portrait = true;
    S.onResize(() => {
      portrait = S.h > S.w;
      const span = portrait ? TW : TW * (S.h / S.w) * 1.9;
      const d = Math.max(7, span * 1.05 / Math.tan((camera.fov * Math.PI) / 360) / (portrait ? 1 : S.w / S.h) * 0.62);
      camera.position.set(0, d, d * 0.28); camera.up.set(portrait ? -1 : 0, 0, portrait ? 0 : -1); camera.lookAt(0, 0, 0);
    });
    sun.position.set(0, 14, 2); sun.shadow.camera.left = -6; sun.shadow.camera.right = 6; sun.shadow.camera.top = 4; sun.shadow.camera.bottom = -4;
    const lamp = new THREE.PointLight(0xfff3d0, 30, 20); lamp.position.set(0, 6, 0); scene.add(lamp);
    // masa
    const felt = new THREE.Mesh(new THREE.BoxGeometry(TW + 0.3, 0.2, TD + 0.3), mat(0x0f7a3d, { roughness: 0.95 })); felt.position.y = -0.1; felt.receiveShadow = true; scene.add(felt);
    const wood = mat(0x6b3410, { roughness: 0.5, metalness: 0.1 });
    const railH = 0.22;
    [[TW + 0.9, 0.45, 0, -TD / 2 - 0.3], [TW + 0.9, 0.45, 0, TD / 2 + 0.3]].forEach(([w, d, x, z]) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, railH, d), wood); m.position.set(x, railH / 2, z); m.castShadow = true; scene.add(m); });
    [[-TW / 2 - 0.3], [TW / 2 + 0.3]].forEach(([x]) => { const m = new THREE.Mesh(new THREE.BoxGeometry(0.45, railH, TD + 0.15), wood); m.position.set(x, railH / 2, 0); m.castShadow = true; scene.add(m); });
    const cushionMat = mat(0x0b6b33, { roughness: 0.9 });
    [[TW, 0.1, 0, -TD / 2 - 0.05], [TW, 0.1, 0, TD / 2 + 0.05]].forEach(([w, d, x, z]) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.12, d), cushionMat); m.position.set(x, 0.06, z); scene.add(m); });
    [[-TW / 2 - 0.05], [TW / 2 + 0.05]].forEach(([x]) => { const m = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.12, TD), cushionMat); m.position.set(x, 0.06, 0); scene.add(m); });
    POCKETS.forEach(([x, z]) => { const p = new THREE.Mesh(new THREE.CylinderGeometry(POCKET_R, POCKET_R, 0.22, 24), new THREE.MeshBasicMaterial({ color: 0x050505 })); p.position.set(x, 0.01, z); scene.add(p); });
    [-1, 1].forEach((s) => [0.25, 0.5, 0.75].forEach((f) => { const d = new THREE.Mesh(new THREE.CircleGeometry(0.04, 10), new THREE.MeshBasicMaterial({ color: 0xffffff })); d.rotation.x = -Math.PI / 2; d.position.set(-TW / 2 + TW * f, 0.12, s * (TD / 2 + 0.3)); scene.add(d); }));
    // toplar
    const ballGeo = new THREE.SphereGeometry(R, 28, 20);
    const meshes = {};
    for (let n = 0; n <= 15; n++) { const m = new THREE.Mesh(ballGeo, mat(0xffffff, { map: ballTexture(n), roughness: 0.15, metalness: 0.05 })); m.castShadow = true; scene.add(m); meshes[n] = m; }
    // ıstaka + nişan çizgisi
    const cue = new THREE.Group();
    const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.05, 4.2, 12), mat(0xd4a373)); stick.rotation.z = Math.PI / 2; stick.position.x = -2.1 - R - 0.05; cue.add(stick);
    const tip = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.026, 0.06, 12), mat(0x3a86ff)); tip.rotation.z = Math.PI / 2; tip.position.x = -R - 0.08; cue.add(tip);
    cue.position.y = R; scene.add(cue);
    const aimGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3(1, 0, 0)]);
    const aimLine = new THREE.Line(aimGeo, new THREE.LineDashedMaterial({ color: 0xffffff, dashSize: 0.12, gapSize: 0.08, transparent: true, opacity: 0.8 }));
    aimLine.position.y = R; scene.add(aimLine);
    const ghost = new THREE.Mesh(new THREE.RingGeometry(R * 0.85, R, 24), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7, side: THREE.DoubleSide })); ghost.rotation.x = -Math.PI / 2; ghost.position.y = 0.01; scene.add(ghost);
    const powerEl = document.createElement('div'); powerEl.className = 'bil-power'; powerEl.innerHTML = '<i></i>'; host.appendChild(powerEl);

    let balls, turn, groups, phase, aim, power, shotInfo, over, L, simSteps;
    function rack() {
      const order = [1, 9, 2, 10, 8, 3, 11, 7, 14, 4, 5, 13, 15, 6, 12];
      const out = [{ n: 0, x: -TW / 4, z: 0, vx: 0, vz: 0, in: false }];
      let k = 0;
      for (let row = 0; row < 5; row++) for (let i = 0; i <= row; i++) {
        out.push({ n: order[k++], x: TW / 4 + row * R * 1.75, z: (i - row / 2) * R * 2.02, vx: 0, vz: 0, in: false });
      }
      return out;
    }
    function start() {
      L = api.level; balls = rack(); turn = 0; groups = [null, null]; phase = 'aim'; aim = Math.PI; power = 0; over = false; shotInfo = null;
      aim = 0; hud(); maybeCpu();
    }
    const ball = (n) => balls.find((b) => b.n === n);
    const moving = () => balls.some((b) => !b.in && (Math.abs(b.vx) > 0.002 || Math.abs(b.vz) > 0.002));
    const isMine = () => (ON ? turn === ON.me : LOCAL2 ? true : turn === 0);
    function hud() {
      const g = groups[turn];
      const left = (grp) => balls.filter((b) => !b.in && groupOf(b.n) === grp).length;
      const label = g ? `${g === 'solid' ? '● Düz' : '◐ Çizgili'} (${left(g)} kaldı)` : 'Grup seçilmedi';
      api.setHud({ score: names[turn], scoreLabel: 'Sıra', extra: `${ON ? (isMine() ? 'Senin sıran' : names[turn] + ' oynuyor') : LOCAL2 ? 'Sıra: ' + names[turn] : turn === 0 ? 'Senin sıran' : 'Bilgisayar düşünüyor'} · ${label}` });
    }
    // ---- fizik (sabit adım: iki cihazda da aynı sonuca yakın) ----
    function step() {
      for (const b of balls) { if (b.in) continue; b.x += b.vx * DT; b.z += b.vz * DT; const f = Math.pow(FRICTION, DT * 60); b.vx *= f; b.vz *= f; if (Math.hypot(b.vx, b.vz) < 0.01) { b.vx = 0; b.vz = 0; } }
      for (let i = 0; i < balls.length; i++) {
        const a = balls[i]; if (a.in) continue;
        for (let j = i + 1; j < balls.length; j++) {
          const c = balls[j]; if (c.in) continue;
          const dx = c.x - a.x, dz = c.z - a.z, d = Math.hypot(dx, dz);
          if (d < 2 * R && d > 0) {
            const nx = dx / d, nz = dz / d, ov = (2 * R - d) / 2;
            a.x -= nx * ov; a.z -= nz * ov; c.x += nx * ov; c.z += nz * ov;
            const rel = (a.vx - c.vx) * nx + (a.vz - c.vz) * nz;
            if (rel > 0) { a.vx -= rel * nx; a.vz -= rel * nz; c.vx += rel * nx; c.vz += rel * nz; if (shotInfo && shotInfo.firstHit === null && (a.n === 0 || c.n === 0)) shotInfo.firstHit = a.n === 0 ? c.n : a.n; if (rel > 0.5) api.sfx.click(); }
          }
        }
        // delik
        for (const [px, pz] of POCKETS) if (Math.hypot(a.x - px, a.z - pz) < POCKET_R) { a.in = true; a.vx = a.vz = 0; shotInfo?.potted.push(a.n); api.sfx.pop(); break; }
        if (a.in) continue;
        // bant
        const hx = TW / 2 - R, hz = TD / 2 - R;
        if (a.x < -hx) { a.x = -hx; a.vx = Math.abs(a.vx) * CUSHION; } if (a.x > hx) { a.x = hx; a.vx = -Math.abs(a.vx) * CUSHION; }
        if (a.z < -hz) { a.z = -hz; a.vz = Math.abs(a.vz) * CUSHION; } if (a.z > hz) { a.z = hz; a.vz = -Math.abs(a.vz) * CUSHION; }
      }
    }
    function shoot(angle, pw, remote = false) {
      if (phase !== 'aim' || over) return;
      const c = ball(0);
      c.vx = Math.cos(angle) * pw * 9; c.vz = Math.sin(angle) * pw * 9;
      shotInfo = { firstHit: null, potted: [], shooter: turn, remote };
      phase = 'roll'; api.sfx.bounce(); api.haptic('medium');
      if (ON && !remote) ON.send({ shot: { a: angle, p: pw } });
    }
    // atış bitince kuralları uygula (atan oyuncunun cihazı karar verir ve sonucu gönderir)
    function resolve() {
      const { firstHit, potted, shooter } = shotInfo;
      const me = shooter, opp = 1 - shooter;
      let keep = false, foul = false, end = null, msg = '';
      const scratch = potted.includes(0);
      if (firstHit === null) { foul = true; msg = 'Hiçbir topa değmedi — faul'; }
      if (groups[me] && firstHit !== null && groupOf(firstHit) !== groups[me] && !(groupOf(firstHit) === 'eight' && myGroupCleared(me))) { foul = true; msg = 'Önce kendi topuna vurmalıydın — faul'; }
      if (scratch) { foul = true; msg = 'Beyaz top deliğe girdi — faul'; }
      const objs = potted.filter((n) => n !== 0 && n !== 8);
      if (!groups[me] && objs.length && !foul) { groups[me] = groupOf(objs[0]); groups[opp] = groups[me] === 'solid' ? 'stripe' : 'solid'; msg = `${names[me]}: ${groups[me] === 'solid' ? 'düz' : 'çizgili'} toplar`; }
      if (potted.includes(8)) {
        end = myGroupCleared(me, true) && !scratch ? me : opp;
        msg = end === me ? '8 numara! Kazandı 🎉' : '8 numara erken girdi — kaybetti';
      }
      if (!foul && objs.some((n) => groupOf(n) === groups[me])) keep = true;
      if (scratch) { const c = ball(0); c.in = false; c.x = -TW / 4; c.z = 0; c.vx = c.vz = 0; }
      const next = keep ? me : opp;
      return { next, groups: [...groups], end, msg };
    }
    function myGroupCleared(p, afterShot = false) { return groups[p] && balls.filter((b) => groupOf(b.n) === groups[p] && !b.in).length === 0; }
    function applyResult(res) {
      groups = res.groups; turn = res.next;
      if (res.msg) S.popText(new THREE.Vector3(0, 0.5, 0), res.msg, '#fff');
      phase = 'aim'; shotInfo = null; hud();
      if (res.end !== null && res.end !== undefined) finish(res.end);
      else maybeCpu();
    }
    function finish(winner) {
      over = true; phase = 'over';
      winner === (ON ? ON.me : 0) || LOCAL2 ? api.sfx.win() : api.sfx.lose();
      setTimeout(() => {
        if (api.mp) api.gameOver({ winner });
        else api.gameOver({ score: winner === 0 ? 300 + L * 40 + balls.filter((b) => b.in).length * 10 : balls.filter((b) => b.in && groupOf(b.n) === groups[0]).length * 30, coins: winner === 0 ? 12 + L * 2 : 2, win: winner === 0, title: winner === 0 ? 'Masayı temizledin! 🎱' : 'Bilgisayar kazandı' });
      }, 1200);
    }
    // ---- bilgisayar (tek kişilik): hedef top + delik seçer; seviye arttıkça isabeti artar ----
    function maybeCpu() {
      if (api.mp || over || turn !== 1) return;
      setTimeout(() => {
        if (over || phase !== 'aim') return;
        const c = ball(0), mine = groups[1];
        const targets = balls.filter((b) => !b.in && b.n !== 0 && (mine ? (groupOf(b.n) === mine || (groupOf(b.n) === 'eight' && myGroupCleared(1))) : b.n !== 8));
        let best = null;
        for (const t of targets) for (const [px, pz] of POCKETS) {
          const tx = t.x - px, tz = t.z - pz, td = Math.hypot(tx, tz);
          const gx = t.x + (tx / td) * 2 * R, gz = t.z + (tz / td) * 2 * R; // hayalet top konumu
          const ax = gx - c.x, az = gz - c.z, ad = Math.hypot(ax, az);
          const cut = Math.abs(Math.atan2(az, ax) - Math.atan2(pz - t.z, px - t.x));
          const score = -ad - td - Math.min(cut, Math.PI * 2 - cut) * 3;
          if (!best || score > best.score) best = { score, a: Math.atan2(az, ax), dist: ad + td };
        }
        const noise = Math.max(0.004, 0.09 - L * 0.012);
        const a = best ? best.a + (Math.random() - 0.5) * noise : Math.random() * Math.PI * 2;
        const pw = best ? Math.min(1, 0.35 + best.dist * 0.08) : 0.6;
        aim = a; shoot(a, pw);
      }, 900);
    }
    // ---- kontrol: sapan gibi çek-bırak ----
    let drag = null;
    S.el.addEventListener('pointerdown', (e) => {
      if (phase !== 'aim' || !isMine() || (!api.mp && turn !== 0)) return;
      const p = S.rayPlaneY(e, R); if (!p) return;
      drag = { sx: p.x, sz: p.z };
    });
    S.el.addEventListener('pointermove', (e) => {
      const p = S.rayPlaneY(e, R); if (!p || phase !== 'aim') return;
      const c = ball(0);
      if (drag) {
        const dx = c.x - p.x, dz = c.z - p.z, d = Math.hypot(dx, dz);
        if (d > 0.05) aim = Math.atan2(dz, dx);
        power = Math.min(1, Math.hypot(p.x - drag.sx, p.z - drag.sz) / 2.2);
      }
    });
    const up = () => { if (drag && power > 0.05) shoot(aim, power); drag = null; power = 0; };
    window.addEventListener('pointerup', up);
    let pendingState = null;
    ON?.on((m) => {
      if (m.shot) { aim = m.shot.a; shoot(m.shot.a, m.shot.p, true); }
      if (m.state) { pendingState = m.state; }
    });

    const lp = S.loop((dt) => {
      if (phase === 'roll') {
        simSteps = Math.round(dt / DT) || 1;
        for (let i = 0; i < simSteps; i++) step();
        if (!moving()) {
          if (shotInfo.remote) {
            // online: atan oyuncunun cihazındaki kesin sonucu bekle
            if (pendingState) { const st = pendingState; pendingState = null; st.balls.forEach((s, i) => Object.assign(balls[i], s)); applyResult(st.res); }
          } else {
            const res = resolve();
            if (ON) ON.send({ state: { balls: balls.map((b) => ({ n: b.n, x: b.x, z: b.z, in: b.in, vx: 0, vz: 0 })), res } });
            applyResult(res);
          }
        }
      }
      // görsel güncelleme
      for (const b of balls) {
        const m = meshes[b.n];
        m.visible = !b.in; m.position.set(b.x, R, b.z);
        const sp = Math.hypot(b.vx, b.vz);
        if (sp > 0) { const ax = new THREE.Vector3(b.vz, 0, -b.vx).normalize(); m.rotateOnWorldAxis(ax, (sp * dt) / R); }
      }
      const c = ball(0), showAim = phase === 'aim' && !over && (isMine() && (api.mp || turn === 0));
      cue.visible = phase === 'aim' && !over; aimLine.visible = showAim; ghost.visible = showAim;
      cue.position.set(c.x, R, c.z); cue.rotation.y = -aim; cue.children.forEach((ch) => (ch.position.x = (ch === stick ? -2.1 - R - 0.05 : -R - 0.08) - power * 0.8));
      if (showAim) {
        // ilk çarpılacak topu bul (basit ışın)
        let dist = 12, hitBall = null;
        const dx = Math.cos(aim), dz = Math.sin(aim);
        for (const b of balls) {
          if (b.in || b.n === 0) continue;
          const px = b.x - c.x, pz = b.z - c.z, t = px * dx + pz * dz; if (t <= 0) continue;
          const perp = Math.abs(px * dz - pz * dx); if (perp < 2 * R) { const back = Math.sqrt(4 * R * R - perp * perp); if (t - back < dist) { dist = t - back; hitBall = b; } }
        }
        if (!hitBall) { const tx = dx > 0 ? (TW / 2 - R - c.x) / dx : dx < 0 ? (-TW / 2 + R - c.x) / dx : 99, tz = dz > 0 ? (TD / 2 - R - c.z) / dz : dz < 0 ? (-TD / 2 + R - c.z) / dz : 99; dist = Math.min(tx, tz); }
        aimLine.position.set(c.x, R, c.z); aimLine.rotation.y = -aim; aimLine.scale.x = Math.max(0.01, dist); aimLine.computeLineDistances();
        ghost.position.set(c.x + dx * dist, 0.01, c.z + dz * dist);
      }
      powerEl.style.opacity = drag ? 1 : 0; powerEl.firstChild.style.height = `${power * 100}%`;
      S.updateParts(dt);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      restart() { start(); },
      destroy() { window.removeEventListener('pointerup', up); powerEl.remove(); S.destroy(); },
    };
  },
};
