// 🍉 Meyve Birleştir: meyveleri bırak, aynı iki meyve birleşip büyür
import { createStage, loop, particles } from '../core/canvas.js';

const TYPES = [
  { r: 13, c: '#e63946', n: 'Kiraz' }, { r: 17, c: '#ff70a6', n: 'Çilek' }, { r: 22, c: '#9d4edd', n: 'Üzüm' },
  { r: 27, c: '#ff9f1c', n: 'Mandalina' }, { r: 33, c: '#fb8500', n: 'Portakal' }, { r: 40, c: '#d00000', n: 'Elma' },
  { r: 47, c: '#e9c46a', n: 'Armut' }, { r: 55, c: '#ffafcc', n: 'Şeftali' }, { r: 64, c: '#ffd60a', n: 'Ananas' },
  { r: 74, c: '#80b918', n: 'Kavun' }, { r: 86, c: '#2d6a4f', n: 'Karpuz' },
];

export default {
  id: 'merge', title: 'Meyve Birleştir', emoji: '🍉', color: '#80b918',
  desc: 'Aynı meyveleri birleştir, karpuza ulaş!',
  target: (L) => Math.round(500 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let balls, next, nextNext, aimX, cooldown, score, over, dangerT, box, L, drops, k;

    function layout() {
      const w = Math.min(st.W - 24, 420) * Math.max(0.78, 1 - (api.level - 1) * 0.025); // seviyeyle kutu daralır
      k = w / 380;
      box = { x: (st.W - w) / 2, w, top: 110, bottom: st.H - 16, line: 150 };
    }
    // Zorluk: seviye arttıkça bırakılan meyveler daha karışık (daha büyük boyutlar da gelir)
    const randType = () => (Math.random() * Math.min(6, 3 + Math.floor((L + 1) / 3))) | 0;
    function start() {
      L = api.level; layout();
      balls = []; next = randType(); nextNext = randType(); aimX = st.W / 2; cooldown = 0; score = 0; over = false; dangerT = 0; drops = 0;
      hud();
    }
    function hud() { api.setHud({ score, extra: `Sıradaki: ${TYPES[nextNext].n}` }); }
    const rad = (t) => TYPES[t].r * k;
    function drop() {
      if (over || cooldown > 0) return;
      const r = rad(next);
      const x = Math.max(box.x + r, Math.min(box.x + box.w - r, aimX));
      drops++;
      // yüksek seviyede ara sıra birleşmeyen taş düşer (15 sn sonra kaybolur)
      const stoneEvery = Math.max(4, 13 - L);
      if (L >= 3 && drops % stoneEvery === 0) balls.push({ x: box.x + 20 + Math.random() * (box.w - 40), y: box.top - 20, vx: 0, vy: 0, t: -1, r: 22 * k, life: 15 });
      balls.push({ x, y: box.top - 10, vx: 0, vy: 0, t: next, r, born: 0 });
      next = nextNext; nextNext = randType(); cooldown = 0.55; api.sfx.tap(); hud();
    }
    st.canvas.addEventListener('pointerdown', (e) => { aimX = st.point(e).x; });
    st.canvas.addEventListener('pointermove', (e) => { aimX = st.point(e).x; });
    st.canvas.addEventListener('pointerup', (e) => { aimX = st.point(e).x; drop(); });

    function physics(dt) {
      const g = 1400 * k;
      for (const b of balls) { b.vy += g * dt; b.x += b.vx * dt; b.y += b.vy * dt; b.vx *= 0.995; if (b.born !== undefined) b.born += dt; }
      for (let it = 0; it < 5; it++) {
        for (const b of balls) {
          if (b.x - b.r < box.x) { b.x = box.x + b.r; b.vx *= -0.3; }
          if (b.x + b.r > box.x + box.w) { b.x = box.x + box.w - b.r; b.vx *= -0.3; }
          if (b.y + b.r > box.bottom) { b.y = box.bottom - b.r; b.vy *= -0.2; b.vx *= 0.9; }
        }
        for (let i = 0; i < balls.length; i++) for (let j = i + 1; j < balls.length; j++) {
          const a = balls[i], c = balls[j];
          const dx = c.x - a.x, dy = c.y - a.y, d = Math.hypot(dx, dy) || 0.01, min = a.r + c.r;
          if (d < min) {
            if (a.t === c.t && a.t >= 0 && !a.dead && !c.dead) { merge(a, c); continue; }
            const push = (min - d) / 2, nx = dx / d, ny = dy / d;
            a.x -= nx * push; a.y -= ny * push; c.x += nx * push; c.y += ny * push;
            const rv = (c.vx - a.vx) * nx + (c.vy - a.vy) * ny;
            if (rv < 0) { const imp = rv * 0.6; a.vx += nx * imp; a.vy += ny * imp; c.vx -= nx * imp; c.vy -= ny * imp; }
          }
        }
        balls = balls.filter((b) => !b.dead);
      }
    }
    function merge(a, c) {
      a.dead = c.dead = true;
      const t = a.t + 1;
      const x = (a.x + c.x) / 2, y = (a.y + c.y) / 2;
      fx.burst(x, y, TYPES[a.t].c, 12, 160);
      const pts = (a.t + 1) * (a.t + 2) * 2;
      score += pts; fx.text(x, y - 20, '+' + pts, '#fff');
      if (t < TYPES.length) { balls.push({ x, y, vx: (a.vx + c.vx) / 2, vy: Math.min(a.vy, c.vy) - 80, t, r: rad(t), born: 0 }); api.sfx.pop(); }
      else { score += 500; api.sfx.win(); fx.text(x, y - 40, 'KARPUZ! +500', '#ffd60a'); }
      if (t >= 6) api.haptic('medium');
      hud();
    }
    function update(dt) {
      if (!over) {
        if (cooldown > 0) cooldown -= dt;
        physics(dt);
        balls.forEach((b) => { if (b.t === -1) { b.life -= dt; if (b.life <= 0) { b.dead = true; fx.burst(b.x, b.y, '#6c757d', 10); } } });
        balls = balls.filter((b) => !b.dead);
        // tehlike: yerleşmiş meyve çizginin üstünde 2 sn kalırsa oyun biter
        const danger = balls.some((b) => b.born > 1.2 && b.y - b.r < box.line && Math.abs(b.vy) < 60);
        dangerT = danger ? dangerT + dt : Math.max(0, dangerT - dt * 2);
        if (dangerT > 2) {
          over = true; api.sfx.lose(); api.haptic('heavy');
          setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 50), canContinue: true, title: 'Kutu taştı! 🍉' }), 500);
        }
      }
      fx.update(dt); draw();
    }
    function fruit(c, x, y, r, t) {
      if (t === -1) {
        c.fillStyle = '#6c757d'; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill();
        c.fillStyle = '#495057'; c.beginPath(); c.arc(x + r * 0.3, y + r * 0.2, r * 0.3, 0, 7); c.fill(); return;
      }
      const T = TYPES[t];
      const g = c.createRadialGradient(x - r * 0.35, y - r * 0.35, r * 0.1, x, y, r);
      g.addColorStop(0, '#fff'); g.addColorStop(0.15, T.c); g.addColorStop(1, T.c);
      c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill();
      if (t === 10) { c.strokeStyle = '#95d5b2'; c.lineWidth = r * 0.12; for (let i = -2; i <= 2; i++) { c.beginPath(); c.ellipse(x + i * r * 0.35, y, r * 0.12, r * 0.95, 0, 0, 7); c.stroke(); } }
      c.fillStyle = 'rgba(0,0,0,.6)'; c.beginPath(); c.arc(x - r * 0.25, y - r * 0.05, r * 0.08, 0, 7); c.arc(x + r * 0.25, y - r * 0.05, r * 0.08, 0, 7); c.fill();
      c.strokeStyle = 'rgba(0,0,0,.6)'; c.lineWidth = Math.max(1.5, r * 0.06); c.beginPath(); c.arc(x, y + r * 0.12, r * 0.18, 0.2, Math.PI - 0.2); c.stroke();
      c.fillStyle = '#2d6a4f'; c.beginPath(); c.ellipse(x + r * 0.15, y - r, r * 0.22, r * 0.1, -0.5, 0, 7); c.fill();
    }
    function draw() {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H); g.addColorStop(0, '#fff3c4'); g.addColorStop(1, '#ffd6a5');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      c.fillStyle = '#e9b872'; c.fillRect(box.x - 8, box.top, 8, box.bottom - box.top + 8); c.fillRect(box.x + box.w, box.top, 8, box.bottom - box.top + 8); c.fillRect(box.x - 8, box.bottom, box.w + 16, 8);
      c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(box.x, box.top, box.w, box.bottom - box.top);
      c.strokeStyle = dangerT > 0 ? `rgba(239,35,60,${0.5 + Math.sin(performance.now() / 80) * 0.5})` : 'rgba(239,35,60,.35)';
      c.setLineDash([8, 6]); c.lineWidth = 2; c.beginPath(); c.moveTo(box.x, box.line); c.lineTo(box.x + box.w, box.line); c.stroke(); c.setLineDash([]);
      if (!over) {
        const r = rad(next), x = Math.max(box.x + r, Math.min(box.x + box.w - r, aimX));
        c.strokeStyle = 'rgba(0,0,0,.15)'; c.beginPath(); c.moveTo(x, box.top); c.lineTo(x, box.bottom); c.stroke();
        c.globalAlpha = cooldown > 0 ? 0.4 : 1; fruit(c, x, box.top - 30, r, next); c.globalAlpha = 1;
      }
      for (const b of balls) fruit(c, b.x, b.y, b.r, b.t);
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { balls.sort((a, b) => a.y - b.y); balls.splice(0, Math.ceil(balls.length / 3)); dangerT = 0; over = false; hud(); },
      restart() { start(); }, destroy() { lp.stop(); st.destroy(); },
    };
  },
};
