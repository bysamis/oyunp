// 🪢 Halat Çekme (2 kişi ya da 2'ye 2 takım): kendi tarafına olabildiğince hızlı dokun, halatı kendine çek!
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

export default {
  id: 'tug', title: 'Halat Çekme', emoji: '🪢', color: '#bc6c25',
  desc: 'Hızlı dokun, halatı kendi tarafına çek!',
  mpOnly: true, players: { min: 2, max: 4, allowed: [2, 4] },
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    const n = api.mp?.n || 2, names = api.mp?.names || ['Oyuncu 1', 'Oyuncu 2', 'Oyuncu 3', 'Oyuncu 4'];
    // takım A = alt (1. ve 3. oyuncu), takım B = üst (2. ve 4. oyuncu)
    const teamA = n === 4 ? `${names[0]} & ${names[2]}` : names[0];
    const teamB = n === 4 ? `${names[1]} & ${names[3]}` : names[1];
    let pos, phase, count, over, tapsA, tapsB, wobble, rate;

    function start() { pos = 0; phase = 'count'; count = 3.5; over = false; tapsA = 0; tapsB = 0; wobble = 0; rate = [0, 0]; hud(); }
    function hud() { api.setHud({ score: `${tapsA} - ${tapsB}`, scoreLabel: 'Dokunuş', extra: 'Halatı çizgiye kadar çek!' }); }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (phase !== 'go' || over) return;
      const p = st.point(e), bottom = p.y > st.H / 2;
      // her dokunuş halatı biraz çeker; yorgunluk yok ama hızlı olan kazanır
      pos += bottom ? 0.028 : -0.028;
      bottom ? (tapsA++, rate[0] += 1) : (tapsB++, rate[1] += 1);
      wobble = 0.15; api.sfx.tap(); api.haptic('light');
      fx.burst(p.x, p.y, bottom ? '#ef233c' : '#3a86ff', 4, 100);
      if (Math.abs(pos) >= 1) {
        over = true; phase = 'won'; api.sfx.win(); api.haptic('heavy');
        const winA = pos > 0;
        for (let i = 0; i < 4; i++) fx.burst(st.W / 2, winA ? st.H * 0.8 : st.H * 0.2, winA ? '#ef233c' : '#3a86ff', 20, 260);
        // 4 kişide kazanan takımın ilk oyuncusu gösterilir, başlıkta iki isim yazar
        setTimeout(() => api.gameOver({ winner: winA ? 0 : 1, title: `${winA ? teamA : teamB} kazandı! 🏆` }), 1200);
      }
      if ((tapsA + tapsB) % 4 === 0) hud();
    });
    function update(dt) {
      if (phase === 'count') {
        const b = Math.ceil(count); count -= dt;
        if (Math.ceil(count) !== b && count > 0) api.sfx.click();
        if (count <= 0) { phase = 'go'; api.sfx.power(); }
      }
      rate = rate.map((r) => r * Math.pow(0.2, dt));
      if (wobble > 0) wobble -= dt;
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx, W = st.W, H = st.H;
      c.fillStyle = '#ffb4a2'; c.fillRect(0, 0, W, H / 2);
      c.fillStyle = '#a8dadc'; c.fillRect(0, H / 2, W, H / 2);
      const g1 = c.createLinearGradient(0, 0, 0, H / 2); g1.addColorStop(0, '#3a86ff'); g1.addColorStop(1, 'rgba(58,134,255,.15)');
      c.fillStyle = g1; c.fillRect(0, 0, W, H / 2);
      const g2 = c.createLinearGradient(0, H / 2, 0, H); g2.addColorStop(0, 'rgba(239,35,60,.15)'); g2.addColorStop(1, '#ef233c');
      c.fillStyle = g2; c.fillRect(0, H / 2, W, H / 2);
      // kazanma çizgileri
      const span = H * 0.32, cy = H / 2;
      c.setLineDash([10, 8]); c.strokeStyle = '#fff'; c.lineWidth = 4;
      [cy - span, cy + span].forEach((y) => { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); });
      c.setLineDash([]);
      // halat
      const knotY = cy + pos * span + (wobble > 0 ? Math.sin(wobble * 80) * 3 : 0);
      c.strokeStyle = '#9c6644'; c.lineWidth = 14; c.lineCap = 'round';
      c.beginPath(); c.moveTo(W / 2, 10); c.lineTo(W / 2, H - 10); c.stroke();
      c.strokeStyle = '#ddb892'; c.lineWidth = 4; c.setLineDash([6, 10]);
      c.beginPath(); c.moveTo(W / 2 - 3, 10); c.lineTo(W / 2 - 3, H - 10); c.stroke(); c.setLineDash([]);
      c.fillStyle = '#ffd60a'; roundRect(c, W / 2 - 26, knotY - 12, 52, 24, 8); c.fill();
      c.fillStyle = '#5a2a00'; c.font = '900 13px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('★', W / 2, knotY + 1);
      // takım isimleri (üst takım ters yazı)
      const label = (txt, y, flip, r) => {
        c.save(); c.translate(W / 2, y); if (flip) c.rotate(Math.PI);
        c.fillStyle = '#fff'; c.font = '900 24px system-ui'; c.fillText(txt, 0, 0);
        c.font = '700 14px system-ui'; c.fillText(r > 3 ? '🔥 Çok hızlı!' : 'Hızlı hızlı dokun!', 0, 26);
        c.restore();
      };
      label(teamB, H * 0.1, true, rate[1]); label(teamA, H * 0.9, false, rate[0]);
      if (phase === 'count') {
        c.fillStyle = 'rgba(0,0,0,.45)'; c.fillRect(0, 0, W, H);
        c.fillStyle = '#fff'; c.font = '900 90px system-ui'; c.fillText(Math.max(1, Math.ceil(count - 0.5)), W / 2, H / 2);
      }
      c.textBaseline = 'alphabetic';
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
