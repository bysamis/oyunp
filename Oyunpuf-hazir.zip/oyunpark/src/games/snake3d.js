// 🐍 Yılan 3D: meyveleri ye, uzun ol, kendine ve duvarlara çarpma
import { create3D, mat, THREE } from '../core/three-stage.js';
import { touchpad } from '../core/touchpad.js';
import { expert, expertSteps } from '../core/expert.js';
import { boardKit, roundedBox } from '../core/board3d.js';
import { model } from '../core/assets.js';

const COLS = 15, ROWS = 21;

export default {
  id: 'snake', title: 'Yılan 3D', emoji: '🐍', color: '#38b000',
  desc: 'Meyveleri ye, uzun ol, kendine çarpma!',
  expertFrom: 12,
  target: (L) => Math.round(150 * Math.pow(1.4, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0x2d6a4f });
    const { scene, camera } = S;
    const K = boardKit(S, COLS, ROWS, { tilt: 0.38, height: 1 });
    // çimen tahta
    const base = new THREE.Mesh(roundedBox(COLS + 0.6, 0.6, ROWS + 0.6, 0.3), mat(0x6c584c)); base.position.y = -0.72; base.receiveShadow = true; scene.add(base);
    const tiles = new THREE.InstancedMesh(new THREE.BoxGeometry(0.98, 0.1, 0.98), mat(0xffffff, { roughness: 0.9 }), COLS * ROWS);
    tiles.receiveShadow = true; scene.add(tiles);
    const m4 = new THREE.Matrix4(), col = new THREE.Color();
    for (let r = 0, i = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++, i++) {
      m4.makeTranslation(K.x(c), -0.05, K.z(r)); tiles.setMatrixAt(i, m4);
      tiles.setColorAt(i, col.setHex((r + c) % 2 ? 0xa7c957 : 0x95b84a));
    }
    // yılan parçaları
    const segGeo = new THREE.SphereGeometry(0.45, 16, 12);
    const segMats = [mat(0x38b000, { roughness: 0.35 }), mat(0x70e000, { roughness: 0.35 })];
    const head = new THREE.Group(); scene.add(head);
    const hm = new THREE.Mesh(new THREE.SphereGeometry(0.52, 20, 14), mat(0x2b9348, { roughness: 0.3 })); hm.scale.set(1, 0.85, 1.15); hm.castShadow = true; head.add(hm);
    for (const s of [-1, 1]) {
      const e = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffffff })); e.position.set(s * 0.22, 0.28, 0.3); head.add(e);
      const p = new THREE.Mesh(new THREE.SphereGeometry(0.075, 8, 6), new THREE.MeshBasicMaterial({ color: 0x111111 })); p.position.set(s * 0.22, 0.3, 0.43); head.add(p);
    }
    const tongue = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.02, 0.3), mat(0xef233c)); tongue.position.set(0, 0, 0.65); head.add(tongue);
    const body = new THREE.Group(); scene.add(body);
    const wallGroup = new THREE.Group(); scene.add(wallGroup);
    // yem
    const food3 = new THREE.Group(); scene.add(food3);
    const apple = new THREE.Group();
    const am = new THREE.Mesh(new THREE.SphereGeometry(0.42, 18, 14), mat(0xff4d6d, { roughness: 0.3 })); am.castShadow = true; apple.add(am);
    const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), mat(0x2d6a4f)); leaf.scale.set(1.8, 0.4, 0.9); leaf.position.set(0.1, 0.4, 0); apple.add(leaf);
    food3.add(apple);
    let goldM = null; model('coin', { height: 0.75, glow: 0xffb703 }).then((m) => { goldM = m; food3.add(m); m.visible = false; }).catch(() => {});
    let wallTpl = null; model('brick', { size: 0.95 }).then((m) => { wallTpl = m; buildWalls(); }).catch(() => {});

    let snake, prev, dir, nextDir, food, score, acc, over, grow, eaten, walls = [], L, interval = 0.16;
    function buildWalls() {
      wallGroup.clear();
      for (const w of walls) {
        const b = wallTpl ? wallTpl.clone() : new THREE.Mesh(roundedBox(0.92, 0.9, 0.92, 0.1), mat(0x6c584c));
        b.position.set(K.x(w.x), 0, K.z(w.y)); b.castShadow = true; wallGroup.add(b);
      }
    }
    function start() {
      snake = [{ x: 7, y: 12 }, { x: 7, y: 13 }, { x: 7, y: 14 }]; prev = snake.map((s) => ({ ...s }));
      L = api.level; walls = [];
      for (let i = 0; i < Math.min((L - 1) * 3, 30) + Math.min(20, expertSteps(L, 11) * 2); i++) { // uzman: daha çok duvar
        const w = { x: (Math.random() * COLS) | 0, y: (Math.random() * ROWS) | 0 };
        if (w.x !== 7 && !walls.some((o) => o.x === w.x && o.y === w.y)) walls.push(w);
      }
      buildWalls();
      dir = { x: 0, y: -1 }; nextDir = dir; score = 0; acc = 0; over = false; grow = 0; eaten = 0; head.visible = true;
      placeFood(); hud();
    }
    function hud() { api.setHud({ score, extra: `Uzunluk ${snake.length}` }); }
    function placeFood() {
      do { food = { x: (Math.random() * COLS) | 0, y: (Math.random() * ROWS) | 0, gold: Math.random() < 0.12 }; }
      while (snake.some((s) => s.x === food.x && s.y === food.y) || walls.some((s) => s.x === food.x && s.y === food.y));
      food3.position.set(K.x(food.x), 0.45, K.z(food.y)); food3.scale.setScalar(0.01);
      apple.visible = !food.gold || !goldM; if (goldM) goldM.visible = food.gold;
    }
    function turn(dx, dy) { if (over) return; if (dx === -dir.x && dy === -dir.y) return; nextDir = { x: dx, y: dy }; }
    let down = null;
    S.el.addEventListener('pointerdown', (e) => { down = { x: e.clientX, y: e.clientY }; });
    S.el.addEventListener('pointerup', (e) => {
      if (!down) return;
      const dx = e.clientX - down.x, dy = e.clientY - down.y;
      if (Math.hypot(dx, dy) < 15) {
        // dokunulan yer başın hangi tarafında?
        const v = head.position.clone().project(camera), r = S.el.getBoundingClientRect();
        const hx = r.left + (v.x + 1) / 2 * r.width, hy = r.top + (1 - v.y) / 2 * r.height;
        if (dir.x !== 0) turn(0, Math.sign(e.clientY - hy) || 1); else turn(Math.sign(e.clientX - hx) || 1, 0);
      } else if (Math.abs(dx) > Math.abs(dy)) turn(Math.sign(dx), 0);
      else turn(0, Math.sign(dy));
      down = null;
    });
    const onKey = (e) => { const k = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0] }[e.key]; if (k) turn(...k); };
    window.addEventListener('keydown', onKey);
    const pad = touchpad(host, { dpad: true, onPress: (id) => ({ up: () => turn(0, -1), down: () => turn(0, 1), left: () => turn(-1, 0), right: () => turn(1, 0) })[id]() });

    function step() {
      prev = snake.map((s) => ({ ...s }));
      dir = nextDir;
      const h = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };
      if (h.x < 0 || h.y < 0 || h.x >= COLS || h.y >= ROWS || snake.some((s) => s.x === h.x && s.y === h.y) || walls.some((s) => s.x === h.x && s.y === h.y)) {
        over = true; api.sfx.crash(); api.haptic('heavy');
        S.burst(K.pos(snake[0].x, snake[0].y, 0.5), 0x38b000, 24, 6);
        setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 15), canContinue: true }), 600);
        return;
      }
      snake.unshift(h);
      if (h.x === food.x && h.y === food.y) {
        const pts = food.gold ? 50 : 10; score += pts; eaten++; grow += food.gold ? 3 : 1;
        api.sfx[food.gold ? 'coin' : 'pop'](); api.haptic('light');
        const p = K.pos(h.x, h.y, 0.6);
        S.burst(p, food.gold ? 0xffd60a : 0xff4d6d, 12, 5, 0.6); S.popText(p, '+' + pts);
        placeFood(); hud();
      }
      if (grow > 0) { grow--; prev.push({ ...prev[prev.length - 1] }); } else snake.pop();
      while (prev.length < snake.length) prev.push({ ...prev[prev.length - 1] });
    }
    function syncBody(k) {
      while (body.children.length < snake.length - 1) { const m = new THREE.Mesh(segGeo, segMats[body.children.length % 2]); m.castShadow = true; body.add(m); }
      while (body.children.length > snake.length - 1) body.remove(body.children[body.children.length - 1]);
      snake.forEach((s, i) => {
        const p = prev[i] || s;
        const x = K.x(p.x + (s.x - p.x) * k), z = K.z(p.y + (s.y - p.y) * k);
        if (i === 0) { head.position.set(x, 0.5, z); }
        else { const m = body.children[i - 1]; m.position.set(x, 0.45, z); m.scale.setScalar(1 - (i / (snake.length + 8)) * 0.45); }
      });
    }

    const lp = S.loop((dt, t) => {
      if (!over) {
        acc += dt;
        interval = Math.max(0.045, 0.16 - (L - 1) * 0.013 - eaten * 0.003);
        while (acc >= interval) { acc -= interval; step(); if (over) break; }
      }
      const k = over ? 1 : Math.min(1, acc / interval);
      syncBody(k);
      const ang = Math.atan2(dir.x, dir.y);
      let dA = ang - head.rotation.y; while (dA > Math.PI) dA -= Math.PI * 2; while (dA < -Math.PI) dA += Math.PI * 2;
      head.rotation.y += dA * Math.min(1, dt * 18);
      tongue.visible = Math.sin(t * 6) > 0.3;
      food3.scale.lerp(new THREE.Vector3(1, 1, 1), Math.min(1, dt * 8));
      food3.rotation.y += dt * 2; food3.position.y = 0.45 + Math.sin(t * 4) * 0.08;
      S.updateParts(dt, 0);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() {
        const len = Math.max(3, Math.floor(snake.length / 2));
        snake = Array.from({ length: len }, (_, i) => ({ x: 7, y: Math.min(ROWS - 1, 8 + i) })); prev = snake.map((s) => ({ ...s }));
        dir = nextDir = { x: 0, y: -1 }; over = false; acc = 0; hud();
      },
      restart() { start(); },
      destroy() { pad.destroy(); S.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
