// 🎈 Balon Patlat (küçükler için de kolay; 3 balon kaçırınca biter)
import { createStage, loop, shade, particles } from '../core/canvas.js';

const COLS = ['#ff4d6d', '#ff9f1c', '#ffd60a', '#2dc653', '#3a86ff', '#b15cff', '#ff70a6'];

export default {
  id: 'balloon', title: 'Balon Patlat', emoji: '🎈', color: '#ff70a6',
  desc: 'Balonlar uçmadan dokun ve patlat!',
  target: (L) => Math.round(250 * Math.pow(1.4, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let balloons, score, missed, spawnIn, elapsed, over, streak, L;
    const S = () => Math.min(st.W, 500) / 400;

    function start() { L = api.level; balloons = []; score = 0; missed = 0; spawnIn = 0; elapsed = 0; over = false; streak = 0; hud(); }
    function hud() { api.setHud({ score, extra: `${'❤️'.repeat(3 - missed)}${'🤍'.repeat(missed)}  ·  Seri ${streak}` }); }

    function spawn() {
      const r = (Math.max(15, 26 - L * 1.4) + Math.random() * 14) * S();
      const special = Math.random();
      balloons.push({
        x: r + Math.random() * (st.W - r * 2), y: st.H + r * 2, r,
        vy: (70 + L * 16 + Math.random() * 40 + elapsed * (2.2 + L * 0.5)) * S(),
        sway: Math.random() * 6, color: COLS[(Math.random() * COLS.length) | 0],
        kind: special < 0.06 ? 'gold' : special < Math.max(0.08, 0.12 - L * 0.01) ? 'bomb' : 'normal',
      });
      spawnIn = Math.max(0.16, 0.95 - L * 0.07 - elapsed * 0.012);
    }

    const onDown = (e) => {
      if (over) return;
      const p = st.point(e);
      for (let i = balloons.length - 1; i >= 0; i--) {
        const b = balloons[i];
        if (Math.hypot(p.x - b.x, p.y - b.y) < b.r * 1.25) {
          balloons.splice(i, 1);
          if (b.kind === 'bomb') {
            // bomba: ekrandaki tüm balonları patlatır
            api.sfx.crash(); api.haptic('heavy');
            for (const o of balloons) { score += 5; fx.burst(o.x, o.y, o.color, 10); }
            fx.text(b.x, b.y, 'BUM! 💥', '#fff');
            balloons.length = 0;
          } else {
            streak++;
            const pts = (b.kind === 'gold' ? 50 : 10) + Math.min(streak, 20);
            score += pts;
            api.sfx.pop(); api.haptic('light');
            if (b.kind === 'gold') api.sfx.coin();
            fx.text(b.x, b.y - b.r, '+' + pts, b.kind === 'gold' ? '#ffd60a' : '#fff');
          }
          fx.burst(b.x, b.y, b.kind === 'gold' ? '#ffd60a' : b.color, 16, 200);
          hud();
          return;
        }
      }
      streak = 0; hud();
    };
    st.canvas.addEventListener('pointerdown', onDown);

    function update(dt, t) {
      if (!over) {
        elapsed += dt;
        spawnIn -= dt; if (spawnIn <= 0) spawn();
        for (let i = balloons.length - 1; i >= 0; i--) {
          const b = balloons[i];
          b.y -= b.vy * dt;
          b.x += Math.sin(t * 2 + b.sway) * 20 * dt;
          if (b.y < -b.r * 2) {
            balloons.splice(i, 1);
            if (b.kind !== 'bomb') {
              missed++; streak = 0; api.sfx.wrong(); api.haptic('medium'); hud();
              if (missed >= 3) {
                over = true; api.sfx.lose();
                api.gameOver({ score, coins: Math.floor(score / 30), canContinue: true, title: 'Balonlar kaçtı! 🎈' });
              }
            }
          }
        }
      }
      fx.update(dt);
      draw(t);
    }

    function draw(t) {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H);
      g.addColorStop(0, '#8ecae6'); g.addColorStop(1, '#e0fbfc');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      // bulutlar
      c.fillStyle = 'rgba(255,255,255,.85)';
      for (let i = 0; i < 4; i++) {
        const x = ((i * 170 + t * 12) % (st.W + 200)) - 100, y = 60 + i * (st.H / 4.5);
        c.beginPath(); c.arc(x, y, 26, 0, 7); c.arc(x + 30, y - 10, 32, 0, 7); c.arc(x + 62, y, 24, 0, 7); c.fill();
      }
      for (const b of balloons) {
        // ip
        c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 1.5;
        c.beginPath(); c.moveTo(b.x, b.y + b.r * 1.15);
        c.quadraticCurveTo(b.x + Math.sin(t * 3 + b.sway) * 8, b.y + b.r * 1.8, b.x, b.y + b.r * 2.5); c.stroke();
        const col = b.kind === 'gold' ? '#ffc300' : b.kind === 'bomb' ? '#2b2d42' : b.color;
        const bg = c.createRadialGradient(b.x - b.r * 0.35, b.y - b.r * 0.4, b.r * 0.1, b.x, b.y, b.r * 1.2);
        bg.addColorStop(0, shade(col, 90)); bg.addColorStop(0.5, col); bg.addColorStop(1, shade(col, -50));
        c.fillStyle = bg;
        c.beginPath(); c.ellipse(b.x, b.y, b.r, b.r * 1.15, 0, 0, 7); c.fill();
        c.beginPath(); c.moveTo(b.x - 5, b.y + b.r * 1.2); c.lineTo(b.x + 5, b.y + b.r * 1.2); c.lineTo(b.x, b.y + b.r * 1.08); c.fill();
        c.fillStyle = 'rgba(255,255,255,.5)';
        c.beginPath(); c.ellipse(b.x - b.r * 0.35, b.y - b.r * 0.45, b.r * 0.18, b.r * 0.3, -0.5, 0, 7); c.fill();
        if (b.kind !== 'normal') {
          c.fillStyle = '#fff'; c.font = `900 ${b.r * 0.8}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle';
          c.fillText(b.kind === 'gold' ? '★' : '✸', b.x, b.y + 2); c.textBaseline = 'alphabetic';
        }
      }
      fx.draw(c);
    }

    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { missed = 2; over = false; balloons.length = 0; hud(); },
      restart() { start(); },
      destroy() { lp.stop(); st.destroy(); },
    };
  },
};
