// ⚫ Dama 3D: rakip taşlarını ye, kral ol, kazan
import { create3D, mat, THREE } from '../core/three-stage.js';
import { boardKit, roundedBox } from '../core/board3d.js';

const N = 8;
// taşlar: 1 = oyuncu (beyaz, aşağıdan yukarı), 2 = bilgisayar; kral: 3 / 4
const own = (v, p) => v && ((v - 1) % 2) + 1 === p;
const isKing = (v) => v >= 3;

function movesFor(b, p) {
  const caps = [], steps = [];
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    const v = b[r][c]; if (!own(v, p)) continue;
    const dirs = isKing(v) ? [[1, 1], [1, -1], [-1, 1], [-1, -1]] : p === 1 ? [[-1, 1], [-1, -1]] : [[1, 1], [1, -1]];
    // çoklu yeme zincirlerini bul
    const chain = (bb, rr, cc, path, eaten) => {
      let found = false;
      const vv = bb[rr][cc];
      const ds = isKing(vv) ? [[1, 1], [1, -1], [-1, 1], [-1, -1]] : dirs;
      for (const [dr, dc] of ds) {
        const mr = rr + dr, mc = cc + dc, tr = rr + dr * 2, tc = cc + dc * 2;
        if (tr < 0 || tr >= N || tc < 0 || tc >= N) continue;
        const mid = bb[mr][mc];
        if (mid && !own(mid, p) && !bb[tr][tc] && !eaten.some(([a, b2]) => a === mr && b2 === mc)) {
          found = true;
          const nb = bb.map((row) => row.slice());
          nb[tr][tc] = nb[rr][cc]; nb[rr][cc] = 0; nb[mr][mc] = 0;
          chain(nb, tr, tc, [...path, [tr, tc]], [...eaten, [mr, mc]]);
        }
      }
      if (!found && path.length > 1) caps.push({ from: path[0], path: path.slice(1), eaten });
    };
    chain(b, r, c, [[r, c]], []);
    for (const [dr, dc] of dirs) {
      const tr = r + dr, tc = c + dc;
      if (tr >= 0 && tr < N && tc >= 0 && tc < N && !b[tr][tc]) steps.push({ from: [r, c], path: [[tr, tc]], eaten: [] });
    }
  }
  return caps.length ? caps : steps; // yeme zorunlu
}
function apply(b, m) {
  const nb = b.map((row) => row.slice());
  const [fr, fc] = m.from, [tr, tc] = m.path[m.path.length - 1];
  let v = nb[fr][fc]; nb[fr][fc] = 0;
  m.eaten.forEach(([r, c]) => (nb[r][c] = 0));
  if (v === 1 && tr === 0) v = 3; if (v === 2 && tr === N - 1) v = 4;
  nb[tr][tc] = v;
  return nb;
}
function score(b) {
  let s = 0;
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    const v = b[r][c]; if (!v) continue;
    const val = isKing(v) ? 3 : 1 + (own(v, 2) ? r : N - 1 - r) * 0.05;
    s += own(v, 2) ? val : -val;
  }
  return s;
}
function search(b, depth, alpha, beta, p) {
  const ms = movesFor(b, p);
  if (!ms.length) return p === 2 ? -100 - depth : 100 + depth;
  if (depth === 0) return score(b);
  if (p === 2) { let best = -Infinity; for (const m of ms) { best = Math.max(best, search(apply(b, m), depth - 1, alpha, beta, 1)); alpha = Math.max(alpha, best); if (alpha >= beta) break; } return best; }
  let best = Infinity; for (const m of ms) { best = Math.min(best, search(apply(b, m), depth - 1, alpha, beta, 2)); beta = Math.min(beta, best); if (alpha >= beta) break; } return best;
}

export default {
  id: 'checkers', title: 'Dama 3D', emoji: '⚫', color: '#6f4518',
  desc: 'Rakip taşlarını ye, kral ol, kazan!',
  winBased: true, players: { min: 2, max: 2 }, online: { min: 2, max: 2 },
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0x582f0e });
    const { scene } = S;
    let b, turn, sel, legal, over, L, anim, eatenByMe, moveCount, dirty = true;
    const ON = api.mp?.online, flip = !!(ON && ON.me === 1), inbox = [];
    ON?.on((m) => inbox.push(m));
    const samePath = (a, b) => JSON.stringify(a) === JSON.stringify(b);
    const depth = () => Math.min(5, L);
    const mistake = () => Math.max(0, 0.4 - (L - 1) * 0.1);
    function count(p) { let n = 0; b.forEach((row) => row.forEach((v) => own(v, p) && n++)); return n; }
    function hud() { api.setHud({ score: eatenByMe, scoreLabel: 'Yenen', extra: over ? '' : ON ? `${turn === ON.me + 1 ? 'Senin sıran' : api.mp.names[turn - 1] + ' düşünüyor…'} ${turn === 1 ? '⚪' : '⚫'} · ${count(1)} - ${count(2)}` : api.mp ? `Sıra: ${api.mp.names[turn - 1]} ${turn === 1 ? '⚪' : '⚫'} · ${count(1)} - ${count(2)}` : turn === 1 ? `Senin sıran · ⚪ ${count(1)} - ${count(2)} ⚫` : 'Bilgisayar düşünüyor…' }); }
    const K = boardKit(S, N, N, { tilt: 0.45, height: 0.8, yaw: flip ? Math.PI : 0 });
    // tahta
    const frame = new THREE.Mesh(roundedBox(N + 1, 0.5, N + 1, 0.3), mat(0x6f4518, { roughness: 0.6 })); frame.position.y = -0.62; frame.receiveShadow = true; frame.castShadow = true; scene.add(frame);
    const sq = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 0.1, 1), mat(0xffffff, { roughness: 0.6 }), N * N); sq.receiveShadow = true;
    const m4 = new THREE.Matrix4(), col = new THREE.Color();
    for (let r = 0, i = 0; r < N; r++) for (let c = 0; c < N; c++, i++) { m4.makeTranslation(K.x(c), -0.1, K.z(r)); sq.setMatrixAt(i, m4); sq.setColorAt(i, col.setHex((r + c) % 2 ? 0x8b5e34 : 0xf3d5b5)); }
    scene.add(sq);
    const pieceGeo = new THREE.CylinderGeometry(0.4, 0.42, 0.22, 32);
    const ringGeo = new THREE.TorusGeometry(0.28, 0.03, 8, 24);
    const whiteM = mat(0xf8f9fa, { roughness: 0.3 }), blackM = mat(0x212529, { roughness: 0.3 }), goldM = mat(0xffc300, { metalness: 0.7, roughness: 0.25, emissive: 0x7a5c00, emissiveIntensity: 0.3 });
    function pieceMesh(v) {
      const g = new THREE.Group(), white = own(v, 1);
      const p = new THREE.Mesh(pieceGeo, white ? whiteM : blackM); p.position.y = 0.11; p.castShadow = true; g.add(p);
      const ring = new THREE.Mesh(ringGeo, white ? blackM : whiteM); ring.rotation.x = Math.PI / 2; ring.position.y = 0.225; g.add(ring);
      if (isKing(v)) {
        const p2 = new THREE.Mesh(pieceGeo, white ? whiteM : blackM); p2.position.y = 0.33; p2.castShadow = true; g.add(p2);
        const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.18, 0.16, 6, 1, true), goldM); crown.position.y = 0.52; g.add(crown);
        for (let i = 0; i < 6; i++) { const s = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.12, 6), goldM); const a = (i / 6) * Math.PI * 2; s.position.set(Math.cos(a) * 0.2, 0.64, Math.sin(a) * 0.2); g.add(s); }
      }
      return g;
    }
    const pieces = new THREE.Group(); scene.add(pieces);
    const marks = new THREE.Group(); scene.add(marks);
    const markGeo = new THREE.CircleGeometry(0.2, 20), markMat = new THREE.MeshBasicMaterial({ color: 0x2dc653, transparent: true, opacity: 0.85 });
    const selRing = new THREE.Mesh(new THREE.RingGeometry(0.44, 0.52, 32), new THREE.MeshBasicMaterial({ color: 0xffd60a })); selRing.rotation.x = -Math.PI / 2; scene.add(selRing);
    const mustMat = new THREE.MeshBasicMaterial({ color: 0xff4d6d });
    let animMesh = null;
    function rebuild() {
      pieces.clear();
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (b[r][c]) { const m = pieceMesh(b[r][c]); m.position.copy(K.pos(c, r, 0)); pieces.add(m); }
      dirty = false;
    }
    function start() {
      inbox.length = 0;
      L = api.level;
      b = Array.from({ length: N }, (_, r) => Array.from({ length: N }, (_, c) => ((r + c) % 2 === 1 ? (r < 3 ? 2 : r > 4 ? 1 : 0) : 0)));
      turn = 1; sel = null; over = false; anim = null; eatenByMe = 0; moveCount = 0; dirty = true;
      legal = movesFor(b, 1); hud();
    }
    function doMove(m, p) {
      const before = count(p === 1 ? 2 : 1);
      anim = { m, t: 0, v: b[m.from[0]][m.from[1]] };
      b[m.from[0]][m.from[1]] = 0; dirty = true;
      setTimeout(() => {
        b[m.from[0]][m.from[1]] = anim.v; b = apply(b, m); anim = null;
        m.eaten.forEach(([r, c]) => S.burst(K.pos(c, r, 0.3), p === 1 ? 0x333333 : 0xffffff, 12, 5, 0.6));
        dirty = true;
        if (m.eaten.length) { api.sfx.pop(); api.haptic('medium'); } else api.sfx.slide();
        if (p === 1) { eatenByMe += before - count(2); moveCount++; }
        turn = p === 1 ? 2 : 1;
        legal = movesFor(b, turn);
        hud();
        if (!legal.length) return finish(turn === 2);
        if (turn === 2 && !api.mp) setTimeout(ai, 250);
      }, 180 * m.path.length);
    }
    function ai() {
      const ms = movesFor(b, 2);
      let pick = ms[(Math.random() * ms.length) | 0];
      if (Math.random() >= mistake()) {
        let best = -Infinity;
        for (const m of ms) { const s = search(apply(b, m), depth() - 1, -Infinity, Infinity, 1) + Math.random() * 0.01; if (s > best) { best = s; pick = m; } }
      }
      doMove(pick, 2);
    }
    function finish(iWon) {
      over = true; hud();
      iWon ? api.sfx.win() : api.sfx.lose();
      const score = iWon ? 300 + count(1) * 30 + L * 40 : eatenByMe * 15;
      if (api.mp) { setTimeout(() => api.gameOver({ winner: iWon ? 0 : 1 }), 900); return; }
      setTimeout(() => api.gameOver({ score, coins: iWon ? 10 + L * 2 : 2, win: iWon, title: iWon ? 'Damayı kazandın! 👑' : 'Bilgisayar kazandı ⚫' }), 900);
    }
    S.el.addEventListener('pointerdown', (e) => {
      if (over || (turn !== 1 && !api.mp) || anim || (ON && turn !== ON.me + 1)) return;
      const cell = K.cellAt(e, 0); if (!cell) return;
      const r = cell.r, c = cell.c;
      if (own(b[r][c], turn)) {
        if (legal.some((m) => m.from[0] === r && m.from[1] === c)) { sel = [r, c]; api.sfx.click(); }
        else { api.sfx.wrong(); if (legal[0]?.eaten.length) api.setHud({ extra: 'Yeme zorunlu! Yiyebilen taşı seç' }); }
        return;
      }
      if (sel) {
        const m = legal.find((m) => m.from[0] === sel[0] && m.from[1] === sel[1] && m.path[m.path.length - 1][0] === r && m.path[m.path.length - 1][1] === c);
        if (m) { sel = null; ON?.send({ f: m.from, p: m.path }); doMove(m, turn); } else api.sfx.wrong();
      }
    });
    const lp = S.loop((dt, t) => {
      if (ON && inbox.length && !anim && !over) {
        const mv = inbox.shift();
        const m = legal.find((x) => x.from[0] === mv.f[0] && x.from[1] === mv.f[1] && samePath(x.path, mv.p));
        if (m) doMove(m, turn);
      }
      if (dirty) rebuild();
      // hamle animasyonu (zıplayarak)
      if (anim) {
        anim.t += dt;
        if (!animMesh || animMesh.userData.v !== anim.v) { if (animMesh) scene.remove(animMesh); animMesh = pieceMesh(anim.v); animMesh.userData.v = anim.v; scene.add(animMesh); }
        const pts = [anim.m.from, ...anim.m.path], seg = Math.min(pts.length - 2, Math.floor(anim.t / 0.18)), k = Math.min(1, (anim.t - seg * 0.18) / 0.18);
        const a = pts[seg], z = pts[seg + 1];
        animMesh.position.set(K.x(a[1] + (z[1] - a[1]) * k), Math.sin(k * Math.PI) * 0.6, K.z(a[0] + (z[0] - a[0]) * k)); animMesh.visible = true;
      } else if (animMesh) animMesh.visible = false;
      // işaretler
      marks.clear();
      const myTurn = !over && (turn === 1 || api.mp) && (!ON || turn === ON.me + 1);
      selRing.visible = !!sel && !over;
      if (sel && !over) {
        selRing.position.copy(K.pos(sel[1], sel[0], 0.25 + Math.sin(t * 6) * 0.02));
        legal.filter((m) => m.from[0] === sel[0] && m.from[1] === sel[1]).forEach((m) => { const [r, c] = m.path[m.path.length - 1]; const d = new THREE.Mesh(markGeo, markMat); d.rotation.x = -Math.PI / 2; d.position.copy(K.pos(c, r, -0.04)); marks.add(d); });
      } else if (myTurn && legal[0]?.eaten.length) {
        legal.forEach((m) => { const d = new THREE.Mesh(new THREE.RingGeometry(0.44, 0.5, 24), mustMat); d.rotation.x = -Math.PI / 2; d.position.copy(K.pos(m.from[1], m.from[0], 0.24)); marks.add(d); });
      }
      S.updateParts(dt, 0);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { S.destroy(); } };
  },
};
