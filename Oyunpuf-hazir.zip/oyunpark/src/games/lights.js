// 💡 Işıkları Söndür: bir kareye dokununca kendisi ve 4 komşusu tersine döner. Hepsini söndür!
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

export default {
  id: 'lights', title: 'Işıkları Söndür', emoji: '💡', color: '#ffb703',
  desc: 'Tüm ışıkları söndür, az hamleyle!',
  winBased: true,
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    let n, grid, glow, moves, limit, over, cs, ox, oy, L, scramble;

    function layout() {
      if (!n) return;
      const size = Math.min(st.W - 32, st.H - 100, 480);
      cs = size / n; ox = (st.W - size) / 2; oy = (st.H - size) / 2 + 20;
    }
    function toggle(r, c) {
      [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([dr, dc]) => {
        const rr = r + dr, cc = c + dc;
        if (rr >= 0 && rr < n && cc >= 0 && cc < n) { grid[rr * n + cc] ^= 1; glow[rr * n + cc] = 1; }
      });
    }
    function start() {
      L = api.level;
      n = Math.min(7, 3 + Math.floor((L + 1) / 2));      // 3x3 → 7x7
      scramble = Math.min(n * n, 3 + L * 2);             // çözümdeki tıklama sayısı
      grid = Array(n * n).fill(0); glow = Array(n * n).fill(0);
      // çözümden geriye doğru karıştır → her zaman çözülebilir
      const picks = new Set();
      while (picks.size < scramble) picks.add((Math.random() * n * n) | 0);
      picks.forEach((i) => toggle((i / n) | 0, i % n));
      glow.fill(0);
      if (grid.every((v) => !v)) return start();
      // hamle sınırı: seviye arttıkça neredeyse en iyi çözüm kadar
      limit = scramble + Math.max(2, 12 - L);
      moves = 0; over = false; layout(); hud();
    }
    function hud() { api.setHud({ score: limit - moves, scoreLabel: 'Kalan hamle', extra: `${n}×${n} · Yanan: ${grid.filter(Boolean).length}` }); }

    st.canvas.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = st.point(e), c = Math.floor((p.x - ox) / cs), r = Math.floor((p.y - oy) / cs);
      if (c < 0 || c >= n || r < 0 || r >= n) return;
      toggle(r, c); moves++; api.sfx.click(); api.haptic('light'); hud();
      if (grid.every((v) => !v)) {
        over = true; api.sfx.win();
        for (let i = 0; i < 5; i++) fx.burst(ox + Math.random() * cs * n, oy + Math.random() * cs * n, '#ffd60a', 16, 200);
        const score = Math.max(50, (limit - moves) * 40 + n * 60);
        setTimeout(() => api.gameOver({ score, coins: 10 + n * 4, win: true, title: 'Karanlık oldu! 🌙' }), 800);
      } else if (moves >= limit) {
        over = true; api.sfx.lose();
        setTimeout(() => api.gameOver({ score: Math.max(0, (n * n - grid.filter(Boolean).length) * 5), coins: 3, title: 'Hamleler bitti! 💡' }), 500);
      }
    });

    function update(dt) { for (let i = 0; i < glow.length; i++) glow[i] = Math.max(0, glow[i] - dt * 4); fx.update(dt); draw(); }
    function draw() {
      const c = st.ctx;
      c.fillStyle = '#14213d'; c.fillRect(0, 0, st.W, st.H);
      c.fillStyle = 'rgba(255,255,255,.7)'; c.font = '700 14px system-ui'; c.textAlign = 'center';
      c.fillText('Dokunduğun kare ve 4 komşusu değişir', st.W / 2, oy - 18);
      for (let i = 0; i < n * n; i++) {
        const x = ox + (i % n) * cs, y = oy + ((i / n) | 0) * cs, on = grid[i];
        roundRect(c, x + 4, y + 4, cs - 8, cs - 8, 12);
        c.fillStyle = on ? '#ffd60a' : '#2b3a67';
        if (on) { c.shadowColor = '#ffd60a'; c.shadowBlur = 20; }
        c.fill(); c.shadowBlur = 0;
        if (glow[i] > 0) { c.fillStyle = `rgba(255,255,255,${glow[i] * 0.4})`; c.fill(); }
      }
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
