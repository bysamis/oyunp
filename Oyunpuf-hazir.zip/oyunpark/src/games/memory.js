// 🃏 Hafıza Kartları
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

const SYMBOLS = [
  ['#ff4d6d', 'heart'], ['#ff9f1c', 'sun'], ['#ffd60a', 'star'], ['#2dc653', 'tree'], ['#3a86ff', 'drop'],
  ['#9d4edd', 'moon'], ['#ff70a6', 'flower'], ['#06d6a0', 'fish'], ['#ef233c', 'apple'], ['#118ab2', 'cloud'],
];

function drawSym(c, kind, color, x, y, r) {
  c.save(); c.translate(x, y); c.fillStyle = color; c.strokeStyle = color; c.lineWidth = r * 0.18; c.lineCap = 'round';
  c.beginPath();
  switch (kind) {
    case 'heart': c.moveTo(0, r * 0.8); c.bezierCurveTo(-r * 1.3, -r * 0.1, -r * 0.6, -r * 1.1, 0, -r * 0.4); c.bezierCurveTo(r * 0.6, -r * 1.1, r * 1.3, -r * 0.1, 0, r * 0.8); c.fill(); break;
    case 'sun': c.arc(0, 0, r * 0.5, 0, 7); c.fill(); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; c.beginPath(); c.moveTo(Math.cos(a) * r * 0.68, Math.sin(a) * r * 0.68); c.lineTo(Math.cos(a) * r * 0.95, Math.sin(a) * r * 0.95); c.stroke(); } break;
    case 'star': for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.42 : r; i ? c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr) : c.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); } c.fill(); break;
    case 'tree': c.moveTo(0, -r); c.lineTo(r * 0.75, r * 0.4); c.lineTo(-r * 0.75, r * 0.4); c.fill(); c.fillStyle = '#6f4518'; c.fillRect(-r * 0.15, r * 0.4, r * 0.3, r * 0.5); break;
    case 'drop': c.moveTo(0, -r); c.quadraticCurveTo(r * 0.9, r * 0.1, 0, r * 0.85); c.quadraticCurveTo(-r * 0.9, r * 0.1, 0, -r); c.fill(); break;
    case 'moon': c.arc(0, 0, r * 0.8, 0, 7); c.fill(); c.globalCompositeOperation = 'destination-out'; c.beginPath(); c.arc(r * 0.4, -r * 0.2, r * 0.65, 0, 7); c.fill(); c.globalCompositeOperation = 'source-over'; break;
    case 'flower': for (let i = 0; i < 5; i++) { const a = i * Math.PI * 0.4; c.beginPath(); c.arc(Math.cos(a) * r * 0.45, Math.sin(a) * r * 0.45, r * 0.38, 0, 7); c.fill(); } c.fillStyle = '#ffd60a'; c.beginPath(); c.arc(0, 0, r * 0.3, 0, 7); c.fill(); break;
    case 'fish': c.ellipse(-r * 0.1, 0, r * 0.65, r * 0.42, 0, 0, 7); c.fill(); c.beginPath(); c.moveTo(r * 0.45, 0); c.lineTo(r * 0.95, -r * 0.4); c.lineTo(r * 0.95, r * 0.4); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.arc(-r * 0.4, -r * 0.08, r * 0.1, 0, 7); c.fill(); break;
    case 'apple': c.arc(-r * 0.3, r * 0.1, r * 0.55, 0, 7); c.arc(r * 0.3, r * 0.1, r * 0.55, 0, 7); c.fill(); c.fillStyle = '#2d6a4f'; c.beginPath(); c.ellipse(r * 0.2, -r * 0.65, r * 0.25, r * 0.12, -0.5, 0, 7); c.fill(); break;
    case 'cloud': c.arc(-r * 0.4, r * 0.1, r * 0.4, 0, 7); c.arc(0, -r * 0.2, r * 0.5, 0, 7); c.arc(r * 0.45, r * 0.1, r * 0.4, 0, 7); c.fill(); c.fillRect(-r * 0.4, r * 0.1, r * 0.85, r * 0.4); break;
  }
  c.restore();
}

export default {
  id: 'memory', title: 'Hafıza Kartları', emoji: '🃏', color: '#06d6a0',
  desc: 'Kartları çevir, eşleri bul!',
  winBased: true,
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    let L, roundTime, level, cols, rows, cards, open, lock, moves, found, time, score, cw, ch, ox, oy, done;

    function layout() {
      if (!cols) return;
      const gap = 8;
      cw = Math.min((st.W - 24 - gap * (cols - 1)) / cols, ((st.H - 24 - gap * (rows - 1)) / rows) / 1.25);
      ch = cw * 1.25;
      ox = (st.W - (cw * cols + gap * (cols - 1))) / 2; oy = (st.H - (ch * rows + gap * (rows - 1))) / 2;
      cards?.forEach((k, i) => { k.x = ox + (i % cols) * (cw + gap); k.y = oy + ((i / cols) | 0) * (ch + gap); });
    }
    function setup() {
      const sizes = [[3, 4], [4, 4], [4, 5]];
      [cols, rows] = sizes[Math.min(level - 1 + Math.floor((L - 1) / 2), 2)];
      roundTime = L >= 2 ? Math.max(18, 75 - L * 7 + cols * rows) : Infinity;
      const pairs = (cols * rows) / 2;
      const syms = SYMBOLS.slice().sort(() => Math.random() - 0.5).slice(0, pairs);
      const deck = [...syms, ...syms].sort(() => Math.random() - 0.5);
      cards = deck.map((s) => ({ sym: s, flip: 0, target: 0, matched: false }));
      open = []; lock = false; found = 0; done = false;
      layout(); hud();
      // başlangıçta kısa önizleme
      cards.forEach((k) => (k.target = 1)); lock = true;
      setTimeout(() => { cards.forEach((k) => (k.target = 0)); lock = false; }, Math.max(350, 1100 + level * 300 - L * 180));
    }
    function start() { L = api.level; level = 1; moves = 0; time = 0; score = 0; setup(); }
    function hud() { api.setHud({ score, extra: `Tur ${level}/3 · Hamle ${moves}` + (roundTime < Infinity ? ` · ⏱ ${Math.ceil(Math.max(0, roundTime))}` : '') }); }

    const onDown = (e) => {
      if (lock || done) return;
      const p = st.point(e);
      const k = cards.find((k) => p.x > k.x && p.x < k.x + cw && p.y > k.y && p.y < k.y + ch);
      if (!k || k.matched || k.target === 1) return;
      k.target = 1; open.push(k); api.sfx.click(); api.haptic('light');
      if (open.length === 2) {
        moves++; lock = true; hud();
        const [a, b] = open;
        if (a.sym === b.sym) {
          setTimeout(() => {
            a.matched = b.matched = true; found++; score += 50 + level * 10;
            api.sfx.pop();
            [a, b].forEach((k) => fx.burst(k.x + cw / 2, k.y + ch / 2, k.sym[0], 14));
            open = []; lock = false; hud();
            if (found === cards.length / 2) roundDone();
          }, 350);
        } else {
          setTimeout(() => { a.target = b.target = 0; open = []; lock = false; api.sfx.wrong(); }, 800);
        }
      }
    };
    st.canvas.addEventListener('pointerdown', onDown);

    function roundDone() {
      api.sfx.win();
      if (level < 3) { level++; fx.text(st.W / 2, st.H / 2, `Tur ${level}!`, '#ffd60a'); setTimeout(setup, 900); }
      else {
        done = true;
        score += Math.max(0, 600 - Math.floor(time) * 3);
        setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 20), win: true, title: 'Süper hafıza! 🧠' }), 600);
      }
    }

    function update(dt) {
      if (!done) {
        time += dt;
        if (roundTime < Infinity && !lock) {
          const before = Math.ceil(roundTime); roundTime -= dt;
          if (Math.ceil(roundTime) !== before) hud();
          if (roundTime <= 0) { done = true; api.sfx.lose(); api.gameOver({ score, coins: Math.floor(score / 30), title: 'Süre doldu! ⏰' }); }
        }
      }
      for (const k of cards) k.flip += (k.target - k.flip) * Math.min(1, dt * 14);
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H);
      g.addColorStop(0, '#80ffdb'); g.addColorStop(1, '#5390d9');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      for (const k of cards) {
        const sx = Math.abs(Math.cos(k.flip * Math.PI));
        const face = k.flip > 0.5;
        const cx = k.x + cw / 2;
        c.save(); c.translate(cx, k.y + ch / 2); c.scale(Math.max(0.02, sx), 1);
        roundRect(c, -cw / 2, -ch / 2, cw, ch, 12);
        if (face) { c.fillStyle = k.matched ? '#e9fff5' : '#fff'; c.fill(); drawSym(c, k.sym[1], k.sym[0], 0, 0, cw * 0.3); }
        else {
          const bg = c.createLinearGradient(0, -ch / 2, 0, ch / 2);
          bg.addColorStop(0, '#7400b8'); bg.addColorStop(1, '#5e60ce'); c.fillStyle = bg; c.fill();
          c.fillStyle = 'rgba(255,255,255,.25)'; c.font = `900 ${cw * 0.4}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('?', 0, 2);
        }
        c.restore();
        if (k.matched) { c.globalAlpha = 0.3; c.fillStyle = '#2dc653'; roundRect(c, k.x, k.y, cw, ch, 12); c.fill(); c.globalAlpha = 1; }
      }
      fx.draw(c);
    }

    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
