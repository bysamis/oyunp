// 🧺 Meyve Yakala 3D: sepeti kaydır, meyveleri yakala, bombalardan kaç
import { create3D, mat, THREE } from '../core/three-stage.js';
import { touchpad } from '../core/touchpad.js';
import { model } from '../core/assets.js';

const FW = 8, TOP = 13, BY = 0.7;
const FRUITS = ['apple', 'banana', 'orange', 'grape', 'pear'];
const FCOL = { apple: 0xef233c, banana: 0xffc300, orange: 0xfb8500, grape: 0x7209b7, pear: 0x9ef01a };

export default {
  id: 'catcher', title: 'Meyve Yakala 3D', emoji: '🧺', color: '#fb8500',
  desc: 'Meyveleri yakala, bombalardan kaç!',
  target: (L) => Math.round(300 * Math.pow(1.38, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 50, bg: 0xffd6a5, fog: [0xffd6a5, 25, 60] });
    const { scene, camera } = S;
    // bahçe
    const grass = new THREE.Mesh(new THREE.PlaneGeometry(80, 60), mat(0x90be6d)); grass.rotation.x = -Math.PI / 2; grass.receiveShadow = true; scene.add(grass);
    const path = new THREE.Mesh(new THREE.PlaneGeometry(FW + 2, 4), mat(0xddb892)); path.rotation.x = -Math.PI / 2; path.position.y = 0.01; path.receiveShadow = true; scene.add(path);
    const fence = new THREE.Group(); scene.add(fence);
    for (let x = -20; x <= 20; x += 1.2) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.25, 1.4, 0.12), mat(0xfefae0)); p.position.set(x, 0.7, -6); p.castShadow = true; fence.add(p); }
    const rail = new THREE.Mesh(new THREE.BoxGeometry(40, 0.15, 0.1), mat(0xfefae0)); rail.position.set(0, 0.9, -6); fence.add(rail);
    // ağaçlar (meyveler buradan düşüyor gibi)
    for (const [x, z, s] of [[-7, -9, 1.4], [6.5, -10, 1.6], [-2, -14, 1.8], [11, -6, 1.2], [-12, -7, 1.3]]) {
      const t = new THREE.Group(); t.position.set(x, 0, z); t.scale.setScalar(s); scene.add(t);
      const tr = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.35, 2.4, 8), mat(0x7f5539)); tr.position.y = 1.2; tr.castShadow = true; t.add(tr);
      [[0, 3.2, 0, 1.6], [-0.9, 2.7, 0.3, 1.1], [0.9, 2.8, -0.2, 1.2]].forEach(([a, b, c, r]) => { const l = new THREE.Mesh(new THREE.IcosahedronGeometry(r, 1), mat(0x52b788, { flatShading: true })); l.position.set(a, b, c); l.castShadow = true; t.add(l); });
    }
    // sepet
    const basket = new THREE.Group(); scene.add(basket);
    const bMat = mat(0xb5835a, { roughness: 0.9 });
    function buildBasket(w) {
      basket.clear();
      const r = w / 2;
      const shell = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 0.8, 0.8, 24, 1, true), new THREE.MeshStandardMaterial({ color: 0xb5835a, side: THREE.DoubleSide, roughness: 0.9 })); shell.position.y = 0.4; shell.castShadow = true; basket.add(shell);
      for (let i = 0; i < 4; i++) { const ring = new THREE.Mesh(new THREE.TorusGeometry(r * (0.8 + i * 0.065), 0.04, 6, 32), mat(0x7f5539)); ring.rotation.x = Math.PI / 2; ring.position.y = 0.1 + i * 0.22; basket.add(ring); }
      const bottom = new THREE.Mesh(new THREE.CircleGeometry(r * 0.8, 24), bMat); bottom.rotation.x = -Math.PI / 2; bottom.position.y = 0.02; basket.add(bottom);
      const handle = new THREE.Mesh(new THREE.TorusGeometry(r * 0.9, 0.06, 6, 24, Math.PI), mat(0x7f5539)); handle.position.y = 0.8; basket.add(handle);
    }
    // meyve modelleri
    function fruitMesh(kind) {
      const g = new THREE.Group();
      if (kind === 'bomb') {
        const b = new THREE.Mesh(new THREE.SphereGeometry(0.42, 18, 12), mat(0x222222, { metalness: 0.4, roughness: 0.3 })); g.add(b);
        const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.15, 10), mat(0x555555)); cap.position.y = 0.45; g.add(cap);
        const spark = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffb703 })); spark.position.y = 0.62; g.add(spark); g.userData.spark = spark;
        const skull = new THREE.Mesh(new THREE.CircleGeometry(0.16, 16), new THREE.MeshBasicMaterial({ color: 0xffffff })); skull.position.set(0, 0.05, 0.41); g.add(skull);
      } else if (kind === 'banana') {
        const b = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.12, 8, 16, Math.PI * 0.9), mat(FCOL.banana)); b.rotation.z = Math.PI * 1.05; g.add(b);
      } else if (kind === 'grape') {
        [[0, 0.25, 0], [-0.17, 0.08, 0.05], [0.17, 0.08, 0.05], [0, 0.08, -0.15], [-0.09, -0.1, 0.05], [0.09, -0.1, 0.05], [0, -0.26, 0]].forEach(([x, y, z]) => { const s = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), mat(FCOL.grape, { roughness: 0.3 })); s.position.set(x, y, z); g.add(s); });
      } else if (kind === 'pear') {
        const lo = new THREE.Mesh(new THREE.SphereGeometry(0.34, 16, 12), mat(FCOL.pear)); lo.position.y = -0.08; g.add(lo);
        const hi = new THREE.Mesh(new THREE.SphereGeometry(0.22, 16, 12), mat(FCOL.pear)); hi.position.y = 0.24; g.add(hi);
      } else {
        const s = new THREE.Mesh(new THREE.SphereGeometry(0.36, 18, 14), mat(FCOL[kind], { roughness: 0.35 })); s.scale.y = 0.92; g.add(s);
      }
      if (kind !== 'bomb' && kind !== 'banana') {
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.18), mat(0x5c4033)); stem.position.y = 0.42; g.add(stem);
        const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), mat(0x2d6a4f)); leaf.scale.set(1.6, 0.4, 0.8); leaf.position.set(0.1, 0.46, 0); g.add(leaf);
      }
      g.traverse((o) => { if (o.isMesh) o.castShadow = true; });
      return g;
    }
    let coinTpl = null; model('coin', { height: 1, glow: 0xffb703 }).then((m) => (coinTpl = m)).catch(() => {});

    const itemGroup = new THREE.Group(); scene.add(itemGroup);
    let bx, bw, items, score, missed, spawnIn, elapsed, over, L, combo;
    function start() {
      L = api.level; bw = Math.max(60, 110 - L * 5) / 50; bx = 0; buildBasket(bw);
      itemGroup.clear(); items = []; score = 0; missed = 0; spawnIn = 0.5; elapsed = 0; over = false; combo = 0; hud();
    }
    function hud() { api.setHud({ score, extra: `Kaçan: ${missed}/5 · Kombo ${combo}` }); }
    function spawn() {
      const bomb = Math.random() < Math.min(0.35, 0.12 + L * 0.025 + elapsed * 0.002);
      const gold = !bomb && Math.random() < 0.06;
      const kind = bomb ? 'bomb' : FRUITS[(Math.random() * FRUITS.length) | 0];
      const m = gold ? (coinTpl ? coinTpl.clone() : fruitMesh('orange')) : fruitMesh(kind);
      const it = { x: (Math.random() - 0.5) * (FW - 0.8), y: TOP, vy: (140 + L * 22 + elapsed * (3 + L * 0.6)) / 50, vx: L >= 4 ? (Math.random() - 0.5) * 1.6 : 0, bomb, gold, kind, m, spin: (Math.random() - 0.5) * 6 };
      if (!gold) m.scale.setScalar(1.35);
      itemGroup.add(m); items.push(it);
      spawnIn = Math.max(0.2, 0.8 - L * 0.05 - elapsed * 0.01);
    }
    const move = (e) => { const p = S.rayPlaneZ(e, 0); if (p) bx = Math.max(-FW / 2 + bw / 2, Math.min(FW / 2 - bw / 2, p.x)); };
    S.el.addEventListener('pointerdown', move);
    S.el.addEventListener('pointermove', move);
    const onKey = (e) => { if (e.key === 'ArrowLeft') bx -= 0.6; if (e.key === 'ArrowRight') bx += 0.6; bx = Math.max(-FW / 2 + bw / 2, Math.min(FW / 2 - bw / 2, bx)); };
    window.addEventListener('keydown', onKey);
    const pad = touchpad(host, { left: [{ id: 'left', icon: '◀', big: true }], right: [{ id: 'right', icon: '▶', big: true }] });
    S.onResize(() => {
      const vfov = (camera.fov * Math.PI) / 180, a = S.w / S.h;
      const dist = Math.max((TOP / 2 + 1.5) / Math.tan(vfov / 2), (FW / 2 + 0.8) / (Math.tan(vfov / 2) * a));
      camera.position.set(0, TOP / 2 + 1.2, dist); camera.lookAt(0, TOP / 2 - 0.3, 0);
    });

    function end(title) { over = true; api.sfx.lose(); api.gameOver({ score, coins: Math.floor(score / 25), canContinue: true, title }); }
    const lp = S.loop((dt, t) => {
      if (!over) {
        elapsed += dt; spawnIn -= dt; if (spawnIn <= 0) spawn();
        for (const it of items) {
          const prevY = it.y;
          it.y -= it.vy * dt; it.x += it.vx * dt;
          if (it.x < -FW / 2 + 0.3 || it.x > FW / 2 - 0.3) it.vx *= -1;
          if (prevY >= BY + 0.2 && it.y < BY + 0.2 && Math.abs(it.x - bx) < bw / 2) {
            it.dead = true;
            const p = new THREE.Vector3(it.x, BY + 0.6, 0);
            if (it.bomb) { S.burst(p, 0x333333, 30, 9); S.burst(p, 0xff7b00, 20, 7); api.sfx.crash(); api.haptic('heavy'); basket.visible = false; end('Bomba yakaladın! 💣'); break; }
            combo++; const pts = (it.gold ? 50 : 10) + Math.min(combo, 15);
            score += pts; api.sfx[it.gold ? 'coin' : 'pop'](); api.haptic('light');
            S.popText(p.clone().setY(BY + 1.5), '+' + pts, it.gold ? '#ffd60a' : '#fff'); S.burst(p, it.gold ? 0xffd60a : FCOL[it.kind] || 0xffffff, 8, 4, 0.6);
            basket.scale.set(1.15, 0.85, 1.15); hud();
          } else if (it.y < -0.5) {
            it.dead = true;
            if (!it.bomb) { missed++; combo = 0; api.sfx.wrong(); S.burst(new THREE.Vector3(it.x, 0.2, 0), FCOL[it.kind] || 0xffd60a, 6, 3, 0.6); hud(); if (missed >= 5) { end('Çok meyve kaçtı! 🍎'); break; } }
          }
        }
        items = items.filter((i) => { if (i.dead) itemGroup.remove(i.m); return !i.dead; });
      }
      for (const it of items) {
        it.m.position.set(it.x, it.y, 0);
        it.m.rotation.y += dt * (it.gold ? 4 : it.spin); if (!it.gold) it.m.rotation.z += dt * it.spin * 0.4;
        if (it.m.userData.spark) it.m.userData.spark.scale.setScalar(0.8 + Math.sin(t * 30) * 0.4);
      }
      if (pad.held.left || pad.held.right) bx = Math.max(-FW / 2 + bw / 2, Math.min(FW / 2 - bw / 2, bx + (pad.held.left ? -1 : 1) * 9 * dt));
      basket.position.x += (bx - basket.position.x) * Math.min(1, dt * 20);
      basket.scale.lerp(new THREE.Vector3(1, 1, 1), Math.min(1, dt * 10));
      S.updateParts(dt, 0);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { missed = Math.min(missed, 3); itemGroup.clear(); items = []; over = false; basket.visible = true; hud(); },
      restart() { basket.visible = true; start(); },
      destroy() { pad.destroy(); S.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
