// 🃏 Hafıza Kartları 3D: kartları çevir, eşleri bul
import { create3D, mat, THREE } from '../core/three-stage.js';
import { expert, expertSteps } from '../core/expert.js';
import { boardKit, roundedBox } from '../core/board3d.js';

const SYMBOLS = [
  ['#ff4d6d', 'heart'], ['#ff9f1c', 'sun'], ['#ffd60a', 'star'], ['#2dc653', 'tree'], ['#3a86ff', 'drop'],
  ['#9d4edd', 'moon'], ['#ff70a6', 'flower'], ['#06d6a0', 'fish'], ['#ef233c', 'apple'], ['#118ab2', 'cloud'],
];

function drawSym(c, kind, color, x, y, r) {
  c.save(); c.translate(x, y); c.fillStyle = color; c.strokeStyle = color; c.lineWidth = r * 0.18; c.lineCap = 'round';
  c.beginPath();
  switch (kind) {
    case 'heart': c.moveTo(0, r * 0.8); c.bezierCurveTo(-r * 1.3, -r * 0.1, -r * 0.6, -r * 1.1, 0, -r * 0.4); c.bezierCurveTo(r * 0.6, -r * 1.1, r * 1.3, -r * 0.1, 0, r * 0.8); c.fill(); break;
    case 'sun': c.arc(0, 0, r * 0.5, 0, 7); c.fill(); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; c.beginPath(); c.moveTo(Math.cos(a) * r * 0.68, Math.sin(a) * r * 0.68); c.lineTo(Math.cos(a) * r * 0.95, Math.sin(a) * r * 0.95); c.stroke(); } break;
    case 'star': for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.42 : r; i ? c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr) : c.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); } c.fill(); break;
    case 'tree': c.moveTo(0, -r); c.lineTo(r * 0.75, r * 0.4); c.lineTo(-r * 0.75, r * 0.4); c.fill(); c.fillStyle = '#6f4518'; c.fillRect(-r * 0.15, r * 0.4, r * 0.3, r * 0.5); break;
    case 'drop': c.moveTo(0, -r); c.quadraticCurveTo(r * 0.9, r * 0.1, 0, r * 0.85); c.quadraticCurveTo(-r * 0.9, r * 0.1, 0, -r); c.fill(); break;
    case 'moon': c.arc(0, 0, r * 0.8, 0, 7); c.fill(); c.globalCompositeOperation = 'destination-out'; c.beginPath(); c.arc(r * 0.4, -r * 0.2, r * 0.65, 0, 7); c.fill(); c.globalCompositeOperation = 'source-over'; break;
    case 'flower': for (let i = 0; i < 5; i++) { const a = i * Math.PI * 0.4; c.beginPath(); c.arc(Math.cos(a) * r * 0.45, Math.sin(a) * r * 0.45, r * 0.38, 0, 7); c.fill(); } c.fillStyle = '#ffd60a'; c.beginPath(); c.arc(0, 0, r * 0.3, 0, 7); c.fill(); break;
    case 'fish': c.ellipse(-r * 0.1, 0, r * 0.65, r * 0.42, 0, 0, 7); c.fill(); c.beginPath(); c.moveTo(r * 0.45, 0); c.lineTo(r * 0.95, -r * 0.4); c.lineTo(r * 0.95, r * 0.4); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.arc(-r * 0.4, -r * 0.08, r * 0.1, 0, 7); c.fill(); break;
    case 'apple': c.arc(-r * 0.3, r * 0.1, r * 0.55, 0, 7); c.arc(r * 0.3, r * 0.1, r * 0.55, 0, 7); c.fill(); c.fillStyle = '#2d6a4f'; c.beginPath(); c.ellipse(r * 0.2, -r * 0.65, r * 0.25, r * 0.12, -0.5, 0, 7); c.fill(); break;
    case 'cloud': c.arc(-r * 0.4, r * 0.1, r * 0.4, 0, 7); c.arc(0, -r * 0.2, r * 0.5, 0, 7); c.arc(r * 0.45, r * 0.1, r * 0.4, 0, 7); c.fill(); c.fillRect(-r * 0.4, r * 0.1, r * 0.85, r * 0.4); break;
  }
  c.restore();
}


const faceTex = {};
function symTexture(sym) {
  const key = sym[1]; if (faceTex[key]) return faceTex[key];
  const cv = document.createElement('canvas'); cv.width = 200; cv.height = 250;
  const c = cv.getContext('2d');
  c.fillStyle = '#ffffff'; c.fillRect(0, 0, 200, 250);
  c.strokeStyle = sym[0]; c.lineWidth = 8; c.strokeRect(10, 10, 180, 230);
  const cv2 = document.createElement('canvas'); cv2.width = 200; cv2.height = 250;
  drawSym(cv2.getContext('2d'), sym[1], sym[0], 100, 125, 62); c.drawImage(cv2, 0, 0);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  t.center.set(0.5, 0.5); t.rotation = Math.PI; // kart çevrilince düz görünsün
  return (faceTex[key] = t);
}
let backTex = null;
function backTexture() {
  if (backTex) return backTex;
  const cv = document.createElement('canvas'); cv.width = 200; cv.height = 250; const c = cv.getContext('2d');
  const g = c.createLinearGradient(0, 0, 0, 250); g.addColorStop(0, '#7400b8'); g.addColorStop(1, '#5e60ce'); c.fillStyle = g; c.fillRect(0, 0, 200, 250);
  c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 6; c.strokeRect(14, 14, 172, 222);
  c.fillStyle = 'rgba(255,255,255,.9)'; c.font = '900 90px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('?', 100, 130);
  backTex = new THREE.CanvasTexture(cv); backTex.colorSpace = THREE.SRGBColorSpace; return backTex;
}

export default {
  id: 'memory', title: 'Hafıza Kartları 3D', emoji: '🃏', color: '#06d6a0',
  desc: 'Kartları çevir, eşleri bul!',
  expertFrom: 12,
  winBased: true,
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0x5390d9 });
    const { scene } = S;
    const table = new THREE.Mesh(new THREE.BoxGeometry(30, 0.4, 30), mat(0x2d6a4f, { roughness: 0.95 })); table.position.y = -0.2; table.receiveShadow = true; scene.add(table);
    const cardGroup = new THREE.Group(); scene.add(cardGroup);
    const CW = 1, CH = 1.25, GAP = 0.15;
    const bodyGeo = roundedBox(CW, 0.06, CH, 0.08);
    const planeGeo = new THREE.PlaneGeometry(CW * 0.94, CH * 0.94);
    let K = null;
    let L, roundTime, level, cols, rows, cards, open, lock, moves, found, time, score, done;
    function setup() {
      const sizes = [[3, 4], [4, 4], [4, 5]];
      [cols, rows] = sizes[Math.min(level - 1 + Math.floor((L - 1) / 2), 2)];
      roundTime = L >= 2 ? Math.max(18, 75 - L * 7 + cols * rows) / (1 + (expert(L, 11) - 1) * 0.6) : Infinity;
      const pairs = (cols * rows) / 2;
      const syms = SYMBOLS.slice().sort(() => Math.random() - 0.5).slice(0, pairs);
      const deck = [...syms, ...syms].sort(() => Math.random() - 0.5);
      cardGroup.clear();
      K = boardKitFor(cols, rows);
      cards = deck.map((s, i) => {
        const g = new THREE.Group();
        const body = new THREE.Mesh(bodyGeo, mat(0xffffff, { roughness: 0.5 })); body.castShadow = true; g.add(body);
        const back = new THREE.Mesh(planeGeo, new THREE.MeshStandardMaterial({ map: backTexture(), roughness: 0.6 })); back.rotation.x = -Math.PI / 2; back.position.y = 0.061; g.add(back);
        const face = new THREE.Mesh(planeGeo, new THREE.MeshStandardMaterial({ map: symTexture(s), roughness: 0.6 })); face.rotation.x = Math.PI / 2; face.position.y = -0.001; g.add(face);
        const c = i % cols, r = (i / cols) | 0;
        g.position.copy(K.pos(c, r, 0)); g.userData.deal = -i * 0.04; g.scale.setScalar(0.01);
        cardGroup.add(g);
        return { sym: s, flip: 0, target: 0, matched: false, g, c, r };
      });
      open = []; lock = false; found = 0; done = false;
      hud();
      cards.forEach((k) => (k.target = 1)); lock = true;
      setTimeout(() => { cards.forEach((k) => (k.target = 0)); lock = false; }, Math.max(350, 1100 + level * 300 - L * 180) + 500);
    }
    // ızgara boyutu tura göre değişir; her seferinde kamera yeniden sığdırılır
    const kits = {};
    function boardKitFor(c, r) {
      const key = c + 'x' + r;
      if (!kits[key]) kits[key] = { c, r };
      const K2 = { pos: (cc, rr, y = 0) => new THREE.Vector3((cc - (c - 1) / 2) * (CW + GAP), y, (rr - (r - 1) / 2) * (CH + GAP)) };
      fitFor(c, r); return K2;
    }
    let curFit = null;
    function fitFor(c, r) { curFit = [c, r]; doFit(); }
    function doFit() {
      if (!curFit) return;
      const [c, r] = curFit, cam = S.camera;
      const hw = (c * (CW + GAP)) / 2 + 0.3, hd = (r * (CH + GAP)) / 2 + 0.3;
      const pts = []; for (const sx of [-1, 1]) for (const sz of [-1, 1]) pts.push(new THREE.Vector3(sx * hw, 0.5, sz * hd));
      const dir = new THREE.Vector3(0, Math.cos(0.3), Math.sin(0.3));
      let lo = 1, hi = 100;
      for (let i = 0; i < 30; i++) { const d = (lo + hi) / 2; cam.position.copy(dir).multiplyScalar(d); cam.lookAt(0, 0, 0); cam.updateMatrixWorld(); const ok = pts.every((p) => { const v = p.clone().project(cam); return Math.abs(v.x) < 0.94 && Math.abs(v.y) < 0.94; }); if (ok) hi = d; else lo = d; }
      cam.position.copy(dir).multiplyScalar(hi); cam.lookAt(0, 0, 0);
    }
    S.onResize(() => doFit());
    function start() { L = api.level; level = 1; moves = 0; time = 0; score = 0; setup(); }
    function hud() { api.setHud({ score, extra: `Tur ${level}/3 · Hamle ${moves}` + (roundTime < Infinity ? ` · ⏱ ${Math.ceil(Math.max(0, roundTime))}` : '') }); }
    S.el.addEventListener('pointerdown', (e) => {
      if (lock || done) return;
      const hit = S.pick(e, cards.map((k) => k.g));
      if (!hit) return;
      let o = hit.object; while (o && !cards.some((k) => k.g === o)) o = o.parent;
      const k = cards.find((q) => q.g === o);
      if (!k || k.matched || k.target === 1) return;
      k.target = 1; open.push(k); api.sfx.click(); api.haptic('light');
      if (open.length === 2) {
        moves++; lock = true; hud();
        const [a, b] = open;
        if (a.sym === b.sym) {
          setTimeout(() => {
            a.matched = b.matched = true; found++; score += 50 + level * 10;
            api.sfx.pop();
            [a, b].forEach((q) => S.burst(q.g.position.clone().setY(0.5), new THREE.Color(q.sym[0]).getHex(), 14, 4, 0.6));
            open = []; lock = false; hud();
            if (found === cards.length / 2) roundDone();
          }, 350);
        } else setTimeout(() => { a.target = b.target = 0; open = []; lock = false; api.sfx.wrong(); }, 800);
      }
    });
    function roundDone() {
      api.sfx.win();
      if (level < 3) { level++; S.popText(new THREE.Vector3(0, 1, 0), `Tur ${level}!`, '#ffd60a'); setTimeout(setup, 900); }
      else {
        done = true; score += Math.max(0, 600 - Math.floor(time) * 3);
        setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 20), win: true, title: 'Süper hafıza! 🧠' }), 600);
      }
    }
    const lp = S.loop((dt, t) => {
      if (!done) {
        time += dt;
        if (roundTime < Infinity && !lock) {
          const before = Math.ceil(roundTime); roundTime -= dt;
          if (Math.ceil(roundTime) !== before) hud();
          if (roundTime <= 0) { done = true; api.sfx.lose(); api.gameOver({ score, coins: Math.floor(score / 30), title: 'Süre doldu! ⏰' }); }
        }
      }
      for (const k of cards) {
        k.flip += (k.target - k.flip) * Math.min(1, dt * 12);
        k.g.userData.deal += dt * 3; const dl = Math.max(0, Math.min(1, k.g.userData.deal));
        k.g.scale.setScalar(Math.max(0.01, dl));
        k.g.rotation.z = k.flip * Math.PI;
        k.g.position.y = Math.sin(k.flip * Math.PI) * 0.5 + (k.flip > 0.5 ? 0.06 : 0) + (k.matched ? Math.sin(t * 4 + k.c) * 0.04 + 0.05 : 0);
      }
      S.updateParts(dt, 0);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { S.destroy(); } };
  },
};
