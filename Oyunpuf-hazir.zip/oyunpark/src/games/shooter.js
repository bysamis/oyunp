// 👾 Uzay Savunması: gemini sürükle, otomatik ateş, dalgaları durdur
import { createStage, loop, particles } from '../core/canvas.js';

export default {
  id: 'shooter', title: 'Uzay Savunması', emoji: '👾', color: '#3c096c',
  desc: 'Gemini sürükle, uzaylıları vur!',
  target: (L) => Math.round(800 * Math.pow(1.4, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let ship, bullets, foes, ebullets, drops, score, wave, spawnIn, fireIn, over, L, lives, invuln, power, stars;
    const S = () => st.W / 400;

    function start() {
      L = api.level;
      ship = { x: st.W / 2, y: st.H - 80 }; bullets = []; foes = []; ebullets = []; drops = [];
      score = 0; wave = 1; spawnIn = 1; fireIn = 0; over = false; lives = 3; invuln = 0; power = 0;
      stars = Array.from({ length: 60 }, () => ({ x: Math.random() * st.W, y: Math.random() * st.H, s: Math.random() * 2 + 0.5 }));
      hud();
    }
    function hud() { api.setHud({ score, extra: `${'❤️'.repeat(lives)} · Dalga ${wave}` }); }
    const diff = () => L + wave * 0.5;
    function spawn() {
      const d = diff(); const r = Math.random();
      const kind = r < Math.min(0.3, d * 0.03) ? 'tank' : r < Math.min(0.55, 0.1 + d * 0.04) ? 'zig' : 'basic';
      const hp = kind === 'tank' ? 4 + Math.floor(d / 3) : kind === 'zig' ? 1 : 1 + Math.floor(d / 6);
      foes.push({ x: 30 + Math.random() * (st.W - 60), y: -30, kind, hp, max: hp, t: Math.random() * 6, vy: (50 + d * 8) * S() * (kind === 'tank' ? 0.6 : 1), fire: 1 + Math.random() * 2 });
      spawnIn = Math.max(0.22, 1.2 - d * 0.07);
    }
    let drag = null;
    st.canvas.addEventListener('pointerdown', (e) => { drag = { p: st.point(e), sx: ship.x, sy: ship.y }; });
    st.canvas.addEventListener('pointermove', (e) => {
      if (!drag) return; const p = st.point(e);
      ship.x = Math.max(20, Math.min(st.W - 20, drag.sx + p.x - drag.p.x));
      ship.y = Math.max(st.H * 0.4, Math.min(st.H - 30, drag.sy + p.y - drag.p.y));
    });
    window.addEventListener('pointerup', () => (drag = null));

    function hit() {
      if (invuln > 0) return;
      lives--; invuln = 2; power = 0; api.sfx.crash(); api.haptic('heavy'); fx.burst(ship.x, ship.y, '#ff9f1c', 24); hud();
      if (lives <= 0) { over = true; api.sfx.lose(); setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 30), canContinue: true, title: 'Gemi düştü! 👾' }), 600); }
    }
    function update(dt, t) {
      for (const s of stars) { s.y += s.s * 60 * dt; if (s.y > st.H) s.y = 0; }
      if (!over) {
        if (invuln > 0) invuln -= dt;
        if (power > 0) power -= dt;
        fireIn -= dt;
        if (fireIn <= 0) {
          fireIn = 0.22;
          const spread = power > 0 ? [-0.25, 0, 0.25] : [0];
          spread.forEach((a) => bullets.push({ x: ship.x, y: ship.y - 20, vx: Math.sin(a) * 600, vy: -Math.cos(a) * 600 }));
          api.sfx.click();
        }
        spawnIn -= dt; if (spawnIn <= 0) spawn();
        bullets.forEach((b) => { b.x += b.vx * dt; b.y += b.vy * dt; });
        bullets = bullets.filter((b) => b.y > -20);
        for (const f of foes) {
          f.t += dt; f.y += f.vy * dt;
          if (f.kind === 'zig') f.x += Math.sin(f.t * 3) * 120 * S() * dt;
          f.fire -= dt;
          if (f.fire <= 0 && f.y > 0 && diff() >= 2) {
            f.fire = Math.max(0.8, 3 - diff() * 0.15) + Math.random();
            const a = Math.atan2(ship.y - f.y, ship.x - f.x), sp = (160 + diff() * 12) * S();
            ebullets.push({ x: f.x, y: f.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp });
          }
          for (const b of bullets) if (!b.dead && Math.abs(b.x - f.x) < 20 * S() && Math.abs(b.y - f.y) < 18 * S()) {
            b.dead = true; f.hp--; api.sfx.brick();
            if (f.hp <= 0) {
              f.dead = true; score += f.kind === 'tank' ? 50 : f.kind === 'zig' ? 20 : 10;
              fx.burst(f.x, f.y, f.kind === 'tank' ? '#ff4d6d' : '#80ffdb', 14);
              if (Math.random() < 0.08) drops.push({ x: f.x, y: f.y, kind: Math.random() < 0.5 ? 'power' : 'life' });
              hud();
            }
          }
          if (!f.dead && Math.abs(f.x - ship.x) < 26 * S() && Math.abs(f.y - ship.y) < 26 * S()) { f.dead = true; hit(); }
          if (f.y > st.H + 30) { f.dead = true; score = Math.max(0, score - 5); }
        }
        bullets = bullets.filter((b) => !b.dead);
        foes = foes.filter((f) => !f.dead);
        for (const b of ebullets) { b.x += b.vx * dt; b.y += b.vy * dt; if (Math.hypot(b.x - ship.x, b.y - ship.y) < 14 * S()) { b.dead = true; hit(); } }
        ebullets = ebullets.filter((b) => !b.dead && b.y < st.H + 20 && b.y > -20 && b.x > -20 && b.x < st.W + 20);
        for (const d of drops) {
          d.y += 120 * dt;
          if (Math.hypot(d.x - ship.x, d.y - ship.y) < 30) { d.dead = true; api.sfx.power(); if (d.kind === 'power') power = 8; else { lives = Math.min(5, lives + 1); hud(); } }
        }
        drops = drops.filter((d) => !d.dead && d.y < st.H + 20);
        const w = 1 + Math.floor(score / 300);
        if (w !== wave) { wave = w; fx.text(st.W / 2, st.H / 2, `Dalga ${wave}!`, '#ffd60a'); api.sfx.win(); hud(); }
      }
      fx.update(dt); draw(t);
    }
    function draw(t) {
      const c = st.ctx;
      c.fillStyle = '#0b0420'; c.fillRect(0, 0, st.W, st.H);
      c.fillStyle = '#fff'; for (const s of stars) { c.globalAlpha = s.s / 2.5; c.fillRect(s.x, s.y, s.s, s.s * 2); } c.globalAlpha = 1;
      c.fillStyle = '#80ffdb'; for (const b of bullets) c.fillRect(b.x - 2, b.y - 8, 4, 14);
      c.fillStyle = '#ff4d6d'; for (const b of ebullets) { c.beginPath(); c.arc(b.x, b.y, 5, 0, 7); c.fill(); }
      for (const f of foes) {
        const s = S() * (f.kind === 'tank' ? 1.4 : 1);
        c.save(); c.translate(f.x, f.y); c.scale(s, s);
        c.fillStyle = f.kind === 'tank' ? '#ff4d6d' : f.kind === 'zig' ? '#ffd60a' : '#9d4edd';
        c.beginPath(); c.ellipse(0, 0, 18, 11, 0, 0, 7); c.fill();
        c.fillStyle = '#80ffdb'; c.beginPath(); c.arc(0, -6, 8, Math.PI, 0); c.fill();
        c.fillStyle = '#fff'; [-10, 0, 10].forEach((x) => { c.beginPath(); c.arc(x, 3, 2.5, 0, 7); c.fill(); });
        if (f.max > 1) { c.fillStyle = '#333'; c.fillRect(-16, 14, 32, 4); c.fillStyle = '#2dc653'; c.fillRect(-16, 14, 32 * f.hp / f.max, 4); }
        c.restore();
      }
      for (const d of drops) { c.fillStyle = d.kind === 'power' ? '#ffd60a' : '#ff70a6'; c.beginPath(); c.arc(d.x, d.y, 12, 0, 7); c.fill(); c.fillStyle = '#000'; c.font = '900 12px system-ui'; c.textAlign = 'center'; c.fillText(d.kind === 'power' ? 'P' : '♥', d.x, d.y + 4); }
      if (!over && !(invuln > 0 && Math.floor(t * 12) % 2)) {
        c.save(); c.translate(ship.x, ship.y); c.scale(S(), S());
        c.fillStyle = '#ff9f1c'; c.beginPath(); c.moveTo(-6, 16); c.lineTo(0, 24 + Math.sin(t * 40) * 4); c.lineTo(6, 16); c.fill();
        c.fillStyle = power > 0 ? '#ffd60a' : '#e0e1dd';
        c.beginPath(); c.moveTo(0, -22); c.lineTo(18, 16); c.lineTo(0, 10); c.lineTo(-18, 16); c.closePath(); c.fill();
        c.fillStyle = '#3a86ff'; c.beginPath(); c.arc(0, -2, 5, 0, 7); c.fill();
        c.restore();
      }
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { lives = 2; invuln = 3; foes = []; ebullets = []; over = false; hud(); },
      restart() { start(); }, destroy() { lp.stop(); st.destroy(); },
    };
  },
};
