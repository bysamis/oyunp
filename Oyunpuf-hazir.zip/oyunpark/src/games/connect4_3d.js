// 🔴 Dört Bağla 3D: taşı sütuna bırak, dört taşı yan yana diz
import { create3D, mat, THREE } from '../core/three-stage.js';

const C = 7, R = 6;
function winnerOf(b) {
  const dirs = [[0, 1], [1, 0], [1, 1], [1, -1]];
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
    const p = b[r][c]; if (!p) continue;
    for (const [dr, dc] of dirs) {
      const cells = [[r, c]];
      for (let k = 1; k < 4; k++) { const rr = r + dr * k, cc = c + dc * k; if (b[rr]?.[cc] !== p) break; cells.push([rr, cc]); }
      if (cells.length === 4) return { p, cells };
    }
  }
  return b[0].every(Boolean) ? { p: 'draw' } : null;
}
const dropRow = (b, c) => { for (let r = R - 1; r >= 0; r--) if (!b[r][c]) return r; return -1; };
function evalBoard(b) {
  let s = 0; const lines = [];
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) for (const [dr, dc] of [[0, 1], [1, 0], [1, 1], [1, -1]]) {
    const w = []; for (let k = 0; k < 4; k++) w.push(b[r + dr * k]?.[c + dc * k]);
    if (w.every((x) => x !== undefined)) lines.push(w);
  }
  for (const w of lines) {
    const a = w.filter((x) => x === 2).length, h = w.filter((x) => x === 1).length;
    if (a && h) continue;
    s += a === 3 ? 6 : a === 2 ? 2 : 0; s -= h === 3 ? 8 : h === 2 ? 2 : 0;
  }
  for (let r = 0; r < R; r++) if (b[r][3] === 2) s += 3; else if (b[r][3] === 1) s -= 3;
  return s;
}
function minimax(b, depth, alpha, beta, ai) {
  const w = winnerOf(b);
  if (w) return w.p === 2 ? 1000 + depth : w.p === 1 ? -1000 - depth : 0;
  if (depth === 0) return evalBoard(b);
  const order = [3, 2, 4, 1, 5, 0, 6];
  if (ai) { let best = -Infinity; for (const c of order) { const r = dropRow(b, c); if (r < 0) continue; b[r][c] = 2; best = Math.max(best, minimax(b, depth - 1, alpha, beta, false)); b[r][c] = 0; alpha = Math.max(alpha, best); if (alpha >= beta) break; } return best; }
  let best = Infinity; for (const c of order) { const r = dropRow(b, c); if (r < 0) continue; b[r][c] = 1; best = Math.min(best, minimax(b, depth - 1, alpha, beta, true)); b[r][c] = 0; beta = Math.min(beta, best); if (alpha >= beta) break; } return best;
}

export default {
  id: 'connect4', title: 'Dört Bağla 3D', emoji: '🔴', color: '#ef233c',
  desc: 'Dört taşı yan yana diz, bilgisayarı yen!',
  winBased: true, players: { min: 2, max: 2 }, online: { min: 2, max: 2 },
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0x90e0ef });
    const { scene, camera, sun } = S;
    sun.position.set(-5, 12, 14);
    const X = (c) => c - (C - 1) / 2, Y = (r) => (R - 1 - r) + 0.7;
    // zemin
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), mat(0xcaf0f8)); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);
    // delikli çerçeve (ön ve arka plaka)
    const shape = new THREE.Shape(); const W = C + 0.4, Hh = R + 0.4;
    shape.moveTo(-W / 2, 0.2); shape.lineTo(W / 2, 0.2); shape.lineTo(W / 2, 0.2 + Hh); shape.lineTo(-W / 2, 0.2 + Hh); shape.lineTo(-W / 2, 0.2);
    for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) { const h = new THREE.Path(); h.absarc(X(c), Y(r), 0.4, 0, Math.PI * 2, true); shape.holes.push(h); }
    const plateGeo = new THREE.ExtrudeGeometry(shape, { depth: 0.12, bevelEnabled: true, bevelThickness: 0.04, bevelSize: 0.04, bevelSegments: 2, curveSegments: 20 });
    const frameMat = mat(0x0077b6, { roughness: 0.35 });
    const front = new THREE.Mesh(plateGeo, frameMat); front.position.z = 0.22; front.castShadow = true; scene.add(front);
    const back = new THREE.Mesh(plateGeo, frameMat); back.position.z = -0.34; scene.add(back);
    for (const s of [-1, 1]) { const leg = new THREE.Mesh(new THREE.BoxGeometry(0.3, R + 1.4, 0.9), frameMat); leg.position.set(s * (W / 2 + 0.15), (R + 1.4) / 2 - 0.3, 0); leg.castShadow = true; scene.add(leg); const foot = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.2, 2.4), frameMat); foot.position.set(s * (W / 2 + 0.15), 0.1, 0); scene.add(foot); }
    const discGeo = new THREE.CylinderGeometry(0.4, 0.4, 0.3, 28); discGeo.rotateX(Math.PI / 2);
    const dMat = { 1: mat(0xe63946, { roughness: 0.3 }), 2: mat(0xffc300, { roughness: 0.3 }) };
    const discs = new THREE.Group(); scene.add(discs);
    const ghost = new THREE.Mesh(discGeo, new THREE.MeshStandardMaterial({ color: 0xe63946, transparent: true, opacity: 0.6 })); scene.add(ghost);
    const fallM = new THREE.Mesh(discGeo, dMat[1]); fallM.castShadow = true; scene.add(fallM);
    S.onResize(() => {
      const vfov = (camera.fov * Math.PI) / 180, a = S.w / S.h;
      const d = Math.max((R + 2.6) / 2 / Math.tan(vfov / 2), (C / 2 + 0.9) / (Math.tan(vfov / 2) * a));
      camera.position.set(0, R / 2 + 1.6, d * 1.02); camera.lookAt(0, R / 2 + 0.6, 0);
    });

    let board, turn, result, falling, L, busy, hover, moves;
    const ON = api.mp?.online, inbox = [];
    ON?.on((m) => inbox.push(m));
    function start() {
      inbox.length = 0; L = api.level; discs.clear();
      board = Array.from({ length: R }, () => Array(C).fill(0));
      turn = 1; result = null; falling = null; busy = false; hover = 3; moves = 0;
      hud();
    }
    const depth = () => Math.min(6, L);
    const mistake = () => Math.max(0, 0.35 - (L - 1) * 0.08);
    function hud() { api.setHud({ score: moves, scoreLabel: api.mp ? 'Hamle' : 'Hamle', extra: result ? '' : ON ? (turn === ON.me + 1 ? `Senin sıran ${turn === 1 ? '🔴' : '🟡'}` : `${api.mp.names[turn - 1]} düşünüyor…`) : api.mp ? `Sıra: ${api.mp.names[turn - 1]} ${turn === 1 ? '🔴' : '🟡'}` : (turn === 1 ? 'Senin sıran 🔴' : 'Bilgisayar düşünüyor… 🟡') + ` · Rakip gücü ${'★'.repeat(Math.min(6, L))}` }); }
    function drop(c, p) {
      const r = dropRow(board, c); if (r < 0) return false;
      falling = { r, c, p, y: R + 1.2, vy: 0 }; busy = true; api.sfx.tap(); fallM.material = dMat[p];
      return true;
    }
    function land() {
      const { r, c, p } = falling;
      board[r][c] = p; falling = null; moves += p === 1 ? 1 : 0;
      const m = new THREE.Mesh(discGeo, dMat[p]); m.position.set(X(c), Y(r), 0); m.castShadow = true; m.userData.rc = [r, c]; discs.add(m);
      api.haptic('light'); api.sfx.bounce();
      const w = winnerOf(board);
      if (w) return finish(w);
      turn = p === 1 ? 2 : 1; busy = false; hud();
      if (turn === 2 && !api.mp) setTimeout(aiMove, 350);
    }
    function aiMove() {
      const valid = [...Array(C).keys()].filter((c) => dropRow(board, c) >= 0);
      let col;
      if (Math.random() < mistake()) col = valid[(Math.random() * valid.length) | 0];
      else {
        let best = -Infinity;
        for (const c of [3, 2, 4, 1, 5, 0, 6]) { const r = dropRow(board, c); if (r < 0) continue; board[r][c] = 2; const s = minimax(board, depth() - 1, -Infinity, Infinity, false); board[r][c] = 0; if (s > best) { best = s; col = c; } }
      }
      drop(col, 2);
    }
    function finish(w) {
      result = w; busy = true; hud();
      if (w.cells) w.cells.forEach(([r, c]) => S.burst(new THREE.Vector3(X(c), Y(r), 0.5), 0xffd60a, 12, 5, 0.6));
      if (w.p === 1) api.sfx.win(); else if (w.p === 2) api.sfx.lose(); else api.sfx.slide();
      const score = w.p === 1 ? Math.max(100, 500 - moves * 10) + L * 30 : w.p === 'draw' ? 80 : 0;
      if (api.mp) { setTimeout(() => api.gameOver({ winner: w.p === 'draw' ? -1 : w.p - 1 }), 1400); return; }
      setTimeout(() => api.gameOver({ score, coins: w.p === 1 ? 8 + L * 2 : w.p === 'draw' ? 3 : 1, win: w.p === 1, title: w.p === 1 ? 'Kazandın! 🔴' : w.p === 2 ? 'Bilgisayar kazandı 🟡' : 'Berabere 🤝' }), 1400);
    }
    const colAt = (e) => { const p = S.rayPlaneZ(e, 0); return p ? Math.round(p.x + (C - 1) / 2) : -1; };
    S.el.addEventListener('pointermove', (e) => { const c = colAt(e); if (c >= 0 && c < C) hover = c; });
    S.el.addEventListener('pointerup', (e) => {
      if (busy || (turn !== 1 && !api.mp) || (ON && turn !== ON.me + 1)) return;
      const c = colAt(e);
      if (c >= 0 && c < C) { hover = c; if (!drop(c, api.mp ? turn : 1)) api.sfx.wrong(); else ON?.send({ c }); }
    });
    const lp = S.loop((dt, t) => {
      if (ON && inbox.length && !busy && !result) { const mv = inbox.shift(); drop(mv.c, turn); }
      if (falling) {
        falling.vy += 40 * dt; falling.y -= falling.vy * dt;
        if (falling.y <= Y(falling.r)) { falling.y = Y(falling.r); land(); }
      }
      fallM.visible = !!falling; if (falling) fallM.position.set(X(falling.c), falling.y, 0);
      const myTurn = !busy && !result && (turn === 1 || api.mp) && (!ON || turn === ON.me + 1);
      ghost.visible = myTurn; ghost.material.color.setHex(api.mp && turn === 2 ? 0xffc300 : 0xe63946);
      ghost.position.set(X(hover), R + 1.2 + Math.sin(t * 4) * 0.1, 0);
      if (result?.cells) discs.children.forEach((m) => { if (result.cells.some(([r, c]) => r === m.userData.rc[0] && c === m.userData.rc[1])) m.rotation.z = t * 6; });
      S.updateParts(dt, 0);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { S.destroy(); } };
  },
};
