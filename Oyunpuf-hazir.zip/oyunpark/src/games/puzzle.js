// 🧩 Kaydırmalı Resim Yapbozu
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

function seeded(seed) {
  let s = seed * 9301 + 49297;
  return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
}

// Her seviye için kodla çizilmiş farklı bir resim
function paintScene(size, level) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = size;
  const c = cv.getContext('2d');
  const R = seeded(level * 7 + 3);
  const kind = level % 3;
  if (kind === 1) {
    // Kır manzarası
    const sky = c.createLinearGradient(0, 0, 0, size);
    sky.addColorStop(0, `hsl(${190 + R() * 30},90%,70%)`); sky.addColorStop(1, '#fff6d5');
    c.fillStyle = sky; c.fillRect(0, 0, size, size);
    c.fillStyle = '#ffd60a'; c.beginPath(); c.arc(size * (0.2 + R() * 0.6), size * 0.2, size * 0.1, 0, 7); c.fill();
    for (let i = 0; i < 3; i++) {
      c.fillStyle = 'rgba(255,255,255,.9)';
      const x = R() * size, y = size * (0.1 + R() * 0.2);
      c.beginPath(); c.arc(x, y, size * 0.05, 0, 7); c.arc(x + size * 0.05, y - size * 0.02, size * 0.06, 0, 7); c.arc(x + size * 0.11, y, size * 0.05, 0, 7); c.fill();
    }
    [['#4f772d', 0.55], ['#90a955', 0.7], ['#31572c', 0.85]].forEach(([col, h]) => {
      c.fillStyle = col; c.beginPath(); c.moveTo(0, size);
      for (let x = 0; x <= size; x += size / 20) c.lineTo(x, size * h + Math.sin(x / size * 6 + R() * 6) * size * 0.05);
      c.lineTo(size, size); c.fill();
    });
    // ev
    const hx = size * 0.55, hy = size * 0.58, hw = size * 0.25;
    c.fillStyle = '#ff4d6d'; c.fillRect(hx, hy, hw, hw * 0.8);
    c.fillStyle = '#7b2cbf'; c.beginPath(); c.moveTo(hx - 10, hy); c.lineTo(hx + hw / 2, hy - hw * 0.55); c.lineTo(hx + hw + 10, hy); c.fill();
    c.fillStyle = '#ffd60a'; c.fillRect(hx + hw * 0.15, hy + hw * 0.2, hw * 0.25, hw * 0.22); c.fillRect(hx + hw * 0.6, hy + hw * 0.2, hw * 0.25, hw * 0.22);
    c.fillStyle = '#6f4518'; c.fillRect(hx + hw * 0.4, hy + hw * 0.45, hw * 0.2, hw * 0.35);
    for (let i = 0; i < 4; i++) {
      const tx = size * (0.05 + i * 0.12), ty = size * 0.72;
      c.fillStyle = '#6f4518'; c.fillRect(tx - 5, ty, 10, size * 0.1);
      c.fillStyle = '#2dc653'; c.beginPath(); c.arc(tx, ty, size * 0.06, 0, 7); c.fill();
    }
  } else if (kind === 2) {
    // Deniz
    const sky = c.createLinearGradient(0, 0, 0, size * 0.5);
    sky.addColorStop(0, '#ff9e00'); sky.addColorStop(1, '#ffd6a5');
    c.fillStyle = sky; c.fillRect(0, 0, size, size * 0.5);
    c.fillStyle = '#ff006e'; c.beginPath(); c.arc(size * 0.5, size * 0.48, size * 0.16, Math.PI, 0); c.fill();
    const sea = c.createLinearGradient(0, size * 0.5, 0, size);
    sea.addColorStop(0, '#00b4d8'); sea.addColorStop(1, '#03045e');
    c.fillStyle = sea; c.fillRect(0, size * 0.5, size, size * 0.5);
    c.strokeStyle = 'rgba(255,255,255,.5)'; c.lineWidth = 3;
    for (let i = 0; i < 6; i++) { const y = size * (0.56 + i * 0.07); c.beginPath(); for (let x = 0; x <= size; x += 10) c.lineTo(x, y + Math.sin(x / 20 + i) * 4); c.stroke(); }
    // tekne
    const bx = size * (0.15 + R() * 0.3), by = size * 0.52;
    c.fillStyle = '#6f1d1b'; c.beginPath(); c.moveTo(bx, by); c.lineTo(bx + size * 0.3, by); c.lineTo(bx + size * 0.25, by + size * 0.07); c.lineTo(bx + size * 0.05, by + size * 0.07); c.fill();
    c.fillStyle = '#fff'; c.beginPath(); c.moveTo(bx + size * 0.15, by - 4); c.lineTo(bx + size * 0.15, by - size * 0.25); c.lineTo(bx + size * 0.28, by - 4); c.fill();
    for (let i = 0; i < 5; i++) {
      const fx = R() * size, fy = size * (0.7 + R() * 0.25), fs = size * 0.04;
      c.fillStyle = `hsl(${R() * 360},90%,60%)`;
      c.beginPath(); c.ellipse(fx, fy, fs, fs * 0.6, 0, 0, 7); c.fill();
      c.beginPath(); c.moveTo(fx - fs, fy); c.lineTo(fx - fs * 1.7, fy - fs * 0.6); c.lineTo(fx - fs * 1.7, fy + fs * 0.6); c.fill();
    }
  } else {
    // Uzay
    c.fillStyle = '#10002b'; c.fillRect(0, 0, size, size);
    for (let i = 0; i < 120; i++) { c.fillStyle = `rgba(255,255,255,${R()})`; c.fillRect(R() * size, R() * size, 2, 2); }
    const px = size * 0.7, py = size * 0.3, pr = size * 0.18;
    const pg = c.createRadialGradient(px - pr * 0.4, py - pr * 0.4, 5, px, py, pr);
    pg.addColorStop(0, '#ffbe0b'); pg.addColorStop(1, '#fb5607');
    c.fillStyle = pg; c.beginPath(); c.arc(px, py, pr, 0, 7); c.fill();
    c.strokeStyle = '#ffd6ff'; c.lineWidth = 6; c.beginPath(); c.ellipse(px, py, pr * 1.6, pr * 0.35, -0.3, 0, 7); c.stroke();
    c.fillStyle = '#9d4edd'; c.beginPath(); c.arc(size * 0.2, size * 0.75, size * 0.1, 0, 7); c.fill();
    // roket
    c.save(); c.translate(size * 0.38, size * 0.62); c.rotate(-0.6);
    c.fillStyle = '#e0e1dd'; roundRect(c, -size * 0.05, -size * 0.18, size * 0.1, size * 0.3, size * 0.05); c.fill();
    c.fillStyle = '#ef233c'; c.beginPath(); c.moveTo(-size * 0.05, -size * 0.12); c.lineTo(0, -size * 0.24); c.lineTo(size * 0.05, -size * 0.12); c.fill();
    c.fillStyle = '#3a86ff'; c.beginPath(); c.arc(0, -size * 0.06, size * 0.025, 0, 7); c.fill();
    c.fillStyle = '#ff9f1c'; c.beginPath(); c.moveTo(-size * 0.04, size * 0.12); c.lineTo(0, size * 0.22); c.lineTo(size * 0.04, size * 0.12); c.fill();
    c.restore();
  }
  return cv;
}

export default {
  id: 'puzzle', title: 'Yapboz', emoji: '🧩', color: '#2dc653',
  desc: 'Parçaları kaydır, resmi tamamla!',
  winBased: true,
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    let n, tiles, empty, img, board, ox, oy, moves, time, solved, level, showNums = true;

    function layout() {
      board = Math.min(st.W - 32, st.H - 150, 520);
      ox = (st.W - board) / 2;
      oy = Math.max(100, (st.H - board) / 2 + 40);
      if (level) img = paintScene(Math.round(board * st.dpr), level);
    }

    function start() {
      level = api.level;
      n = level <= 2 ? 3 : level <= 5 ? 4 : level <= 9 ? 5 : 6;
      layout();
      // çözülmüş halden rastgele geçerli hamlelerle karıştır (her zaman çözülebilir)
      tiles = [];
      for (let i = 0; i < n * n - 1; i++) tiles.push({ id: i, r: (i / n) | 0, c: i % n, x: i % n, y: (i / n) | 0 });
      empty = { r: n - 1, c: n - 1 };
      let prev = null;
      for (let k = 0; k < n * n * 25; k++) {
        const opts = [[0, 1], [1, 0], [0, -1], [-1, 0]].filter(([dr, dc]) => {
          const r = empty.r + dr, c = empty.c + dc;
          return r >= 0 && r < n && c >= 0 && c < n && !(prev && prev[0] === -dr && prev[1] === -dc);
        });
        const [dr, dc] = opts[(Math.random() * opts.length) | 0];
        const t = tiles.find((t) => t.r === empty.r + dr && t.c === empty.c + dc);
        t.r = empty.r; t.c = empty.c; empty = { r: empty.r + dr, c: empty.c + dc }; prev = [dr, dc];
      }
      if (isSolved()) return start();
      tiles.forEach((t) => { t.x = t.c; t.y = t.r; });
      moves = 0; time = 0; solved = false;
      hud();
    }

    function hud() { api.setHud({ score: moves, scoreLabel: 'Hamle', extra: `Seviye ${level} · ${n}×${n} · ⏱ ${Math.floor(time)}s` }); }
    const isSolved = () => tiles.every((t) => t.r === ((t.id / n) | 0) && t.c === t.id % n);

    function tapCell(r, c) {
      if (solved) return;
      if (r !== empty.r && c !== empty.c) { api.sfx.wrong(); return; }
      if (r === empty.r && c === empty.c) return;
      // aynı satır/sütundaki tüm parçaları boşluğa doğru kaydır
      const dr = Math.sign(r - empty.r), dc = Math.sign(c - empty.c);
      while (empty.r !== r || empty.c !== c) {
        const nr = empty.r + dr, nc = empty.c + dc;
        const t = tiles.find((t) => t.r === nr && t.c === nc);
        t.r = empty.r; t.c = empty.c; empty = { r: nr, c: nc };
        moves++;
      }
      api.sfx.slide(); api.haptic('light'); hud();
      if (isSolved()) win();
    }

    function win() {
      solved = true;
      api.sfx.win(); api.haptic('heavy');
      for (let i = 0; i < 6; i++) setTimeout(() => fx.burst(ox + Math.random() * board, oy + Math.random() * board, `hsl(${Math.random() * 360},90%,60%)`, 20, 220), i * 150);
      const scoreVal = Math.max(50, Math.round(n * n * 60 - moves * 3 - time * 2));
      const coins = 10 + (n - 2) * 10 + (moves < n * n * 6 ? 10 : 0);
      setTimeout(() => api.gameOver({ score: scoreVal, coins, win: true, title: 'Tebrikler! 🎉', againLabel: 'Sonraki seviye ▶' }), 1100);
    }

    const onDown = (e) => {
      const p = st.point(e);
      // numara göster/gizle düğmesi
      if (p.y < 90 && p.x > st.W - 120) { showNums = !showNums; api.sfx.click(); return; }
      const s = board / n;
      const c = Math.floor((p.x - ox) / s), r = Math.floor((p.y - oy) / s);
      if (r >= 0 && r < n && c >= 0 && c < n) tapCell(r, c);
    };
    st.canvas.addEventListener('pointerdown', onDown);

    function update(dt) {
      if (!solved) { const before = Math.floor(time); time += dt; if (Math.floor(time) !== before) hud(); }
      for (const t of tiles) {
        t.x += (t.c - t.x) * Math.min(1, dt * 18);
        t.y += (t.r - t.y) * Math.min(1, dt * 18);
      }
      fx.update(dt);
      draw();
    }

    function draw() {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H);
      g.addColorStop(0, '#caffbf'); g.addColorStop(1, '#9bf6ff');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      // hedef önizleme
      const pv = 70;
      c.save(); roundRect(c, 16, 14, pv, pv, 12); c.clip();
      c.drawImage(img, 16, 14, pv, pv); c.restore();
      c.fillStyle = '#1b4332'; c.font = '700 14px system-ui'; c.textAlign = 'left';
      c.fillText('Hedef resim', 96, 40);
      c.font = '500 12px system-ui'; c.fillStyle = '#2d6a4f';
      c.fillText('Boşluğun yanındaki parçaya dokun', 96, 60);
      // numara düğmesi
      roundRect(c, st.W - 112, 22, 96, 34, 17); c.fillStyle = showNums ? '#2dc653' : 'rgba(0,0,0,.15)'; c.fill();
      c.fillStyle = '#fff'; c.font = '700 13px system-ui'; c.textAlign = 'center';
      c.fillText(showNums ? '123 Açık' : '123 Kapalı', st.W - 64, 44);

      roundRect(c, ox - 8, oy - 8, board + 16, board + 16, 18);
      c.fillStyle = 'rgba(27,67,50,.25)'; c.fill();
      const s = board / n, src = img.width / n, gap = 2;
      for (const t of tiles) {
        const x = ox + t.x * s, y = oy + t.y * s;
        c.save();
        roundRect(c, x + gap, y + gap, s - gap * 2, s - gap * 2, 8); c.clip();
        c.drawImage(img, (t.id % n) * src, ((t.id / n) | 0) * src, src, src, x, y, s, s);
        c.restore();
        c.strokeStyle = 'rgba(255,255,255,.7)'; c.lineWidth = 2;
        roundRect(c, x + gap, y + gap, s - gap * 2, s - gap * 2, 8); c.stroke();
        if (showNums && !solved) {
          c.fillStyle = 'rgba(0,0,0,.45)'; c.beginPath(); c.arc(x + 16, y + 16, 11, 0, 7); c.fill();
          c.fillStyle = '#fff'; c.font = '800 12px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle';
          c.fillText(t.id + 1, x + 16, y + 17); c.textBaseline = 'alphabetic';
        }
      }
      if (solved) { // eksik son parçayı da göster
        const x = ox + (n - 1) * s, y = oy + (n - 1) * s;
        c.drawImage(img, (n - 1) * src, (n - 1) * src, src, src, x, y, s, s);
      }
      fx.draw(c);
    }

    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      restart() { start(); },
      destroy() { lp.stop(); st.destroy(); },
    };
  },
};
