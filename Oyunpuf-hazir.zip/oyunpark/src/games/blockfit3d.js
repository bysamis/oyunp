// 🟦 Blok Yerleştir 3D: parçaları tahtaya sürükle, dolu satır/sütunları patlat
import { create3D, mat, THREE } from '../core/three-stage.js';
import { expert, expertSteps } from '../core/expert.js';
import { boardKit, roundedBox } from '../core/board3d.js';

const N = 8;
// [hücreler, zorluk ağırlığı] — büyük/garip parçalar yüksek seviyede daha sık gelir
const SHAPES = [
  [[[0, 0]], 0], [[[0, 0], [0, 1]], 0], [[[0, 0], [1, 0]], 0],
  [[[0, 0], [0, 1], [1, 0], [1, 1]], 1], [[[0, 0], [0, 1], [0, 2]], 1], [[[0, 0], [1, 0], [2, 0]], 1],
  [[[0, 0], [1, 0], [1, 1]], 1], [[[0, 1], [1, 0], [1, 1]], 1],
  [[[0, 0], [0, 1], [0, 2], [0, 3]], 2], [[[0, 0], [1, 0], [2, 0], [3, 0]], 2],
  [[[0, 0], [1, 0], [2, 0], [2, 1]], 2], [[[0, 1], [1, 1], [2, 1], [2, 0]], 2], [[[0, 0], [0, 1], [0, 2], [1, 1]], 2],
  [[[0, 1], [1, 0], [1, 1], [2, 0]], 3], [[[0, 0], [1, 0], [1, 1], [2, 1]], 3],
  [[[0, 0], [0, 1], [0, 2], [0, 3], [0, 4]], 3], [[[0, 0], [1, 0], [2, 0], [3, 0], [4, 0]], 3],
  [[[0, 0], [0, 1], [0, 2], [1, 0], [2, 0]], 3], [[[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]], 4],
  [[[0, 0], [1, 1], [2, 2]], 4], [[[0, 2], [1, 1], [2, 0]], 4],
];
const COLORS = ['#ff4d6d', '#ff9f1c', '#ffd60a', '#2dc653', '#3a86ff', '#9d4edd', '#06d6a0'];

export default {
  id: 'blockfit', title: 'Blok Yerleştir 3D', emoji: '🟦', color: '#3a86ff',
  desc: 'Parçaları yerleştir, satırları patlat!',
  expertFrom: 11,
  target: (L) => Math.round(600 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0x1d3557 });
    const { scene } = S;
    const TRAY_Z = N / 2 + 2.4;
    const K = boardKit(S, N, N, { tilt: 0.3, height: 0.8, extraBottom: 4.2 });
    const cell = 1, ox = -N / 2, oy = -N / 2, st = { W: 0 };
    const fx = { burst: (x, y, col, n) => S.burst(new THREE.Vector3(x, 0.5, y), new THREE.Color(col).getHex(), Math.min(n, 6), 4, 0.5), text: (x, y, t, col) => S.popText(new THREE.Vector3(x, 0.8, y), t, col) };
    const frame = new THREE.Mesh(roundedBox(N + 0.6, 0.5, N + 0.6, 0.3), mat(0x14213d)); frame.position.y = -0.62; frame.receiveShadow = true; scene.add(frame);
    const slotGeo = roundedBox(0.92, 0.06, 0.92, 0.1), slotMat = mat(0x2b4a7a);
    for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) { const s = new THREE.Mesh(slotGeo, slotMat); s.position.copy(K.pos(c, r, -0.12)); s.receiveShadow = true; scene.add(s); }
    const trayPad = new THREE.Mesh(roundedBox(N + 0.6, 0.2, 3.6, 0.3), mat(0x0f1d33)); trayPad.position.set(0, -0.45, TRAY_Z); trayPad.receiveShadow = true; scene.add(trayPad);
    const blockGeo = roundedBox(0.92, 0.5, 0.92, 0.14);
    const matCache = {};
    const bmat = (col, a = 1) => { const k = col + a; return matCache[k] || (matCache[k] = mat(new THREE.Color(col), { roughness: 0.3, transparent: a < 1, opacity: a, depthWrite: a >= 1 })); };
    const placedG = new THREE.Group(), trayG = new THREE.Group(), ghostG = new THREE.Group(); scene.add(placedG, trayG, ghostG);
    let grid, tray, drag, score, combo, over, L, placed, dirty = true;
    function pickShape() {
      // seviye ve puan arttıkça zor parça olasılığı artar
      const hard = Math.min(4, (L - 1) * 0.45 + placed / 40);
      const pool = SHAPES.map(([cells, w]) => ({ cells, wt: w <= hard + 0.5 ? 1 + (w <= hard ? w * 0.6 : 0) : 0.15 }));
      let r = Math.random() * pool.reduce((a, b) => a + b.wt, 0);
      for (const p of pool) { r -= p.wt; if (r <= 0) return p.cells; }
      return pool[0].cells;
    }
    function refill() {
      tray = [0, 1, 2].map(() => ({ cells: pickShape(), color: COLORS[(Math.random() * COLORS.length) | 0], used: false }));
    }
    function start() {
      L = api.level;
      grid = Array.from({ length: N }, () => Array(N).fill(null));
      // yüksek seviyede tahtada başlangıç taşları
      const stones = Math.min(16, Math.max(0, (L - 2) * 2)) + Math.min(8, expertSteps(L, 10)); // uzman: daha çok taş
      for (let i = 0; i < stones; i++) grid[(Math.random() * N) | 0][(Math.random() * N) | 0] = '#6c757d';
      score = 0; combo = 0; over = false; drag = null; placed = 0; refill(); hud(); dirty = true;
    }
    function hud() { api.setHud({ score, extra: combo > 1 ? `Kombo ×${combo} 🔥` : 'Parçayı tahtaya sürükle' }); }
    const fits = (cells, r, c) => cells.every(([dr, dc]) => grid[r + dr]?.[c + dc] === null);
    const anyFit = (cells) => { for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (fits(cells, r, c)) return true; return false; };
    function slot(i) { return { x: (i - 1) * 3, y: TRAY_Z }; }
    const size = (cells) => [Math.max(...cells.map((p) => p[0])) + 1, Math.max(...cells.map((p) => p[1])) + 1];
    function dropAt(piece, px, py) {
      const [h, w] = size(piece.cells);
      const c = Math.round((px - ox) / cell - w / 2), r = Math.round((py - oy) / cell - h / 2);
      return { r, c, ok: fits(piece.cells, r, c) };
    }
    // parmak parçanın üstünü kapatmasın diye parça biraz yukarıda (uzakta) tutulur
    const LIFT = 1.8;
    S.el.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = S.rayPlaneY(e, 0); if (!p) return;
      tray.forEach((t, i) => { if (t.used) return; const s = slot(i); if (Math.abs(p.x - s.x) < 1.6 && p.z > TRAY_Z - 2) { drag = { i, x: p.x, y: p.z - LIFT }; api.sfx.click(); } });
    });
    S.el.addEventListener('pointermove', (e) => { if (!drag) return; const p = S.rayPlaneY(e, 0); if (p) { drag.x = p.x; drag.y = p.z - LIFT; } });
    const onUp = () => {
      if (!drag) return;
      const piece = tray[drag.i], d = dropAt(piece, drag.x, drag.y);
      if (d.ok) place(piece, d.r, d.c); else api.sfx.wrong();
      drag = null; dirty = true;
    };
    window.addEventListener('pointerup', onUp);
    function place(piece, r, c) {
      piece.cells.forEach(([dr, dc]) => (grid[r + dr][c + dc] = piece.color));
      piece.used = true; placed++; dirty = true;
      score += piece.cells.length; api.sfx.slide(); api.haptic('light');
      // dolan satır ve sütunlar
      const rows = [], cols = [];
      for (let i = 0; i < N; i++) { if (grid[i].every(Boolean)) rows.push(i); if (grid.every((row) => row[i])) cols.push(i); }
      const lines = rows.length + cols.length;
      if (lines) {
        combo++;
        rows.forEach((i) => grid[i].forEach((col, j) => { fx.burst(ox + (j + 0.5) * cell, oy + (i + 0.5) * cell, col, 4, 120); grid[i][j] = null; }));
        cols.forEach((j) => grid.forEach((row, i) => { if (row[j]) fx.burst(ox + (j + 0.5) * cell, oy + (i + 0.5) * cell, row[j], 4, 120); row[j] = null; }));
        const pts = lines * 10 * lines * combo;
        score += pts; fx.text(st.W / 2, oy + cell * N / 2, `+${pts}${combo > 1 ? ' ×' + combo : ''}`, '#fff');
        lines > 1 || combo > 1 ? api.sfx.combo(combo) : api.sfx.pop(); api.haptic('medium');
      } else combo = 0;
      if (tray.every((t) => t.used)) refill();
      hud();
      if (!tray.some((t) => !t.used && anyFit(t.cells))) {
        over = true; api.sfx.lose();
        setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 40), canContinue: true, title: 'Yer kalmadı! 🟦' }), 500);
      }
    }

    function pieceGroup(cells, color, s) {
      const g = new THREE.Group(), [h, w] = size(cells);
      cells.forEach(([dr, dc]) => { const m = new THREE.Mesh(blockGeo, bmat(color)); m.position.set((dc - (w - 1) / 2) * s, 0, (dr - (h - 1) / 2) * s); m.scale.setScalar(s); m.castShadow = true; g.add(m); });
      return g;
    }
    function rebuild() {
      placedG.clear();
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (grid[r][c]) { const m = new THREE.Mesh(blockGeo, bmat(grid[r][c])); m.position.copy(K.pos(c, r, -0.1)); m.castShadow = true; m.receiveShadow = true; placedG.add(m); }
      trayG.clear();
      tray.forEach((t, i) => {
        if (t.used) return;
        const g = pieceGroup(t.cells, anyFit(t.cells) ? t.color : '#555555', 0.55); const s = slot(i); g.position.set(s.x, -0.2, s.y); g.userData.i = i; trayG.add(g);
      });
      dirty = false;
    }
    let dragG = null, dragI = -1;
    const lp = S.loop((dt, t) => {
      if (dirty) rebuild();
      ghostG.clear();
      if (drag) {
        const piece = tray[drag.i];
        if (dragI !== drag.i) { if (dragG) scene.remove(dragG); dragG = pieceGroup(piece.cells, piece.color, 1); scene.add(dragG); dragI = drag.i; }
        dragG.position.set(drag.x, 0.8, drag.y); dragG.visible = true;
        trayG.children.forEach((g) => (g.visible = g.userData.i !== drag.i));
        const d = dropAt(piece, drag.x, drag.y);
        if (d.ok) piece.cells.forEach(([dr, dc]) => { const m = new THREE.Mesh(blockGeo, bmat(piece.color, 0.35)); m.position.copy(K.pos(d.c + dc, d.r + dr, -0.1)); ghostG.add(m); });
      } else { if (dragG) { scene.remove(dragG); dragG = null; dragI = -1; } trayG.children.forEach((g) => (g.visible = true)); }
      trayG.children.forEach((g, k) => { g.position.y = -0.2 + Math.sin(t * 2 + k) * 0.05; });
      S.updateParts(dt, -0.2);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() {
        // ortadaki 4x4 alanı temizle
        for (let r = 2; r < 6; r++) for (let col = 2; col < 6; col++) grid[r][col] = null;
        over = false; hud(); dirty = true;
      },
      restart() { start(); }, destroy() { S.destroy(); window.removeEventListener('pointerup', onUp); },
    };
  },
};
