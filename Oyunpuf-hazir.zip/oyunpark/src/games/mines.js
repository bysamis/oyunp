// 💣 Mayın Tarlası
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

const NUMC = ['', '#3a86ff', '#2dc653', '#ff4d6d', '#7209b7', '#e85d04', '#118ab2', '#000', '#555'];

export default {
  id: 'mines', title: 'Mayın Tarlası', emoji: '💣', color: '#6c757d',
  desc: 'Mayınlara basmadan tüm kareleri aç!',
  winBased: true,
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    let C, R, M, cells, first, flagMode, opened, over, time, cs, ox, oy, L;

    function layout() {
      if (!C) return;
      cs = Math.floor(Math.min((st.W - 16) / C, (st.H - 80) / R));
      ox = (st.W - cs * C) / 2; oy = 64 + (st.H - 64 - cs * R) / 2;
    }
    function start() {
      L = api.level;
      C = Math.min(12, 8 + Math.floor((L - 1) / 2)); R = Math.min(16, 10 + (L - 1));
      M = Math.round(C * R * Math.min(0.22, 0.11 + L * 0.012));
      cells = Array.from({ length: R * C }, () => ({ mine: false, n: 0, open: false, flag: false, anim: 0 }));
      first = true; flagMode = false; opened = 0; over = false; time = 0;
      layout(); hud();
    }
    const at = (r, c) => (r >= 0 && r < R && c >= 0 && c < C ? cells[r * C + c] : null);
    const nbrs = (r, c) => { const o = []; for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dr || dc) { const x = at(r + dr, c + dc); if (x) o.push([r + dr, c + dc, x]); } return o; };
    function plant(sr, sc) {
      let k = 0;
      while (k < M) {
        const r = (Math.random() * R) | 0, c = (Math.random() * C) | 0;
        if (Math.abs(r - sr) <= 1 && Math.abs(c - sc) <= 1) continue;
        const x = at(r, c); if (x.mine) continue; x.mine = true; k++;
      }
      for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) at(r, c).n = nbrs(r, c).filter(([, , x]) => x.mine).length;
    }
    function hud() {
      const flags = cells.filter((x) => x.flag).length;
      api.setHud({ score: M - flags, scoreLabel: '💣', extra: `⏱ ${Math.floor(time)} sn · ${C}×${R}` });
    }
    function reveal(r, c) {
      const stack = [[r, c]];
      while (stack.length) {
        const [rr, cc] = stack.pop(); const x = at(rr, cc);
        if (!x || x.open || x.flag) continue;
        x.open = true; x.anim = 0.01; opened++;
        if (x.n === 0 && !x.mine) nbrs(rr, cc).forEach(([a, b]) => stack.push([a, b]));
      }
    }
    function tap(r, c, longPress) {
      const x = at(r, c); if (!x || over) return;
      if (flagMode || longPress) { if (!x.open) { x.flag = !x.flag; api.sfx.click(); api.haptic('light'); hud(); } return; }
      if (x.flag) return;
      if (first) { plant(r, c); first = false; }
      if (x.open) { // akor: etrafındaki bayrak sayısı tutuyorsa komşuları aç
        const f = nbrs(r, c).filter(([, , y]) => y.flag).length;
        if (f === x.n) nbrs(r, c).forEach(([a, b, y]) => { if (!y.flag && !y.open) { if (y.mine) boom(a, b); else reveal(a, b); } });
      } else if (x.mine) { boom(r, c); return; }
      else { reveal(r, c); api.sfx.pop(); }
      if (!over && opened === R * C - M) win();
    }
    function boom(r, c) {
      over = true;
      cells.forEach((x) => { if (x.mine) x.open = true; });
      fx.burst(ox + (c + 0.5) * cs, oy + (r + 0.5) * cs, '#ff4d6d', 40, 300);
      api.sfx.crash(); api.haptic('heavy');
      setTimeout(() => api.gameOver({ score: opened * 2, coins: Math.floor(opened / 6), title: 'Mayına bastın! 💥' }), 900);
    }
    function win() {
      over = true; api.sfx.win();
      const score = Math.max(100, M * 40 - Math.floor(time) * 2);
      setTimeout(() => api.gameOver({ score, coins: 15 + M, win: true, title: 'Tarlayı temizledin! 🏆' }), 600);
    }
    let pressT = null, pressPos = null;
    st.canvas.addEventListener('pointerdown', (e) => {
      const p = st.point(e);
      if (p.y < 60) { if (p.x > st.W / 2 - 90 && p.x < st.W / 2 + 90) { flagMode = !flagMode; api.sfx.click(); } return; }
      pressPos = p;
      pressT = setTimeout(() => { pressT = null; const c = Math.floor((p.x - ox) / cs), r = Math.floor((p.y - oy) / cs); tap(r, c, true); pressPos = null; }, 420);
    });
    st.canvas.addEventListener('pointerup', () => {
      if (pressT && pressPos) { clearTimeout(pressT); const c = Math.floor((pressPos.x - ox) / cs), r = Math.floor((pressPos.y - oy) / cs); tap(r, c, false); }
      pressT = null; pressPos = null;
    });

    function update(dt) {
      if (!over && !first) { const b = Math.floor(time); time += dt; if (Math.floor(time) !== b) hud(); }
      cells.forEach((x) => { if (x.anim > 0 && x.anim < 1) x.anim = Math.min(1, x.anim + dt * 6); });
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx;
      c.fillStyle = '#dee2e6'; c.fillRect(0, 0, st.W, st.H);
      roundRect(c, st.W / 2 - 90, 12, 180, 38, 19); c.fillStyle = flagMode ? '#ff4d6d' : '#adb5bd'; c.fill();
      c.fillStyle = '#fff'; c.font = '800 15px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(flagMode ? '🚩 Bayrak modu AÇIK' : '⛏️ Kazma modu', st.W / 2, 31);
      for (let r = 0; r < R; r++) for (let col = 0; col < C; col++) {
        const x = at(r, col), px = ox + col * cs, py = oy + r * cs;
        if (x.open) {
          c.fillStyle = x.mine ? '#ff8fa3' : '#f8f9fa'; c.fillRect(px + 1, py + 1, cs - 2, cs - 2);
          if (x.mine) { c.fillStyle = '#212529'; c.beginPath(); c.arc(px + cs / 2, py + cs / 2, cs * 0.25, 0, 7); c.fill(); }
          else if (x.n) { c.fillStyle = NUMC[x.n]; c.font = `900 ${cs * 0.55}px system-ui`; c.fillText(x.n, px + cs / 2, py + cs / 2 + 1); }
        } else {
          roundRect(c, px + 1, py + 1, cs - 2, cs - 2, 5); c.fillStyle = '#74c69d'; c.fill();
          c.fillStyle = 'rgba(255,255,255,.25)'; c.fillRect(px + 3, py + 3, cs - 6, cs * 0.2);
          if (x.flag) { c.font = `${cs * 0.55}px system-ui`; c.fillText('🚩', px + cs / 2, py + cs / 2 + 1); }
        }
      }
      c.textBaseline = 'alphabetic';
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
