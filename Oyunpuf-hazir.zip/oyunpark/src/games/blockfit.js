// 🟦 Blok Yerleştir: 3 parçayı tahtaya sürükle, dolan satır/sütunları temizle
import { createStage, loop, roundRect, shade, particles } from '../core/canvas.js';

const N = 8;
// [hücreler, zorluk ağırlığı] — büyük/garip parçalar yüksek seviyede daha sık gelir
const SHAPES = [
  [[[0, 0]], 0], [[[0, 0], [0, 1]], 0], [[[0, 0], [1, 0]], 0],
  [[[0, 0], [0, 1], [1, 0], [1, 1]], 1], [[[0, 0], [0, 1], [0, 2]], 1], [[[0, 0], [1, 0], [2, 0]], 1],
  [[[0, 0], [1, 0], [1, 1]], 1], [[[0, 1], [1, 0], [1, 1]], 1],
  [[[0, 0], [0, 1], [0, 2], [0, 3]], 2], [[[0, 0], [1, 0], [2, 0], [3, 0]], 2],
  [[[0, 0], [1, 0], [2, 0], [2, 1]], 2], [[[0, 1], [1, 1], [2, 1], [2, 0]], 2], [[[0, 0], [0, 1], [0, 2], [1, 1]], 2],
  [[[0, 1], [1, 0], [1, 1], [2, 0]], 3], [[[0, 0], [1, 0], [1, 1], [2, 1]], 3],
  [[[0, 0], [0, 1], [0, 2], [0, 3], [0, 4]], 3], [[[0, 0], [1, 0], [2, 0], [3, 0], [4, 0]], 3],
  [[[0, 0], [0, 1], [0, 2], [1, 0], [2, 0]], 3], [[[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]], 4],
  [[[0, 0], [1, 1], [2, 2]], 4], [[[0, 2], [1, 1], [2, 0]], 4],
];
const COLORS = ['#ff4d6d', '#ff9f1c', '#ffd60a', '#2dc653', '#3a86ff', '#9d4edd', '#06d6a0'];

export default {
  id: 'blockfit', title: 'Blok Yerleştir', emoji: '🟦', color: '#3a86ff',
  desc: 'Parçaları yerleştir, satırları patlat!',
  target: (L) => Math.round(600 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    let grid, tray, drag, score, combo, over, cell, ox, oy, trayY, L, placed;

    function layout() {
      cell = Math.floor(Math.min((st.W - 24) / N, (st.H * 0.66) / N));
      ox = (st.W - cell * N) / 2; oy = 16; trayY = oy + cell * N + 20;
    }
    function pickShape() {
      // seviye ve puan arttıkça zor parça olasılığı artar
      const hard = Math.min(4, (L - 1) * 0.45 + placed / 40);
      const pool = SHAPES.map(([cells, w]) => ({ cells, wt: w <= hard + 0.5 ? 1 + (w <= hard ? w * 0.6 : 0) : 0.15 }));
      let r = Math.random() * pool.reduce((a, b) => a + b.wt, 0);
      for (const p of pool) { r -= p.wt; if (r <= 0) return p.cells; }
      return pool[0].cells;
    }
    function refill() {
      tray = [0, 1, 2].map(() => ({ cells: pickShape(), color: COLORS[(Math.random() * COLORS.length) | 0], used: false }));
    }
    function start() {
      L = api.level; layout();
      grid = Array.from({ length: N }, () => Array(N).fill(null));
      // yüksek seviyede tahtada başlangıç taşları
      const stones = Math.min(16, Math.max(0, (L - 2) * 2));
      for (let i = 0; i < stones; i++) grid[(Math.random() * N) | 0][(Math.random() * N) | 0] = '#6c757d';
      score = 0; combo = 0; over = false; drag = null; placed = 0; refill(); hud();
    }
    function hud() { api.setHud({ score, extra: combo > 1 ? `Kombo ×${combo} 🔥` : 'Parçayı tahtaya sürükle' }); }
    const fits = (cells, r, c) => cells.every(([dr, dc]) => grid[r + dr]?.[c + dc] === null);
    const anyFit = (cells) => { for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (fits(cells, r, c)) return true; return false; };
    function slot(i) { const w = st.W / 3; return { x: w * i + w / 2, y: trayY + (st.H - trayY) / 2 }; }
    const size = (cells) => [Math.max(...cells.map((p) => p[0])) + 1, Math.max(...cells.map((p) => p[1])) + 1];

    function dropAt(piece, px, py) {
      const [h, w] = size(piece.cells);
      const c = Math.round((px - ox) / cell - w / 2), r = Math.round((py - oy) / cell - h / 2);
      return { r, c, ok: fits(piece.cells, r, c) };
    }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = st.point(e);
      tray.forEach((t, i) => {
        if (t.used) return;
        const s = slot(i);
        if (Math.abs(p.x - s.x) < st.W / 6 && p.y > trayY - 10) { drag = { i, x: p.x, y: p.y - cell * 2 }; api.sfx.click(); }
      });
    });
    st.canvas.addEventListener('pointermove', (e) => { if (drag) { const p = st.point(e); drag.x = p.x; drag.y = p.y - cell * 2; } });
    const onUp = () => {
      if (!drag) return;
      const piece = tray[drag.i], d = dropAt(piece, drag.x, drag.y);
      if (d.ok) place(piece, d.r, d.c); else api.sfx.wrong();
      drag = null;
    };
    window.addEventListener('pointerup', onUp);

    function place(piece, r, c) {
      piece.cells.forEach(([dr, dc]) => (grid[r + dr][c + dc] = piece.color));
      piece.used = true; placed++;
      score += piece.cells.length; api.sfx.slide(); api.haptic('light');
      // dolan satır ve sütunlar
      const rows = [], cols = [];
      for (let i = 0; i < N; i++) { if (grid[i].every(Boolean)) rows.push(i); if (grid.every((row) => row[i])) cols.push(i); }
      const lines = rows.length + cols.length;
      if (lines) {
        combo++;
        rows.forEach((i) => grid[i].forEach((col, j) => { fx.burst(ox + (j + 0.5) * cell, oy + (i + 0.5) * cell, col, 4, 120); grid[i][j] = null; }));
        cols.forEach((j) => grid.forEach((row, i) => { if (row[j]) fx.burst(ox + (j + 0.5) * cell, oy + (i + 0.5) * cell, row[j], 4, 120); row[j] = null; }));
        const pts = lines * 10 * lines * combo;
        score += pts; fx.text(st.W / 2, oy + cell * N / 2, `+${pts}${combo > 1 ? ' ×' + combo : ''}`, '#fff');
        lines > 1 || combo > 1 ? api.sfx.combo(combo) : api.sfx.pop(); api.haptic('medium');
      } else combo = 0;
      if (tray.every((t) => t.used)) refill();
      hud();
      if (!tray.some((t) => !t.used && anyFit(t.cells))) {
        over = true; api.sfx.lose();
        setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 40), canContinue: true, title: 'Yer kalmadı! 🟦' }), 500);
      }
    }

    function drawBlock(c, x, y, s, col, a = 1) {
      c.globalAlpha = a;
      roundRect(c, x + 1.5, y + 1.5, s - 3, s - 3, s * 0.18);
      const g = c.createLinearGradient(0, y, 0, y + s); g.addColorStop(0, shade(col, 45)); g.addColorStop(1, shade(col, -25));
      c.fillStyle = g; c.fill();
      c.fillStyle = 'rgba(255,255,255,.35)'; roundRect(c, x + 4, y + 3, s - 8, s * 0.22, 3); c.fill();
      c.globalAlpha = 1;
    }
    function update(dt) { fx.update(dt); draw(); }
    function draw() {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H); g.addColorStop(0, '#1d3557'); g.addColorStop(1, '#14213d');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      roundRect(c, ox - 6, oy - 6, cell * N + 12, cell * N + 12, 14); c.fillStyle = 'rgba(0,0,0,.3)'; c.fill();
      for (let r = 0; r < N; r++) for (let col = 0; col < N; col++) {
        const x = ox + col * cell, y = oy + r * cell;
        if (grid[r][col]) drawBlock(c, x, y, cell, grid[r][col]);
        else { c.fillStyle = 'rgba(255,255,255,.06)'; roundRect(c, x + 2, y + 2, cell - 4, cell - 4, 5); c.fill(); }
      }
      if (drag) {
        const piece = tray[drag.i], d = dropAt(piece, drag.x, drag.y);
        if (d.ok) piece.cells.forEach(([dr, dc]) => drawBlock(c, ox + (d.c + dc) * cell, oy + (d.r + dr) * cell, cell, piece.color, 0.35));
      }
      tray.forEach((t, i) => {
        if (t.used) return;
        const dragging = drag && drag.i === i;
        const s = dragging ? cell : cell * 0.55;
        const [h, w] = size(t.cells);
        const cx = dragging ? drag.x : slot(i).x, cy = dragging ? drag.y : slot(i).y;
        const fitsSomewhere = anyFit(t.cells);
        t.cells.forEach(([dr, dc]) => drawBlock(c, cx - (w * s) / 2 + dc * s, cy - (h * s) / 2 + dr * s, s, fitsSomewhere ? t.color : '#555'));
      });
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() {
        // ortadaki 4x4 alanı temizle
        for (let r = 2; r < 6; r++) for (let col = 2; col < 6; col++) grid[r][col] = null;
        over = false; hud();
      },
      restart() { start(); }, destroy() { lp.stop(); st.destroy(); window.removeEventListener('pointerup', onUp); },
    };
  },
};
