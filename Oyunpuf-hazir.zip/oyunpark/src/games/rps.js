// ✊ Taş Kağıt Makas (online, 2 kişi): ikisi de gizlice seçer, sonra aynı anda açılır. İlk 3 alan kazanır
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

const PICKS = ['rock', 'paper', 'scissors'];
const NAMES = { rock: 'Taş', paper: 'Kağıt', scissors: 'Makas' };
const beats = (a, b) => (a === 'rock' && b === 'scissors') || (a === 'paper' && b === 'rock') || (a === 'scissors' && b === 'paper');
const WIN = 3;

function drawHand(c, kind, x, y, s, color) {
  c.save(); c.translate(x, y); c.fillStyle = color; c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = s * 0.05;
  if (kind === 'rock') {
    c.beginPath(); c.ellipse(0, 0, s * 0.42, s * 0.36, 0, 0, 7); c.fill(); c.stroke();
    for (let i = 0; i < 4; i++) { c.beginPath(); c.arc(-s * 0.27 + i * s * 0.18, -s * 0.25, s * 0.1, 0, 7); c.fill(); c.stroke(); }
  } else if (kind === 'paper') {
    roundRect(c, -s * 0.32, -s * 0.42, s * 0.64, s * 0.84, s * 0.08); c.fill(); c.stroke();
    c.strokeStyle = 'rgba(0,0,0,.2)'; for (let i = 0; i < 5; i++) { c.beginPath(); c.moveTo(-s * 0.22, -s * 0.25 + i * s * 0.13); c.lineTo(s * 0.22, -s * 0.25 + i * s * 0.13); c.stroke(); }
  } else {
    c.rotate(-0.4); c.beginPath(); c.ellipse(-s * 0.06, -s * 0.15, s * 0.07, s * 0.36, -0.25, 0, 7); c.fill(); c.stroke();
    c.rotate(0.8); c.beginPath(); c.ellipse(s * 0.06, -s * 0.15, s * 0.07, s * 0.36, 0.25, 0, 7); c.fill(); c.stroke();
    c.rotate(-0.4); c.fillStyle = '#ef233c'; [-1, 1].forEach((d) => { c.beginPath(); c.arc(d * s * 0.14, s * 0.25, s * 0.12, 0, 7); c.fill(); });
  }
  c.restore();
}

export default {
  id: 'rps', title: 'Taş Kağıt Makas', emoji: '✊', color: '#8338ec',
  desc: 'Gizlice seç, aynı anda aç! İlk 3 kazanır',
  onlineOnly: true, online: { min: 2, max: 2 },
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    const ON = api.mp?.online, me = ON?.me ?? 0, names = api.mp?.names || ['Sen', 'Rakip'];
    let round, mine, theirs, score, phase, revealT, over, lastResult;
    const theirsQueue = {};
    ON?.on((m) => { if (m.pick) theirsQueue[m.r] = m.pick; });

    function start() { round = 1; score = [0, 0]; over = false; nextRound(); }
    function nextRound() { mine = null; theirs = null; phase = 'pick'; revealT = 0; lastResult = ''; hud(); }
    function hud() { api.setHud({ score: `${score[me]} - ${score[1 - me]}`, scoreLabel: `Sen · ${names[1 - me]}`, extra: phase === 'pick' ? (mine ? 'Rakibin seçmesi bekleniyor…' : 'Seçimini yap!') : `Tur ${round}` }); }
    function btn(i) { const w = Math.min(st.W - 24, 460), bw = (w - 20) / 3; return { x: (st.W - w) / 2 + i * (bw + 10), y: st.H - bw - 30, w: bw, h: bw }; }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (over || phase !== 'pick' || mine) return;
      const p = st.point(e);
      for (let i = 0; i < 3; i++) { const b = btn(i); if (p.x > b.x && p.x < b.x + b.w && p.y > b.y && p.y < b.y + b.h) { mine = PICKS[i]; ON?.send({ r: round, pick: mine }); api.sfx.tap(); api.haptic('light'); hud(); } }
    });
    function update(dt) {
      if (phase === 'pick' && theirsQueue[round]) { theirs = theirsQueue[round]; }
      if (phase === 'pick' && mine && theirs) { phase = 'reveal'; revealT = 0; api.sfx.swap(); }
      if (phase === 'reveal') {
        revealT += dt;
        if (revealT > 1.0 && !lastResult) {
          if (mine === theirs) { lastResult = 'Berabere!'; api.sfx.slide(); }
          else if (beats(mine, theirs)) { score[me]++; lastResult = 'Bu turu kazandın! 🎉'; api.sfx.coin(); fx.burst(st.W / 2, st.H * 0.62, '#ffd60a', 24, 220); }
          else { score[1 - me]++; lastResult = `${names[1 - me]} aldı`; api.sfx.wrong(); }
          hud();
          if (score[0] >= WIN || score[1] >= WIN) { over = true; setTimeout(() => api.gameOver({ winner: score[0] >= WIN ? 0 : 1 }), 1400); }
        }
        if (revealT > 2.4 && !over) { delete theirsQueue[round]; round++; nextRound(); }
      }
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H); g.addColorStop(0, '#3a0ca3'); g.addColorStop(1, '#7209b7');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      const s = Math.min(st.W * 0.38, 170);
      c.fillStyle = '#fff'; c.textAlign = 'center'; c.font = '800 16px system-ui';
      c.fillText(names[1 - me], st.W / 2, 34);
      // rakibin eli (açılınca görünür)
      const shake = phase === 'reveal' && revealT < 1 ? Math.sin(revealT * 30) * 12 : 0;
      if (phase === 'reveal' && revealT >= 1) drawHand(c, theirs, st.W / 2, 50 + s / 2, s, '#ffd6a5');
      else { c.fillStyle = 'rgba(255,255,255,.15)'; roundRect(c, st.W / 2 - s / 2, 50 + shake, s, s, 24); c.fill(); c.fillStyle = '#fff'; c.font = `900 ${s * 0.5}px system-ui`; c.textBaseline = 'middle'; c.fillText(theirs ? '✓' : '?', st.W / 2, 50 + s / 2 + shake); c.textBaseline = 'alphabetic'; }
      // benim seçimim
      const my = st.H * 0.62;
      if (mine) drawHand(c, mine, st.W / 2, my - shake, s * 0.9, '#ffd6a5');
      c.fillStyle = '#fff'; c.font = '900 22px system-ui';
      if (lastResult) c.fillText(lastResult, st.W / 2, (50 + s + my - s * 0.45) / 2 + 8);
      for (let i = 0; i < 3; i++) {
        const b = btn(i), on = mine === PICKS[i];
        roundRect(c, b.x, b.y, b.w, b.h, 20); c.fillStyle = on ? '#ffd60a' : 'rgba(255,255,255,.92)'; c.fill();
        drawHand(c, PICKS[i], b.x + b.w / 2, b.y + b.h / 2 - 10, b.w * 0.6, '#ffcb9a');
        c.fillStyle = '#3a0ca3'; c.font = '800 14px system-ui'; c.fillText(NAMES[PICKS[i]], b.x + b.w / 2, b.y + b.h - 10);
      }
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { Object.keys(theirsQueue).forEach((k) => delete theirsQueue[k]); start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
