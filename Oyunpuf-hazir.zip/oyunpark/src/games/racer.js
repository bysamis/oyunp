// 🏎️ Araba Yarışı (şerit değiştirerek engellerden kaç)
import { createStage, loop, roundRect, shade, particles } from '../core/canvas.js';
import { store } from '../core/store.js';

export const CAR_SKINS = {
  red: { name: 'Kırmızı Şimşek', color: '#ff3b3b', price: 0 },
  blue: { name: 'Mavi Roket', color: '#3a86ff', price: 250 },
  green: { name: 'Yeşil Turbo', color: '#2dc653', price: 250 },
  pink: { name: 'Pembe Pırlanta', color: '#ff70a6', price: 400 },
  purple: { name: 'Mor Fırtına', color: '#9d4edd', price: 400 },
  black: { name: 'Gece Kartalı', color: '#2b2d42', price: 700 },
  gold: { name: 'Altın VIP', color: '#ffc300', price: 3000 },
};
const TRAFFIC = ['#06d6a0', '#118ab2', '#ef476f', '#ffd166', '#8338ec', '#fb8500', '#adb5bd'];
const LANES = 3;

export function drawCar(c, x, y, w, h, color, opts = {}) {
  c.save(); c.translate(x, y);
  if (opts.flip) c.rotate(Math.PI);
  // gölge
  c.fillStyle = 'rgba(0,0,0,.25)'; roundRect(c, -w / 2 + 3, -h / 2 + 5, w, h, w * 0.3); c.fill();
  // tekerlekler
  c.fillStyle = '#111';
  [[-1, -0.3], [1, -0.3], [-1, 0.3], [1, 0.3]].forEach(([sx, sy]) => { roundRect(c, sx * w / 2 - (sx > 0 ? w * 0.12 : 0) - (sx < 0 ? w * 0.06 : 0), sy * h - h * 0.1, w * 0.18, h * 0.2, 3); c.fill(); });
  // gövde
  const g = c.createLinearGradient(-w / 2, 0, w / 2, 0);
  g.addColorStop(0, shade(color, -40)); g.addColorStop(0.5, shade(color, 30)); g.addColorStop(1, shade(color, -40));
  c.fillStyle = g; roundRect(c, -w / 2, -h / 2, w, h, w * 0.3); c.fill();
  // camlar
  c.fillStyle = 'rgba(20,30,60,.85)';
  roundRect(c, -w * 0.36, -h * 0.22, w * 0.72, h * 0.2, 5); c.fill();
  roundRect(c, -w * 0.32, h * 0.15, w * 0.64, h * 0.14, 5); c.fill();
  c.fillStyle = shade(color, 15); roundRect(c, -w * 0.33, -h * 0.02, w * 0.66, h * 0.16, 4); c.fill();
  // farlar
  c.fillStyle = '#fff6b0';
  c.beginPath(); c.arc(-w * 0.3, -h * 0.45, w * 0.08, 0, 7); c.arc(w * 0.3, -h * 0.45, w * 0.08, 0, 7); c.fill();
  // şerit
  if (opts.stripe) { c.fillStyle = 'rgba(255,255,255,.8)'; c.fillRect(-w * 0.06, -h / 2, w * 0.12, h * 0.25); }
  c.restore();
}

export default {
  id: 'racer', title: 'Araba Yarışı', emoji: '🏎️', color: '#ff9f1c',
  desc: 'Şerit değiştir, arabalardan kaç, altınları topla!',
  target: (L) => Math.round(400 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    let L, roadW, roadX, laneW, carW, carH, player, objs, speed, dist, coins, scroll, spawnIn, state, invuln, shake = 0;

    function layout() {
      roadW = Math.min(st.W * 0.86, 440);
      roadX = (st.W - roadW) / 2;
      laneW = roadW / LANES;
      carW = laneW * 0.52; carH = carW * 1.8;
      if (player) { player.y = st.H - carH - 30; }
    }
    const laneX = (l) => roadX + laneW * (l + 0.5);
    const scale = () => st.H / 700;

    function start() {
      layout();
      player = { lane: 1, x: laneX(1), y: st.H - carH - 30 };
      L = api.level; objs = []; speed = (320 + (L - 1) * 40) * scale(); dist = 0; coins = 0; scroll = 0; spawnIn = 0.8; state = 'play'; invuln = 0;
      hud();
    }
    function hud() { api.setHud({ score: Math.floor(dist / 10), scoreLabel: 'Metre', extra: `🪙 ${coins}  ·  ${Math.round(speed / scale() / 3)} km/s` }); }

    function setLane(l) {
      if (state !== 'play') return;
      const nl = Math.max(0, Math.min(LANES - 1, l));
      if (nl !== player.lane) { player.lane = nl; api.sfx.lane(); api.haptic('light'); }
    }
    let downX = null;
    const onDown = (e) => { downX = st.point(e).x; };
    const onUp = (e) => {
      if (downX === null) return;
      const x = st.point(e).x, dx = x - downX;
      if (Math.abs(dx) > 30) setLane(player.lane + Math.sign(dx));
      else setLane(player.lane + (x < st.W / 2 ? -1 : 1));
      downX = null;
    };
    const onKey = (e) => {
      if (e.key === 'ArrowLeft') setLane(player.lane - 1);
      if (e.key === 'ArrowRight') setLane(player.lane + 1);
    };
    st.canvas.addEventListener('pointerdown', onDown);
    st.canvas.addEventListener('pointerup', onUp);
    window.addEventListener('keydown', onKey);

    function spawn() {
      // en az bir şerit boş kalsın
      const free = (Math.random() * LANES) | 0;
      const count = Math.random() < Math.min(0.7, 0.15 + L * 0.06 + dist / 40000) ? 2 : 1;
      const lanes = [0, 1, 2].filter((l) => l !== free).sort(() => Math.random() - 0.5).slice(0, count);
      for (const l of lanes) {
        const truck = Math.random() < 0.2;
        objs.push({ kind: 'car', lane: l, y: -carH * (truck ? 1.6 : 1), h: carH * (truck ? 1.6 : 1), w: carW * (truck ? 1.1 : 1), color: TRAFFIC[(Math.random() * TRAFFIC.length) | 0], rel: 0.35 + Math.random() * 0.25, truck });
      }
      // boş şeride altın dizisi
      if (Math.random() < 0.6) {
        for (let i = 0; i < 3; i++) objs.push({ kind: 'coin', lane: free, y: -carH - i * 50 * scale(), h: 26, w: 26 });
      }
      spawnIn = Math.max(0.32, 1.0 - L * 0.05 - dist / 30000) * (0.85 + Math.random() * 0.3);
    }

    function update(dt, t) {
      if (state === 'play') {
        speed = Math.min((820 + L * 60) * scale(), speed + (9 + L * 2) * scale() * dt);
        dist += speed * dt / scale() / 3;
        scroll = (scroll + speed * dt) % 80;
        spawnIn -= dt; if (spawnIn <= 0) spawn();
        player.x += (laneX(player.lane) - player.x) * Math.min(1, dt * 14);
        if (invuln > 0) invuln -= dt;
        for (let i = objs.length - 1; i >= 0; i--) {
          const o = objs[i];
          o.y += speed * (o.kind === 'car' ? 1 - o.rel : 1) * dt;
          if (o.y > st.H + 200) { objs.splice(i, 1); continue; }
          const ox = laneX(o.lane);
          const hit = Math.abs(ox - player.x) < (o.w + carW) / 2 * 0.78 && Math.abs(o.y - player.y) < (o.h + carH) / 2 * 0.85;
          if (hit && o.kind === 'coin') {
            objs.splice(i, 1); coins++; api.sfx.coin(); fx.burst(ox, o.y, '#ffd60a', 8, 100);
          } else if (hit && o.kind === 'car' && invuln <= 0) {
            state = 'over'; shake = 0.5;
            api.sfx.crash(); api.haptic('heavy');
            fx.burst(player.x, player.y - carH / 2, '#ff9f1c', 30, 260);
            fx.burst(player.x, player.y - carH / 2, '#555', 20, 160);
            const m = Math.floor(dist / 10);
            setTimeout(() => api.gameOver({ score: m, coins: coins + Math.floor(m / 40), canContinue: true, title: 'Kaza yaptın! 💥' }), 700);
          }
        }
        if ((t * 10 | 0) % 3 === 0) hud();
      }
      if (shake > 0) shake -= dt;
      fx.update(dt);
      draw(t);
    }

    function draw(t) {
      const c = st.ctx;
      c.save();
      if (shake > 0) c.translate((Math.random() - 0.5) * 14 * shake, (Math.random() - 0.5) * 14 * shake);
      // çim
      c.fillStyle = '#57cc99'; c.fillRect(-20, -20, st.W + 40, st.H + 40);
      c.fillStyle = '#4caf88';
      for (let y = -80 + scroll; y < st.H; y += 80) { c.fillRect(0, y, roadX, 40); c.fillRect(roadX + roadW, y, st.W, 40); }
      // ağaçlar
      for (let i = 0; i < 8; i++) {
        const y = ((i * 140 + scroll * 1.75) % (st.H + 140)) - 70;
        const side = i % 2 ? roadX - 30 : roadX + roadW + 30;
        if (side < 10 || side > st.W - 10) continue;
        c.fillStyle = '#2d6a4f'; c.beginPath(); c.arc(side, y, 20, 0, 7); c.fill();
        c.fillStyle = '#40916c'; c.beginPath(); c.arc(side - 5, y - 5, 12, 0, 7); c.fill();
      }
      // yol
      c.fillStyle = '#495057'; c.fillRect(roadX, -20, roadW, st.H + 40);
      // kenar bordürü
      for (let y = -80 + scroll; y < st.H; y += 40) {
        c.fillStyle = ((y - scroll) / 40) % 2 ? '#fff' : '#ef233c';
        c.fillRect(roadX - 8, y, 8, 40); c.fillRect(roadX + roadW, y, 8, 40);
      }
      // şerit çizgileri
      c.fillStyle = 'rgba(255,255,255,.8)';
      for (let l = 1; l < LANES; l++) {
        const x = roadX + laneW * l - 3;
        for (let y = -80 + scroll; y < st.H; y += 80) c.fillRect(x, y, 6, 40);
      }
      // nesneler
      for (const o of objs) {
        const x = laneX(o.lane);
        if (o.kind === 'coin') {
          const sx = Math.abs(Math.cos(t * 5 + o.y * 0.02));
          c.fillStyle = '#ffd60a'; c.beginPath(); c.ellipse(x, o.y, 13 * sx + 2, 13, 0, 0, 7); c.fill();
          c.strokeStyle = '#e09f00'; c.lineWidth = 2; c.stroke();
        } else if (o.truck) {
          c.save(); c.translate(x, o.y);
          c.fillStyle = 'rgba(0,0,0,.25)'; roundRect(c, -o.w / 2 + 3, -o.h / 2 + 5, o.w, o.h, 8); c.fill();
          c.fillStyle = '#dee2e6'; roundRect(c, -o.w / 2, -o.h / 2, o.w, o.h * 0.72, 6); c.fill();
          c.fillStyle = o.color; roundRect(c, -o.w / 2, o.h * 0.24, o.w, o.h * 0.26, 8); c.fill();
          c.fillStyle = 'rgba(20,30,60,.85)'; roundRect(c, -o.w * 0.35, o.h * 0.36, o.w * 0.7, o.h * 0.08, 4); c.fill();
          c.restore();
        } else {
          drawCar(c, x, o.y, o.w, o.h, o.color, { flip: false });
        }
      }
      // oyuncu
      if (!(invuln > 0 && Math.floor(t * 12) % 2)) {
        const skin = CAR_SKINS[store.get().carSkin] || CAR_SKINS.red;
        const tilt = (laneX(player.lane) - player.x) * -0.004;
        c.save(); c.translate(player.x, player.y); c.rotate(tilt);
        drawCar(c, 0, 0, carW, carH, skin.color, { stripe: true });
        c.restore();
      }
      fx.draw(c);
      c.restore();
    }

    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() {
        objs = objs.filter((o) => o.y > player.y + carH || o.kind === 'coin');
        state = 'play'; invuln = 2.5; speed *= 0.8; hud();
      },
      restart() { start(); },
      destroy() { lp.stop(); st.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
