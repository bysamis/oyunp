// 🎯 Ok Fırlat: dönen hedefe okları sapla, diğer oklara çarpma!
import { createStage, loop, particles } from '../core/canvas.js';

export default {
  id: 'arrows', title: 'Ok Fırlat', emoji: '🎯', color: '#9c6644',
  desc: 'Dönen hedefe ok sapla, oklara çarpma!',
  target: (L) => 20 + (L - 1) * 10,
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let stage, rot, rotV, arrows, left, flying, score, over, L, apples, patT, shake, burstT;
    const R = () => Math.min(st.W, st.H) * 0.22;
    const cy = () => st.H * 0.33;
    const ALEN = () => R() * 0.75;

    function setupStage() {
      // Zorluk: aşama ve seviye arttıkça ok sayısı, önceden saplı ok ve hız artar; yön değişimleri başlar
      left = Math.min(14, 6 + stage + Math.floor(L / 2));
      arrows = [];
      const pre = Math.min(7, Math.floor((L - 1) / 2) + Math.floor(stage / 2));
      for (let i = 0; i < pre; i++) arrows.push({ a: (i / pre) * Math.PI * 2 + Math.random() * 0.4, pre: true });
      apples = Math.random() < 0.6 ? [{ a: Math.random() * Math.PI * 2 }] : [];
      rotV = (1.4 + L * 0.22 + stage * 0.15) * (Math.random() < 0.5 ? 1 : -1);
      patT = 0; flying = null; burstT = 0;
      hud();
    }
    function start() { L = api.level; stage = 1; rot = 0; score = 0; over = false; shake = 0; setupStage(); }
    function hud() { api.setHud({ score, scoreLabel: 'Ok', extra: `Aşama ${stage} · Kalan ok: ${left}` }); }
    function throwArrow() {
      if (over || flying || left <= 0 || burstT > 0) return;
      flying = { y: st.H - 80, v: -1800 }; left--; api.sfx.swap(); hud();
    }
    st.canvas.addEventListener('pointerdown', throwArrow);
    const onKey = (e) => { if (e.key === ' ') throwArrow(); };
    window.addEventListener('keydown', onKey);
    const angDist = (a, b) => { let d = Math.abs(a - b) % (Math.PI * 2); return d > Math.PI ? Math.PI * 2 - d : d; };

    function update(dt, t) {
      if (!over && burstT <= 0) {
        patT += dt;
        let v = rotV;
        if (L >= 3) v *= 1 + Math.sin(patT * (0.8 + L * 0.1)) * Math.min(0.9, (L - 2) * 0.15); // hız dalgalanır
        if (L >= 5 && Math.sin(patT * 0.9) > 0.97) rotV = -rotV;                               // ani yön değişimi
        rot += v * dt;
      }
      if (flying && !over) {
        flying.y += flying.v * dt;
        const hitY = cy() + R();
        if (flying.y <= hitY) {
          const a = Math.PI / 2 - rot; // hedefin alt noktasının hedefe göre açısı
          const tooClose = arrows.some((ar) => angDist(ar.a, a) < 0.16);
          if (tooClose) {
            over = true; flying = null; shake = 0.4; api.sfx.crash(); api.haptic('heavy');
            fx.burst(st.W / 2, hitY, '#ffffff', 16);
            setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 4), canContinue: true, title: 'Oka çarptın! 🎯' }), 700);
          } else {
            arrows.push({ a }); score++; api.sfx.brick(); api.haptic('light'); shake = 0.08;
            const ap = apples.findIndex((p) => angDist(p.a, a) < 0.22);
            if (ap >= 0) { apples.splice(ap, 1); score += 3; api.sfx.coin(); fx.burst(st.W / 2, hitY, '#e63946', 14); fx.text(st.W / 2, hitY - 20, '+3 🍎', '#fff'); }
            fx.burst(st.W / 2, hitY, '#c68b59', 6, 80);
            flying = null; hud();
            if (left === 0) {
              burstT = 1; api.sfx.win(); score += 5;
              for (let i = 0; i < 4; i++) fx.burst(st.W / 2 + (Math.random() - 0.5) * R(), cy() + (Math.random() - 0.5) * R(), '#9c6644', 14, 260);
              fx.text(st.W / 2, cy(), `Aşama ${stage} tamam!`, '#ffd60a');
            }
          }
        }
      }
      if (burstT > 0) { burstT -= dt; if (burstT <= 0) { stage++; setupStage(); } }
      if (shake > 0) shake -= dt;
      fx.update(dt); draw(t);
    }
    function drawArrow(c, x, y, ang, len) {
      c.save(); c.translate(x, y); c.rotate(ang);
      c.fillStyle = '#6c757d'; c.fillRect(-2, 0, 4, len);
      c.fillStyle = '#adb5bd'; c.beginPath(); c.moveTo(0, -10); c.lineTo(7, 4); c.lineTo(-7, 4); c.fill();
      c.fillStyle = '#ef233c'; c.beginPath(); c.moveTo(-2, len - 18); c.lineTo(-9, len); c.lineTo(-2, len - 6); c.fill(); c.beginPath(); c.moveTo(2, len - 18); c.lineTo(9, len); c.lineTo(2, len - 6); c.fill();
      c.restore();
    }
    function draw() {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H); g.addColorStop(0, '#3d405b'); g.addColorStop(1, '#1b1b2f');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      c.save(); if (shake > 0) c.translate((Math.random() - 0.5) * 10 * shake * 10, 0);
      const x = st.W / 2, y = cy(), r = R();
      if (burstT <= 0) {
        // saplı oklar (hedefin arkasında)
        for (const ar of arrows) { const a = ar.a + rot; drawArrow(c, x + Math.cos(a) * r, y + Math.sin(a) * r, a - Math.PI / 2, ALEN()); }
        // ahşap hedef
        c.save(); c.translate(x, y); c.rotate(rot);
        const wg = c.createRadialGradient(0, 0, r * 0.1, 0, 0, r);
        wg.addColorStop(0, '#e9c46a'); wg.addColorStop(1, '#9c6644');
        c.fillStyle = wg; c.beginPath(); c.arc(0, 0, r, 0, 7); c.fill();
        c.strokeStyle = 'rgba(80,40,10,.35)'; c.lineWidth = 3;
        for (let k = 1; k < 4; k++) { c.beginPath(); c.arc(0, 0, (r * k) / 4, 0, 7); c.stroke(); }
        c.fillStyle = '#d62828'; c.beginPath(); c.arc(0, 0, r * 0.12, 0, 7); c.fill();
        c.restore();
        for (const ap of apples) {
          const a = ap.a + rot, ax = x + Math.cos(a) * (r + 12), ay = y + Math.sin(a) * (r + 12);
          c.fillStyle = '#e63946'; c.beginPath(); c.arc(ax, ay, 11, 0, 7); c.fill();
          c.fillStyle = '#2d6a4f'; c.beginPath(); c.ellipse(ax + 3, ay - 11, 5, 2.5, -0.5, 0, 7); c.fill();
        }
      }
      if (flying) drawArrow(c, x, flying.y, 0, ALEN());
      else if (!over && left > 0 && burstT <= 0) drawArrow(c, x, st.H - 80, 0, ALEN());
      // kalan ok göstergesi
      for (let i = 0; i < left; i++) { c.fillStyle = 'rgba(255,255,255,.75)'; c.fillRect(18, st.H - 30 - i * 14, 16, 6); }
      c.restore();
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { over = false; flying = null; left = Math.max(left, 1); hud(); },
      restart() { start(); }, destroy() { lp.stop(); st.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
