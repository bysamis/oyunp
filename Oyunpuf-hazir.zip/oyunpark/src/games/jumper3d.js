// 🐸 Zıpla Zıpla 3D: platformlardan zıplayarak yüksel (ekranın sağına/soluna basılı tut)
import { create3D, mat, THREE } from '../core/three-stage.js';
import { touchpad } from '../core/touchpad.js';
import { modelInto, stubFigure } from '../core/assets.js';

const FW = 8;           // oyun alanı genişliği
const G = 30, JUMP = 16.4;

export default {
  id: 'jumper', title: 'Zıpla Zıpla 3D', emoji: '🐸', color: '#80b918',
  desc: 'Platformlarda zıpla, en yükseğe çık!',
  target: (L) => Math.round(1500 * Math.pow(1.4, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 50, bg: 0x9bd3f5 });
    const { scene, camera, sun } = S;
    sun.shadow.camera.top = 12; sun.shadow.camera.bottom = -12;
    // arka plan: uzak tepeler ve bulutlar
    const back = new THREE.Group(); scene.add(back);
    for (let i = 0; i < 9; i++) {
      const h = new THREE.Mesh(new THREE.ConeGeometry(3 + Math.random() * 3, 6 + Math.random() * 6, 6), mat(0x74c69d, { flatShading: true }));
      h.position.set(-14 + i * 3.5, -6, -14 - Math.random() * 4); back.add(h);
    }
    const clouds = [];
    for (let i = 0; i < 10; i++) {
      const c = new THREE.Group(); const cm = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 0.55 });
      for (let k = 0; k < 4; k++) { const b = new THREE.Mesh(new THREE.SphereGeometry(0.6 + Math.random() * 0.4, 12, 8), cm); b.position.set(k * 0.7 - 1, Math.random() * 0.3, 0); c.add(b); }
      c.position.set((Math.random() - 0.5) * 18, i * 6, -9 - Math.random() * 5); scene.add(c); clouds.push(c);
    }
    // kahraman (Kenney karakteri)
    const hero = new THREE.Group(); scene.add(hero);
    const heroHolder = modelInto(hero, 'character', { height: 1.75, anim: 'jump', fallback: stubFigure(0x80b918, 1.6) });
    heroHolder.rotation.y = 0;
    const coinTpl = [];
    
    let p, plats, camY, maxH, score, over, hold, L, coinsGot, platGroup;
    function clearPlats() { if (platGroup) scene.remove(platGroup); platGroup = new THREE.Group(); scene.add(platGroup); }
    function start() {
      L = api.level; clearPlats();
      p = { x: 0, y: 1, vx: 0, vy: 0 };
      plats = []; camY = 0; maxH = 0; score = 0; over = false; hold = 0; coinsGot = 0;
      addPlat(0, 0, 2.2, 'n', false);
      let y = 0;
      while (y < 20) { y += gapFor(0); addPlatRandom(y); }
      hud();
    }
    const gapFor = (h) => Math.min(3, (62 + L * 6 + h * 10) / 50);
    function addPlat(x, y, w, kind, coin) {
      const g = new THREE.Group(); g.position.set(x, y, 0); platGroup.add(g);
      const col = kind === 'move' ? 0x4cc9f0 : kind === 'break' ? 0xc9a27e : 0x6bcb3c;
      const base = new THREE.Mesh(new THREE.BoxGeometry(w, 0.32, 1.2), mat(kind === 'break' ? 0x8d6748 : 0x7f5539));
      base.position.y = -0.3; base.castShadow = true; base.receiveShadow = true; g.add(base);
      const top = new THREE.Mesh(new THREE.BoxGeometry(w + 0.08, 0.16, 1.28), mat(col));
      top.position.y = -0.08; top.castShadow = true; top.receiveShadow = true; g.add(top);
      if (kind === 'break') { const crack = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.5, 1.3), mat(0x3d2b1f)); crack.position.set(w * 0.1, -0.2, 0); crack.rotation.z = 0.4; g.add(crack); }
      if (kind === 'move') { [-1, 1].forEach((d) => { const a = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.25, 8), mat(0xffffff)); a.rotation.z = -d * Math.PI / 2; a.position.set(d * (w / 2 + 0.18), -0.1, 0); g.add(a); }); }
      if (kind === 'n' && Math.random() < 0.5) { const gr = modelInto(g, 'grass-small', { height: 0.3 }); gr.position.set((Math.random() - 0.5) * (w - 0.4), 0, -0.3); }
      let coinM = null;
      if (coin) { coinM = modelInto(g, 'coin', { height: 0.6, glow: 0xffb703 }); coinM.position.y = 0.6; }
      const pl = { x, y, w, kind, dir: Math.random() < 0.5 ? -1 : 1, coin, g, coinM };
      plats.push(pl); return pl;
    }
    function addPlatRandom(y) {
      const h = y;
      const w = Math.max(0.96, (90 - L * 4 - h * 10 / 6) / 50 * 1.1);
      const r = Math.random();
      const kind = r < Math.min(0.35, 0.05 + L * 0.03 + h / 400) ? 'move' : r < Math.min(0.55, 0.1 + L * 0.04 + h / 500) ? 'break' : 'n';
      addPlat((Math.random() - 0.5) * (FW - w), y, w, kind, Math.random() < 0.15);
    }
    function hud() { api.setHud({ score, scoreLabel: 'Yükseklik', extra: `🪙 ${coinsGot}` }); }

    const onDown = (e) => { const r = S.el.getBoundingClientRect(); hold = e.clientX - r.left < r.width / 2 ? -1 : 1; };
    const onUp = () => { hold = 0; };
    S.el.addEventListener('pointerdown', onDown);
    S.el.addEventListener('pointermove', (e) => { if (e.buttons) onDown(e); });
    window.addEventListener('pointerup', onUp);
    const keys = {};
    const pad = touchpad(host, { left: [{ id: 'left', icon: '◀', big: true }], right: [{ id: 'right', icon: '▶', big: true }] });
    const kd = (e) => { keys[e.key] = true; }, ku = (e) => { keys[e.key] = false; };
    window.addEventListener('keydown', kd); window.addEventListener('keyup', ku);

    // ekran genişliğine göre kamera mesafesi (tüm alan görünsün)
    let camDist = 14;
    S.onResize(() => { const a = S.w / S.h; const vfov = (camera.fov * Math.PI) / 180; camDist = Math.max(10, (FW / 2 + 1) / (Math.tan(vfov / 2) * a)); });

    const lp = S.loop((dt, time) => {
      if (!over) {
        const dir = (pad.held.left ? -1 : pad.held.right ? 1 : 0) || hold || (keys.ArrowLeft ? -1 : keys.ArrowRight ? 1 : 0);
        p.vx += (dir * 8.4 - p.vx) * Math.min(1, dt * 8);
        p.x += p.vx * dt;
        if (p.x < -FW / 2 - 0.4) p.x = FW / 2 + 0.4; if (p.x > FW / 2 + 0.4) p.x = -FW / 2 - 0.4;
        const prevY = p.y;
        p.vy -= G * dt; p.y += p.vy * dt;
        for (const pl of plats) {
          if (pl.kind === 'move') { pl.x += pl.dir * (60 + L * 15) / 50 * dt; if (pl.x - pl.w / 2 < -FW / 2 || pl.x + pl.w / 2 > FW / 2) pl.dir *= -1; pl.g.position.x = pl.x; }
          if (pl.dead) continue;
          if (p.vy < 0 && prevY >= pl.y - 0.05 && p.y <= pl.y && Math.abs(p.x - pl.x) < pl.w / 2 + 0.25) {
            if (pl.kind === 'break') {
              pl.dead = true; pl.fall = 0; S.burst(new THREE.Vector3(pl.x, pl.y, 0), 0xa98467, 10, 4); api.sfx.brick(); continue;
            }
            p.y = pl.y; p.vy = JUMP; api.sfx.bounce();
            heroHolder.userData.model?.userData.play('jump', 0.05);
            hero.scale.set(1.2, 0.8, 1.2);
            if (pl.coin) { pl.coin = false; pl.g.remove(pl.coinM); coinsGot++; api.sfx.coin(); S.burst(new THREE.Vector3(pl.x, pl.y + 0.8, 0), 0xffd60a, 10, 4, 0.7); hud(); }
          }
        }
        const target = p.y - 2.5;
        if (target > camY) camY = target;
        const h = Math.floor(p.y * 5);
        if (h > maxH) { maxH = h; score = maxH; hud(); }
        let top = Math.max(...plats.map((q) => q.y));
        while (top < camY + 16) { top += gapFor(top); addPlatRandom(top); }
        plats = plats.filter((q) => { if (q.y < camY - 10) { platGroup.remove(q.g); return false; } return true; });
        if (p.y < camY - 7) {
          over = true; api.sfx.lose(); api.haptic('heavy');
          api.gameOver({ score, coins: coinsGot * 5 + Math.floor(score / 60), canContinue: true, title: 'Düştün! 🐸' });
        }
      }
      // kırılan platformlar düşer
      for (const pl of plats) if (pl.dead) { pl.fall += dt; pl.g.position.y = pl.y - pl.fall * pl.fall * 8; pl.g.rotation.z += dt * 2; }
      for (const pl of plats) if (pl.coinM) pl.coinM.rotation.y = time * 3;
      // kahraman
      hero.position.set(p.x, p.y, 0);
      hero.rotation.y = THREE.MathUtils.lerp(hero.rotation.y, p.vx * 0.12, Math.min(1, dt * 8));
      hero.scale.lerp(new THREE.Vector3(1, 1, 1), Math.min(1, dt * 10));
      heroHolder.userData.model?.userData.update(dt);
      // gökyüzü yükseldikçe kararır
      const k = Math.min(1, score / 8000);
      scene.background.setHSL((200 + k * 60) / 360, 0.7, 0.75 - k * 0.5);
      // kamera
      camera.position.set(0, camY + 4.2, camDist); camera.lookAt(0, camY + 1.2, 0); // kahraman ekranın alt-orta kısmında, düğmelerin üstünde kalır
      sun.position.set(-6, camY + 14, 8); sun.target.position.set(0, camY, 0);
      back.position.y = camY * 0.85;
      clouds.forEach((c) => { if (c.position.y < camY - 10) c.position.y += 60; c.position.x += dt * 0.3; if (c.position.x > 9) c.position.x = -9; });
      S.updateParts(dt, -999);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() {
        p.y = camY + 2; p.vy = JUMP;
        addPlat(p.x, p.y - 0.5, 2.4, 'n', false); over = false;
      },
      restart() { start(); },
      destroy() { pad.destroy(); S.destroy(); window.removeEventListener('pointerup', onUp); window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku); },
    };
  },
};
