// ⚫ Dama (çapraz dama): taş yeme zorunlu, karşıya ulaşan taş kral olur
import { createStage, loop, particles } from '../core/canvas.js';

const N = 8;
// taşlar: 1 = oyuncu (beyaz, aşağıdan yukarı), 2 = bilgisayar; kral: 3 / 4
const own = (v, p) => v && ((v - 1) % 2) + 1 === p;
const isKing = (v) => v >= 3;

function movesFor(b, p) {
  const caps = [], steps = [];
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    const v = b[r][c]; if (!own(v, p)) continue;
    const dirs = isKing(v) ? [[1, 1], [1, -1], [-1, 1], [-1, -1]] : p === 1 ? [[-1, 1], [-1, -1]] : [[1, 1], [1, -1]];
    // çoklu yeme zincirlerini bul
    const chain = (bb, rr, cc, path, eaten) => {
      let found = false;
      const vv = bb[rr][cc];
      const ds = isKing(vv) ? [[1, 1], [1, -1], [-1, 1], [-1, -1]] : dirs;
      for (const [dr, dc] of ds) {
        const mr = rr + dr, mc = cc + dc, tr = rr + dr * 2, tc = cc + dc * 2;
        if (tr < 0 || tr >= N || tc < 0 || tc >= N) continue;
        const mid = bb[mr][mc];
        if (mid && !own(mid, p) && !bb[tr][tc] && !eaten.some(([a, b2]) => a === mr && b2 === mc)) {
          found = true;
          const nb = bb.map((row) => row.slice());
          nb[tr][tc] = nb[rr][cc]; nb[rr][cc] = 0; nb[mr][mc] = 0;
          chain(nb, tr, tc, [...path, [tr, tc]], [...eaten, [mr, mc]]);
        }
      }
      if (!found && path.length > 1) caps.push({ from: path[0], path: path.slice(1), eaten });
    };
    chain(b, r, c, [[r, c]], []);
    for (const [dr, dc] of dirs) {
      const tr = r + dr, tc = c + dc;
      if (tr >= 0 && tr < N && tc >= 0 && tc < N && !b[tr][tc]) steps.push({ from: [r, c], path: [[tr, tc]], eaten: [] });
    }
  }
  return caps.length ? caps : steps; // yeme zorunlu
}
function apply(b, m) {
  const nb = b.map((row) => row.slice());
  const [fr, fc] = m.from, [tr, tc] = m.path[m.path.length - 1];
  let v = nb[fr][fc]; nb[fr][fc] = 0;
  m.eaten.forEach(([r, c]) => (nb[r][c] = 0));
  if (v === 1 && tr === 0) v = 3; if (v === 2 && tr === N - 1) v = 4;
  nb[tr][tc] = v;
  return nb;
}
function score(b) {
  let s = 0;
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    const v = b[r][c]; if (!v) continue;
    const val = isKing(v) ? 3 : 1 + (own(v, 2) ? r : N - 1 - r) * 0.05;
    s += own(v, 2) ? val : -val;
  }
  return s;
}
function search(b, depth, alpha, beta, p) {
  const ms = movesFor(b, p);
  if (!ms.length) return p === 2 ? -100 - depth : 100 + depth;
  if (depth === 0) return score(b);
  if (p === 2) { let best = -Infinity; for (const m of ms) { best = Math.max(best, search(apply(b, m), depth - 1, alpha, beta, 1)); alpha = Math.max(alpha, best); if (alpha >= beta) break; } return best; }
  let best = Infinity; for (const m of ms) { best = Math.min(best, search(apply(b, m), depth - 1, alpha, beta, 2)); beta = Math.min(beta, best); if (alpha >= beta) break; } return best;
}

export default {
  id: 'checkers', title: 'Dama', emoji: '⚫', color: '#6f4518',
  desc: 'Rakip taşlarını ye, kral ol, kazan!',
  winBased: true,
  players: { min: 2, max: 2 },
  online: { min: 2, max: 2 },
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let b, turn, sel, legal, over, L, anim, eatenByMe, moveCount;

    // online: kurucu beyaz (alt), katılan siyah; siyah oynayanın ekranında tahta 180° çevrilir
    const ON = api.mp?.online, flip = !!(ON && ON.me === 1), inbox = [];
    ON?.on((m) => inbox.push(m));
    const samePath = (a, b) => JSON.stringify(a) === JSON.stringify(b);
    function start() {
      inbox.length = 0;
      L = api.level;
      b = Array.from({ length: N }, (_, r) => Array.from({ length: N }, (_, c) => ((r + c) % 2 === 1 ? (r < 3 ? 2 : r > 4 ? 1 : 0) : 0)));
      turn = 1; sel = null; over = false; anim = null; eatenByMe = 0; moveCount = 0;
      legal = movesFor(b, 1); hud();
    }
    // Zorluk: bilgisayarın kaç hamle ileriyi düşündüğü (1 → 6) ve hata payı
    const depth = () => Math.min(5, L);
    const mistake = () => Math.max(0, 0.4 - (L - 1) * 0.1);
    function count(p) { let n = 0; b.forEach((row) => row.forEach((v) => own(v, p) && n++)); return n; }
    function hud() { api.setHud({ score: eatenByMe, scoreLabel: 'Yenen', extra: over ? '' : ON ? `${turn === ON.me + 1 ? 'Senin sıran' : api.mp.names[turn - 1] + ' düşünüyor…'} ${turn === 1 ? '⚪' : '⚫'} · ${count(1)} - ${count(2)}` : api.mp ? `Sıra: ${api.mp.names[turn - 1]} ${turn === 1 ? '⚪' : '⚫'} · ${count(1)} - ${count(2)}` : turn === 1 ? `Senin sıran · ⚪ ${count(1)} - ${count(2)} ⚫` : 'Bilgisayar düşünüyor…' }); }
    function geo() { const s = Math.min(st.W - 16, st.H - 80); return { cs: s / N, ox: (st.W - s) / 2, oy: (st.H - s) / 2 + 10 }; }

    function doMove(m, p) {
      const before = count(p === 1 ? 2 : 1);
      anim = { m, t: 0, v: b[m.from[0]][m.from[1]] };
      b[m.from[0]][m.from[1]] = 0;
      setTimeout(() => {
        b[m.from[0]][m.from[1]] = anim.v; b = apply(b, m); anim = null;
        const { cs, ox, oy } = geo();
        m.eaten.forEach(([r, c]) => fx.burst(ox + (c + 0.5) * cs, oy + (r + 0.5) * cs, p === 1 ? '#333' : '#fff', 12));
        if (m.eaten.length) { api.sfx.pop(); api.haptic('medium'); } else api.sfx.slide();
        if (p === 1) { eatenByMe += before - count(2); moveCount++; }
        turn = p === 1 ? 2 : 1;
        legal = movesFor(b, turn);
        hud();
        if (!legal.length) return finish(turn === 2);
        if (turn === 2 && !api.mp) setTimeout(ai, 250);
      }, 180 * m.path.length);
    }
    function ai() {
      const ms = movesFor(b, 2);
      let pick = ms[(Math.random() * ms.length) | 0];
      if (Math.random() >= mistake()) {
        let best = -Infinity;
        for (const m of ms) { const s = search(apply(b, m), depth() - 1, -Infinity, Infinity, 1) + Math.random() * 0.01; if (s > best) { best = s; pick = m; } }
      }
      doMove(pick, 2);
    }
    function finish(iWon) {
      over = true; hud();
      iWon ? api.sfx.win() : api.sfx.lose();
      const score = iWon ? 300 + count(1) * 30 + L * 40 : eatenByMe * 15;
      if (api.mp) { setTimeout(() => api.gameOver({ winner: iWon ? 0 : 1 }), 900); return; }
      setTimeout(() => api.gameOver({ score, coins: iWon ? 10 + L * 2 : 2, win: iWon, title: iWon ? 'Damayı kazandın! 👑' : 'Bilgisayar kazandı ⚫' }), 900);
    }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (over || (turn !== 1 && !api.mp) || anim || (ON && turn !== ON.me + 1)) return;
      const { cs, ox, oy } = geo(), p = st.point(e);
      let c = Math.floor((p.x - ox) / cs), r = Math.floor((p.y - oy) / cs);
      if (flip) { c = N - 1 - c; r = N - 1 - r; }
      if (r < 0 || r >= N || c < 0 || c >= N) return;
      if (own(b[r][c], turn)) {
        if (legal.some((m) => m.from[0] === r && m.from[1] === c)) { sel = [r, c]; api.sfx.click(); }
        else { api.sfx.wrong(); if (legal[0]?.eaten.length) api.setHud({ extra: 'Yeme zorunlu! Yiyebilen taşı seç' }); }
        return;
      }
      if (sel) {
        const m = legal.find((m) => m.from[0] === sel[0] && m.from[1] === sel[1] && m.path[m.path.length - 1][0] === r && m.path[m.path.length - 1][1] === c);
        if (m) { sel = null; ON?.send({ f: m.from, p: m.path }); doMove(m, turn); } else api.sfx.wrong();
      }
    });
    function update(dt) {
      if (ON && inbox.length && !anim && !over) {
        const mv = inbox.shift();
        const m = legal.find((x) => x.from[0] === mv.f[0] && x.from[1] === mv.f[1] && samePath(x.path, mv.p));
        if (m) doMove(m, turn);
      }
      if (anim) anim.t += dt; fx.update(dt); draw();
    }
    function piece(c, x, y, r, v) {
      const white = own(v, 1);
      c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.arc(x + 2, y + 4, r, 0, 7); c.fill();
      const g = c.createRadialGradient(x - r * 0.3, y - r * 0.3, 2, x, y, r);
      g.addColorStop(0, white ? '#ffffff' : '#555'); g.addColorStop(1, white ? '#d6ccc2' : '#111');
      c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill();
      c.strokeStyle = white ? '#bfb5aa' : '#333'; c.lineWidth = 2; c.beginPath(); c.arc(x, y, r * 0.68, 0, 7); c.stroke();
      if (isKing(v)) { c.fillStyle = '#ffc300'; c.font = `900 ${r}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('♛', x, y + 1); c.textBaseline = 'alphabetic'; }
    }
    function draw() {
      const c = st.ctx, { cs, ox, oy } = geo();
      c.fillStyle = '#3e2723'; c.fillRect(0, 0, st.W, st.H);
      c.save(); if (flip) { c.translate(ox + cs * N / 2, oy + cs * N / 2); c.rotate(Math.PI); c.translate(-(ox + cs * N / 2), -(oy + cs * N / 2)); }
      for (let r = 0; r < N; r++) for (let col = 0; col < N; col++) {
        c.fillStyle = (r + col) % 2 ? '#8d6e63' : '#efebe9'; c.fillRect(ox + col * cs, oy + r * cs, cs, cs);
      }
      if (sel && !over) {
        c.fillStyle = 'rgba(255,214,10,.45)'; c.fillRect(ox + sel[1] * cs, oy + sel[0] * cs, cs, cs);
        legal.filter((m) => m.from[0] === sel[0] && m.from[1] === sel[1]).forEach((m) => {
          const [r, col] = m.path[m.path.length - 1];
          c.fillStyle = 'rgba(45,198,83,.7)'; c.beginPath(); c.arc(ox + (col + 0.5) * cs, oy + (r + 0.5) * cs, cs * 0.18, 0, 7); c.fill();
        });
      } else if ((turn === 1 || api.mp) && !over && legal[0]?.eaten.length) {
        legal.forEach((m) => { c.strokeStyle = '#ff4d6d'; c.lineWidth = 3; c.strokeRect(ox + m.from[1] * cs + 2, oy + m.from[0] * cs + 2, cs - 4, cs - 4); });
      }
      for (let r = 0; r < N; r++) for (let col = 0; col < N; col++) if (b[r][col]) piece(c, ox + (col + 0.5) * cs, oy + (r + 0.5) * cs, cs * 0.38, b[r][col]);
      if (anim) {
        const pts = [anim.m.from, ...anim.m.path], seg = Math.min(pts.length - 2, Math.floor(anim.t / 0.18)), k = Math.min(1, (anim.t - seg * 0.18) / 0.18);
        const a = pts[seg], z = pts[seg + 1];
        piece(c, ox + (a[1] + (z[1] - a[1]) * k + 0.5) * cs, oy + (a[0] + (z[0] - a[0]) * k + 0.5) * cs - Math.sin(k * Math.PI) * 8, cs * 0.38, anim.v);
      }
      c.restore();
      c.fillStyle = '#d7ccc8'; c.font = '700 13px system-ui'; c.textAlign = 'center';
      if (!api.mp) c.fillText(`Rakip gücü: ${'★'.repeat(depth())}${'☆'.repeat(5 - depth())}`, st.W / 2, oy + cs * N + 24);
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
