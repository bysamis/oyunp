// 🚀 Zıpzıp Roket (dokun → yüksel, asteroid kapılarından geç)
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

export default {
  id: 'rocket', title: 'Zıpzıp Roket', emoji: '🚀', color: '#7b2cbf',
  desc: 'Dokun, roketi uçur, boşluklardan geç!',
  target: (L) => 8 + (L - 1) * 6,
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let rk, walls, score, state, spawnX, stars, trail;
    const S = () => st.H / 700;

    function start() {
      rk = { x: st.W * 0.28, y: st.H * 0.45, vy: 0, r: 16 * S() };
      walls = []; score = 0; state = 'ready'; spawnX = 0; trail = [];
      stars = Array.from({ length: 60 }, () => ({ x: Math.random() * st.W, y: Math.random() * st.H, s: Math.random() * 2 + 0.5 }));
      hud();
    }
    function hud() { api.setHud({ score, extra: state === 'ready' ? 'Başlamak için dokun' : 'Kapı geç, puan kazan!' }); }
    const speed = () => (170 + api.level * 22 + Math.min(score, 50) * 4) * S();
    const gap = () => Math.max(115, 235 - api.level * 12 - score * 2.2) * S();

    function flap() {
      if (state === 'over') return;
      if (state === 'ready') { state = 'play'; hud(); }
      rk.vy = -330 * S();
      api.sfx.tap();
      fx.burst(rk.x - rk.r, rk.y + 4, '#ff9f1c', 4, 80);
    }
    const onDown = () => flap();
    const onKey = (e) => { if (e.key === ' ' || e.key === 'ArrowUp') flap(); };
    st.canvas.addEventListener('pointerdown', onDown);
    window.addEventListener('keydown', onKey);

    function crash() {
      state = 'over';
      api.sfx.crash(); api.haptic('heavy');
      fx.burst(rk.x, rk.y, '#ff9f1c', 30, 240); fx.burst(rk.x, rk.y, '#fff', 14, 160);
      setTimeout(() => api.gameOver({ score, coins: score * 2, canContinue: true, title: 'Roket çarptı! 💫' }), 700);
    }

    function update(dt, t) {
      for (const s of stars) { s.x -= s.s * 20 * dt * (state === 'play' ? 2 : 0.5); if (s.x < 0) s.x += st.W; }
      if (state === 'ready') rk.y = st.H * 0.45 + Math.sin(t * 3) * 10;
      if (state === 'play') {
        rk.vy += 900 * S() * dt;
        rk.y += rk.vy * dt;
        trail.push({ x: rk.x, y: rk.y, t: 0 }); if (trail.length > 18) trail.shift();
        spawnX -= speed() * dt;
        if (spawnX <= 0) {
          const g = gap(), w = 60 * S();
          const cy = g / 2 + 40 + Math.random() * (st.H - g - 80);
          walls.push({ x: st.W + w, w, top: cy - g / 2, bot: cy + g / 2, passed: false, hue: (score * 37) % 360 });
          spawnX = 230 * S();
        }
        for (let i = walls.length - 1; i >= 0; i--) {
          const w = walls[i];
          w.x -= speed() * dt;
          if (!w.passed && w.x + w.w < rk.x) { w.passed = true; score++; api.sfx.coin(); fx.text(rk.x, rk.y - 30, '+1', '#ffd60a'); hud(); }
          if (w.x < -w.w - 10) walls.splice(i, 1);
          const inX = rk.x + rk.r * 0.8 > w.x && rk.x - rk.r * 0.8 < w.x + w.w;
          if (inX && (rk.y - rk.r * 0.8 < w.top || rk.y + rk.r * 0.8 > w.bot)) crash();
        }
        if (rk.y > st.H - rk.r || rk.y < rk.r) { if (state === 'play') crash(); }
      }
      fx.update(dt);
      draw(t);
    }

    function draw(t) {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H);
      g.addColorStop(0, '#10002b'); g.addColorStop(1, '#5a189a');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      c.fillStyle = '#fff';
      for (const s of stars) { c.globalAlpha = 0.4 + s.s / 4; c.fillRect(s.x, s.y, s.s, s.s); }
      c.globalAlpha = 1;
      for (const w of walls) {
        c.fillStyle = `hsl(${w.hue},70%,55%)`;
        roundRect(c, w.x, -20, w.w, w.top + 20, 14); c.fill();
        roundRect(c, w.x, w.bot, w.w, st.H - w.bot + 20, 14); c.fill();
        c.fillStyle = 'rgba(255,255,255,.25)';
        c.fillRect(w.x + 8, -20, 8, w.top + 10); c.fillRect(w.x + 8, w.bot + 10, 8, st.H);
        // krater benekleri
        c.fillStyle = 'rgba(0,0,0,.18)';
        c.beginPath(); c.arc(w.x + w.w * 0.65, w.top - 30, 7, 0, 7); c.arc(w.x + w.w * 0.4, w.bot + 40, 9, 0, 7); c.fill();
      }
      // iz
      trail.forEach((p, i) => { c.globalAlpha = i / trail.length * 0.5; c.fillStyle = '#ff9f1c'; c.beginPath(); c.arc(p.x - (trail.length - i) * 3, p.y, rk.r * 0.35 * (i / trail.length), 0, 7); c.fill(); });
      c.globalAlpha = 1;
      if (state !== 'over') {
        const ang = Math.max(-0.5, Math.min(0.9, rk.vy / (600 * S())));
        c.save(); c.translate(rk.x, rk.y); c.rotate(ang + Math.PI / 2);
        const r = rk.r;
        c.fillStyle = '#ff9f1c'; c.beginPath(); c.moveTo(-r * 0.4, r * 1.0); c.lineTo(0, r * (1.6 + Math.sin(t * 40) * 0.25)); c.lineTo(r * 0.4, r * 1.0); c.fill();
        c.fillStyle = '#ef233c';
        c.beginPath(); c.moveTo(-r * 0.55, r * 0.4); c.lineTo(-r * 0.95, r * 1.0); c.lineTo(-r * 0.4, r * 0.9); c.fill();
        c.beginPath(); c.moveTo(r * 0.55, r * 0.4); c.lineTo(r * 0.95, r * 1.0); c.lineTo(r * 0.4, r * 0.9); c.fill();
        c.fillStyle = '#edf2f4'; roundRect(c, -r * 0.55, -r * 0.8, r * 1.1, r * 1.8, r * 0.5); c.fill();
        c.fillStyle = '#ef233c'; c.beginPath(); c.moveTo(-r * 0.5, -r * 0.55); c.quadraticCurveTo(0, -r * 1.7, r * 0.5, -r * 0.55); c.fill();
        c.fillStyle = '#3a86ff'; c.beginPath(); c.arc(0, -r * 0.1, r * 0.28, 0, 7); c.fill();
        c.restore();
      }
      if (state === 'ready') {
        c.fillStyle = '#fff'; c.font = `800 ${20}px system-ui`; c.textAlign = 'center';
        c.fillText('Dokun → yüksel 🚀', st.W / 2, st.H * 0.7);
      }
      fx.draw(c);
    }

    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() {
        walls = walls.filter((w) => w.x > rk.x + 140 * S());
        rk.y = st.H * 0.45; rk.vy = 0; state = 'ready'; hud();
      },
      restart() { start(); },
      destroy() { lp.stop(); st.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
