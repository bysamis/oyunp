// ⚽ Penaltı 3D: kaydırarak şut çek, kaleciyi geç! 3 kaçırınca biter
import { create3D, mat, THREE } from '../core/three-stage.js';
import { modelInto, loadModel } from '../core/assets.js';

const GZ = -11, GW = 7.0, GH = 2.4, BR = 0.22;

export default {
  id: 'penalty', title: 'Penaltı 3D', emoji: '⚽', color: '#2dc653',
  desc: 'Şut çek, kaleciyi geç, gol at!',
  target: (L) => Math.round(300 * Math.pow(1.3, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 50, bg: 0x8ecae6, fog: [0x8ecae6, 40, 90] });
    const { scene, camera } = S;
    camera.position.set(0, 2.3, 6.2); camera.lookAt(0, 1.0, GZ);
    // ---------- saha: Kenney çim dokusu + biçilmiş çim şeritleri ----------
    const pitch = new THREE.Mesh(new THREE.PlaneGeometry(70, 70), mat(0x3f9b4a, { roughness: 1 })); pitch.rotation.x = -Math.PI / 2; pitch.position.z = -10; pitch.receiveShadow = true; scene.add(pitch);
    loadModel('kv-grass').then((g) => {
      let src = null; g.scene.traverse((o) => { if (o.isMesh) src = o.material.map; });
      if (!src) return; const t = src.clone(); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(28, 28); t.needsUpdate = true;
      pitch.material.map = t; pitch.material.color.set(0xffffff); pitch.material.needsUpdate = true;
    }).catch(() => {});
    for (let i = 0; i < 14; i++) { const st = new THREE.Mesh(new THREE.PlaneGeometry(70, 2.5), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: i % 2 ? 0.0 : 0.09, depthWrite: false })); st.rotation.x = -Math.PI / 2; st.position.set(0, 0.003, 9 - i * 2.5); scene.add(st); }
    const lineM = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const line = (w, d, x, z) => { const l = new THREE.Mesh(new THREE.PlaneGeometry(w, d), lineM); l.rotation.x = -Math.PI / 2; l.position.set(x, 0.006, z); scene.add(l); };
    line(GW + 22, 0.12, 0, GZ); line(0.12, 5.5, -(GW / 2 + 5), GZ + 2.75); line(0.12, 5.5, GW / 2 + 5, GZ + 2.75); line(GW + 10, 0.12, 0, GZ + 5.5);
    line(0.12, 1.8, -(GW / 2 + 1.2), GZ + 0.9); line(0.12, 1.8, GW / 2 + 1.2, GZ + 0.9); line(GW + 2.4, 0.12, 0, GZ + 1.8);
    const arc = new THREE.Mesh(new THREE.RingGeometry(2.9, 3.02, 40, 1, Math.PI * 0.18, Math.PI * 0.64), lineM); arc.rotation.x = -Math.PI / 2; arc.position.set(0, 0.006, GZ + 2.6); scene.add(arc);
    const spot = new THREE.Mesh(new THREE.CircleGeometry(0.15, 16), lineM); spot.rotation.x = -Math.PI / 2; spot.position.set(0, 0.007, 0); scene.add(spot);
    // ---------- kale: yuvarlak direkler + ağ dokusu ----------
    const postM = mat(0xffffff, { roughness: 0.25 });
    const cyl = (len, x, y, z, rz = 0, rx = 0) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, len, 12), postM); m.position.set(x, y, z); m.rotation.set(rx, 0, rz); m.castShadow = true; scene.add(m); return m; };
    cyl(GH, -GW / 2, GH / 2, GZ); cyl(GH, GW / 2, GH / 2, GZ); cyl(GW + 0.14, 0, GH, GZ, Math.PI / 2);
    const back = 1.8; cyl(back, -GW / 2, GH, GZ - back / 2, 0, Math.PI / 2); cyl(back, GW / 2, GH, GZ - back / 2, 0, Math.PI / 2);
    const netCv = document.createElement('canvas'); netCv.width = netCv.height = 64; const nc = netCv.getContext('2d');
    nc.strokeStyle = 'rgba(255,255,255,0.95)'; nc.lineWidth = 3; for (let k = 0; k <= 64; k += 16) { nc.beginPath(); nc.moveTo(k, 0); nc.lineTo(k, 64); nc.stroke(); nc.beginPath(); nc.moveTo(0, k); nc.lineTo(64, k); nc.stroke(); }
    const netTex = (rx, ry) => { const t = new THREE.CanvasTexture(netCv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); return t; };
    const netMat = (rx, ry) => new THREE.MeshBasicMaterial({ map: netTex(rx, ry), transparent: true, alphaTest: 0.3, side: THREE.DoubleSide, depthWrite: false, opacity: 0.85 });
    const netBack = new THREE.Mesh(new THREE.PlaneGeometry(GW, GH), netMat(GW * 4, GH * 4)); netBack.position.set(0, GH / 2, GZ - back); scene.add(netBack);
    const netTop = new THREE.Mesh(new THREE.PlaneGeometry(GW, back), netMat(GW * 4, back * 4)); netTop.rotation.x = -Math.PI / 2; netTop.position.set(0, GH, GZ - back / 2); scene.add(netTop);
    [-1, 1].forEach((sd) => { const n = new THREE.Mesh(new THREE.PlaneGeometry(back, GH), netMat(back * 4, GH * 4)); n.rotation.y = Math.PI / 2; n.position.set(sd * GW / 2, GH / 2, GZ - back / 2); scene.add(n); });
    // ---------- reklam panoları ----------
    const adCv = document.createElement('canvas'); adCv.width = 512; adCv.height = 64; const ac = adCv.getContext('2d');
    ['#ef233c', '#3a86ff', '#ffc300', '#2dc653'].forEach((c, i) => { ac.fillStyle = c; ac.fillRect(i * 128, 0, 128, 64); ac.fillStyle = '#fff'; ac.font = '900 30px system-ui'; ac.textAlign = 'center'; ac.fillText(['Oyunpuf', 'GOL!', '⚽ 3D', 'Oyunpuf'][i], i * 128 + 64, 43); });
    const adTex = new THREE.CanvasTexture(adCv); adTex.colorSpace = THREE.SRGBColorSpace; adTex.wrapS = THREE.RepeatWrapping; adTex.repeat.set(5, 1);
    const ads = new THREE.Mesh(new THREE.BoxGeometry(50, 0.8, 0.2), [mat(0x222222), mat(0x222222), mat(0x222222), mat(0x222222), new THREE.MeshBasicMaterial({ map: adTex }), mat(0x222222)]); ads.position.set(0, 0.4, GZ - 4.2); scene.add(ads);
    // ---------- tribün + seyirci (Kenney Blocky Characters, CC0) ----------
    const STZ = GZ - 6, ROWS = 5, RD = 1.1, RH = 0.75;
    const standG = new THREE.Group(); scene.add(standG);
    const seatCols = [0xd62828, 0xf1faee, 0x1d3557];
    for (let r = 0; r < ROWS; r++) {
      const step = new THREE.Mesh(new THREE.BoxGeometry(56, RH * (r + 1), RD), mat(0x8d99ae, { roughness: 0.9 })); step.position.set(0, RH * (r + 1) / 2, STZ - r * RD); step.receiveShadow = true; standG.add(step);
      const seats = new THREE.Mesh(new THREE.BoxGeometry(56, 0.12, 0.4), mat(seatCols[r % 3])); seats.position.set(0, RH * (r + 1) + 0.06, STZ - r * RD + 0.2); standG.add(seats);
    }
    const backWall = new THREE.Mesh(new THREE.BoxGeometry(56, 1.2, 0.4), mat(0x1d3557)); backWall.position.set(0, RH * ROWS + 0.6, STZ - (ROWS - 1) * RD - 0.7); standG.add(backWall);
    const FANS = ['bc-fan1', 'bc-fan2', 'bc-fan3', 'bc-fan4', 'bc-fan5', 'bc-fan6', 'bc-red', 'bc-blue', 'bc-green', 'bc-girl'];
    const fans = [];
    for (let r = 0; r < ROWS; r++) for (let x = -12; x <= 12; x += 1.2 + Math.random() * 0.8) {
      if (Math.random() < 0.15) continue;
      const f = modelInto(standG, FANS[(Math.random() * FANS.length) | 0], { height: 1.25, anim: 'idle', pose: Math.random() * 2 });
      f.position.set(x + (Math.random() - 0.5) * 0.3, RH * (r + 1), STZ - r * RD + 0.05); f.userData.ph = Math.random() * 6; fans.push(f);
    }
    // bayraklar
    [-9, -3, 3, 9].forEach((x, i) => { const b = modelInto(standG, 'ma-banner', { height: 1.6 }); b.position.set(x, RH * ROWS + 0.1, STZ - (ROWS - 1) * RD - 0.2); });
    let cheer = 0;
    // ---------- kaleci (Kenney Blocky Characters, CC0) ----------
    const keeper = new THREE.Group(); scene.add(keeper);
    const kStub = new THREE.Mesh(new THREE.BoxGeometry(0.7, 1.8, 0.35), mat(0xffd60a)); kStub.position.y = 0.9;
    const keeperM = modelInto(keeper, 'bc-yellow', { height: 1.95, anim: 'idle', fallback: kStub });
    // eldivenler: kaleci kolları açık
    const gloveM = mat(0x06d6a0);
    [-0.62, 0.62].forEach((x) => { const g = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.26, 0.2), gloveM); g.position.set(x, 1.25, 0.1); g.castShadow = true; keeper.add(g); });
    // ---------- şutçu ----------
    const striker = new THREE.Group(); scene.add(striker);
    const strikerM = modelInto(striker, 'bc-striker', { height: 1.5, anim: 'idle' });
    strikerM.rotation.y = Math.PI; // kaleye bakar
    // baraj (yüksek seviyede) — mavi formalı oyuncular
    const wallGroup = new THREE.Group(); scene.add(wallGroup);
    const wallMs = [];
    for (let i = 0; i < 3; i++) { const st = new THREE.Mesh(new THREE.BoxGeometry(0.55, 1.7, 0.3), mat(0x3a86ff)); st.position.y = 0.85; const w = modelInto(wallGroup, 'bc-blue', { height: 1.8, anim: 'idle', fallback: st }); w.position.x = (i - 1) * 0.6; wallMs.push(w); }
    // ---------- top: klasik siyah-beyaz desen ----------
    const ballCv = document.createElement('canvas'); ballCv.width = 256; ballCv.height = 128; const bc = ballCv.getContext('2d');
    bc.fillStyle = '#fff'; bc.fillRect(0, 0, 256, 128); bc.fillStyle = '#111';
    const pent = (cx, cy, r) => { bc.beginPath(); for (let k = 0; k < 5; k++) { const a = -Math.PI / 2 + k * Math.PI * 2 / 5; bc.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); } bc.fill(); };
    for (let k = 0; k < 5; k++) { pent(k * 51 + 25, 40, 13); pent(k * 51 + 50, 92, 13); } pent(128, 4, 30); pent(128, 126, 30);
    bc.strokeStyle = '#555'; bc.lineWidth = 1.5; for (let k = 0; k < 10; k++) { bc.beginPath(); bc.moveTo(k * 25.6, 0); bc.lineTo(k * 25.6 + 12, 128); bc.stroke(); }
    const ballTex = new THREE.CanvasTexture(ballCv); ballTex.colorSpace = THREE.SRGBColorSpace;
    const ballM = new THREE.Mesh(new THREE.SphereGeometry(BR, 24, 16), mat(0xffffff, { map: ballTex, roughness: 0.45 })); ballM.castShadow = true; scene.add(ballM);
    const ballShadow = new THREE.Mesh(new THREE.CircleGeometry(BR * 1.1, 16), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.25, depthWrite: false })); ballShadow.rotation.x = -Math.PI / 2; scene.add(ballShadow);

    let L, score, misses, goals, streak, over, ball, flying, kp, kTarget, kDelay, resultT, wallOn, wallX, wallDir, curve;
    const guess = () => Math.min(0.8, 0.2 + L * 0.07);
    const kSpeed = () => 6.5 + L * 0.6;
    const kReact = () => Math.max(0.06, 0.34 - L * 0.03);
    function start() { L = api.level; score = 0; misses = 0; goals = 0; streak = 0; over = false; wallX = 0; wallDir = 1; newShot(); hud(); }
    function hud() { api.setHud({ score, extra: `⚽ Gol ${goals} · ❌ ${'●'.repeat(misses)}${'○'.repeat(3 - misses)}` + (streak >= 3 ? ' · 🔥' : '') }); }
    function newShot() {
      ball = { p: new THREE.Vector3(0, BR, 0), v: new THREE.Vector3() };
      flying = false; resultT = 0; kp = 0; kTarget = 0; kDelay = 0; curve = 0;
      keeper.position.set(0, 0, GZ + 0.5); keeper.rotation.z = 0;
      striker.position.set(-1.25, 0, 0.15); keeperM.userData.model?.userData.play('idle');
      wallOn = L >= 5; wallGroup.visible = wallOn; wallGroup.position.set(wallX, 0, -5);
    }
    let sw = null;
    S.el.addEventListener('pointerdown', (e) => { if (!flying && !over) sw = { x: e.clientX, y: e.clientY, pts: [[e.clientX, e.clientY]] }; });
    S.el.addEventListener('pointermove', (e) => { if (sw) sw.pts.push([e.clientX, e.clientY]); });
    S.el.addEventListener('pointerup', (e) => {
      if (!sw || flying || over) return;
      const dy = sw.y - e.clientY; if (dy < 40) { sw = null; return; }
      // parmağın bittiği nokta kale düzlemine izdüşürülür
      const r = S.el.getBoundingClientRect();
      const aim = S.rayPlaneZ({ clientX: e.clientX, clientY: e.clientY - r.height * 0.05 }, GZ);
      const target = aim ? new THREE.Vector3(aim.x * 1.15, Math.max(0.1, aim.y), GZ) : new THREE.Vector3(0, 1, GZ);
      // eğri: kaydırma yolunun ortasının sapması
      const mid = sw.pts[Math.floor(sw.pts.length / 2)];
      curve = ((mid[0] - (sw.x + e.clientX) / 2) / r.width) * -14;
      sw = null;
      const tFly = Math.max(0.45, 0.7 - L * 0.01);
      ball.v.set((target.x - ball.p.x) / tFly - curve * tFly * 0.5, (target.y - ball.p.y + 0.5 * 9.8 * tFly * tFly) / tFly, GZ / tFly);
      flying = true; api.sfx.tap(); api.haptic('medium');
      strikerM.userData.model?.userData.once('attack-kick-right', 'idle', 0.05);
      // kaleci kararı
      kTarget = Math.random() < guess() ? target.x : (Math.random() < 0.5 ? -1 : 1) * (1 + Math.random() * 2.2);
      kTarget = Math.max(-GW / 2 + 0.4, Math.min(GW / 2 - 0.4, kTarget));
      kDelay = kReact();
      ball.targetY = target.y;
    });
    function result(goal, text) {
      if (resultT) return;
      resultT = 0.001;
      if (goal) {
        goals++; streak++;
        const corner = Math.min(1, Math.abs(ball.p.x) / (GW / 2)) + Math.min(1, ball.p.y / GH) * 0.5;
        const pts = Math.round(100 + corner * 60) * (streak >= 3 ? 2 : 1);
        score += pts; api.sfx.win(); api.haptic('heavy'); cheer = 2.2;
        fans.forEach((f) => f.userData.model?.userData.play('emote-yes', 0.1));
        S.burst(ball.p.clone(), 0xffd60a, 24, 6); S.popText(new THREE.Vector3(0, GH + 0.6, GZ), `GOL! +${pts}`, '#ffd60a');
      } else {
        misses++; streak = 0; api.sfx.wrong(); api.haptic('medium');
        S.popText(new THREE.Vector3(ball.p.x, 1.5, ball.p.z), text, '#ff4d6d');
      }
      hud();
      if (misses >= 3) { over = true; setTimeout(() => api.gameOver({ score, coins: goals * 2, canContinue: true, title: 'Maç bitti! ⚽' }), 1200); }
    }
    const lp = S.loop((dt) => {
      // baraj seviye 8'den sonra kayar
      if (wallOn && L >= 8 && !flying) { wallX += wallDir * (0.8 + (L - 8) * 0.2) * dt; if (Math.abs(wallX) > 1.6) wallDir *= -1; wallGroup.position.x = wallX; }
      if (flying) {
        const steps = 3;
        for (let i = 0; i < steps && !resultT; i++) {
          const h = dt / steps, prevZ = ball.p.z;
          ball.v.y -= 9.8 * h; ball.v.x += curve * h; ball.p.addScaledVector(ball.v, h);
          if (ball.p.y < BR) { ball.p.y = BR; ball.v.y = Math.abs(ball.v.y) * 0.5; }
          // baraj
          if (wallOn && prevZ > -5 && ball.p.z <= -5 && Math.abs(ball.p.x - wallX) < 1.0 && ball.p.y < 1.9) { ball.v.z = Math.abs(ball.v.z) * 0.3; ball.v.x *= -0.5; api.sfx.bounce(); result(false, 'Baraja çarptı!'); }
          // kaleci
          if (prevZ > GZ + 0.5 && ball.p.z <= GZ + 0.5) {
            const kx = keeper.position.x, reachY = 0.2 + 2.2;
            const dxk = Math.abs(ball.p.x - kx);
            const lean = Math.abs(keeper.rotation.z);
            const reach = 0.5 + lean * 0.9 + (L >= 6 ? 0.15 : 0);
            if (dxk < reach && ball.p.y < reachY - lean * 0.6) { ball.v.z = Math.abs(ball.v.z) * 0.4; ball.v.x = (ball.p.x - kx) * 4; api.sfx.bounce(); result(false, 'Kurtardı! 🧤'); }
          }
          if (!resultT && prevZ > GZ && ball.p.z <= GZ) {
            const inGoal = Math.abs(ball.p.x) < GW / 2 - BR && ball.p.y < GH - BR;
            const post = !inGoal && Math.abs(ball.p.x) < GW / 2 + BR && ball.p.y < GH + BR;
            if (inGoal) { result(true); ball.v.multiplyScalar(0.25); }
            else { if (post) { ball.v.z = Math.abs(ball.v.z) * 0.5; api.sfx.bounce(); } result(false, post ? 'Direk!' : 'Auta gitti!'); }
          }
        }
        // kaleci hareketi
        if (kDelay > 0) kDelay -= dt;
        else {
          const dx = kTarget - keeper.position.x, step = kSpeed() * dt;
          keeper.position.x += Math.sign(dx) * Math.min(Math.abs(dx), step);
          const tilt = Math.max(-1.1, Math.min(1.1, -(keeper.position.x) * 0.45 - Math.sign(dx) * (Math.abs(dx) > 0.3 ? 0.4 : 0)));
          keeper.rotation.z += (tilt - keeper.rotation.z) * Math.min(1, dt * 10);
          keeper.position.y = Math.max(0, Math.min(0.5, (ball.targetY || 0) - 1.2)) * Math.min(1, Math.abs(keeper.rotation.z));
        }
        if (resultT) { resultT += dt; if (resultT > 1.4 && !over) newShot(); }
        if (ball.p.z < GZ - 1.6) { ball.p.z = GZ - 1.6; ball.v.z = 0; ball.v.x *= 0.3; }
      }
      ballM.position.copy(ball.p); if (flying) { ballM.rotation.x -= dt * 14; ballM.rotation.y += curve * dt; }
      ballShadow.position.set(ball.p.x, 0.008, ball.p.z); ballShadow.scale.setScalar(Math.max(0.4, 1 - ball.p.y * 0.25));
      // karakter animasyonları
      strikerM.userData.model?.userData.update(dt);
      const km = keeperM.userData.model?.userData; if (km) { km.play(flying && kDelay <= 0 ? 'holding-both' : 'idle'); km.update(dt); }
      wallMs.forEach((w) => w.userData.model?.userData.update(dt));
      // seyirci: golde zıplar ve sevinir, normalde hafif sallanır
      if (cheer > 0) { cheer -= dt; fans.forEach((f) => { f.children[0] && (f.children[0].position.y = Math.max(0, Math.sin(cheer * 9 + f.userData.ph)) * 0.35); f.userData.model?.userData.update(dt); }); if (cheer <= 0) fans.forEach((f) => { if (f.children[0]) f.children[0].position.y = 0; f.userData.model?.userData.play('idle', 0.2); f.userData.model?.userData.update(0.3); }); }
      S.updateParts(dt);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), continue() { misses = 2; over = false; newShot(); hud(); }, restart() { start(); }, destroy() { S.destroy(); } };
  },
};
