// 🎨 Renk Avcısı: yazının RENGİNE bas (kelimenin anlamına değil!)
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

const COLS = [
  { n: 'KIRMIZI', c: '#ef233c' }, { n: 'MAVİ', c: '#3a86ff' }, { n: 'YEŞİL', c: '#2dc653' },
  { n: 'SARI', c: '#ffc300' }, { n: 'MOR', c: '#9d4edd' }, { n: 'TURUNCU', c: '#fb8500' },
];

export default {
  id: 'colortap', title: 'Renk Avcısı', emoji: '🎨', color: '#ef233c',
  desc: 'Yazının rengine bas, anlamına değil!',
  target: (L) => Math.round(150 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let word, ink, opts, timer, maxT, score, streak, over, L, lives, shakeT = 0, n;

    function start() { L = api.level; n = L >= 3 ? 6 : 4; score = 0; streak = 0; over = false; lives = 3; next(); }
    function next() {
      const pool = COLS.slice(0, n);
      ink = pool[(Math.random() * n) | 0];
      do { word = pool[(Math.random() * n) | 0]; } while (word === ink && Math.random() < 0.85);
      opts = pool.slice().sort(() => Math.random() - 0.5);
      maxT = Math.max(0.75, 3 - L * 0.2 - streak * 0.04); timer = maxT;
      hud();
    }
    function hud() { api.setHud({ score, extra: `${'❤️'.repeat(lives)} · Seri ${streak}` }); }
    function btn(i) {
      const cols = 2, rows = n / 2, w = Math.min(st.W - 32, 440), bh = Math.min(80, (st.H * 0.5 - 12 * rows) / rows);
      const ox = (st.W - w) / 2, oy = st.H * 0.45, g = 12, bw = (w - g) / cols;
      return { x: ox + (i % cols) * (bw + g), y: oy + ((i / cols) | 0) * (bh + g), w: bw, h: bh };
    }
    function wrong() {
      lives--; streak = 0; shakeT = 0.3; api.sfx.wrong(); api.haptic('medium');
      if (lives <= 0) { over = true; api.sfx.lose(); api.gameOver({ score, coins: Math.floor(score / 12), canContinue: true, title: 'Gözlerin kandı! 🎨' }); }
      else next();
    }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = st.point(e);
      for (let i = 0; i < opts.length; i++) {
        const b = btn(i);
        if (p.x > b.x && p.x < b.x + b.w && p.y > b.y && p.y < b.y + b.h) {
          if (opts[i] === ink) {
            streak++; const pts = 10 + Math.min(streak, 20) + Math.round(timer * 5);
            score += pts; api.sfx.pop(); api.haptic('light'); fx.text(b.x + b.w / 2, b.y, '+' + pts, '#fff');
            fx.burst(b.x + b.w / 2, b.y + b.h / 2, ink.c, 10); next();
          } else wrong();
          return;
        }
      }
    });
    function update(dt) {
      if (!over) { timer -= dt; if (timer <= 0) wrong(); }
      if (shakeT > 0) shakeT -= dt;
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx;
      c.fillStyle = '#f8f9fa'; c.fillRect(0, 0, st.W, st.H);
      c.save(); if (shakeT > 0) c.translate((Math.random() - 0.5) * 16, 0);
      c.fillStyle = '#6c757d'; c.font = '700 15px system-ui'; c.textAlign = 'center';
      c.fillText('Yazının RENGİ hangisi?', st.W / 2, st.H * 0.13);
      c.fillStyle = ink.c; c.font = `900 ${Math.min(64, st.W / 6)}px system-ui`; c.textBaseline = 'middle';
      c.fillText(word.n, st.W / 2, st.H * 0.26);
      // süre çubuğu
      const w = Math.min(st.W - 60, 400), x = (st.W - w) / 2;
      roundRect(c, x, st.H * 0.36, w, 12, 6); c.fillStyle = '#e9ecef'; c.fill();
      roundRect(c, x, st.H * 0.36, w * Math.max(0, timer / maxT), 12, 6); c.fillStyle = timer / maxT < 0.3 ? '#ef233c' : '#2dc653'; c.fill();
      for (let i = 0; i < opts.length; i++) {
        const b = btn(i);
        roundRect(c, b.x, b.y, b.w, b.h, 18); c.fillStyle = opts[i].c; c.fill();
        // yüksek seviyede düğme yazıları da yanıltıcı
        const label = L >= 2 ? COLS[(i + 2) % n].n : opts[i].n;
        c.fillStyle = '#fff'; c.font = '900 18px system-ui'; c.fillText(L >= 5 ? '' : label, b.x + b.w / 2, b.y + b.h / 2);
      }
      c.textBaseline = 'alphabetic'; c.restore();
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { lives = 1; over = false; next(); },
      restart() { start(); }, destroy() { lp.stop(); st.destroy(); },
    };
  },
};
