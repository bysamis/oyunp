// 🎵 Renk Sırası (Simon): yanan renk sırasını aklında tut, tekrarla
import { createStage, loop, particles } from '../core/canvas.js';

const PADS = [
  { c: '#2dc653', f: 392 }, { c: '#ff4d6d', f: 330 }, { c: '#ffd60a', f: 262 }, { c: '#3a86ff', f: 196 },
  { c: '#9d4edd', f: 440 }, { c: '#ff9f1c', f: 494 },
];

export default {
  id: 'simon', title: 'Renk Sırası', emoji: '🎵', color: '#9d4edd',
  desc: 'Yanan renk sırasını ezberle ve tekrarla!',
  target: (L) => 6 + (L - 1) * 2,
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let seq, idx, phase, glow, showT, showI, score, nPads, L, over, inputTimer;

    function start() {
      L = api.level; nPads = L >= 4 ? 6 : 4;
      seq = []; score = 0; over = false; glow = Array(6).fill(0);
      nextRound();
    }
    const showGap = () => Math.max(0.18, 0.6 - L * 0.04 - seq.length * 0.012);
    function nextRound() {
      seq.push((Math.random() * nPads) | 0);
      idx = 0; phase = 'show'; showT = 0.7; showI = 0; hud();
    }
    function hud() { api.setHud({ score, scoreLabel: 'Tur', extra: phase === 'show' ? '👀 İzle…' : `👉 Sıra sende · ${idx}/${seq.length}` + (inputTimer < 99 ? ` · ⏱ ${Math.ceil(inputTimer)}` : '') }); }
    function padRect(i) {
      const cols = 2, rows = nPads / 2;
      const w = Math.min(st.W - 40, 420), h = Math.min(st.H - 60, 560);
      const ox = (st.W - w) / 2, oy = (st.H - h) / 2, g = 14;
      const pw = (w - g) / cols, ph = (h - g * (rows - 1)) / rows;
      return { x: ox + (i % cols) * (pw + g), y: oy + ((i / cols) | 0) * (ph + g), w: pw, h: ph };
    }
    function flash(i) { glow[i] = 1; api.sfx.tap(); playTone(PADS[i].f); }
    let actx;
    function playTone(f) {
      try {
        actx = actx || new (window.AudioContext || window.webkitAudioContext)();
        const o = actx.createOscillator(), g = actx.createGain();
        o.frequency.value = f; o.type = 'triangle'; g.gain.setValueAtTime(0.25, actx.currentTime); g.gain.exponentialRampToValueAtTime(0.001, actx.currentTime + 0.35);
        o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + 0.4);
      } catch (e) {}
    }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (phase !== 'input' || over) return;
      const p = st.point(e);
      for (let i = 0; i < nPads; i++) {
        const r = padRect(i);
        if (p.x > r.x && p.x < r.x + r.w && p.y > r.y && p.y < r.y + r.h) {
          flash(i); api.haptic('light');
          if (i !== seq[idx]) return fail();
          idx++; inputTimer = Math.max(1.6, 4 - L * 0.3);
          if (idx === seq.length) {
            score++; api.sfx.coin(); fx.text(st.W / 2, st.H / 2, '✓', '#fff'); phase = 'wait';
            setTimeout(nextRound, 600);
          }
          hud(); return;
        }
      }
    });
    function fail() {
      over = true; phase = 'over'; api.sfx.lose(); api.haptic('heavy');
      setTimeout(() => api.gameOver({ score, coins: score * 3, canContinue: true, title: 'Sıra karıştı! 🎵' }), 500);
    }
    function update(dt) {
      for (let i = 0; i < 6; i++) glow[i] = Math.max(0, glow[i] - dt * 3.5);
      if (phase === 'show') {
        showT -= dt;
        if (showT <= 0) {
          if (showI < seq.length) { flash(seq[showI]); showI++; showT = showGap(); }
          else { phase = 'input'; inputTimer = Math.max(1.6, 4 - L * 0.3); hud(); }
        }
      } else if (phase === 'input' && L >= 2) {
        const b = Math.ceil(inputTimer); inputTimer -= dt;
        if (Math.ceil(inputTimer) !== b) hud();
        if (inputTimer <= 0) fail();
      }
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx;
      c.fillStyle = '#1b1035'; c.fillRect(0, 0, st.W, st.H);
      for (let i = 0; i < nPads; i++) {
        const r = padRect(i), g = glow[i];
        c.globalAlpha = 0.35 + g * 0.65;
        c.fillStyle = PADS[i].c;
        c.shadowColor = PADS[i].c; c.shadowBlur = g * 40;
        c.beginPath(); c.roundRect(r.x, r.y, r.w, r.h, 26); c.fill();
        c.shadowBlur = 0; c.globalAlpha = 1;
      }
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { over = false; idx = 0; phase = 'show'; showT = 0.8; showI = 0; hud(); },
      restart() { start(); }, destroy() { lp.stop(); st.destroy(); },
    };
  },
};
