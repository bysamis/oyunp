// 🍉 Meyve Birleştir 3D: aynı meyveleri çarpıştır, büyüt, karpuza ulaş (kutuyu taşırma!)
import { create3D, mat, THREE } from '../core/three-stage.js';
import { expert, expertSteps } from '../core/expert.js';

const TYPES = [
  { r: 13, c: '#e63946', n: 'Kiraz' }, { r: 17, c: '#ff70a6', n: 'Çilek' }, { r: 22, c: '#9d4edd', n: 'Üzüm' },
  { r: 27, c: '#ff9f1c', n: 'Mandalina' }, { r: 33, c: '#fb8500', n: 'Portakal' }, { r: 40, c: '#d00000', n: 'Elma' },
  { r: 47, c: '#e9c46a', n: 'Armut' }, { r: 55, c: '#ffafcc', n: 'Şeftali' }, { r: 64, c: '#ffd60a', n: 'Ananas' },
  { r: 74, c: '#80b918', n: 'Kavun' }, { r: 86, c: '#2d6a4f', n: 'Karpuz' },
];

const VW = 400, VH = 760; // sanal oyun alanı (fizik bu ölçüde çalışır)
const U = 1 / 40;          // sanal birim → 3D birim

export default {
  id: 'merge', title: 'Meyve Birleştir 3D', emoji: '🍉', color: '#80b918',
  desc: 'Aynı meyveleri birleştir, karpuza ulaş!',
  expertFrom: 11,
  target: (L) => Math.round(500 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0xffe8b0 });
    const { scene, camera, sun } = S;
    sun.position.set(-4, 14, 12);
    const fx = { burst: (x, y, c, n) => S.burst(V(x, y, 0.3), new THREE.Color(c).getHex(), Math.min(n, 14), 4, 0.6), text: (x, y, t, c) => S.popText(V(x, y, 0.5), t, c) };
    const V = (x, y, z = 0) => new THREE.Vector3((x - VW / 2) * U, (VH - y) * U, z);
    const st = { W: VW, H: VH };
    const boxG = new THREE.Group(); scene.add(boxG);
    const fruitG = new THREE.Group(); scene.add(fruitG);
    const fruitMats = TYPES.map((T) => mat(new THREE.Color(T.c), { roughness: 0.35 }));
    const sphere = new THREE.SphereGeometry(1, 24, 18);
    const stoneMat = mat(0x6c757d, { flatShading: true, roughness: 1 });
    let melonTex = null;
    function melon() {
      if (melonTex) return melonTex;
      const cv = document.createElement('canvas'); cv.width = 256; cv.height = 128; const c = cv.getContext('2d');
      c.fillStyle = '#2d6a4f'; c.fillRect(0, 0, 256, 128); c.fillStyle = '#95d5b2';
      for (let i = 0; i < 8; i++) { c.beginPath(); for (let y = 0; y <= 128; y += 8) c.lineTo(i * 32 + 8 + Math.sin(y * 0.15) * 4, y); for (let y = 128; y >= 0; y -= 8) c.lineTo(i * 32 + 16 + Math.sin(y * 0.15) * 4, y); c.fill(); }
      melonTex = new THREE.CanvasTexture(cv); melonTex.colorSpace = THREE.SRGBColorSpace; return melonTex;
    }
    function fruitMesh(t, r) {
      const g = new THREE.Group();
      if (t === -1) { const m = new THREE.Mesh(new THREE.DodecahedronGeometry(1, 0), stoneMat); m.castShadow = true; g.add(m); g.scale.setScalar(r * U); return g; }
      const m = new THREE.Mesh(sphere, t === 10 ? mat(0xffffff, { map: melon(), roughness: 0.4 }) : fruitMats[t]); m.castShadow = true; g.add(m);
      if (t !== 10 && t !== 2) {
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.3), mat(0x5c4033)); stem.position.y = 1.05; g.add(stem);
        const leaf = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), mat(0x2d6a4f)); leaf.scale.set(1.8, 0.4, 0.9); leaf.position.set(0.18, 1.1, 0); g.add(leaf);
      }
      if (t === 2) for (let i = 0; i < 5; i++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.4, 10, 8), fruitMats[2]); const a = (i / 5) * Math.PI * 2; s.position.set(Math.cos(a) * 0.55, Math.sin(a) * 0.55, 0.3); g.add(s); }
      // gözler: sevimli meyveler
      for (const sx of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 6), new THREE.MeshBasicMaterial({ color: 0x222222 })); e.position.set(sx * 0.3, 0.15, 0.93); g.add(e); }
      g.scale.setScalar(r * U);
      return g;
    }
    let balls, next, nextNext, aimX, cooldown, score, over, dangerT, box, L, drops, k;
    function layout() {
      const w = 380 * Math.max(0.78, 1 - (api.level - 1) * 0.025);
      k = w / 380;
      box = { x: (VW - w) / 2, w, top: 110, bottom: VH - 16, line: 150 };
      buildBox();
    }
    function buildBox() {
      boxG.clear();
      const glass = new THREE.MeshPhysicalMaterial({ color: 0xffffff, transparent: true, opacity: 0.18, roughness: 0.05, side: THREE.DoubleSide, depthWrite: false });
      const wood = mat(0xbc8a5f);
      const H = (box.bottom - box.line + 40) * U, Wd = box.w * U, D = 2.4;
      const cx = (box.x + box.w / 2 - VW / 2) * U, by = (VH - box.bottom) * U;
      const floor = new THREE.Mesh(new THREE.BoxGeometry(Wd + 0.4, 0.3, D + 0.4), wood); floor.position.set(cx, by - 0.15, 0); floor.receiveShadow = true; boxG.add(floor);
      for (const s of [-1, 1]) { const side = new THREE.Mesh(new THREE.BoxGeometry(0.2, H, D + 0.4), wood); side.position.set(cx + s * (Wd / 2 + 0.1), by + H / 2, 0); side.castShadow = true; side.receiveShadow = true; boxG.add(side); }
      const back = new THREE.Mesh(new THREE.BoxGeometry(Wd, H, 0.1), mat(0xfefae0)); back.position.set(cx, by + H / 2, -D / 2); back.receiveShadow = true; boxG.add(back);
      const front = new THREE.Mesh(new THREE.PlaneGeometry(Wd, H), glass); front.position.set(cx, by + H / 2, D / 2); boxG.add(front);
      const line = new THREE.Mesh(new THREE.BoxGeometry(Wd, 0.04, D), new THREE.MeshBasicMaterial({ color: 0xff4d6d, transparent: true, opacity: 0.6 })); line.position.set(cx, (VH - box.line) * U, 0); boxG.add(line); boxG.userData.line = line;
      const tbl = new THREE.Mesh(new THREE.PlaneGeometry(80, 40), mat(0xd4a373)); tbl.rotation.x = -Math.PI / 2; tbl.position.y = by - 0.3; tbl.receiveShadow = true; boxG.add(tbl);
    }
    const randType = () => (Math.random() * Math.min(6, 3 + Math.floor((L + 1) / 3))) | 0;
    function start() {
      L = api.level; layout(); fruitG.clear();
      balls = []; next = randType(); nextNext = randType(); aimX = st.W / 2; cooldown = 0; score = 0; over = false; dangerT = 0; drops = 0;
      hud();
    }
    function hud() { api.setHud({ score, extra: `Sıradaki: ${TYPES[nextNext].n}` }); }
    const rad = (t) => TYPES[t].r * k;
    function drop() {
      if (over || cooldown > 0) return;
      const r = rad(next);
      const x = Math.max(box.x + r, Math.min(box.x + box.w - r, aimX));
      drops++;
      // yüksek seviyede ara sıra birleşmeyen taş düşer (15 sn sonra kaybolur)
      const stoneEvery = Math.max(4, 13 - L);
      if (L >= 3 && drops % Math.max(3, Math.round(stoneEvery / (1 + (expert(L, 10) - 1) * 0.6))) === 0) balls.push({ x: box.x + 20 + Math.random() * (box.w - 40), y: box.top - 20, vx: 0, vy: 0, t: -1, r: 22 * k, life: 15 });
      balls.push({ x, y: box.top - 10, vx: 0, vy: 0, t: next, r, born: 0 });
      next = nextNext; nextNext = randType(); cooldown = 0.55; api.sfx.tap(); hud();
    }
    const toVX = (e) => { const p = S.rayPlaneZ(e, 0); return p ? p.x / U + VW / 2 : aimX; };
    S.el.addEventListener('pointerdown', (e) => { aimX = toVX(e); });
    S.el.addEventListener('pointermove', (e) => { aimX = toVX(e); });
    S.el.addEventListener('pointerup', (e) => { aimX = toVX(e); drop(); });
    function physics(dt) {
      const g = 1400 * k;
      for (const b of balls) { b.vy += g * dt; b.x += b.vx * dt; b.y += b.vy * dt; b.vx *= 0.995; if (b.born !== undefined) b.born += dt; }
      for (let it = 0; it < 5; it++) {
        for (const b of balls) {
          if (b.x - b.r < box.x) { b.x = box.x + b.r; b.vx *= -0.3; }
          if (b.x + b.r > box.x + box.w) { b.x = box.x + box.w - b.r; b.vx *= -0.3; }
          if (b.y + b.r > box.bottom) { b.y = box.bottom - b.r; b.vy *= -0.2; b.vx *= 0.9; }
        }
        for (let i = 0; i < balls.length; i++) for (let j = i + 1; j < balls.length; j++) {
          const a = balls[i], c = balls[j];
          const dx = c.x - a.x, dy = c.y - a.y, d = Math.hypot(dx, dy) || 0.01, min = a.r + c.r;
          if (d < min) {
            if (a.t === c.t && a.t >= 0 && !a.dead && !c.dead) { merge(a, c); continue; }
            const push = (min - d) / 2, nx = dx / d, ny = dy / d;
            a.x -= nx * push; a.y -= ny * push; c.x += nx * push; c.y += ny * push;
            const rv = (c.vx - a.vx) * nx + (c.vy - a.vy) * ny;
            if (rv < 0) { const imp = rv * 0.6; a.vx += nx * imp; a.vy += ny * imp; c.vx -= nx * imp; c.vy -= ny * imp; }
          }
        }
        balls = balls.filter((b) => !b.dead);
      }
    }
    function merge(a, c) {
      a.dead = c.dead = true;
      const t = a.t + 1;
      const x = (a.x + c.x) / 2, y = (a.y + c.y) / 2;
      fx.burst(x, y, TYPES[a.t].c, 12, 160);
      const pts = (a.t + 1) * (a.t + 2) * 2;
      score += pts; fx.text(x, y - 20, '+' + pts, '#fff');
      if (t < TYPES.length) { balls.push({ x, y, vx: (a.vx + c.vx) / 2, vy: Math.min(a.vy, c.vy) - 80, t, r: rad(t), born: 0 }); api.sfx.pop(); }
      else { score += 500; api.sfx.win(); fx.text(x, y - 40, 'KARPUZ! +500', '#ffd60a'); }
      if (t >= 6) api.haptic('medium');
      hud();
    }
    function update(dt, t) {
      if (!over) {
        if (cooldown > 0) cooldown -= dt;
        physics(dt);
        balls.forEach((b) => { if (b.t === -1) { b.life -= dt; if (b.life <= 0) { b.dead = true; fx.burst(b.x, b.y, '#6c757d', 10); } } });
        balls = balls.filter((b) => !b.dead);
        // tehlike: yerleşmiş meyve çizginin üstünde 2 sn kalırsa oyun biter
        const danger = balls.some((b) => b.born > 1.2 && b.y - b.r < box.line && Math.abs(b.vy) < 60);
        dangerT = danger ? dangerT + dt : Math.max(0, dangerT - dt * 2);
        if (dangerT > 2) {
          over = true; api.sfx.lose(); api.haptic('heavy');
          setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 50), canContinue: true, title: 'Kutu taştı! 🍉' }), 500);
        }
      }
      // görselleri eşle
      const alive = new Set(balls);
      for (const m of [...fruitG.children]) if (!alive.has(m.userData.b)) fruitG.remove(m);
      for (const b of balls) {
        if (!b.m) { b.m = fruitMesh(b.t, b.r); b.m.userData.b = b; fruitG.add(b.m); b.rot = 0; }
        b.rot = (b.rot || 0) - (b.vx * dt) / (b.r || 1);
        const s = b.born !== undefined ? Math.min(1, 0.4 + b.born * 4) : 1;
        b.m.position.copy(V(b.x, b.y, 0)); b.m.rotation.z = b.rot; b.m.scale.setScalar(b.r * U * s);
      }
      // nişan: sıradaki meyve üstte bekler
      if (!aimM || aimM.userData.t !== next) { if (aimM) scene.remove(aimM); aimM = fruitMesh(next, rad(next)); aimM.userData.t = next; scene.add(aimM); }
      const r = rad(next), ax = Math.max(box.x + r, Math.min(box.x + box.w - r, aimX));
      aimM.position.copy(V(ax, box.top - 10, 0)); aimM.visible = !over && cooldown <= 0;
      guide.position.copy(V(ax, (box.top + box.bottom) / 2, -0.5)); guide.scale.y = (box.bottom - box.top) * U; guide.visible = aimM.visible;
      boxG.userData.line.material.opacity = 0.4 + Math.min(1, dangerT) * 0.6 * (Math.sin(t * 20) * 0.5 + 0.5);
      S.updateParts(dt, (VH - box.bottom) * U);
    }
    let aimM = null;
    const guide = new THREE.Mesh(new THREE.PlaneGeometry(0.04, 1), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5 })); scene.add(guide);
    S.onResize(() => {
      const vfov = (camera.fov * Math.PI) / 180, a = S.w / S.h, w = VW * U, h = VH * U;
      const d = Math.max((h / 2 + 0.3) / Math.tan(vfov / 2), (w / 2 + 0.3) / (Math.tan(vfov / 2) * a));
      camera.position.set(0, h / 2 + 1.2, d + 1.2); camera.lookAt(0, h / 2 - 0.2, 0);
    });
    start();
    const lp = S.loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { balls.sort((a, b) => a.y - b.y); balls.splice(0, Math.ceil(balls.length / 3)); dangerT = 0; over = false; hud(); },
      restart() { start(); }, destroy() { S.destroy(); },
    };
  },
};
