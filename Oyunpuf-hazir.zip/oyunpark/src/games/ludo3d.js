// 🎲 Kızma Birader 3D: zarı at, taşlarını eve götür, rakibi kızdır
import { create3D, mat, THREE } from '../core/three-stage.js';
import { boardKit, roundedBox } from '../core/board3d.js';
import { roundRect } from '../core/canvas.js';

const PATH = [];
(() => {
  const seg = (pts) => pts.forEach((p) => PATH.push(p));
  seg([[1, 6], [2, 6], [3, 6], [4, 6], [5, 6]]);
  seg([[6, 5], [6, 4], [6, 3], [6, 2], [6, 1], [6, 0]]);
  seg([[7, 0], [8, 0]]);
  seg([[8, 1], [8, 2], [8, 3], [8, 4], [8, 5]]);
  seg([[9, 6], [10, 6], [11, 6], [12, 6], [13, 6], [14, 6]]);
  seg([[14, 7], [14, 8]]);
  seg([[13, 8], [12, 8], [11, 8], [10, 8], [9, 8]]);
  seg([[8, 9], [8, 10], [8, 11], [8, 12], [8, 13], [8, 14]]);
  seg([[7, 14], [6, 14]]);
  seg([[6, 13], [6, 12], [6, 11], [6, 10], [6, 9]]);
  seg([[5, 8], [4, 8], [3, 8], [2, 8], [1, 8], [0, 8]]);
  seg([[0, 7], [0, 6]]);
})();
const COLORS = [
  { name: 'Kırmızı', c: '#ef233c', light: '#ffb3c1', start: 0, home: [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7]], base: [1, 1] },
  { name: 'Yeşil', c: '#2dc653', light: '#b7efc5', start: 13, home: [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5]], base: [10, 1] },
  { name: 'Sarı', c: '#ffc300', light: '#fff1b3', start: 26, home: [[13, 7], [12, 7], [11, 7], [10, 7], [9, 7]], base: [10, 10] },
  { name: 'Mavi', c: '#3a86ff', light: '#c1d9ff', start: 39, home: [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9]], base: [1, 10] },
];
const SAFE = new Set([0, 8, 13, 21, 26, 34, 39, 47]);
const FINISH = 56; // 0..50 dış yol, 51..55 ev yolu, 56 bitti


// 2D tahta çizimini dokuya dönüştür (taşlar ve zar 3D)
function boardCanvas() {
  const S = 1024, cv = document.createElement('canvas'); cv.width = cv.height = S;
  const c = cv.getContext('2d'), g = { cs: S / 15, ox: 0, oy: 0 }, st = { W: S, H: S }, cs = g.cs;
    c.fillStyle = '#f1faee'; c.fillRect(0, 0, st.W, st.H);
    const cell = (x, y, col, stroke = true) => { c.fillStyle = col; c.fillRect(g.ox + x * cs, g.oy + y * cs, cs, cs); if (stroke) { c.strokeStyle = '#ccc'; c.lineWidth = 1; c.strokeRect(g.ox + x * cs, g.oy + y * cs, cs, cs); } };
    // dış yol
    PATH.forEach(([x, y], i) => cell(x, y, '#fff'));
    COLORS.forEach((C, ci) => {
      // ev bölgesi
      const [bx, by] = C.base;
      c.fillStyle = C.c; roundRect(c, g.ox + (bx - 1) * cs, g.oy + (by - 1) * cs, cs * 6, cs * 6, cs * 0.4); c.fill();
      c.fillStyle = '#fff'; roundRect(c, g.ox + bx * cs - cs * 0.1, g.oy + by * cs - cs * 0.1, cs * 4.2, cs * 4.2, cs * 0.5); c.fill();
      for (let k = 0; k < 4; k++) { c.fillStyle = C.light; c.beginPath(); c.arc(g.ox + (bx + (k % 2) * 2 + 1.5) * cs, g.oy + (by + Math.floor(k / 2) * 2 + 1.5) * cs, cs * 0.6, 0, 7); c.fill(); }
      C.home.forEach(([x, y]) => cell(x, y, C.c));
      const [sx, sy] = PATH[C.start]; cell(sx, sy, C.light);
    });
    // güvenli yıldız kareleri
    [8, 21, 34, 47].forEach((i) => { const [x, y] = PATH[i]; c.fillStyle = '#adb5bd'; c.font = `${cs * 0.6}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('★', g.ox + (x + 0.5) * cs, g.oy + (y + 0.55) * cs); });
    // orta (bitiş) üçgenleri
    const mx = g.ox + 7.5 * cs, my = g.oy + 7.5 * cs, h = 1.5 * cs;
    [[0, [-h, -h], [-h, h]], [1, [-h, -h], [h, -h]], [2, [h, -h], [h, h]], [3, [-h, h], [h, h]]].forEach(([ci, a, b]) => { c.fillStyle = COLORS[ci].c; c.beginPath(); c.moveTo(mx, my); c.lineTo(mx + a[0], my + a[1]); c.lineTo(mx + b[0], my + b[1]); c.fill(); });

  return cv;
}

export default {
  id: 'ludo', title: 'Kızma Birader 3D', emoji: '🎲', color: '#ef233c',
  desc: 'Zarı at, taşlarını eve götür, rakibi kızdır!',
  winBased: true, players: { min: 2, max: 4 }, online: { min: 2, max: 4 },
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0xf1faee });
    const { scene, camera } = S;
    const K = boardKit(S, 15, 15, { tilt: 0.42, height: 0.6, extraBottom: 2.6 });
    const table = new THREE.Mesh(new THREE.BoxGeometry(40, 0.4, 40), mat(0xd4a373)); table.position.y = -0.75; table.receiveShadow = true; scene.add(table);
    const tex = new THREE.CanvasTexture(boardCanvas()); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
    const slab = new THREE.Mesh(roundedBox(15.6, 0.5, 15.6, 0.4), mat(0x8d5524)); slab.position.y = -0.55; slab.castShadow = true; slab.receiveShadow = true; scene.add(slab);
    const top = new THREE.Mesh(new THREE.PlaneGeometry(15, 15), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.7 })); top.rotation.x = -Math.PI / 2; top.position.y = -0.04; top.receiveShadow = true; scene.add(top);
    // piyonlar
    function pawn(color) {
      const g = new THREE.Group(), m = mat(new THREE.Color(color), { roughness: 0.3 }); g.scale.setScalar(1.25);
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.36, 0.16, 20), m); base.position.y = 0.08; g.add(base);
      const body = new THREE.Mesh(new THREE.ConeGeometry(0.26, 0.6, 20), m); body.position.y = 0.42; g.add(body);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 16, 12), m); head.position.y = 0.78; g.add(head);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.05, 8, 24), new THREE.MeshBasicMaterial({ color: 0x111111 })); ring.rotation.x = Math.PI / 2; ring.position.y = 0.02; ring.visible = false; g.add(ring);
      g.userData.ring = ring;
      g.traverse((o) => { if (o.isMesh && o !== ring) o.castShadow = true; });
      return g;
    }
    // zar: 6 yüzü noktalı küp
    const pipTex = (n) => {
      const cv = document.createElement('canvas'); cv.width = cv.height = 128; const c = cv.getContext('2d');
      c.fillStyle = '#fff'; c.fillRect(0, 0, 128, 128); c.fillStyle = '#222';
      ({ 1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]], 5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]] })[n].forEach(([x, y]) => { c.beginPath(); c.arc(64 + x * 32, 64 + y * 32, 12, 0, 7); c.fill(); });
      const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t;
    };
    // BoxGeometry yüz sırası: +x, -x, +y, -y, +z, -z
    const FACE_VAL = [3, 4, 1, 6, 2, 5];
    const dieMesh = new THREE.Mesh(roundedBox(1, 1, 1, 0.16), mat(0xffffff));
    const die = new THREE.Group(); die.scale.setScalar(1.35); scene.add(die);
    const cube = new THREE.Mesh(new THREE.BoxGeometry(0.96, 0.96, 0.96), FACE_VAL.map((v) => new THREE.MeshStandardMaterial({ map: pipTex(v), roughness: 0.4 }))); cube.castShadow = true; die.add(cube);
    // istenen değer üste gelsin
    const UP = { 1: new THREE.Euler(0, 0, 0), 6: new THREE.Euler(Math.PI, 0, 0), 3: new THREE.Euler(0, 0, Math.PI / 2), 4: new THREE.Euler(0, 0, -Math.PI / 2), 2: new THREE.Euler(-Math.PI / 2, 0, 0), 5: new THREE.Euler(Math.PI / 2, 0, 0) };
    const diePad = new THREE.Mesh(new THREE.CircleGeometry(1.1, 32), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5 })); diePad.rotation.x = -Math.PI / 2; scene.add(diePad);
    const DIE_POS = new THREE.Vector3(0, 0.5, 8.9);
    die.position.copy(DIE_POS); diePad.position.set(DIE_POS.x, -0.54, DIE_POS.z);
    const tokenGroup = new THREE.Group(); scene.add(tokenGroup);
    const fx = { update() {}, draw() {}, burst() {} };
    const st = { W: 1, H: 1 };
    let players, turn, dice, rolled, rolling, rollT, sixes, movable, over, L, anim, msg, pawns = [];
    const ON = api.mp?.online, inbox = [];
    let forcedDice = 0;
    ON?.on((m) => inbox.push(m));
    const myTurn = () => !ON || turn === ON.me;
    function setup() {
      inbox.length = 0; forcedDice = 0;
      L = api.level;
      const n = api.mp ? api.mp.n : 4;
      // 2 kişide karşılıklı renkler
      const colorIdx = n === 2 ? [0, 2] : n === 3 ? [0, 1, 2] : [0, 1, 2, 3];
      players = colorIdx.map((ci, k) => ({
        ci, name: api.mp ? api.mp.names[k] : k === 0 ? 'Sen' : `Bilgisayar ${k}`,
        cpu: !api.mp && k > 0, tokens: [-1, -1, -1, -1], done: false,
      }));
      turn = 0; dice = 1; rolled = false; rolling = false; sixes = 0; movable = []; over = false; anim = null; msg = '';
      hud();
      maybeCpu();
    }
    const P = () => players[turn];
    const absOf = (pl, rp) => (rp >= 0 && rp <= 50 ? (COLORS[pl.ci].start + rp) % 52 : -1);
    function cellOf(pl, rp, k) {
      const C = COLORS[pl.ci];
      if (rp < 0) { const [bx, by] = C.base; return [bx + (k % 2) * 2 + 1, by + Math.floor(k / 2) * 2 + 1]; }
      if (rp <= 50) return PATH[absOf(pl, rp)];
      if (rp < FINISH) return C.home[rp - 51];
      return [7, 7];
    }
    function hud() {
      const p = P();
      api.setHud({ score: players.map((q) => q.tokens.filter((t) => t === FINISH).length).join(' · '), scoreLabel: 'Evde', extra: msg || (ON ? (myTurn() ? `Senin sıran (${COLORS[p.ci].name}) ${rolled ? '· Taş seç' : '· Zarı at'}` : `${p.name} oynuyor…`) : `Sıra: ${p.name} (${COLORS[p.ci].name}) ${rolled ? '· Taş seç' : p.cpu ? '· düşünüyor…' : '· Zarı at'}`) });
    }
    function legalMoves(pl, d) {
      const res = [];
      pl.tokens.forEach((rp, k) => {
        if (rp === FINISH) return;
        if (rp < 0) { if (d === 6) res.push(k); return; }
        if (rp + d <= FINISH) res.push(k);
      });
      return res;
    }
    function roll(forced = 0) {
      if (rolled || rolling || over || anim) return;
      forcedDice = forced;
      rolling = true; rollT = 0.6; api.sfx.click(); msg = '';
    }
    function afterRoll() {
      rolling = false; rolled = true;
      if (ON && myTurn()) ON.send({ roll: dice });
      if (dice === 6) sixes++; else sixes = 0;
      if (sixes === 3) { msg = 'Üç kez 6! Sıra geçti'; api.sfx.wrong(); sixes = 0; return endTurn(false); }
      movable = legalMoves(P(), dice);
      if (!movable.length) { msg = 'Oynayacak taş yok'; hud(); setTimeout(() => endTurn(false), 700); return; }
      hud();
      if (!myTurn()) return; // rakibin taş seçimini bekle
      if (P().cpu) setTimeout(() => moveToken(cpuPick()), 450);
      else if (movable.length === 1 || new Set(movable.map((k) => P().tokens[k])).size === 1) setTimeout(() => moveToken(movable[0]), 250);
    }
    function cpuPick() {
      const pl = P();
      // Zorluk: seviye düşükken rastgele, yüksekken akıllı seçim
      if (Math.random() > Math.min(0.95, 0.35 + L * 0.12)) return movable[(Math.random() * movable.length) | 0];
      let best = movable[0], bestS = -Infinity;
      for (const k of movable) {
        const rp = pl.tokens[k], np = rp < 0 ? 0 : rp + dice, ab = absOf(pl, np);
        let s = np;
        if (rp < 0) s += 40;
        if (np === FINISH) s += 60;
        if (np > 50) s += 25;
        if (ab >= 0 && SAFE.has(ab)) s += 15;
        if (ab >= 0 && !SAFE.has(ab)) players.forEach((q) => { if (q !== pl) q.tokens.forEach((t) => { if (absOf(q, t) === ab) s += 80; }); });
        // tehlike: arkasında 1–6 kare yakında rakip var mı
        if (ab >= 0 && !SAFE.has(ab)) players.forEach((q) => { if (q !== pl) q.tokens.forEach((t) => { const qa = absOf(q, t); if (qa >= 0) { const d = (ab - qa + 52) % 52; if (d > 0 && d <= 6) s -= 30; } }); });
        if (s > bestS) { bestS = s; best = k; }
      }
      return best;
    }
    function moveToken(k, remote = false) {
      if (!rolled || !movable.includes(k) || anim) return;
      if (ON && !remote) ON.send({ tok: k });
      const pl = P(), from = pl.tokens[k];
      const to = from < 0 ? 0 : from + dice;
      // adım adım animasyon
      const steps = [];
      if (from < 0) steps.push(0); else for (let r = from + 1; r <= to; r++) steps.push(r);
      anim = { pl, k, steps, i: 0, t: 0 };
      movable = []; rolled = false;
    }
    function land(pl, k) {
      const rp = pl.tokens[k], ab = absOf(pl, rp);
      let extra = dice === 6, captured = false;
      if (ab >= 0 && !SAFE.has(ab)) {
        players.forEach((q) => { if (q === pl) return; q.tokens.forEach((t, j) => { if (absOf(q, t) === ab) { q.tokens[j] = -1; captured = true; } }); });
      }
      const [cx, cy] = cellOf(pl, rp, k);
      if (captured) { extra = true; api.sfx.crash(); api.haptic('heavy'); S.burst(K.pos(cx, cy, 0.4), 0xffffff, 20, 6); msg = `${pl.name} rakibi kızdırdı! 😈`; }
      if (rp === FINISH) { extra = true; api.sfx.coin(); S.burst(K.pos(7, 7, 0.5), new THREE.Color(COLORS[pl.ci].c).getHex(), 20, 6); }
      if (pl.tokens.every((t) => t === FINISH)) return finish(pl);
      endTurn(extra);
    }
    function endTurn(extra) {
      if (!extra) { turn = (turn + 1) % players.length; sixes = 0; }
      rolled = false; movable = []; hud(); maybeCpu();
    }
    function maybeCpu() { if (!over && P().cpu) setTimeout(roll, 600); }
    function finish(pl) {
      over = true; api.sfx.win(); hud();
      const idx = players.indexOf(pl);
      for (let i = 0; i < 5; i++) S.burst(K.pos(7, 7, 0.6), new THREE.Color(COLORS[pl.ci].c).getHex(), 20, 8);
      if (api.mp) setTimeout(() => api.gameOver({ winner: idx }), 1200);
      else {
        const mine = players[0].tokens.filter((t) => t === FINISH).length;
        setTimeout(() => api.gameOver({ score: idx === 0 ? 400 + L * 50 : mine * 60, coins: idx === 0 ? 12 + L * 2 : mine, win: idx === 0, title: idx === 0 ? 'Kazandın! 🎲' : `${pl.name} kazandı` }), 1200);
      }
    }
    function tokenCell(pl, k) {
      const rp = pl.tokens[k];
      let [cx, cy] = cellOf(pl, rp, k);
      let off = 0;
      if (rp >= 0) players.forEach((q) => q.tokens.forEach((t, j) => { if ((q !== pl || j < k) && t >= 0) { const [ax, ay] = cellOf(q, t, j); if (ax === cx && ay === cy) off++; } }));
      return K.pos(cx + off * 0.18, cy - off * 0.12, off * 0.15);
    }
    function buildPawns() {
      tokenGroup.clear(); pawns = [];
      players.forEach((pl, pi) => { pawns[pi] = pl.tokens.map(() => { const m = pawn(COLORS[pl.ci].c); tokenGroup.add(m); return m; }); });
    }
    const origSetup = setup;
    S.el.addEventListener('pointerdown', (e) => {
      if (over || P().cpu || anim || !myTurn()) return;
      if (!rolled) { roll(); return; }
      let pick = -1, bd = 60;
      const r = S.el.getBoundingClientRect();
      movable.forEach((k) => { const v = tokenCell(P(), k).add(new THREE.Vector3(0, 0.4, 0)).project(camera); const d = Math.hypot(r.left + (v.x + 1) / 2 * r.width - e.clientX, r.top + (1 - v.y) / 2 * r.height - e.clientY); if (d < bd) { bd = d; pick = k; } });
      if (pick >= 0) moveToken(pick);
    });
    let dieSpin = new THREE.Vector3(), lastDice = 0;
    const lp = S.loop((dt, t) => {
      if (ON && inbox.length && !rolling && !anim && !over) {
        const mv = inbox[0];
        if (mv.roll && !rolled) { inbox.shift(); roll(mv.roll); }
        else if (mv.tok !== undefined && rolled) { inbox.shift(); moveToken(mv.tok, true); }
      }
      if (rolling) { rollT -= dt; dice = 1 + ((Math.random() * 6) | 0); if (rollT <= 0) { dice = forcedDice || 1 + ((Math.random() * 6) | 0); afterRoll(); } }
      if (anim) {
        anim.t += dt;
        if (anim.t > 0.12) {
          anim.t = 0; anim.pl.tokens[anim.k] = anim.steps[anim.i]; anim.i++; api.sfx.tap();
          if (anim.i >= anim.steps.length) { const a = anim; anim = null; land(a.pl, a.k); }
        }
      }
      if (pawns.length !== players.length) buildPawns();
      // piyonları yerleştir (zıplayarak ilerler)
      players.forEach((pl, pi) => pl.tokens.forEach((rp, k) => {
        const m = pawns[pi][k], target = tokenCell(pl, k);
        const moving = anim && anim.pl === pl && anim.k === k;
        m.position.x += (target.x - m.position.x) * Math.min(1, dt * 18);
        m.position.z += (target.z - m.position.z) * Math.min(1, dt * 18);
        m.position.y = target.y + (moving ? Math.sin(Math.min(1, anim.t / 0.12) * Math.PI) * 0.5 : 0);
        const can = pl === P() && movable.includes(k) && !pl.cpu && myTurn();
        m.userData.ring.visible = can; if (can) m.scale.setScalar(1 + Math.sin(t * 8) * 0.08); else m.scale.setScalar(1);
      }));
      // zar
      if (rolling) { die.position.y = DIE_POS.y + Math.abs(Math.sin(t * 14)) * 0.8; cube.rotation.x += dt * 14; cube.rotation.y += dt * 11; cube.rotation.z += dt * 9; }
      else {
        die.position.y += (DIE_POS.y - die.position.y) * Math.min(1, dt * 12);
        const tq = new THREE.Quaternion().setFromEuler(UP[dice]);
        cube.quaternion.slerp(tq, Math.min(1, dt * 12));
      }
      diePad.material.color.set(COLORS[P().ci].c);
      S.updateParts(dt, 0);
    });
    setup();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { setup(); pawns = []; }, destroy() { S.destroy(); } };
  },
};
