// 🔟 Sayı Avı: sayılara 1'den başlayarak sırayla en hızlı şekilde dokun
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

export default {
  id: 'schulte', title: 'Sayı Avı', emoji: '🔟', color: '#0077b6',
  desc: "1'den başla, sayılara sırayla dokun!",
  winBased: true,
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    let n, nums, nextN, time, limit, over, cs, ox, oy, L, wrongT, shuffleEvery, flash;

    function layout() { if (!n) return; cs = Math.min((st.W - 24) / n, (st.H - 40) / n); ox = (st.W - cs * n) / 2; oy = (st.H - cs * n) / 2; }
    function start() {
      L = api.level; n = Math.min(7, 3 + Math.ceil(L / 2));
      nums = Array.from({ length: n * n }, (_, i) => i + 1).sort(() => Math.random() - 0.5).map((v) => ({ v, done: false, a: 0 }));
      nextN = 1; time = 0; over = false; wrongT = 0; flash = 0;
      limit = Math.max(n * n * 0.9, n * n * 2.6 - L * n * 1.2);
      shuffleEvery = L >= 5 ? Math.max(4, 12 - L) : 0; // çok zor: belirli aralıklarla karışır
      layout(); hud();
    }
    function hud() { api.setHud({ score: nextN - 1, scoreLabel: 'Bulunan', extra: `Sıradaki: ${nextN} · ⏱ ${Math.max(0, Math.ceil(limit - time))} sn` }); }
    function reshuffle() {
      const left = nums.filter((x) => !x.done).map((x) => x.v).sort(() => Math.random() - 0.5);
      let k = 0; nums.forEach((x) => { if (!x.done) x.v = left[k++]; });
      flash = 0.3; api.sfx.swap();
    }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = st.point(e), c = Math.floor((p.x - ox) / cs), r = Math.floor((p.y - oy) / cs);
      if (c < 0 || r < 0 || c >= n || r >= n) return;
      const cell = nums[r * n + c];
      if (cell.done) return;
      if (cell.v === nextN) {
        cell.done = true; nextN++; api.sfx.tap(); api.haptic('light');
        fx.burst(ox + (c + 0.5) * cs, oy + (r + 0.5) * cs, '#48cae4', 8);
        if (shuffleEvery && (nextN - 1) % shuffleEvery === 0) reshuffle();
        hud();
        if (nextN > n * n) {
          over = true; api.sfx.win();
          const score = Math.max(50, Math.round(n * n * 20 - time * 5));
          api.gameOver({ score, coins: 8 + n * 3, win: true, title: `${time.toFixed(1)} saniye! ⚡` });
        }
      } else { wrongT = 0.25; time += 1; api.sfx.wrong(); api.haptic('medium'); fx.text(ox + (c + 0.5) * cs, oy + r * cs, '+1 sn', '#ef233c'); }
    });
    function update(dt) {
      if (!over) {
        const b = Math.ceil(limit - time); time += dt; if (Math.ceil(limit - time) !== b) hud();
        if (time >= limit) { over = true; api.sfx.lose(); api.gameOver({ score: (nextN - 1) * 5, coins: Math.floor(nextN / 4), title: 'Süre doldu! ⏰' }); }
      }
      if (wrongT > 0) wrongT -= dt; if (flash > 0) flash -= dt;
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx;
      c.fillStyle = wrongT > 0 ? '#ffccd5' : '#caf0f8'; c.fillRect(0, 0, st.W, st.H);
      nums.forEach((x, i) => {
        const col = i % n, r = (i / n) | 0, px = ox + col * cs, py = oy + r * cs;
        roundRect(c, px + 3, py + 3, cs - 6, cs - 6, 12);
        c.fillStyle = x.done ? '#90e0ef' : flash > 0 ? '#ffd60a' : '#fff'; c.fill();
        if (!x.done) {
          c.fillStyle = '#03045e'; c.font = `900 ${cs * 0.42}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle';
          c.fillText(x.v, px + cs / 2, py + cs / 2 + 1);
        }
      });
      c.textBaseline = 'alphabetic'; fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
