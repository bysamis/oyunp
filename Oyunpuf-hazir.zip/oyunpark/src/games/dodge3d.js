// ☄️ Kaç Kurtul 3D: yuvarlanan alevli kayalardan kaç, elmasları topla
import { create3D, mat, THREE } from '../core/three-stage.js';
import { touchpad } from '../core/touchpad.js';
import { modelInto, stubFigure } from '../core/assets.js';

const FW = 8, ZF = -18, ZN = 3; // alan: x [-4,4], z [ZF, ZN]

export default {
  id: 'dodge', title: 'Kaç Kurtul 3D', emoji: '☄️', color: '#e63946',
  desc: 'Yuvarlanan kayalardan kaç, ne kadar dayanabilirsin?',
  target: (L) => Math.round(300 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 50, bg: 0x370617, fog: [0x370617, 30, 60] });
    const { scene, camera, sun, hemi } = S;
    hemi.color.setHex(0xffd6a5); hemi.groundColor.setHex(0x6a040f); sun.color.setHex(0xffe8d6);
    Object.assign(sun.shadow.camera, { left: -10, right: 10, top: 14, bottom: -14 });
    sun.position.set(-4, 16, 4); sun.target.position.set(0, 0, -7);
    // kanyon zemini + kenarlar + lav
    const floor = new THREE.Mesh(new THREE.BoxGeometry(FW + 0.4, 0.6, 40), mat(0xe6ccb2, { roughness: 1 })); floor.position.set(0, -0.3, -8); floor.receiveShadow = true; scene.add(floor);
    for (let z = ZN; z > -28; z -= 2) for (const s of [-1, 1]) {
      const w = new THREE.Mesh(new THREE.DodecahedronGeometry(1.1 + Math.random() * 0.6, 0), mat(0x7f4f24, { flatShading: true })); w.position.set(s * (FW / 2 + 1.1), 0.4 + Math.random() * 0.6, z + Math.random()); w.castShadow = true; w.receiveShadow = true; scene.add(w);
    }
    const lava = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), new THREE.MeshBasicMaterial({ color: 0xff5400 })); lava.rotation.x = -Math.PI / 2; lava.position.y = -1.2; scene.add(lava);
    const stripes = [];
    for (let z = ZN; z > -26; z -= 3) { const s = new THREE.Mesh(new THREE.PlaneGeometry(FW, 0.08), new THREE.MeshBasicMaterial({ color: 0x9c6644 })); s.rotation.x = -Math.PI / 2; s.position.set(0, 0.005, z); scene.add(s); stripes.push(s); }
    // kahraman
    const hero = new THREE.Group(); scene.add(hero);
    const heroM = modelInto(hero, 'character', { height: 1.8, anim: 'idle', fallback: stubFigure(0x9d4edd, 1.5) });
    heroM.rotation.y = Math.PI; // ileri (kameradan uzağa) bakar
    const shieldM = new THREE.Mesh(new THREE.SphereGeometry(0.9, 20, 14), new THREE.MeshBasicMaterial({ color: 0x80ffdb, transparent: true, opacity: 0.3 })); shieldM.position.y = 0.6; hero.add(shieldM);

    const rockGroup = new THREE.Group(); scene.add(rockGroup);
    const rockMats = [mat(0x6c584c, { flatShading: true }), mat(0x9a031e, { flatShading: true, emissive: 0xff5400, emissiveIntensity: 0.5 }), mat(0x3c096c, { flatShading: true, emissive: 0x7b2cbf, emissiveIntensity: 0.5 })];
    const gemMat = mat(0x80ffdb, { emissive: 0x2ec4b6, emissiveIntensity: 0.6, metalness: 0.3, roughness: 0.1 });
    let me, rocks, gems, time, score, spawnIn, over, L, shield, gemsGot;
    function start() {
      L = api.level; me = { x: 0, z: 0, r: 0.35, tx: 0, tz: 0 };
      rockGroup.clear(); rocks = []; gems = []; time = 0; score = 0; spawnIn = 0.5; over = false; shield = 0; gemsGot = 0; hero.visible = true; hud();
    }
    function hud() { api.setHud({ score, extra: `⏱ ${Math.floor(time)} sn · 💎 ${gemsGot}` }); }
    function spawn() {
      const d = L + time / 12;
      const r = (10 + Math.random() * (10 + d * 1.5)) / 40;
      const kind = Math.random() < Math.min(0.4, d * 0.04) ? 'bounce' : Math.random() < Math.min(0.3, d * 0.03) ? 'homing' : 'fall';
      const sp = (110 + d * 22 + Math.random() * 60) / 50;
      const m = new THREE.Mesh(new THREE.DodecahedronGeometry(r, 1), rockMats[kind === 'fall' ? 0 : kind === 'bounce' ? 1 : 2]); m.castShadow = true; rockGroup.add(m);
      rocks.push({ x: (Math.random() - 0.5) * (FW - 0.4), z: ZF, r, vx: kind === 'bounce' ? (Math.random() - 0.5) * sp : 0, vz: sp, kind, m });
      if (Math.random() < 0.12) { const gm = new THREE.Mesh(new THREE.OctahedronGeometry(0.28), gemMat); gm.castShadow = true; rockGroup.add(gm); gems.push({ x: (Math.random() - 0.5) * (FW - 1), z: ZF, vz: 2.4, m: gm }); }
      spawnIn = Math.max(0.1, 0.7 - L * 0.05 - time * 0.008);
    }
    // sürükle: parmağın hareketi kadar karakter hareket eder
    let drag = null;
    S.el.addEventListener('pointerdown', (e) => { const p = S.rayPlaneY(e, 0); if (p) drag = { p, x: me.tx, z: me.tz }; });
    S.el.addEventListener('pointermove', (e) => {
      if (!drag || over) return; const p = S.rayPlaneY(e, 0); if (!p) return;
      me.tx = Math.max(-FW / 2 + me.r, Math.min(FW / 2 - me.r, drag.x + (p.x - drag.p.x) * 1.2));
      me.tz = Math.max(-9, Math.min(ZN - 1, drag.z + (p.z - drag.p.z) * 1.2));
    });
    const up = () => (drag = null);
    window.addEventListener('pointerup', up);
    const pad = touchpad(host, { dpad: true });
    const keys = {}; const kd = (e) => (keys[e.key] = true), ku = (e) => (keys[e.key] = false);
    window.addEventListener('keydown', kd); window.addEventListener('keyup', ku);
    S.onResize(() => {
      const vfov = (camera.fov * Math.PI) / 180, a = S.w / S.h;
      // neredeyse tepeden bakış: dikey ekranda uzun koridor sığar
      const need = (FW / 2 + 0.3) / (Math.tan(vfov / 2) * a);
      const d = Math.max(10, Math.min(need, 22));
      camera.position.set(0, d, ZN + d * 0.32); camera.lookAt(0, 0, -5.5);
    });

    const lp = S.loop((dt, t) => {
      if (!over) {
        time += dt; const ns = Math.floor(time * 10) + gemsGot * 30;
        if (ns !== score) { score = ns; if ((t * 10 | 0) % 3 === 0) hud(); }
        if (shield > 0) shield -= dt;
        if (keys.ArrowLeft || pad.held.left) me.tx -= 6 * dt; if (keys.ArrowRight || pad.held.right) me.tx += 6 * dt; if (keys.ArrowUp || pad.held.up) me.tz -= 6 * dt; if (keys.ArrowDown || pad.held.down) me.tz += 6 * dt;
        me.tx = Math.max(-FW / 2 + me.r, Math.min(FW / 2 - me.r, me.tx)); me.tz = Math.max(-9, Math.min(ZN - 1, me.tz));
        spawnIn -= dt; if (spawnIn <= 0) spawn();
        for (const r of rocks) {
          if (r.kind === 'homing') r.vx += Math.sign(me.x - r.x) * 1.2 * dt;
          r.x += r.vx * dt; r.z += r.vz * dt;
          if (r.kind === 'bounce' && (r.x < -FW / 2 + r.r || r.x > FW / 2 - r.r)) r.vx *= -1;
          if (Math.hypot(r.x - me.x, r.z - me.z) < r.r + me.r * 0.8 && shield <= 0) {
            over = true; api.sfx.crash(); api.haptic('heavy');
            S.burst(new THREE.Vector3(me.x, 0.6, me.z), 0xffd60a, 30, 7); hero.visible = false;
            setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 25) + gemsGot * 2, canContinue: true, title: 'Kaya çarptı! ☄️' }), 600);
          }
        }
        rocks = rocks.filter((r) => { if (r.z > ZN + 3) { rockGroup.remove(r.m); return false; } return true; });
        for (const g of gems) {
          g.z += g.vz * dt;
          if (Math.hypot(g.x - me.x, g.z - me.z) < me.r + 0.35) { g.dead = true; gemsGot++; api.sfx.coin(); S.popText(new THREE.Vector3(g.x, 1.2, g.z), '💎 +30', '#80ffdb'); S.burst(new THREE.Vector3(g.x, 0.5, g.z), 0x80ffdb, 10, 4, 0.5); hud(); }
        }
        gems = gems.filter((g) => { if (g.dead || g.z > ZN + 2) { rockGroup.remove(g.m); return false; } return true; });
      }
      // görseller
      for (const r of rocks) { r.m.position.set(r.x, r.r, r.z); r.m.rotation.x += (r.vz / r.r) * dt; r.m.rotation.z -= (r.vx / r.r) * dt; }
      for (const g of gems) { g.m.position.set(g.x, 0.5 + Math.sin(t * 4 + g.x) * 0.1, g.z); g.m.rotation.y += dt * 3; }
      const dx = me.tx - me.x, dz = me.tz - me.z, sp = Math.hypot(dx, dz);
      me.x += dx * Math.min(1, dt * 14); me.z += dz * Math.min(1, dt * 14);
      hero.position.set(me.x, 0, me.z);
      const hm = heroM.userData.model;
      if (hm) { hm.userData.play(sp > 0.05 ? 'walk' : 'idle'); hm.userData.update(dt * (sp > 0.05 ? 1.6 : 1)); }
      if (sp > 0.05) heroM.rotation.y = Math.atan2(dx, dz);
      shieldM.visible = shield > 0 && Math.floor(t * 10) % 2 === 0;
      stripes.forEach((s) => { s.position.z += dt * 2.5; if (s.position.z > ZN) s.position.z -= 30; });
      lava.material.color.setHSL(0.05 + Math.sin(t * 2) * 0.01, 1, 0.5);
      S.updateParts(dt, 0);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { rockGroup.clear(); rocks = []; gems = []; shield = 3; over = false; hero.visible = true; hud(); },
      restart() { start(); },
      destroy() { pad.destroy(); S.destroy(); window.removeEventListener('pointerup', up); window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku); },
    };
  },
};
