// 🎯 Hedef Vur: hedefler küçülerek kaybolur, kaçırmadan vur
import { createStage, loop, particles } from '../core/canvas.js';

export default {
  id: 'reflex', title: 'Hedef Vur', emoji: '🎯', color: '#d00000',
  desc: 'Hedefler kaybolmadan hepsini vur!',
  target: (L) => Math.round(400 * Math.pow(1.4, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let targets, score, lives, spawnIn, elapsed, over, L, streak;
    const S = () => Math.min(st.W, 500) / 400;

    function start() { L = api.level; targets = []; score = 0; lives = 3; spawnIn = 0.3; elapsed = 0; over = false; streak = 0; hud(); }
    function hud() { api.setHud({ score, extra: `${'❤️'.repeat(lives)} · Seri ${streak}` }); }
    function spawn() {
      const r = Math.max(16, 42 - L * 2.5 - elapsed * 0.15) * S();
      const life = Math.max(0.7, 2.4 - L * 0.15 - elapsed * 0.012);
      const moving = L >= 3 && Math.random() < Math.min(0.6, (L - 2) * 0.12);
      const decoy = L >= 2 && Math.random() < Math.min(0.25, 0.05 + L * 0.02); // basılmaması gereken mavi hedef
      targets.push({ x: r + Math.random() * (st.W - 2 * r), y: r + Math.random() * (st.H - 2 * r), r, life, t: 0, vx: moving ? (Math.random() - 0.5) * 220 * S() : 0, vy: moving ? (Math.random() - 0.5) * 220 * S() : 0, decoy });
      spawnIn = Math.max(0.25, 0.9 - L * 0.05 - elapsed * 0.01);
    }
    function lose() {
      lives--; streak = 0; api.sfx.wrong(); api.haptic('medium'); hud();
      if (lives <= 0 && !over) { over = true; api.sfx.lose(); api.gameOver({ score, coins: Math.floor(score / 25), canContinue: true, title: 'Hedefler kaçtı! 🎯' }); }
    }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = st.point(e);
      for (let i = targets.length - 1; i >= 0; i--) {
        const tg = targets[i], k = 1 - tg.t / tg.life;
        if (Math.hypot(p.x - tg.x, p.y - tg.y) < tg.r * Math.max(0.35, k) + 6) {
          targets.splice(i, 1);
          if (tg.decoy) { fx.burst(tg.x, tg.y, '#3a86ff', 14); lose(); return; }
          const center = Math.hypot(p.x - tg.x, p.y - tg.y) < tg.r * 0.3;
          streak++; const pts = 10 + Math.round(k * 20) + (center ? 15 : 0) + Math.min(streak, 15);
          score += pts; api.sfx.pop(); api.haptic('light');
          fx.burst(tg.x, tg.y, '#ff4d6d', 14); fx.text(tg.x, tg.y - tg.r, center ? `TAM! +${pts}` : `+${pts}`, center ? '#ffd60a' : '#fff'); hud();
          return;
        }
      }
      score = Math.max(0, score - 5); streak = 0; hud();
    });
    function update(dt) {
      if (!over) {
        elapsed += dt; spawnIn -= dt; if (spawnIn <= 0) spawn();
        for (let i = targets.length - 1; i >= 0; i--) {
          const tg = targets[i]; tg.t += dt; tg.x += tg.vx * dt; tg.y += tg.vy * dt;
          if (tg.x < tg.r || tg.x > st.W - tg.r) tg.vx *= -1; if (tg.y < tg.r || tg.y > st.H - tg.r) tg.vy *= -1;
          if (tg.t >= tg.life) { targets.splice(i, 1); if (!tg.decoy) lose(); }
        }
      }
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx;
      c.fillStyle = '#f1faee'; c.fillRect(0, 0, st.W, st.H);
      c.strokeStyle = 'rgba(0,0,0,.05)'; c.lineWidth = 1;
      for (let x = 0; x < st.W; x += 40) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, st.H); c.stroke(); }
      for (let y = 0; y < st.H; y += 40) { c.beginPath(); c.moveTo(0, y); c.lineTo(st.W, y); c.stroke(); }
      for (const tg of targets) {
        const k = Math.max(0.05, 1 - tg.t / tg.life), r = tg.r * Math.max(0.35, k);
        const cols = tg.decoy ? ['#3a86ff', '#fff', '#3a86ff'] : ['#d00000', '#fff', '#d00000'];
        [1, 0.66, 0.33].forEach((m, i) => { c.fillStyle = cols[i]; c.beginPath(); c.arc(tg.x, tg.y, r * m, 0, 7); c.fill(); });
        c.strokeStyle = 'rgba(0,0,0,.2)'; c.lineWidth = 3; c.beginPath(); c.arc(tg.x, tg.y, r + 4, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * k); c.stroke();
        if (tg.decoy) { c.fillStyle = '#fff'; c.font = `900 ${r * 0.5}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('✕', tg.x, tg.y); c.textBaseline = 'alphabetic'; }
      }
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), continue() { lives = 2; targets = []; over = false; hud(); }, restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
