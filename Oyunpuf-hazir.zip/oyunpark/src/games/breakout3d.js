// 🧱 Blok Kırma 3D
import { create3D, mat, THREE } from '../core/three-stage.js';
import { touchpad } from '../core/touchpad.js';
import { expert, expertSteps } from '../core/expert.js';
import { store } from '../core/store.js';
import { BALL_SKINS } from './breakout.js';

const COLORS = [0xff4d6d, 0xff9f1c, 0xffd60a, 0x2dc653, 0x3a86ff, 0x9d4edd, 0xff70a6];
const FW = 10, ZTOP = -9, ZBOT = 7.5;

export default {
  id: 'breakout', title: 'Blok Kırma 3D', emoji: '🧱', color: '#3a86ff',
  desc: 'Topu sektir, tüm blokları kır!',
  expertFrom: 26,
  target: (L) => Math.round(400 * Math.pow(1.45, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 50, bg: 0x1b1f4b, fog: [0x1b1f4b, 30, 60] });
    const { scene, camera } = S;
    S.onResize(() => {
      const a = S.w / S.h, dist = Math.max(14, 11.5 / a);
      camera.position.set(0, dist * 0.92, dist * 0.62); camera.lookAt(0, 0, -0.6);
    });
    // masa
    const floor = new THREE.Mesh(new THREE.BoxGeometry(FW + 1, 0.4, ZBOT - ZTOP + 3), mat(0x2b2d6e, { roughness: 0.8 }));
    floor.position.set(0, -0.2, (ZTOP + ZBOT) / 2 + 0.5); floor.receiveShadow = true; scene.add(floor);
    const railMat = mat(0x7b68ee, { metalness: 0.4, roughness: 0.3, emissive: 0x2a1a6e, emissiveIntensity: 0.4 });
    [[-FW / 2 - 0.25, 0], [FW / 2 + 0.25, 0]].forEach(([x]) => { const r = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.7, ZBOT - ZTOP + 3), railMat); r.position.set(x, 0.35, (ZTOP + ZBOT) / 2 + 0.5); r.castShadow = true; scene.add(r); });
    const back = new THREE.Mesh(new THREE.BoxGeometry(FW + 1, 0.7, 0.5), railMat); back.position.set(0, 0.35, ZTOP - 0.25); scene.add(back);
    // yıldızlar
    const stars = new THREE.Points(new THREE.BufferGeometry().setAttribute('position', new THREE.Float32BufferAttribute(Array.from({ length: 600 }, (_, i) => (i % 3 === 1 ? -5 - Math.random() * 20 : (Math.random() - 0.5) * 80)), 3)), new THREE.PointsMaterial({ color: 0xffffff, size: 0.12 }));
    scene.add(stars);

    const paddleMat = mat(0xffffff, { metalness: 0.3, roughness: 0.25, emissive: 0x88aaff, emissiveIntensity: 0.25 });
    const paddleM = new THREE.Mesh(new THREE.BoxGeometry(1, 0.45, 0.5), paddleMat); paddleM.castShadow = true; scene.add(paddleM);
    const ballGeo = new THREE.SphereGeometry(0.24, 20, 14);
    const brickGeo = new THREE.BoxGeometry(1, 1, 1);

    let paddle, balls, bricks, drops, lives, level, score, bonus, wideT, state, L;
    const speed = () => 9 + Math.min(level, 25) * 0.6 + Math.min(8, expertSteps(level, 25) * 0.25); // uzman: top hızlanmaya devam
    const pScale = () => Math.max(0.55, 1 - (level - 1) * 0.05);
    const baseW = () => 2.3 * pScale() * (wideT > 0 ? 1.5 : 1);
    function ballMat() {
      const sk = BALL_SKINS[store.get().ballSkin] || BALL_SKINS.white;
      const col = sk.color === 'rainbow' ? 0xff00ff : new THREE.Color(sk.color).getHex();
      return mat(col, { emissive: col, emissiveIntensity: 0.6, roughness: 0.2 });
    }
    function clearAll() { bricks?.forEach((b) => scene.remove(b.m)); balls?.forEach((b) => scene.remove(b.m)); drops?.forEach((d) => scene.remove(d.m)); }
    function buildLevel() {
      bricks?.forEach((b) => scene.remove(b.m)); bricks = [];
      const cols = 8, rows = Math.min(4 + level, 10), gap = 0.12, bw = (FW - 0.4 - gap * (cols - 1)) / cols, bd = 0.6;
      const pattern = level % 4;
      for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
        if (pattern === 1 && (r + c) % 2 === 1 && r > 1) continue;
        if (pattern === 2 && Math.abs(c - 3.5) > rows - r + 0.5) continue;
        if (pattern === 3 && (c === 3 || c === 4) && r % 3 === 1) continue;
        const hp = level >= 6 && r < level - 6 ? 3 : level >= 3 && r < Math.min(level - 1, 6) ? 2 : 1;
        const col = COLORS[r % COLORS.length];
        const m = new THREE.Mesh(brickGeo, mat(col, { roughness: 0.35, metalness: hp > 1 ? 0.5 : 0.1 }));
        const x = -FW / 2 + 0.2 + bw / 2 + c * (bw + gap), z = ZTOP + 0.6 + r * (bd + gap);
        m.scale.set(bw, 0.5 + (hp - 1) * 0.25, bd); m.position.set(x, m.scale.y / 2, z); m.castShadow = true; m.receiveShadow = true;
        scene.add(m); bricks.push({ m, x, z, w: bw, d: bd, hp, col });
      }
      drops?.forEach((d) => scene.remove(d.m)); drops = [];
      resetBall();
    }
    function resetBall() {
      balls?.forEach((b) => scene.remove(b.m));
      const m = new THREE.Mesh(ballGeo, ballMat()); m.castShadow = true; scene.add(m);
      balls = [{ m, x: paddle.x, z: paddle.z - 0.5, vx: 0, vz: 0, r: 0.24, stuck: true }];
      state = 'ready';
    }
    function launch() {
      balls.forEach((b) => { if (b.stuck) { const a = (Math.random() - 0.5) * 0.6; b.vx = Math.sin(a) * speed(); b.vz = -Math.cos(a) * speed(); b.stuck = false; } });
      state = 'play'; api.sfx.tap();
    }
    function start() {
      clearAll(); L = api.level;
      paddle = { x: 0, z: 6.2, w: 2.3 };
      lives = 3; level = L; score = 0; bonus = 0; wideT = 0;
      buildLevel(); hud();
    }
    function hud() { api.setHud({ score, extra: `❤️ ${lives}  ·  Seviye ${level}` }); }

    const move = (e) => { const p = S.rayPlaneY(e, 0.25); if (p) paddle.x = Math.max(-FW / 2 + paddle.w / 2, Math.min(FW / 2 - paddle.w / 2, p.x)); };
    S.el.addEventListener('pointerdown', move);
    S.el.addEventListener('pointermove', move);
    S.el.addEventListener('pointerup', () => { if (state === 'ready') launch(); });
    const onKey = (e) => { if (e.key === 'ArrowLeft') paddle.x -= 0.8; if (e.key === 'ArrowRight') paddle.x += 0.8; if (e.key === ' ' && state === 'ready') launch(); };
    window.addEventListener('keydown', onKey);
    const pad = touchpad(host, { left: [{ id: 'left', icon: '◀', big: true }, { id: 'right', icon: '▶', big: true }], right: [{ id: 'fire', icon: '🚀', label: 'Fırlat', cls: 'fire' }], onPress: (id) => { if (id === 'fire' && state === 'ready') launch(); } });

    const hitBox = (b, br) => {
      const cx = Math.max(br.x - br.w / 2, Math.min(b.x, br.x + br.w / 2)), cz = Math.max(br.z - br.d / 2, Math.min(b.z, br.z + br.d / 2));
      return (b.x - cx) ** 2 + (b.z - cz) ** 2 < b.r * b.r;
    };
    function hit(br) {
      br.hp--; api.sfx.brick(); api.haptic('light');
      if (br.hp <= 0) {
        score += 10 * level;
        S.burst(new THREE.Vector3(br.x, 0.3, br.z), br.col, 10, 5);
        scene.remove(br.m); bricks.splice(bricks.indexOf(br), 1);
        if (Math.random() < 0.13) {
          const type = ['wide', 'multi', 'coin', 'coin'][(Math.random() * 4) | 0];
          const col = type === 'wide' ? 0x7ee8fa : type === 'multi' ? 0xff70a6 : 0xffd60a;
          const m = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.6, 16), mat(col, { emissive: col, emissiveIntensity: 0.5 }));
          m.rotation.z = Math.PI / 2; m.position.set(br.x, 0.35, br.z); scene.add(m); drops.push({ m, type });
        }
      } else { score += 5; br.m.scale.y = 0.5 + (br.hp - 1) * 0.25; br.m.position.y = br.m.scale.y / 2; br.m.material.color.offsetHSL(0, -0.2, -0.1); }
      hud();
    }
    function stepBall(b, dt) {
      const n = 4;
      for (let i = 0; i < n; i++) {
        const h = dt / n;
        b.x += b.vx * h;
        if (b.x < -FW / 2 + b.r) { b.x = -FW / 2 + b.r; b.vx = Math.abs(b.vx); api.sfx.bounce(); }
        if (b.x > FW / 2 - b.r) { b.x = FW / 2 - b.r; b.vx = -Math.abs(b.vx); api.sfx.bounce(); }
        for (const br of bricks) if (hitBox(b, br)) { b.vx = -b.vx; b.x += b.vx * h; hit(br); break; }
        b.z += b.vz * h;
        if (b.z < ZTOP + b.r) { b.z = ZTOP + b.r; b.vz = Math.abs(b.vz); api.sfx.bounce(); }
        for (const br of bricks) if (hitBox(b, br)) { b.vz = -b.vz; b.z += b.vz * h; hit(br); break; }
        if (b.vz > 0 && b.z + b.r >= paddle.z - 0.25 && b.z - b.r <= paddle.z + 0.25 && Math.abs(b.x - paddle.x) < paddle.w / 2 + b.r) {
          const rel = Math.max(-1, Math.min(1, (b.x - paddle.x) / (paddle.w / 2))), a = rel * 1.05, sp = speed();
          b.vx = Math.sin(a) * sp; b.vz = -Math.cos(a) * sp; b.z = paddle.z - 0.25 - b.r; api.sfx.bounce();
        }
      }
    }
    const lp = S.loop((dt, t) => {
      if (state !== 'over') {
        if (wideT > 0) wideT -= dt;
        paddle.w += (baseW() - paddle.w) * Math.min(1, dt * 8);
        if (pad.held.left) paddle.x -= 11 * dt; if (pad.held.right) paddle.x += 11 * dt;
        paddle.x = Math.max(-FW / 2 + paddle.w / 2, Math.min(FW / 2 - paddle.w / 2, paddle.x));
        if (state === 'ready') balls.forEach((b) => { b.x = paddle.x; b.z = paddle.z - 0.5; });
        else {
          balls.forEach((b) => stepBall(b, dt));
          balls = balls.filter((b) => { if (b.z > ZBOT + 1) { scene.remove(b.m); return false; } return true; });
          if (!balls.length) {
            lives--; hud(); api.sfx.wrong(); api.haptic('medium');
            if (lives <= 0) { state = 'over'; api.sfx.lose(); api.gameOver({ score, coins: Math.floor(score / 25) + bonus, canContinue: true }); }
            else resetBall();
          }
          if (!bricks.length) { level++; score += 100; api.sfx.win(); S.popText(new THREE.Vector3(0, 1, 0), `Seviye ${level}!`, '#ffd60a'); buildLevel(); hud(); }
        }
        drops = drops.filter((d) => {
          d.m.position.z += 4 * dt; d.m.rotation.x += dt * 4;
          if (Math.abs(d.m.position.z - paddle.z) < 0.5 && Math.abs(d.m.position.x - paddle.x) < paddle.w / 2 + 0.3) {
            scene.remove(d.m); api.sfx.power();
            if (d.type === 'wide') { wideT = 12; S.popText(d.m.position, 'Geniş!', '#7ee8fa'); }
            if (d.type === 'coin') { bonus += 5; api.sfx.coin(); S.popText(d.m.position, '+5 🪙', '#ffd60a'); }
            if (d.type === 'multi' && state === 'play' && balls[0]) {
              const src = balls[0];
              [-0.5, 0.5].forEach((a) => { const m = new THREE.Mesh(ballGeo, ballMat()); m.castShadow = true; scene.add(m); balls.push({ m, x: src.x, z: src.z, r: 0.24, vx: Math.sin(a) * speed(), vz: -Math.cos(a) * speed() }); });
              S.popText(d.m.position, '×3 Top!', '#ff70a6');
            }
            return false;
          }
          if (d.m.position.z > ZBOT + 2) { scene.remove(d.m); return false; }
          return true;
        });
      }
      paddleM.scale.x = paddle.w; paddleM.position.set(paddle.x, 0.25, paddle.z);
      const sk = BALL_SKINS[store.get().ballSkin];
      balls.forEach((b) => { b.m.position.set(b.x, 0.25, b.z); if (sk?.color === 'rainbow') b.m.material.color.setHSL((t * 0.8) % 1, 1, 0.6); });
      bricks.forEach((br, i) => (br.m.position.y = br.m.scale.y / 2 + Math.sin(t * 2 + i) * 0.02));
      S.updateParts(dt);
    });

    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { lives = 1; resetBall(); hud(); },
      restart() { start(); },
      destroy() { window.removeEventListener('keydown', onKey); pad.destroy(); S.destroy(); },
    };
  },
};
