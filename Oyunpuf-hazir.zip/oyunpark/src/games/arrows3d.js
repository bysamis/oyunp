// 🎯 Ok Fırlat 3D: dönen kütüğe ok sapla, diğer oklara çarpma
import { create3D, mat, THREE } from '../core/three-stage.js';

const R = 2, ALEN = 1.6;

export default {
  id: 'arrows', title: 'Ok Fırlat 3D', emoji: '🏹', color: '#9c6644',
  desc: 'Dönen kütüğe ok sapla, oklara çarpma!',
  target: (L) => 20 + (L - 1) * 10,
  create(host, api) {
    const S = create3D(host, { fov: 45, bg: 0x2b2d42 });
    const { scene, camera, sun } = S;
    sun.position.set(-4, 8, 12);
    // arka plan: orman silueti
    for (let i = 0; i < 14; i++) { const t = new THREE.Mesh(new THREE.ConeGeometry(1 + Math.random(), 5 + Math.random() * 4, 6), mat(0x1b4332, { flatShading: true })); t.position.set(-14 + i * 2.2, -3 + Math.random(), -10 - Math.random() * 4); scene.add(t); }
    const moon = new THREE.Mesh(new THREE.CircleGeometry(1.4, 32), new THREE.MeshBasicMaterial({ color: 0xfefae0 })); moon.position.set(-5, 11, -16); scene.add(moon);
    // kütük (yüzü kameraya bakar, z ekseni etrafında döner)
    const wheel = new THREE.Group(); scene.add(wheel);
    const log = new THREE.Mesh(new THREE.CylinderGeometry(R, R, 0.9, 40), [mat(0x7f5539, { roughness: 1 }), mat(0xe9c46a, { roughness: 0.8 }), mat(0xe9c46a)]);
    log.rotation.x = Math.PI / 2; log.castShadow = true; wheel.add(log);
    for (let k = 1; k < 4; k++) { const ring = new THREE.Mesh(new THREE.RingGeometry((R * k) / 4 - 0.03, (R * k) / 4, 40), new THREE.MeshBasicMaterial({ color: 0x9c6644 })); ring.position.z = 0.452; wheel.add(ring); }
    const bark = new THREE.Mesh(new THREE.TorusGeometry(R, 0.08, 6, 40), mat(0x5c4033)); bark.position.z = 0.45; wheel.add(bark);
    const stuck = new THREE.Group(); wheel.add(stuck);

    function arrowMesh() {
      const g = new THREE.Group();
      const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, ALEN, 8), mat(0xdda15e)); shaft.position.y = -ALEN / 2; g.add(shaft);
      const tip = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.28, 8), mat(0xadb5bd, { metalness: 0.8, roughness: 0.2 })); tip.position.y = 0.05; g.add(tip);
      for (let i = 0; i < 3; i++) { const f = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.35, 0.2), mat(0xef233c)); f.position.y = -ALEN + 0.15; f.rotation.y = (i / 3) * Math.PI * 2; f.translateZ(0.08); g.add(f); }
      g.traverse((o) => { if (o.isMesh) o.castShadow = true; });
      return g; // uç y=0'da, gövde -y yönünde
    }
    const flyM = arrowMesh(); scene.add(flyM);
    const appleGroup = new THREE.Group(); wheel.add(appleGroup);
    const quiver = new THREE.Group(); scene.add(quiver);

    let stage, rot, rotV, arrows, left, flying, score, over, L, apples, patT, shake, burstT, cy = 2.5, bottomY = -6, pieces = [];
    S.onResize(() => {
      const vfov = (camera.fov * Math.PI) / 180, a = S.w / S.h;
      const halfH = 7.2, need = Math.max(halfH / Math.tan(vfov / 2), (R + 1.4) / (Math.tan(vfov / 2) * a));
      camera.position.set(0, 0, need); camera.lookAt(0, 0, 0);
      const vis = Math.tan(vfov / 2) * need; cy = vis * 0.38; bottomY = -vis * 0.72;
      wheel.position.set(0, cy, 0); quiver.position.set(-Math.min(vis * a - 0.8, 3.2), bottomY, 0);
    });
    function setupStage() {
      left = Math.min(14, 6 + stage + Math.floor(L / 2));
      arrows = []; stuck.clear(); appleGroup.clear(); wheel.visible = true;
      const pre = Math.min(7, Math.floor((L - 1) / 2) + Math.floor(stage / 2));
      for (let i = 0; i < pre; i++) addStuck((i / pre) * Math.PI * 2 + Math.random() * 0.4, true);
      apples = Math.random() < 0.6 ? [{ a: Math.random() * Math.PI * 2 }] : [];
      for (const ap of apples) {
        const m = new THREE.Group();
        const s = new THREE.Mesh(new THREE.SphereGeometry(0.32, 16, 12), mat(0xe63946, { roughness: 0.3 })); m.add(s);
        const lf = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 6), mat(0x2d6a4f)); lf.scale.set(1.8, 0.4, 0.8); lf.position.set(0.08, 0.34, 0); m.add(lf);
        m.position.set(Math.cos(ap.a) * (R + 0.3), Math.sin(ap.a) * (R + 0.3), 0.2); ap.m = m; appleGroup.add(m);
      }
      rotV = (1.4 + L * 0.22 + stage * 0.15) * (Math.random() < 0.5 ? 1 : -1);
      patT = 0; flying = null; burstT = 0;
      hud(); syncQuiver();
    }
    function addStuck(a, pre) {
      arrows.push({ a, pre });
      const m = arrowMesh();
      // uç kütüğün içinde, gövde dışarı bakar
      m.position.set(Math.cos(a) * (R - 0.25), Math.sin(a) * (R - 0.25), 0.15);
      m.rotation.z = a - Math.PI / 2 + Math.PI; // gövde merkezden dışarı
      if (pre) m.children[0].material = mat(0x6c757d);
      stuck.add(m);
    }
    function syncQuiver() { quiver.clear(); for (let i = 0; i < left; i++) { const m = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.08, 0.08), mat(0xffffff, { emissive: 0xffffff, emissiveIntensity: 0.3 })); m.position.y = i * 0.2; quiver.add(m); } }
    function start() { L = api.level; stage = 1; rot = 0; score = 0; over = false; shake = 0; pieces.forEach((p) => scene.remove(p.m)); pieces = []; setupStage(); }
    function hud() { api.setHud({ score, scoreLabel: 'Ok', extra: `Aşama ${stage} · Kalan ok: ${left}` }); }
    function throwArrow() {
      if (over || flying || left <= 0 || burstT > 0) return;
      flying = { y: bottomY + ALEN, v: 36 }; left--; api.sfx.swap(); hud(); syncQuiver();
    }
    S.el.addEventListener('pointerdown', throwArrow);
    const onKey = (e) => { if (e.key === ' ') throwArrow(); };
    window.addEventListener('keydown', onKey);
    const angDist = (a, b) => { let d = Math.abs(a - b) % (Math.PI * 2); return d > Math.PI ? Math.PI * 2 - d : d; };

    const lp = S.loop((dt, t) => {
      if (!over && burstT <= 0) {
        patT += dt;
        let v = rotV;
        if (L >= 3) v *= 1 + Math.sin(patT * (0.8 + L * 0.1)) * Math.min(0.9, (L - 2) * 0.15);
        if (L >= 5 && Math.sin(patT * 0.9) > 0.97) rotV = -rotV;
        rot += v * dt;
      }
      if (flying && !over) {
        flying.y += flying.v * dt;
        const hitY = cy - R;
        if (flying.y >= hitY + 0.25) {
          // kütüğün alt noktası, kütüğün kendi açısıyla
          const a = -Math.PI / 2 - rot;
          const tooClose = arrows.some((ar) => angDist(ar.a, a) < 0.16);
          if (tooClose) {
            over = true; shake = 0.4; api.sfx.crash(); api.haptic('heavy');
            S.burst(new THREE.Vector3(0, hitY, 0.5), 0xffffff, 16, 5, 0.6);
            const m = arrowMesh(); m.position.set(0, hitY, 0.3); scene.add(m); pieces.push({ m, vx: (Math.random() - 0.5) * 6, vy: -4, vr: 10 });
            flying = null;
            setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 4), canContinue: true, title: 'Oka çarptın! 🎯' }), 700);
          } else {
            addStuck(a, false); score++; api.sfx.brick(); api.haptic('light'); shake = 0.08;
            const ap = apples.findIndex((p) => angDist(p.a, a) < 0.22);
            if (ap >= 0) { appleGroup.remove(apples[ap].m); apples.splice(ap, 1); score += 3; api.sfx.coin(); S.burst(new THREE.Vector3(0, hitY, 0.5), 0xe63946, 14, 5, 0.6); S.popText(new THREE.Vector3(0, hitY - 0.6, 0.5), '+3 🍎', '#fff'); }
            S.burst(new THREE.Vector3(0, hitY, 0.5), 0xc68b59, 6, 3, 0.4);
            flying = null; hud();
            if (left === 0) {
              burstT = 1; api.sfx.win(); score += 5;
              // kütük parçalanır, oklar düşer
              wheel.visible = false;
              for (let i = 0; i < 6; i++) { const m = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.2, 0.9), mat(0xe9c46a)); m.position.set(Math.cos(i) * 1, cy + Math.sin(i) * 1, 0); scene.add(m); pieces.push({ m, vx: Math.cos(i) * 5, vy: 3 + Math.random() * 3, vr: 4 }); }
              S.popText(new THREE.Vector3(0, cy, 1), `Aşama ${stage} tamam!`, '#ffd60a');
            }
          }
        }
      }
      if (burstT > 0) { burstT -= dt; if (burstT <= 0) { stage++; setupStage(); } }
      if (shake > 0) shake -= dt;
      wheel.rotation.z = rot;
      wheel.position.x = shake > 0 ? Math.sin(t * 80) * 0.08 : 0;
      wheel.position.y = cy + (shake > 0 ? 0.1 * shake : 0);
      flyM.visible = !over && burstT <= 0 && (flying || left > 0);
      flyM.position.set(0, flying ? flying.y : bottomY + ALEN, 0.3);
      pieces = pieces.filter((p) => { p.vy -= 20 * dt; p.m.position.x += p.vx * dt; p.m.position.y += p.vy * dt; p.m.rotation.z += p.vr * dt; if (p.m.position.y < -20) { scene.remove(p.m); return false; } return true; });
      S.updateParts(dt, -20);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { over = false; flying = null; left = Math.max(left, 1); hud(); syncQuiver(); },
      restart() { start(); },
      destroy() { S.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
