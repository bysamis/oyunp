// 🔨 Köstebek Vur (60 saniye)
import { createStage, loop, particles } from '../core/canvas.js';

export default {
  id: 'mole', title: 'Köstebek Vur', emoji: '🔨', color: '#bc6c25',
  desc: 'Çıkan köstebeklere hızlıca vur!',
  target: (L) => Math.round(300 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    const GAME_TIME = 45;
    let holes, score, timeLeft, spawnIn, over, combo, hitFlash, L;

    function layout() {
      const cols = 3, rows = 4;
      const w = Math.min(st.W - 30, 460), h = Math.min(st.H - 40, 640);
      const ox = (st.W - w) / 2, oy = (st.H - h) / 2;
      const r = Math.min(w / cols, h / rows) * 0.36;
      holes = holes || [];
      for (let i = 0; i < cols * rows; i++) {
        const hx = ox + (w / cols) * ((i % cols) + 0.5), hy = oy + (h / rows) * (((i / cols) | 0) + 0.6);
        holes[i] = { ...(holes[i] || { up: 0, state: 'down', t: 0 }), x: hx, y: hy, r };
      }
    }
    function start() { L = api.level; holes = null; layout(); score = 0; timeLeft = GAME_TIME; spawnIn = 0.6; over = false; combo = 0; hitFlash = 0; hud(); }
    function hud() { api.setHud({ score, extra: `⏱ ${Math.ceil(timeLeft)} sn · Kombo ×${Math.max(1, combo)}` }); }

    function spawn() {
      const free = holes.filter((h) => h.state === 'down');
      if (free.length) {
        const h = free[(Math.random() * free.length) | 0];
        const elapsed = GAME_TIME - timeLeft;
        h.state = 'rising'; h.t = 0;
        h.stay = Math.max(0.32, 1.3 - L * 0.1 - elapsed * 0.018);
        h.kind = Math.random() < Math.min(0.3, 0.1 + L * 0.025) ? 'bomb' : Math.random() < 0.1 ? 'gold' : 'mole';
      }
      spawnIn = Math.max(0.18, 0.85 - L * 0.06 - (GAME_TIME - timeLeft) * 0.012);
    }

    const onDown = (e) => {
      if (over) return;
      const p = st.point(e);
      const h = holes.find((h) => h.up > 0.4 && h.state !== 'hit' && Math.abs(p.x - h.x) < h.r * 1.1 && p.y < h.y + h.r * 0.4 && p.y > h.y - h.r * 1.9);
      if (!h) { combo = 0; hud(); return; }
      if (h.kind === 'bomb') {
        score = Math.max(0, score - 30); combo = 0; api.sfx.crash(); api.haptic('heavy'); hitFlash = 0.3;
        fx.text(h.x, h.y - h.r * 1.5, '-30', '#ff4d6d');
      } else {
        combo++;
        const pts = (h.kind === 'gold' ? 30 : 10) * Math.min(combo, 5);
        score += pts; api.sfx[h.kind === 'gold' ? 'coin' : 'pop'](); api.haptic('medium');
        fx.text(h.x, h.y - h.r * 1.5, '+' + pts, h.kind === 'gold' ? '#ffd60a' : '#fff');
      }
      fx.burst(h.x, h.y - h.r * 0.6, h.kind === 'bomb' ? '#333' : '#ffd60a', 12);
      h.state = 'hit'; h.t = 0; hud();
    };
    st.canvas.addEventListener('pointerdown', onDown);

    function update(dt, t) {
      if (!over) {
        timeLeft -= dt;
        if (Math.ceil(timeLeft) !== Math.ceil(timeLeft + dt)) hud();
        if (timeLeft <= 0) {
          timeLeft = 0; over = true; api.sfx.win(); hud();
          api.gameOver({ score, coins: Math.floor(score / 25), title: 'Süre doldu! ⏰' });
        }
        spawnIn -= dt; if (spawnIn <= 0) spawn();
      }
      for (const h of holes) {
        h.t += dt;
        if (h.state === 'rising') { h.up = Math.min(1, h.up + dt * 7); if (h.up >= 1) { h.state = 'up'; h.t = 0; } }
        else if (h.state === 'up') { if (h.t > h.stay) { h.state = 'falling'; if (h.kind !== 'bomb') combo = 0; } }
        else if (h.state === 'falling' || h.state === 'hit') {
          if (h.state === 'hit' && h.t < 0.2) continue;
          h.up = Math.max(0, h.up - dt * 6); if (h.up <= 0) h.state = 'down';
        }
      }
      if (hitFlash > 0) hitFlash -= dt;
      fx.update(dt); draw(t);
    }

    function draw(t) {
      const c = st.ctx;
      c.fillStyle = '#90be6d'; c.fillRect(0, 0, st.W, st.H);
      c.fillStyle = '#7fb15b';
      for (let i = 0; i < 30; i++) c.fillRect((i * 83) % st.W, (i * 131) % st.H, 4, 10);
      for (const h of holes) {
        const r = h.r;
        c.fillStyle = '#3e2a14'; c.beginPath(); c.ellipse(h.x, h.y, r * 1.1, r * 0.4, 0, 0, 7); c.fill();
        // karakter (deliğin içinden çıkar)
        c.save();
        c.beginPath(); c.rect(h.x - r * 1.5, h.y - r * 3, r * 3, r * 3); c.clip();
        const yy = h.y + r * 1.3 - h.up * r * 1.9;
        if (h.up > 0) {
          if (h.kind === 'bomb') {
            c.fillStyle = '#2b2d42'; c.beginPath(); c.arc(h.x, yy, r * 0.75, 0, 7); c.fill();
            c.strokeStyle = '#bc6c25'; c.lineWidth = 4; c.beginPath(); c.moveTo(h.x + r * 0.3, yy - r * 0.6); c.quadraticCurveTo(h.x + r * 0.6, yy - r * 1.1, h.x + r * 0.3, yy - r * 1.2); c.stroke();
            c.fillStyle = `hsl(${30 + Math.sin(t * 30) * 20},100%,60%)`; c.beginPath(); c.arc(h.x + r * 0.3, yy - r * 1.2, 5, 0, 7); c.fill();
          } else {
            const body = h.kind === 'gold' ? '#ffc300' : '#8d5524';
            c.fillStyle = body; c.beginPath(); c.ellipse(h.x, yy + r * 0.3, r * 0.8, r * 1.1, 0, 0, 7); c.fill();
            c.fillStyle = h.kind === 'gold' ? '#ffe066' : '#c68642'; c.beginPath(); c.ellipse(h.x, yy + r * 0.45, r * 0.5, r * 0.6, 0, 0, 7); c.fill();
            const hit = h.state === 'hit';
            c.fillStyle = '#000';
            if (hit) { c.font = `900 ${r * 0.45}px system-ui`; c.textAlign = 'center'; c.fillText('× ×', h.x, yy - r * 0.1); }
            else { c.beginPath(); c.arc(h.x - r * 0.28, yy - r * 0.2, r * 0.1, 0, 7); c.arc(h.x + r * 0.28, yy - r * 0.2, r * 0.1, 0, 7); c.fill(); }
            c.fillStyle = '#ff8fab'; c.beginPath(); c.ellipse(h.x, yy + r * 0.05, r * 0.16, r * 0.11, 0, 0, 7); c.fill();
            c.fillStyle = '#fff'; c.fillRect(h.x - r * 0.12, yy + r * 0.15, r * 0.1, r * 0.15); c.fillRect(h.x + r * 0.02, yy + r * 0.15, r * 0.1, r * 0.15);
            if (h.kind === 'gold') { c.fillStyle = '#ff006e'; c.font = `900 ${r * 0.5}px system-ui`; c.textAlign = 'center'; c.fillText('♛', h.x, yy - r * 0.7); }
          }
        }
        c.restore();
        // ön toprak kenarı
        c.fillStyle = '#6b4423'; c.beginPath(); c.ellipse(h.x, h.y + r * 0.12, r * 1.15, r * 0.32, 0, 0, Math.PI); c.fill();
      }
      fx.draw(c);
      if (hitFlash > 0) { c.fillStyle = `rgba(255,0,0,${hitFlash})`; c.fillRect(0, 0, st.W, st.H); }
    }

    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
