// 🏒 Hava Hokeyi: bilgisayara karşı ya da aynı telefonda arkadaşınla (üst yarıya o dokunsun)
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

const GOALS_TO_WIN = 5;

export default {
  id: 'hockey', title: 'Hava Hokeyi', emoji: '🏒', color: '#00b4d8',
  desc: 'Bilgisayara ya da arkadaşına gol at! İlk 5 kazanır',
  winBased: true,
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let me, cpu, puck, sMe, sCpu, over, pause, L, twoP, touches = new Map(), flash = 0;
    const S = () => Math.min(st.W, st.H * 0.6) / 400;
    const goalW = () => st.W * 0.36;

    function start() {
      L = api.level; twoP = false;
      me = { x: st.W / 2, y: st.H - 80, r: 30 * S(), vx: 0, vy: 0, px: 0, py: 0 };
      cpu = { x: st.W / 2, y: 80, r: 30 * S(), vx: 0, vy: 0 };
      sMe = 0; sCpu = 0; over = false; resetPuck(1); hud();
    }
    function resetPuck(towards) {
      puck = { x: st.W / 2, y: st.H / 2 + towards * 40, vx: 0, vy: 0, r: 16 * S() };
      pause = 0.7;
    }
    function hud() { api.setHud({ score: `${sMe} - ${sCpu}`, scoreLabel: twoP ? 'Alt · Üst' : 'Sen · CPU', extra: twoP ? '👥 2 kişilik mod' : `İlk ${GOALS_TO_WIN} gol kazanır` }); }
    // Zorluk: bilgisayarın hızı, tepki süresi ve topu tahmin etme becerisi
    const cpuSpeed = () => (260 + L * 70) * S();
    const cpuSmart = () => Math.min(1, 0.2 + L * 0.12);

    function onPtr(e) {
      const p = st.point(e);
      touches.set(e.pointerId, p);
      // ekranın üst yarısındaki dokunuş → 2. oyuncu
      if (p.y < st.H / 2) { if (!twoP) { twoP = true; hud(); } cpu.tx = p.x; cpu.ty = p.y; }
      else { me.tx = p.x; me.ty = p.y; }
    }
    st.canvas.addEventListener('pointerdown', onPtr);
    st.canvas.addEventListener('pointermove', (e) => { if (e.buttons || e.pointerType === 'touch') onPtr(e); });
    const up = (e) => touches.delete(e.pointerId);
    window.addEventListener('pointerup', up);

    function movePaddle(p, tx, ty, minY, maxY, dt, maxSp = Infinity) {
      if (tx === undefined) return;
      tx = Math.max(p.r, Math.min(st.W - p.r, tx)); ty = Math.max(minY + p.r, Math.min(maxY - p.r, ty));
      let dx = tx - p.x, dy = ty - p.y; const d = Math.hypot(dx, dy), step = maxSp * dt;
      if (d > step) { dx *= step / d; dy *= step / d; }
      p.vx = dx / Math.max(dt, 0.001); p.vy = dy / Math.max(dt, 0.001);
      p.x += dx; p.y += dy;
    }
    function collide(p) {
      const dx = puck.x - p.x, dy = puck.y - p.y, d = Math.hypot(dx, dy), min = puck.r + p.r;
      if (d < min && d > 0) {
        const nx = dx / d, ny = dy / d;
        puck.x = p.x + nx * min; puck.y = p.y + ny * min;
        const rel = (puck.vx - p.vx) * nx + (puck.vy - p.vy) * ny;
        if (rel < 0) { puck.vx -= 1.9 * rel * nx; puck.vy -= 1.9 * rel * ny; }
        const sp = Math.hypot(puck.vx, puck.vy), max = (1300 + L * 60) * S();
        if (sp > max) { puck.vx *= max / sp; puck.vy *= max / sp; }
        api.sfx.bounce(); api.haptic('light');
      }
    }
    function update(dt) {
      if (!over) {
        movePaddle(me, me.tx, me.ty, st.H / 2, st.H, dt);
        if (twoP) movePaddle(cpu, cpu.tx, cpu.ty, 0, st.H / 2, dt);
        else {
          // yapay zekâ: topu tahmin edip araya girer, top kendi yarısındaysa vurur
          let tx = st.W / 2, ty = 70 * S();
          const coming = puck.vy < 0;
          if (puck.y < st.H / 2 || coming) {
            const lead = cpuSmart() * 0.25;
            tx = puck.x + puck.vx * lead; ty = puck.y < st.H / 2 ? puck.y - puck.r * 1.5 : Math.min(st.H * 0.3, puck.y);
            if (puck.y < cpu.y) { ty = 50 * S(); tx = puck.x + (puck.x < st.W / 2 ? 30 : -30); }
          }
          movePaddle(cpu, tx, ty, 0, st.H / 2, dt, cpuSpeed());
        }
        if (pause > 0) pause -= dt;
        else {
          puck.x += puck.vx * dt; puck.y += puck.vy * dt;
          puck.vx *= Math.pow(0.6, dt); puck.vy *= Math.pow(0.6, dt);
          if (puck.x < puck.r) { puck.x = puck.r; puck.vx = Math.abs(puck.vx); api.sfx.click(); }
          if (puck.x > st.W - puck.r) { puck.x = st.W - puck.r; puck.vx = -Math.abs(puck.vx); api.sfx.click(); }
          const inGoal = Math.abs(puck.x - st.W / 2) < goalW() / 2;
          if (puck.y < puck.r && !inGoal) { puck.y = puck.r; puck.vy = Math.abs(puck.vy); api.sfx.click(); }
          if (puck.y > st.H - puck.r && !inGoal) { puck.y = st.H - puck.r; puck.vy = -Math.abs(puck.vy); api.sfx.click(); }
          if (puck.y < -puck.r) goal(true);
          else if (puck.y > st.H + puck.r) goal(false);
          collide(me); collide(cpu);
        }
      }
      if (flash > 0) flash -= dt;
      fx.update(dt); draw();
    }
    function goal(mine) {
      mine ? sMe++ : sCpu++; flash = 0.4;
      fx.burst(st.W / 2, mine ? 10 : st.H - 10, mine ? '#2dc653' : '#ff4d6d', 30, 260);
      api.sfx[mine ? 'coin' : 'wrong'](); api.haptic('heavy'); hud();
      if (sMe >= GOALS_TO_WIN || sCpu >= GOALS_TO_WIN) {
        over = true; const won = sMe > sCpu;
        won ? api.sfx.win() : api.sfx.lose();
        // 2 kişilik oyunda seviye atlanmaz
        setTimeout(() => api.gameOver({
          score: twoP ? 0 : sMe * 60 + (won ? 200 + L * 30 : 0), coins: twoP ? 2 : won ? 8 + L * 2 : sMe,
          win: won && !twoP, title: twoP ? (won ? 'Alttaki oyuncu kazandı! 🏆' : 'Üstteki oyuncu kazandı! 🏆') : won ? 'Maçı kazandın! 🏒' : 'Bilgisayar kazandı 🤖',
        }), 700);
      } else resetPuck(mine ? -1 : 1);
    }
    function paddle(c, p, col) {
      c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.arc(p.x + 3, p.y + 5, p.r, 0, 7); c.fill();
      c.fillStyle = col; c.beginPath(); c.arc(p.x, p.y, p.r, 0, 7); c.fill();
      c.fillStyle = 'rgba(255,255,255,.35)'; c.beginPath(); c.arc(p.x, p.y, p.r * 0.62, 0, 7); c.fill();
      c.fillStyle = col; c.beginPath(); c.arc(p.x, p.y, p.r * 0.4, 0, 7); c.fill();
    }
    function draw() {
      const c = st.ctx;
      c.fillStyle = '#e0fbfc'; c.fillRect(0, 0, st.W, st.H);
      c.strokeStyle = '#90e0ef'; c.lineWidth = 4;
      c.beginPath(); c.moveTo(0, st.H / 2); c.lineTo(st.W, st.H / 2); c.stroke();
      c.beginPath(); c.arc(st.W / 2, st.H / 2, 60 * S(), 0, 7); c.stroke();
      c.beginPath(); c.arc(st.W / 2, 0, goalW() * 0.7, 0, Math.PI); c.stroke();
      c.beginPath(); c.arc(st.W / 2, st.H, goalW() * 0.7, Math.PI, 0); c.stroke();
      c.fillStyle = '#023e8a'; roundRect(c, st.W / 2 - goalW() / 2, -6, goalW(), 12, 6); c.fill(); roundRect(c, st.W / 2 - goalW() / 2, st.H - 6, goalW(), 12, 6); c.fill();
      c.fillStyle = 'rgba(2,62,138,.12)'; c.font = `900 ${90 * S()}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(sCpu, st.W / 2, st.H * 0.27); c.fillText(sMe, st.W / 2, st.H * 0.73); c.textBaseline = 'alphabetic';
      paddle(c, cpu, twoP ? '#3a86ff' : '#ef233c'); paddle(c, me, '#2dc653');
      c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.arc(puck.x + 2, puck.y + 4, puck.r, 0, 7); c.fill();
      c.fillStyle = '#212529'; c.beginPath(); c.arc(puck.x, puck.y, puck.r, 0, 7); c.fill();
      c.fillStyle = '#495057'; c.beginPath(); c.arc(puck.x, puck.y, puck.r * 0.6, 0, 7); c.fill();
      if (!twoP && sMe + sCpu === 0) { c.fillStyle = 'rgba(2,62,138,.55)'; c.font = '700 13px system-ui'; c.textAlign = 'center'; c.fillText('Arkadaşınla oynamak için o ekranın üst yarısına dokunsun', st.W / 2, st.H / 2 - 12); }
      if (flash > 0) { c.fillStyle = `rgba(255,214,10,${flash})`; c.fillRect(0, 0, st.W, st.H); }
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); window.removeEventListener('pointerup', up); } };
  },
};
