// 🎲 Kızma Birader: 2–4 kişi aynı telefonda, ya da tek başına 3 bilgisayara karşı
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

// 15x15 tahta üzerinde 52 karelik dış yol (kırmızının başlangıcından saat yönünde)
const PATH = [];
(() => {
  const seg = (pts) => pts.forEach((p) => PATH.push(p));
  seg([[1, 6], [2, 6], [3, 6], [4, 6], [5, 6]]);
  seg([[6, 5], [6, 4], [6, 3], [6, 2], [6, 1], [6, 0]]);
  seg([[7, 0], [8, 0]]);
  seg([[8, 1], [8, 2], [8, 3], [8, 4], [8, 5]]);
  seg([[9, 6], [10, 6], [11, 6], [12, 6], [13, 6], [14, 6]]);
  seg([[14, 7], [14, 8]]);
  seg([[13, 8], [12, 8], [11, 8], [10, 8], [9, 8]]);
  seg([[8, 9], [8, 10], [8, 11], [8, 12], [8, 13], [8, 14]]);
  seg([[7, 14], [6, 14]]);
  seg([[6, 13], [6, 12], [6, 11], [6, 10], [6, 9]]);
  seg([[5, 8], [4, 8], [3, 8], [2, 8], [1, 8], [0, 8]]);
  seg([[0, 7], [0, 6]]);
})();
const COLORS = [
  { name: 'Kırmızı', c: '#ef233c', light: '#ffb3c1', start: 0, home: [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7]], base: [1, 1] },
  { name: 'Yeşil', c: '#2dc653', light: '#b7efc5', start: 13, home: [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5]], base: [10, 1] },
  { name: 'Sarı', c: '#ffc300', light: '#fff1b3', start: 26, home: [[13, 7], [12, 7], [11, 7], [10, 7], [9, 7]], base: [10, 10] },
  { name: 'Mavi', c: '#3a86ff', light: '#c1d9ff', start: 39, home: [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9]], base: [1, 10] },
];
const SAFE = new Set([0, 8, 13, 21, 26, 34, 39, 47]);
const FINISH = 56; // 0..50 dış yol, 51..55 ev yolu, 56 bitti

export default {
  id: 'ludo', title: 'Kızma Birader', emoji: '🎲', color: '#ef233c',
  desc: 'Zarı at, taşlarını eve götür, rakibi kızdır!',
  winBased: true, players: { min: 2, max: 4 },
  online: { min: 2, max: 4 },
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let players, turn, dice, rolled, rolling, rollT, sixes, movable, over, L, anim, msg;

    // online: sırası gelen oyuncu zarı kendi telefonunda atar ve sonucu gönderir; diğerleri aynı zarı oynatır
    const ON = api.mp?.online, inbox = [];
    let forcedDice = 0;
    ON?.on((m) => inbox.push(m));
    const myTurn = () => !ON || turn === ON.me;
    function setup() {
      inbox.length = 0; forcedDice = 0;
      L = api.level;
      const n = api.mp ? api.mp.n : 4;
      // 2 kişide karşılıklı renkler
      const colorIdx = n === 2 ? [0, 2] : n === 3 ? [0, 1, 2] : [0, 1, 2, 3];
      players = colorIdx.map((ci, k) => ({
        ci, name: api.mp ? api.mp.names[k] : k === 0 ? 'Sen' : `Bilgisayar ${k}`,
        cpu: !api.mp && k > 0, tokens: [-1, -1, -1, -1], done: false,
      }));
      turn = 0; dice = 1; rolled = false; rolling = false; sixes = 0; movable = []; over = false; anim = null; msg = '';
      hud();
      maybeCpu();
    }
    const P = () => players[turn];
    const absOf = (pl, rp) => (rp >= 0 && rp <= 50 ? (COLORS[pl.ci].start + rp) % 52 : -1);
    function cellOf(pl, rp, k) {
      const C = COLORS[pl.ci];
      if (rp < 0) { const [bx, by] = C.base; return [bx + (k % 2) * 2 + 1, by + Math.floor(k / 2) * 2 + 1]; }
      if (rp <= 50) return PATH[absOf(pl, rp)];
      if (rp < FINISH) return C.home[rp - 51];
      return [7, 7];
    }
    function hud() {
      const p = P();
      api.setHud({ score: players.map((q) => q.tokens.filter((t) => t === FINISH).length).join(' · '), scoreLabel: 'Evde', extra: msg || (ON ? (myTurn() ? `Senin sıran (${COLORS[p.ci].name}) ${rolled ? '· Taş seç' : '· Zarı at'}` : `${p.name} oynuyor…`) : `Sıra: ${p.name} (${COLORS[p.ci].name}) ${rolled ? '· Taş seç' : p.cpu ? '· düşünüyor…' : '· Zarı at'}`) });
    }
    function legalMoves(pl, d) {
      const res = [];
      pl.tokens.forEach((rp, k) => {
        if (rp === FINISH) return;
        if (rp < 0) { if (d === 6) res.push(k); return; }
        if (rp + d <= FINISH) res.push(k);
      });
      return res;
    }
    function roll(forced = 0) {
      if (rolled || rolling || over || anim) return;
      forcedDice = forced;
      rolling = true; rollT = 0.6; api.sfx.click(); msg = '';
    }
    function afterRoll() {
      rolling = false; rolled = true;
      if (ON && myTurn()) ON.send({ roll: dice });
      if (dice === 6) sixes++; else sixes = 0;
      if (sixes === 3) { msg = 'Üç kez 6! Sıra geçti'; api.sfx.wrong(); sixes = 0; return endTurn(false); }
      movable = legalMoves(P(), dice);
      if (!movable.length) { msg = 'Oynayacak taş yok'; hud(); setTimeout(() => endTurn(false), 700); return; }
      hud();
      if (!myTurn()) return; // rakibin taş seçimini bekle
      if (P().cpu) setTimeout(() => moveToken(cpuPick()), 450);
      else if (movable.length === 1 || new Set(movable.map((k) => P().tokens[k])).size === 1) setTimeout(() => moveToken(movable[0]), 250);
    }
    function cpuPick() {
      const pl = P();
      // Zorluk: seviye düşükken rastgele, yüksekken akıllı seçim
      if (Math.random() > Math.min(0.95, 0.35 + L * 0.12)) return movable[(Math.random() * movable.length) | 0];
      let best = movable[0], bestS = -Infinity;
      for (const k of movable) {
        const rp = pl.tokens[k], np = rp < 0 ? 0 : rp + dice, ab = absOf(pl, np);
        let s = np;
        if (rp < 0) s += 40;
        if (np === FINISH) s += 60;
        if (np > 50) s += 25;
        if (ab >= 0 && SAFE.has(ab)) s += 15;
        if (ab >= 0 && !SAFE.has(ab)) players.forEach((q) => { if (q !== pl) q.tokens.forEach((t) => { if (absOf(q, t) === ab) s += 80; }); });
        // tehlike: arkasında 1–6 kare yakında rakip var mı
        if (ab >= 0 && !SAFE.has(ab)) players.forEach((q) => { if (q !== pl) q.tokens.forEach((t) => { const qa = absOf(q, t); if (qa >= 0) { const d = (ab - qa + 52) % 52; if (d > 0 && d <= 6) s -= 30; } }); });
        if (s > bestS) { bestS = s; best = k; }
      }
      return best;
    }
    function moveToken(k, remote = false) {
      if (!rolled || !movable.includes(k) || anim) return;
      if (ON && !remote) ON.send({ tok: k });
      const pl = P(), from = pl.tokens[k];
      const to = from < 0 ? 0 : from + dice;
      // adım adım animasyon
      const steps = [];
      if (from < 0) steps.push(0); else for (let r = from + 1; r <= to; r++) steps.push(r);
      anim = { pl, k, steps, i: 0, t: 0 };
      movable = []; rolled = false;
    }
    function land(pl, k) {
      const rp = pl.tokens[k], ab = absOf(pl, rp);
      let extra = dice === 6, captured = false;
      if (ab >= 0 && !SAFE.has(ab)) {
        players.forEach((q) => { if (q === pl) return; q.tokens.forEach((t, j) => { if (absOf(q, t) === ab) { q.tokens[j] = -1; captured = true; } }); });
      }
      const [cx, cy] = cellOf(pl, rp, k), g = geo();
      if (captured) { extra = true; api.sfx.crash(); api.haptic('heavy'); fx.burst(g.ox + (cx + 0.5) * g.cs, g.oy + (cy + 0.5) * g.cs, '#fff', 20, 200); msg = `${pl.name} rakibi kızdırdı! 😈`; }
      if (rp === FINISH) { extra = true; api.sfx.coin(); fx.burst(g.ox + 7.5 * g.cs, g.oy + 7.5 * g.cs, COLORS[pl.ci].c, 20, 200); }
      if (pl.tokens.every((t) => t === FINISH)) return finish(pl);
      endTurn(extra);
    }
    function endTurn(extra) {
      if (!extra) { turn = (turn + 1) % players.length; sixes = 0; }
      rolled = false; movable = []; hud(); maybeCpu();
    }
    function maybeCpu() { if (!over && P().cpu) setTimeout(roll, 600); }
    function finish(pl) {
      over = true; api.sfx.win(); hud();
      const idx = players.indexOf(pl);
      for (let i = 0; i < 5; i++) fx.burst(st.W / 2, st.H / 2, COLORS[pl.ci].c, 20, 260);
      if (api.mp) setTimeout(() => api.gameOver({ winner: idx }), 1200);
      else {
        const mine = players[0].tokens.filter((t) => t === FINISH).length;
        setTimeout(() => api.gameOver({ score: idx === 0 ? 400 + L * 50 : mine * 60, coins: idx === 0 ? 12 + L * 2 : mine, win: idx === 0, title: idx === 0 ? 'Kazandın! 🎲' : `${pl.name} kazandı` }), 1200);
      }
    }
    function geo() { const s = Math.min(st.W - 12, st.H - 130); const cs = s / 15; return { cs, ox: (st.W - s) / 2, oy: 8 }; }
    function tokenPos(pl, k) {
      const g = geo(), rp = pl.tokens[k];
      let [cx, cy] = cellOf(pl, rp, k);
      // aynı karedeki taşları hafifçe kaydır
      let off = 0;
      if (rp >= 0) players.forEach((q) => q.tokens.forEach((t, j) => { if ((q !== pl || j < k) && t >= 0) { const [ax, ay] = cellOf(q, t, j); if (ax === cx && ay === cy) off++; } }));
      return { x: g.ox + (cx + 0.5) * g.cs + off * g.cs * 0.18, y: g.oy + (cy + 0.5) * g.cs - off * g.cs * 0.12 };
    }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (over || P().cpu || anim || !myTurn()) return;
      const p = st.point(e), g = geo();
      const diceBox = { x: st.W / 2 - 40, y: g.oy + g.cs * 15 + 18, s: 80 };
      if (p.x > diceBox.x && p.x < diceBox.x + diceBox.s && p.y > diceBox.y && p.y < diceBox.y + diceBox.s) return roll();
      if (!rolled) { roll(); return; } // zar atılmadıysa ekranın herhangi bir yerine dokunmak zar atar
      let pick = -1, bd = g.cs * 0.9;
      movable.forEach((k) => { const q = tokenPos(P(), k), d = Math.hypot(q.x - p.x, q.y - p.y); if (d < bd) { bd = d; pick = k; } });
      if (pick >= 0) moveToken(pick);
    });
    function update(dt, t) {
      if (ON && inbox.length && !rolling && !anim && !over) {
        const mv = inbox[0];
        if (mv.roll && !rolled) { inbox.shift(); roll(mv.roll); }
        else if (mv.tok !== undefined && rolled) { inbox.shift(); moveToken(mv.tok, true); }
      }
      if (rolling) { rollT -= dt; dice = 1 + ((Math.random() * 6) | 0); if (rollT <= 0) { dice = forcedDice || 1 + ((Math.random() * 6) | 0); afterRoll(); } }
      if (anim) {
        anim.t += dt;
        if (anim.t > 0.12) {
          anim.t = 0; anim.pl.tokens[anim.k] = anim.steps[anim.i]; anim.i++; api.sfx.tap();
          if (anim.i >= anim.steps.length) { const a = anim; anim = null; land(a.pl, a.k); }
        }
      }
      fx.update(dt); draw(t);
    }
    function draw(t) {
      const c = st.ctx, g = geo(), cs = g.cs;
      c.fillStyle = '#f1faee'; c.fillRect(0, 0, st.W, st.H);
      const cell = (x, y, col, stroke = true) => { c.fillStyle = col; c.fillRect(g.ox + x * cs, g.oy + y * cs, cs, cs); if (stroke) { c.strokeStyle = '#ccc'; c.lineWidth = 1; c.strokeRect(g.ox + x * cs, g.oy + y * cs, cs, cs); } };
      // dış yol
      PATH.forEach(([x, y], i) => cell(x, y, '#fff'));
      COLORS.forEach((C, ci) => {
        // ev bölgesi
        const [bx, by] = C.base;
        c.fillStyle = C.c; roundRect(c, g.ox + (bx - 1) * cs, g.oy + (by - 1) * cs, cs * 6, cs * 6, cs * 0.4); c.fill();
        c.fillStyle = '#fff'; roundRect(c, g.ox + bx * cs - cs * 0.1, g.oy + by * cs - cs * 0.1, cs * 4.2, cs * 4.2, cs * 0.5); c.fill();
        for (let k = 0; k < 4; k++) { c.fillStyle = C.light; c.beginPath(); c.arc(g.ox + (bx + (k % 2) * 2 + 1.5) * cs, g.oy + (by + Math.floor(k / 2) * 2 + 1.5) * cs, cs * 0.6, 0, 7); c.fill(); }
        C.home.forEach(([x, y]) => cell(x, y, C.c));
        const [sx, sy] = PATH[C.start]; cell(sx, sy, C.light);
      });
      // güvenli yıldız kareleri
      [8, 21, 34, 47].forEach((i) => { const [x, y] = PATH[i]; c.fillStyle = '#adb5bd'; c.font = `${cs * 0.6}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('★', g.ox + (x + 0.5) * cs, g.oy + (y + 0.55) * cs); });
      // orta (bitiş) üçgenleri
      const mx = g.ox + 7.5 * cs, my = g.oy + 7.5 * cs, h = 1.5 * cs;
      [[0, [-h, -h], [-h, h]], [1, [-h, -h], [h, -h]], [2, [h, -h], [h, h]], [3, [-h, h], [h, h]]].forEach(([ci, a, b]) => { c.fillStyle = COLORS[ci].c; c.beginPath(); c.moveTo(mx, my); c.lineTo(mx + a[0], my + a[1]); c.lineTo(mx + b[0], my + b[1]); c.fill(); });
      // taşlar
      players.forEach((pl) => pl.tokens.forEach((rp, k) => {
        const q = tokenPos(pl, k), C = COLORS[pl.ci], canMove = pl === P() && movable.includes(k) && !pl.cpu;
        const r = cs * 0.36 * (canMove ? 1 + Math.sin(t * 8) * 0.12 : 1);
        c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.arc(q.x + 2, q.y + 3, r, 0, 7); c.fill();
        c.fillStyle = C.c; c.beginPath(); c.arc(q.x, q.y, r, 0, 7); c.fill();
        c.strokeStyle = '#fff'; c.lineWidth = Math.max(2, cs * 0.08); c.stroke();
        c.fillStyle = 'rgba(255,255,255,.5)'; c.beginPath(); c.arc(q.x - r * 0.3, q.y - r * 0.3, r * 0.3, 0, 7); c.fill();
        if (canMove) { c.strokeStyle = '#111'; c.lineWidth = 2; c.beginPath(); c.arc(q.x, q.y, r + 4, 0, 7); c.stroke(); }
      }));
      // zar ve sıra göstergesi
      const p = P(), C = COLORS[p.ci], dy = g.oy + cs * 15 + 18, dx = st.W / 2 - 40;
      c.fillStyle = C.c; roundRect(c, 12, dy, st.W - 24, 80, 18); c.globalAlpha = 0.18; c.fill(); c.globalAlpha = 1;
      c.save(); c.translate(dx + 40, dy + 40); if (rolling) c.rotate(Math.sin(t * 40) * 0.3);
      c.fillStyle = '#fff'; roundRect(c, -34, -34, 68, 68, 14); c.fill(); c.strokeStyle = C.c; c.lineWidth = 4; c.stroke();
      const pip = (x, y) => { c.fillStyle = '#222'; c.beginPath(); c.arc(x * 18, y * 18, 6, 0, 7); c.fill(); };
      ({ 1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]], 5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]] })[dice].forEach(([x, y]) => pip(x, y));
      c.restore();
      c.fillStyle = '#222'; c.font = '800 14px system-ui'; c.textAlign = 'left'; c.textBaseline = 'middle';
      c.fillText(p.name, 24, dy + 28); c.font = '600 12px system-ui'; c.fillStyle = '#555';
      c.fillText(rolled ? 'Parlayan taşa dokun' : p.cpu ? 'Bilgisayar oynuyor' : 'Zara dokun', 24, dy + 50);
      c.textBaseline = 'alphabetic';
      fx.draw(c);
    }
    setup();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { setup(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
