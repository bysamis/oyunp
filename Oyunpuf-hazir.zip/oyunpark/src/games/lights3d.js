// 💡 Işıkları Söndür 3D: lambaya bas, kendisi ve komşuları yanar/söner; hepsini söndür
import { create3D, mat, THREE } from '../core/three-stage.js';
import { boardKit, roundedBox } from '../core/board3d.js';

export default {
  id: 'lights', title: 'Işıkları Söndür 3D', emoji: '💡', color: '#ffb703',
  desc: 'Tüm ışıkları söndür, az hamleyle!',
  winBased: true,
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0x14213d });
    const { scene, hemi, sun } = S;
    hemi.intensity = 0.5; sun.intensity = 0.9;
    const floor = new THREE.Mesh(new THREE.BoxGeometry(30, 0.4, 30), mat(0x1b263b)); floor.position.y = -0.6; floor.receiveShadow = true; scene.add(floor);
    const grid3 = new THREE.Group(); scene.add(grid3);
    let K = null, panel = null;
    const offMat = mat(0x415a77, { roughness: 0.4 });
    let n, grid, glow, moves, limit, over, L, scramble, lamps = [];
    function build() {
      grid3.clear(); lamps = [];
      K = boardKit(S, n, n, { tilt: 0.35, height: 0.6 });
      panel = new THREE.Mesh(roundedBox(n + 0.5, 0.3, n + 0.5, 0.25), mat(0x0d1b2a)); panel.position.y = -0.4; panel.receiveShadow = true; grid3.add(panel);
      for (let i = 0; i < n * n; i++) {
        const g = new THREE.Group(); g.position.copy(K.pos(i % n, (i / n) | 0, 0));
        const base = new THREE.Mesh(roundedBox(0.86, 0.25, 0.86, 0.15), mat(0x778da9)); base.position.y = -0.2; base.castShadow = true; base.receiveShadow = true; g.add(base);
        const bulb = new THREE.Mesh(roundedBox(0.7, 0.2, 0.7, 0.18), mat(0xffd60a, { emissive: 0xffb703, emissiveIntensity: 1 })); bulb.position.y = 0.02; g.add(bulb);
        const halo = new THREE.Mesh(new THREE.CircleGeometry(0.62, 24), new THREE.MeshBasicMaterial({ color: 0xffd60a, transparent: true, opacity: 0.25, depthWrite: false })); halo.rotation.x = -Math.PI / 2; halo.position.y = 0.25; g.add(halo);
        grid3.add(g); lamps.push({ g, bulb, halo, onMat: bulb.material });
      }
    }
    function toggle(r, c) {
      [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]].forEach(([dr, dc]) => {
        const rr = r + dr, cc = c + dc;
        if (rr >= 0 && rr < n && cc >= 0 && cc < n) { grid[rr * n + cc] ^= 1; glow[rr * n + cc] = 1; }
      });
    }
    function start() {
      L = api.level;
      n = Math.min(7, 3 + Math.floor((L + 1) / 2));
      scramble = Math.min(n * n, 3 + L * 2);
      grid = Array(n * n).fill(0); glow = Array(n * n).fill(0);
      const picks = new Set();
      while (picks.size < scramble) picks.add((Math.random() * n * n) | 0);
      picks.forEach((i) => toggle((i / n) | 0, i % n));
      glow.fill(0);
      if (grid.every((v) => !v)) return start();
      limit = scramble + Math.max(2, 12 - L);
      moves = 0; over = false; build(); hud();
    }
    function hud() { api.setHud({ score: limit - moves, scoreLabel: 'Kalan hamle', extra: `${n}×${n} · Yanan: ${grid.filter(Boolean).length}` }); }
    S.el.addEventListener('pointerdown', (e) => {
      if (over || !K) return;
      const cell = K.cellAt(e, 0); if (!cell) return;
      toggle(cell.r, cell.c); moves++; api.sfx.click(); api.haptic('light'); hud();
      lamps[cell.r * n + cell.c].g.position.y = -0.12;
      if (grid.every((v) => !v)) {
        over = true; api.sfx.win();
        for (let i = 0; i < 5; i++) S.burst(new THREE.Vector3((Math.random() - 0.5) * n, 0.5, (Math.random() - 0.5) * n), 0xffd60a, 16, 5);
        const score = Math.max(50, (limit - moves) * 40 + n * 60);
        setTimeout(() => api.gameOver({ score, coins: 10 + n * 4, win: true, title: 'Karanlık oldu! 🌙' }), 800);
      } else if (moves >= limit) {
        over = true; api.sfx.lose();
        setTimeout(() => api.gameOver({ score: Math.max(0, (n * n - grid.filter(Boolean).length) * 5), coins: 3, title: 'Hamleler bitti! 💡' }), 500);
      }
    });
    const lp = S.loop((dt, t) => {
      for (let i = 0; i < lamps.length; i++) {
        glow[i] = Math.max(0, glow[i] - dt * 4);
        const lm = lamps[i], on = grid[i];
        lm.bulb.material = on ? lm.onMat : offMat;
        lm.onMat.emissiveIntensity = 0.8 + Math.sin(t * 3 + i) * 0.15;
        lm.halo.visible = !!on; lm.halo.material.opacity = 0.2 + glow[i] * 0.4;
        lm.g.position.y += (0 - lm.g.position.y) * Math.min(1, dt * 12);
        const s = 1 + glow[i] * 0.12; lm.bulb.scale.set(s, 1, s);
      }
      S.updateParts(dt, -0.4);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { S.destroy(); } };
  },
};
