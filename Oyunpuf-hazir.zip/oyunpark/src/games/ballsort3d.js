// 🧪 Top Sırala 3D: cam tüplerdeki topları renklerine göre sırala
import { create3D, mat, THREE } from '../core/three-stage.js';
import { expert, expertSteps } from '../core/expert.js';
import { roundedBox } from '../core/board3d.js';

const COLORS = ['#ff4d6d', '#3a86ff', '#2dc653', '#ffd60a', '#9d4edd', '#ff9f1c', '#06d6a0', '#ff70a6', '#8d5524', '#adb5bd', '#1d3557', '#e9ff70'];
const BR = 0.32, TR = 0.4; // top ve tüp yarıçapı

export default {
  id: 'ballsort', title: 'Top Sırala 3D', emoji: '🧪', color: '#06d6a0',
  desc: 'Her tüpte tek renk kalsın!',
  expertFrom: 12,
  winBased: true,
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0x14213d });
    const { scene, camera, sun } = S;
    sun.position.set(-4, 12, 10);
    const room = new THREE.Mesh(new THREE.PlaneGeometry(60, 40), mat(0x1d3557)); room.position.z = -3; scene.add(room);
    const world = new THREE.Group(); scene.add(world);
    const ballMats = COLORS.map((c) => mat(new THREE.Color(c), { roughness: 0.2, metalness: 0.1 }));
    const ballGeo = new THREE.SphereGeometry(BR, 22, 16);
    const glassMat = new THREE.MeshPhysicalMaterial({ color: 0xffffff, transparent: true, opacity: 0.22, roughness: 0.05, metalness: 0, side: THREE.DoubleSide, depthWrite: false });
    const undoBtn = document.createElement('button');
    undoBtn.style.cssText = 'position:absolute;right:10px;top:10px;z-index:5;border:0;border-radius:18px;padding:8px 14px;font:800 14px system-ui;color:#3a2400;background:#ffd60a;box-shadow:0 3px 0 rgba(0,0,0,.25)';
    host.appendChild(undoBtn);
    undoBtn.addEventListener('pointerdown', (e) => { e.stopPropagation(); doUndo(); });
    let tubes, cap, nColors, sel, moves, undo, undoLeft, over, time, L, lift, layout = [], tubeMeshes = [], balls = [];
    function start() {
      L = api.level;
      nColors = Math.min(12, 3 + L);                 // 4, 5, 6 … 12 renk
      cap = L >= 12 ? 6 : L >= 7 ? 5 : 4;            // 7. seviyede daha derin tüpler, uzman modunda (12+) en derin
      const empty = 2;
      // çözülmüş halden geriye doğru geçerli hamlelerle karıştır → her zaman çözülebilir
      tubes = Array.from({ length: nColors }, (_, i) => Array(cap).fill(i));
      for (let i = 0; i < empty; i++) tubes.push([]);
      let steps = 0, tries = 0;
      const target = 120 + nColors * 40;
      while (steps < target && tries < target * 20) {
        tries++;
        const b = (Math.random() * tubes.length) | 0, a = (Math.random() * tubes.length) | 0;
        if (a === b || !tubes[b].length || tubes[a].length >= cap) continue;
        const ball = tubes[b][tubes[b].length - 1];
        const below = tubes[b][tubes[b].length - 2];
        if (below !== undefined && below !== ball) continue; // ileri yönde geçerli olmalı
        tubes[a].push(tubes[b].pop()); steps++;
      }
      if (solved()) return start();
      sel = -1; moves = 0; undo = []; undoLeft = Math.max(0, 5 - L); over = false; time = 0; lift = 0;
      build(); hud();
    }
    function hud() { api.setHud({ score: moves, scoreLabel: 'Hamle', extra: `${nColors} renk · ⏱ ${Math.floor(time)} sn` }); undoBtn.textContent = `↶ Geri al (${undoLeft})`; undoBtn.style.opacity = undoLeft && undo.length ? 1 : 0.45; }
    const solved = () => tubes.every((t) => t.length === 0 || (t.length === cap && t.every((b) => b === t[0])));
    function build() {
      world.clear(); tubeMeshes = []; balls = [];
      const n = tubes.length, a = S.w / S.h;
      const perRow = n > (a > 1 ? 10 : 7) ? Math.ceil(n / 2) : n, rows = Math.ceil(n / perRow);
      const th = cap * BR * 2 + 0.5, gx = 1.15, gy = th + 1.6;
      layout = [];
      for (let i = 0; i < n; i++) {
        const row = (i / perRow) | 0, inRow = Math.min(perRow, n - row * perRow), col = i % perRow;
        layout.push(new THREE.Vector3((col - (inRow - 1) / 2) * gx, (rows - 1 - row) * gy, 0));
      }
      for (let r = 0; r < rows; r++) { const shelf = new THREE.Mesh(roundedBox(perRow * gx + 0.6, 0.2, 1.4, 0.08), mat(0x8d5524)); shelf.position.set(0, (rows - 1 - r) * gy - 0.2, 0); shelf.receiveShadow = true; shelf.castShadow = true; world.add(shelf); }
      layout.forEach((p) => {
        const g = new THREE.Group(); g.position.copy(p);
        const glass = new THREE.Mesh(new THREE.CylinderGeometry(TR, TR, th, 24, 1, true), glassMat); glass.position.y = th / 2; g.add(glass);
        const bottom = new THREE.Mesh(new THREE.SphereGeometry(TR, 20, 10, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), glassMat); bottom.position.y = 0.05; g.add(bottom);
        const rim = new THREE.Mesh(new THREE.TorusGeometry(TR, 0.04, 8, 24), mat(0xffffff, { roughness: 0.2 })); rim.rotation.x = Math.PI / 2; rim.position.y = th; g.add(rim);
        const hit = new THREE.Mesh(new THREE.CylinderGeometry(TR + 0.15, TR + 0.15, th + 1.2, 8), new THREE.MeshBasicMaterial({ visible: false })); hit.position.y = th / 2 + 0.3; g.add(hit);
        world.add(g); tubeMeshes.push(g);
      });
      // kamera: hepsi sığsın
      const w = perRow * gx + 0.8, h = rows * gy + 1.2, vfov = (camera.fov * Math.PI) / 180;
      const d = Math.max((h / 2) / Math.tan(vfov / 2), (w / 2) / (Math.tan(vfov / 2) * a)) * 1.08;
      const cy = ((rows - 1) * gy + th) / 2 + 0.3;
      camera.position.set(0, cy + d * 0.25, d); camera.lookAt(0, cy - 0.2, 0);
      syncBalls(true);
    }
    // topları tüp içeriğine göre yerleştir (yumuşak geçişle)
    function syncBalls(snap) {
      const need = tubes.reduce((s, t) => s + t.length, 0);
      while (balls.length < need) { const m = new THREE.Mesh(ballGeo, ballMats[0]); m.castShadow = true; world.add(m); balls.push(m); }
      while (balls.length > need) world.remove(balls.pop());
      let k = 0;
      tubes.forEach((t, i) => t.forEach((b, j) => {
        const m = balls[k++]; m.material = ballMats[b];
        const top = j === t.length - 1 && sel === i;
        const th = cap * BR * 2 + 0.5;
        const target = layout[i].clone().add(new THREE.Vector3(0, top ? th + 0.55 : BR + 0.08 + j * BR * 2, 0));
        m.userData.target = target; if (snap || !m.userData.init) { m.position.copy(target); m.userData.init = true; }
      }));
    }
    S.onResize(() => { if (tubes) build(); });
    function canPour(a, b) {
      const A = tubes[a], B = tubes[b];
      if (!A.length || B.length >= cap) return false;
      return !B.length || B[B.length - 1] === A[A.length - 1];
    }
    S.el.addEventListener('pointerdown', (e) => {
      if (over) return;
      const hit = S.pick(e, tubeMeshes);
      const i = hit ? tubeMeshes.findIndex((g) => g === hit.object.parent) : -1;
      if (i < 0) { sel = -1; syncBalls(); return; }
      if (sel < 0) { if (tubes[i].length) { sel = i; lift = 0; api.sfx.tap(); syncBalls(); } return; }
      if (i === sel) { sel = -1; syncBalls(); return; }
      if (canPour(sel, i)) {
        undo.push(tubes.map((t) => t.slice()));
        // aynı renkten üstteki tüm topları taşı
        const color = tubes[sel][tubes[sel].length - 1];
        while (tubes[sel].length && tubes[sel][tubes[sel].length - 1] === color && tubes[i].length < cap) tubes[i].push(tubes[sel].pop());
        moves++; api.sfx.slide(); api.haptic('light');
        const t = tubes[i];
        if (t.length === cap && t.every((b) => b === t[0])) { S.burst(layout[i].clone().setY(layout[i].y + cap * BR * 2 + 0.6), new THREE.Color(COLORS[t[0]]).getHex(), 16, 5, 0.6); api.sfx.coin(); }
        sel = -1; hud(); syncBalls();
        if (solved()) {
          over = true; api.sfx.win();
          const score = Math.max(50, nColors * 120 - moves * 4 - Math.floor(time));
          setTimeout(() => api.gameOver({ score, coins: 8 + nColors * 2, win: true, title: 'Hepsi sıralandı! 🧪' }), 800);
        }
      } else { api.sfx.wrong(); sel = tubes[i].length ? i : -1; }
      syncBalls();
    });
    function doUndo() {
      if (!undo.length || undoLeft <= 0) { api.sfx.wrong(); return; }
      tubes = undo.pop(); undoLeft--; moves++; sel = -1; api.sfx.swap(); hud(); syncBalls(true);
    }
    const lp = S.loop((dt, t) => {
      if (!over) { const b = Math.floor(time); time += dt; if (Math.floor(time) !== b) hud(); }
      for (const m of balls) if (m.userData.target) m.position.lerp(m.userData.target, Math.min(1, dt * 14));
      S.updateParts(dt, -5);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { undoBtn.remove(); S.destroy(); } };
  },
};
