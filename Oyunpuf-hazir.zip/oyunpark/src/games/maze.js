// 🌀 Labirent: topu çıkışa götür (kaydırarak), seviye arttıkça labirent büyür ve süre kısalır
import { createStage, loop, particles } from '../core/canvas.js';

export default {
  id: 'maze', title: 'Labirent', emoji: '🌀', color: '#f72585',
  desc: 'Kaydır, topu labirentten çıkar!',
  winBased: true,
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    let N, M, walls, pos, draw_, cs, ox, oy, time, limit, over, L, stars, moves, trail;

    function gen() {
      // derinlik öncelikli arama ile kusursuz labirent
      walls = Array.from({ length: M * N }, () => [1, 1, 1, 1]); // üst, sağ, alt, sol
      const seen = new Set([0]); const stack = [0];
      while (stack.length) {
        const cur = stack[stack.length - 1], r = (cur / N) | 0, c = cur % N;
        const nb = [[-1, 0, 0, 2], [0, 1, 1, 3], [1, 0, 2, 0], [0, -1, 3, 1]]
          .map(([dr, dc, w, ow]) => [r + dr, c + dc, w, ow]).filter(([rr, cc]) => rr >= 0 && rr < M && cc >= 0 && cc < N && !seen.has(rr * N + cc));
        if (!nb.length) { stack.pop(); continue; }
        const [rr, cc, w, ow] = nb[(Math.random() * nb.length) | 0];
        walls[cur][w] = 0; walls[rr * N + cc][ow] = 0; seen.add(rr * N + cc); stack.push(rr * N + cc);
      }
      stars = [];
      for (let i = 0; i < 3; i++) stars.push({ r: (Math.random() * M) | 0, c: (Math.random() * N) | 0, got: false });
    }
    function layout() { if (!N) return; cs = Math.floor(Math.min((st.W - 20) / N, (st.H - 30) / M)); ox = (st.W - cs * N) / 2; oy = (st.H - cs * M) / 2; }
    function start() {
      L = api.level; N = Math.min(18, 6 + L * 2); M = Math.min(26, Math.round(N * 1.35));
      gen(); layout();
      pos = { r: 0, c: 0 }; draw_ = { r: 0, c: 0 }; time = 0; moves = 0; over = false; trail = [];
      limit = L >= 2 ? Math.round(N * M * Math.max(0.12, 0.35 - L * 0.025)) : Infinity;
      hud();
    }
    function hud() { api.setHud({ score: Math.floor(time), scoreLabel: 'Saniye', extra: `${N}×${M}` + (limit < Infinity ? ` · Süre: ${Math.max(0, Math.ceil(limit - time))}` : '') + ` · ⭐ ${stars.filter((s) => s.got).length}/3` }); }
    // kaydırma yönünde, kavşağa kadar ilerle
    function go(dr, dc) {
      if (over) return;
      const w = dr === -1 ? 0 : dc === 1 ? 1 : dr === 1 ? 2 : 3;
      let moved = false;
      while (!walls[pos.r * N + pos.c][w]) {
        trail.push({ ...pos });
        pos = { r: pos.r + dr, c: pos.c + dc }; moved = true;
        const s = stars.find((s) => !s.got && s.r === pos.r && s.c === pos.c);
        if (s) { s.got = true; api.sfx.coin(); }
        const open = walls[pos.r * N + pos.c].filter((x) => !x).length;
        if (open > 2 || (pos.r === M - 1 && pos.c === N - 1)) break;
      }
      if (moved) { moves++; api.sfx.slide(); api.haptic('light'); hud(); }
      if (pos.r === M - 1 && pos.c === N - 1) win();
    }
    function win() {
      over = true; api.sfx.win(); fx.burst(ox + (N - 0.5) * cs, oy + (M - 0.5) * cs, '#ffd60a', 40, 250);
      const got = stars.filter((s) => s.got).length;
      const score = Math.max(50, N * M * 3 - Math.floor(time) * 2 + got * 50);
      setTimeout(() => api.gameOver({ score, coins: 10 + L * 3 + got * 5, win: true, title: 'Çıkışı buldun! 🌀' }), 700);
    }
    let down = null;
    st.canvas.addEventListener('pointerdown', (e) => (down = st.point(e)));
    st.canvas.addEventListener('pointerup', (e) => {
      if (!down) return; const p = st.point(e), dx = p.x - down.x, dy = p.y - down.y; down = null;
      if (Math.hypot(dx, dy) < 15) return;
      Math.abs(dx) > Math.abs(dy) ? go(0, Math.sign(dx)) : go(Math.sign(dy), 0);
    });
    const onKey = (e) => { const k = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] }[e.key]; if (k) go(...k); };
    window.addEventListener('keydown', onKey);

    function update(dt) {
      if (!over) {
        const b = Math.floor(time); time += dt; if (Math.floor(time) !== b) hud();
        if (time >= limit) { over = true; api.sfx.lose(); api.gameOver({ score: moves, coins: 3, title: 'Süre doldu! ⏰' }); }
      }
      draw_.r += (pos.r - draw_.r) * Math.min(1, dt * 14); draw_.c += (pos.c - draw_.c) * Math.min(1, dt * 14);
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx;
      c.fillStyle = '#240046'; c.fillRect(0, 0, st.W, st.H);
      c.fillStyle = 'rgba(247,37,133,.25)';
      for (const t of trail) c.fillRect(ox + t.c * cs + cs * 0.3, oy + t.r * cs + cs * 0.3, cs * 0.4, cs * 0.4);
      c.fillStyle = '#2dc653'; c.fillRect(ox + (N - 1) * cs + 2, oy + (M - 1) * cs + 2, cs - 4, cs - 4);
      for (const s of stars) if (!s.got) { c.fillStyle = '#ffd60a'; c.font = `${cs * 0.6}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('★', ox + (s.c + 0.5) * cs, oy + (s.r + 0.5) * cs); }
      c.strokeStyle = '#c77dff'; c.lineWidth = Math.max(2, cs * 0.12); c.lineCap = 'round';
      c.beginPath();
      for (let r = 0; r < M; r++) for (let col = 0; col < N; col++) {
        const w = walls[r * N + col], x = ox + col * cs, y = oy + r * cs;
        if (w[0]) { c.moveTo(x, y); c.lineTo(x + cs, y); }
        if (w[1]) { c.moveTo(x + cs, y); c.lineTo(x + cs, y + cs); }
        if (w[2]) { c.moveTo(x, y + cs); c.lineTo(x + cs, y + cs); }
        if (w[3]) { c.moveTo(x, y); c.lineTo(x, y + cs); }
      }
      c.stroke();
      c.fillStyle = '#f72585'; c.shadowColor = '#f72585'; c.shadowBlur = 12;
      c.beginPath(); c.arc(ox + (draw_.c + 0.5) * cs, oy + (draw_.r + 0.5) * cs, cs * 0.32, 0, 7); c.fill(); c.shadowBlur = 0;
      c.textBaseline = 'alphabetic'; fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); window.removeEventListener('keydown', onKey); } };
  },
};
