// 🐍 Yılan
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

export default {
  id: 'snake', title: 'Yılan', emoji: '🐍', color: '#38b000',
  desc: 'Meyveleri ye, uzun ol, kendine çarpma!',
  target: (L) => Math.round(150 * Math.pow(1.4, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    const COLS = 15, ROWS = 21;
    let cell, ox, oy, snake, dir, nextDir, food, score, acc, over, grow, eaten, walls = [], L;

    function layout() {
      cell = Math.floor(Math.min((st.W - 16) / COLS, (st.H - 16) / ROWS));
      ox = (st.W - cell * COLS) / 2; oy = (st.H - cell * ROWS) / 2;
    }
    function start() {
      layout();
      snake = [{ x: 7, y: 12 }, { x: 7, y: 13 }, { x: 7, y: 14 }];
      L = api.level; walls = [];
      // seviye arttıkça duvar engelleri
      for (let i = 0; i < Math.min((L - 1) * 3, 30); i++) {
        const w = { x: (Math.random() * COLS) | 0, y: (Math.random() * ROWS) | 0 };
        if (w.x !== 7 && !walls.some((o) => o.x === w.x && o.y === w.y)) walls.push(w);
      }
      dir = { x: 0, y: -1 }; nextDir = dir; score = 0; acc = 0; over = false; grow = 0; eaten = 0;
      placeFood(); hud();
    }
    function hud() { api.setHud({ score, extra: `Uzunluk ${snake.length}` }); }
    function placeFood() {
      do { food = { x: (Math.random() * COLS) | 0, y: (Math.random() * ROWS) | 0, gold: Math.random() < 0.12 }; }
      while (snake.some((s) => s.x === food.x && s.y === food.y) || walls.some((s) => s.x === food.x && s.y === food.y));
    }
    function turn(dx, dy) {
      if (over) return;
      if (dx === -dir.x && dy === -dir.y) return;
      nextDir = { x: dx, y: dy };
    }
    let down = null;
    const onDown = (e) => { down = st.point(e); };
    const onUp = (e) => {
      if (!down) return;
      const p = st.point(e), dx = p.x - down.x, dy = p.y - down.y;
      if (Math.hypot(dx, dy) < 15) {
        // dokunma: yılanın başına göre yön
        const h = snake[0], hx = ox + (h.x + 0.5) * cell, hy = oy + (h.y + 0.5) * cell;
        const ddx = p.x - hx, ddy = p.y - hy;
        if (dir.x !== 0) turn(0, Math.sign(ddy) || 1); else turn(Math.sign(ddx) || 1, 0);
      } else if (Math.abs(dx) > Math.abs(dy)) turn(Math.sign(dx), 0);
      else turn(0, Math.sign(dy));
      down = null;
    };
    const onKey = (e) => {
      const k = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0] }[e.key];
      if (k) turn(...k);
    };
    st.canvas.addEventListener('pointerdown', onDown);
    st.canvas.addEventListener('pointerup', onUp);
    window.addEventListener('keydown', onKey);

    function step() {
      dir = nextDir;
      const h = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };
      if (h.x < 0 || h.y < 0 || h.x >= COLS || h.y >= ROWS || snake.some((s) => s.x === h.x && s.y === h.y) || walls.some((s) => s.x === h.x && s.y === h.y)) {
        over = true; api.sfx.crash(); api.haptic('heavy');
        fx.burst(ox + (snake[0].x + 0.5) * cell, oy + (snake[0].y + 0.5) * cell, '#38b000', 24);
        setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 15), canContinue: true }), 600);
        return;
      }
      snake.unshift(h);
      if (h.x === food.x && h.y === food.y) {
        const pts = food.gold ? 50 : 10; score += pts; eaten++; grow += food.gold ? 3 : 1;
        api.sfx[food.gold ? 'coin' : 'pop'](); api.haptic('light');
        fx.burst(ox + (h.x + 0.5) * cell, oy + (h.y + 0.5) * cell, food.gold ? '#ffd60a' : '#ff4d6d', 12);
        fx.text(ox + (h.x + 0.5) * cell, oy + h.y * cell, '+' + pts);
        placeFood(); hud();
      }
      if (grow > 0) grow--; else snake.pop();
    }

    function update(dt, t) {
      if (!over) {
        acc += dt;
        const interval = Math.max(0.045, 0.16 - (L - 1) * 0.013 - eaten * 0.003);
        while (acc >= interval) { acc -= interval; step(); if (over) break; }
      }
      fx.update(dt);
      draw(t);
    }

    function draw(t) {
      const c = st.ctx;
      c.fillStyle = '#1b4332'; c.fillRect(0, 0, st.W, st.H);
      for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) {
        c.fillStyle = (x + y) % 2 ? '#a7c957' : '#b5d66b';
        c.fillRect(ox + x * cell, oy + y * cell, cell, cell);
      }
      for (const w of walls) { c.fillStyle = '#6c584c'; roundRect(c, ox + w.x * cell + 1, oy + w.y * cell + 1, cell - 2, cell - 2, 4); c.fill(); c.fillStyle = '#a98467'; c.fillRect(ox + w.x * cell + 4, oy + w.y * cell + 4, cell - 8, 3); }
      // meyve
      const fx0 = ox + (food.x + 0.5) * cell, fy0 = oy + (food.y + 0.5) * cell, pr = cell * 0.38 * (1 + Math.sin(t * 6) * 0.08);
      c.fillStyle = food.gold ? '#ffc300' : '#e63946'; c.beginPath(); c.arc(fx0, fy0, pr, 0, 7); c.fill();
      c.fillStyle = '#2d6a4f'; c.beginPath(); c.ellipse(fx0 + 3, fy0 - pr, 4, 2.5, -0.5, 0, 7); c.fill();
      c.fillStyle = 'rgba(255,255,255,.5)'; c.beginPath(); c.arc(fx0 - pr * 0.35, fy0 - pr * 0.3, pr * 0.25, 0, 7); c.fill();
      // yılan
      snake.forEach((s, i) => {
        const k = 1 - i / (snake.length + 6);
        c.fillStyle = `hsl(${110 + i * 2},70%,${30 + k * 15}%)`;
        roundRect(c, ox + s.x * cell + 1, oy + s.y * cell + 1, cell - 2, cell - 2, cell * 0.35); c.fill();
      });
      const h = snake[0], hx = ox + (h.x + 0.5) * cell, hy = oy + (h.y + 0.5) * cell;
      const ex = dir.y !== 0 ? cell * 0.2 : 0, ey = dir.x !== 0 ? cell * 0.2 : 0;
      c.fillStyle = '#fff';
      c.beginPath(); c.arc(hx - ex + dir.x * 3, hy - ey + dir.y * 3, cell * 0.14, 0, 7); c.arc(hx + ex + dir.x * 3, hy + ey + dir.y * 3, cell * 0.14, 0, 7); c.fill();
      c.fillStyle = '#000';
      c.beginPath(); c.arc(hx - ex + dir.x * 4, hy - ey + dir.y * 4, cell * 0.07, 0, 7); c.arc(hx + ex + dir.x * 4, hy + ey + dir.y * 4, cell * 0.07, 0, 7); c.fill();
      fx.draw(c);
    }

    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() {
        // yılanı kısalt ve ortaya yeniden yerleştir
        const len = Math.max(3, Math.floor(snake.length / 2));
        snake = Array.from({ length: len }, (_, i) => ({ x: 7, y: Math.min(ROWS - 1, 8 + i) }));
        dir = nextDir = { x: 0, y: -1 }; over = false; acc = 0; hud();
      },
      restart() { start(); },
      destroy() { lp.stop(); st.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
