// ⛏️ Blok Dünyası 3D — kendi tasarımımız blok inşa / keşif oyunu (karakter, dokular, arayüz OyunPark'a özgü).
// Oynanış: 3. şahıs (istersen 1. şahıs) kamera, sol altta hareket kolu, sağda bakış; basılı tut → kır, dokun → koy.
// Kırılan bloklar envantere girer, koydukça azalır (Yaratıcı modda sınırsız). Online: 4 kişiye kadar aynı dünyada.
import { create3D, mat, THREE } from '../core/three-stage.js';
import { store } from '../core/store.js';
import { model, modelInto, loadModel, attachTo } from '../core/assets.js';

const SIZE = 40, HMAX = 22, WATER = 3;
const BLOCKS = [
  null,
  { name: 'Çimen', top: '#5cb85c', side: '#8b5a2b', hard: 0.45, drop: 2 },
  { name: 'Toprak', top: '#8b5a2b', side: '#8b5a2b', hard: 0.4 },
  { name: 'Taş', top: '#8d99ae', side: '#8d99ae', hard: 1.3 },
  { name: 'Kum', top: '#f2d49b', side: '#f2d49b', hard: 0.35 },
  { name: 'Tahta', top: '#c68b59', side: '#a0663b', hard: 0.9 },
  { name: 'Yaprak', top: '#2d6a4f', side: '#2d6a4f', hard: 0.15 },
  { name: 'Tuğla', top: '#b23a48', side: '#b23a48', hard: 1.4 },
  { name: 'Cam', top: '#bde0fe', side: '#bde0fe', hard: 0.25, glass: true },
  { name: 'Altın', top: '#ffc300', side: '#ffb703', hard: 1.6 },
  { name: 'Kar', top: '#ffffff', side: '#e9ecef', hard: 0.2 },
  { name: 'Su', top: '#3a86ff', side: '#3a86ff', water: true },
];
const HOTBAR = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const START_INV = { 1: 10, 2: 10, 5: 16, 7: 8, 8: 6 };
const QUESTS = [
  { text: '5 blok kır', check: (s) => s.broken >= 5, reward: 4 },
  { text: '10 blok koy', check: (s) => s.placed >= 10, reward: 5 },
  { text: '3 taş kır', check: (s) => (s.minedBy[3] || 0) >= 3, reward: 6 },
  { text: '6 blok yüksekliğe çık', check: (s) => s.maxHeight >= 6 + WATER + 3, reward: 8 },
  { text: '8 tahta koy (bir kulübe yap!)', check: (s) => (s.byType[5] || 0) >= 8, reward: 8 },
  { text: 'Altın bul ve kaz', check: (s) => (s.minedBy[9] || 0) >= 1, reward: 12 },
  { text: '50 blok koy', check: (s) => s.placed >= 50, reward: 15 },
];

// ---------- savaş: silahlar, tarifler (birleştirme), canavarlar ----------
const WEAPONS = {
  hand: { name: 'El', icon: '✊', dmg: 1, reach: 2.3 },
  wsword: { name: 'Tahta Kılıç', icon: '🗡️', dmg: 2, reach: 2.8 },
  ssword: { name: 'Taş Kılıç', icon: '⚔️', dmg: 3, reach: 2.9 },
  gsword: { name: 'Altın Kılıç', icon: '🌟', dmg: 5, reach: 3.1 },
  bow: { name: 'Yay', icon: '🏹', dmg: 4, ranged: true },
};
const RECIPES = [
  { give: 'wsword', need: { 5: 3 }, text: 'Tahta Kılıç', icon: '🗡️' },
  { give: 'ssword', need: { 3: 2, 5: 1 }, text: 'Taş Kılıç', icon: '⚔️' },
  { give: 'gsword', need: { 9: 3, 5: 1 }, text: 'Altın Kılıç', icon: '🌟' },
  { give: 'bow', need: { 5: 3, 6: 2 }, text: 'Yay', icon: '🏹' },
  { give: 'arrows', n: 8, need: { 5: 1, 3: 1 }, text: '8 Ok', icon: '➶' },
  { give: 'potion', need: { 6: 3, 9: 1 }, text: 'Can İksiri', icon: '🧪' },
];
const MONSTERS = {
  jelly: { name: 'Zombi', model: 'gy-zombie', h: 1.5, hp: 3, dmg: 1, speed: 1.9, r: 0.5, color: 0xff70a6 },
  rock: { name: 'İskelet', model: 'gy-skeleton', h: 1.85, hp: 8, dmg: 2, speed: 1.25, r: 0.7, color: 0x8d99ae },
  ghost: { name: 'Hayalet', model: 'gy-ghost', h: 1.35, hp: 4, dmg: 1, speed: 3.0, r: 0.45, color: 0x9d4edd, fly: true },
};
// Canavarlar: Kenney Graveyard Kit (CC0) modelleri; yüklenene kadar basit yer tutucu görünür
function buildMonster(kind) {
  const M = MONSTERS[kind], g = new THREE.Group();
  const stub = buildMonsterStub(kind);
  const holder = modelInto(g, M.model, { height: M.h, anim: kind === 'ghost' ? 'idle' : 'walk', fallback: stub }, (m) => {
    m.rotation.y = Math.PI; // modeller +Z'ye bakar, oyun -Z'yi ön kabul eder
    const mats = []; m.traverse((o) => { if (o.isMesh) { o.material = o.material.clone(); mats.push({ m: o.material, c: o.material.color.clone() }); if (kind === 'ghost') { o.material.transparent = true; o.material.opacity = 0.85; } } });
    g.userData.flash = (on) => mats.forEach((x) => x.m.color.copy(on ? new THREE.Color(0xff5555) : x.c));
  });
  g.userData.holder = holder;
  g.userData.flash = (on) => stub.userData.body?.material.emissive?.setHex(on ? 0xff0000 : 0);
  g.userData.update = (dt) => holder.userData.model?.userData.update(dt);
  return g;
}
function buildMonsterStub(kind) {
  const g = new THREE.Group(), M = MONSTERS[kind];
  const eyeW = new THREE.MeshBasicMaterial({ color: 0xffffff }), eyeB = new THREE.MeshBasicMaterial({ color: 0x111111 });
  if (kind === 'jelly') {
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.5, 20, 14, 0, Math.PI * 2, 0, Math.PI / 1.7), mat(M.color, { transparent: true, opacity: 0.85, roughness: 0.15 }));
    b.castShadow = true; g.add(b);
    const core = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), mat(0xffb3c6)); core.position.y = 0.2; g.add(core);
    [-0.17, 0.17].forEach((x) => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.11, 10, 8), eyeW); e.position.set(x, 0.3, -0.38); g.add(e); const p = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 6), eyeB); p.position.set(x, 0.3, -0.48); g.add(p); });
    g.userData.body = b;
  } else if (kind === 'rock') {
    const b = new THREE.Mesh(new THREE.IcosahedronGeometry(0.7, 1), mat(M.color, { flatShading: true, roughness: 1 }));
    b.position.y = 0.75; b.scale.set(1, 0.9, 1); b.castShadow = true; g.add(b);
    const moss = new THREE.Mesh(new THREE.SphereGeometry(0.55, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2.5), mat(0x52b788, { roughness: 1 })); moss.position.y = 1.18; g.add(moss);
    [-0.22, 0.22].forEach((x) => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffd60a })); e.position.set(x, 0.9, -0.6); g.add(e); });
    [-0.3, 0.3].forEach((x) => { const f = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 6), mat(0x6c757d)); f.position.set(x, 0.12, -0.05); g.add(f); });
    g.userData.body = b;
  } else {
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.42, 18, 12), mat(M.color, { transparent: true, opacity: 0.8, emissive: 0x3c096c, emissiveIntensity: 0.5 }));
    b.position.y = 0.55; g.add(b);
    const tail = new THREE.Mesh(new THREE.ConeGeometry(0.4, 0.6, 14), b.material); tail.position.y = 0.12; tail.rotation.x = Math.PI; g.add(tail);
    [-0.14, 0.14].forEach((x) => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 6), new THREE.MeshBasicMaterial({ color: 0xe0aaff })); e.position.set(x, 0.62, -0.36); g.add(e); });
    g.userData.body = b;
  }
  return g;
}

function blockTexture(hex, seed, isTop) {
  const cv = document.createElement('canvas'); cv.width = cv.height = 16;
  const c = cv.getContext('2d'); let s = seed * 997 + (isTop ? 13 : 0);
  const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const base = new THREE.Color(hex);
  for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) { const col = base.clone().multiplyScalar(0.86 + rnd() * 0.22); c.fillStyle = `#${col.getHexString()}`; c.fillRect(x, y, 1, 1); }
  if (!isTop && seed === 1) { c.fillStyle = '#5cb85c'; c.fillRect(0, 0, 16, 4); for (let x = 0; x < 16; x += 2) c.fillRect(x, 4, 1, 1 + ((x * 7) % 3)); }
  if (seed === 7) { c.fillStyle = 'rgba(255,255,255,.35)'; for (let y = 0; y < 16; y += 4) { c.fillRect(0, y, 16, 1); for (let x = (y / 4) % 2 ? 0 : 4; x < 16; x += 8) c.fillRect(x, y, 1, 4); } }
  if (seed === 5) { c.fillStyle = 'rgba(0,0,0,.18)'; for (let y = 3; y < 16; y += 5) c.fillRect(0, y, 16, 1); }
  if (seed === 9) { c.fillStyle = 'rgba(255,255,255,.6)'; [[3, 3], [10, 5], [6, 11], [12, 12]].forEach(([x, y]) => c.fillRect(x, y, 2, 2)); }
  if (seed === 3) { c.fillStyle = 'rgba(0,0,0,.15)'; [[2, 5], [9, 2], [12, 9], [5, 12]].forEach(([x, y]) => c.fillRect(x, y, 3, 2)); }
  if (seed === 8) { c.clearRect(0, 0, 16, 16); c.fillStyle = 'rgba(189,224,254,.35)'; c.fillRect(0, 0, 16, 16); c.fillStyle = 'rgba(255,255,255,.9)'; c.fillRect(0, 0, 16, 1); c.fillRect(0, 15, 16, 1); c.fillRect(0, 0, 1, 16); c.fillRect(15, 0, 1, 16); c.fillRect(4, 4, 2, 1); c.fillRect(5, 5, 2, 1); }
  const t = new THREE.CanvasTexture(cv); t.magFilter = THREE.NearestFilter; t.minFilter = THREE.NearestFilter; t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
function seeded(seed) { let s = seed % 2147483647 || 1; return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }
const hashCode = (str) => [...String(str)].reduce((h, ch) => (h * 31 + ch.charCodeAt(0)) | 0, 7) >>> 0;
const PCOLORS = [0xef233c, 0x3a86ff, 0x2dc653, 0xffc300];

// OyunPark'a özgü karakter: yuvarlak kafa, bere, tulum, sırt çantası
function buildHero(color) {
  const g = new THREE.Group();
  const skin = mat(0xffcf9e), suit = mat(color, { roughness: 0.6 }), dark = mat(0x22223b), shoe = mat(0x6b3410);
  const part = (geo, m, x, y, z) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.castShadow = true; g.add(o); return o; };
  const body = part(new THREE.CylinderGeometry(0.26, 0.3, 0.62, 16), suit, 0, 0.78, 0);
  part(new THREE.SphereGeometry(0.29, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), suit, 0, 1.08, 0);
  const head = part(new THREE.SphereGeometry(0.3, 20, 16), skin, 0, 1.42, 0);
  const hat = part(new THREE.SphereGeometry(0.31, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2.2), mat(0xffd60a), 0, 1.47, 0);
  part(new THREE.SphereGeometry(0.08, 10, 8), mat(0xffffff), 0, 1.78, 0);
  [-0.11, 0.11].forEach((x) => { part(new THREE.SphereGeometry(0.065, 10, 8), mat(0xffffff), x, 1.45, -0.26); part(new THREE.SphereGeometry(0.035, 8, 6), dark, x, 1.45, -0.31); });
  part(new THREE.BoxGeometry(0.34, 0.4, 0.16), mat(0x9c6644), 0, 0.85, 0.3); // çanta
  const limb = (w, h, m, x, y) => { const p = new THREE.Group(); p.position.set(x, y, 0); const l = new THREE.Mesh(new THREE.CapsuleGeometry(w, h, 4, 8), m); l.position.y = -h / 2 - w / 2; l.castShadow = true; p.add(l); g.add(p); return p; };
  const legL = limb(0.1, 0.32, suit, -0.12, 0.52), legR = limb(0.1, 0.32, suit, 0.12, 0.52);
  const armL = limb(0.08, 0.36, skin, -0.34, 1.04), armR = limb(0.08, 0.36, skin, 0.34, 1.04);
  [legL, legR].forEach((lg) => { const s = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.1, 0.28), shoe); s.position.set(0, -0.5, -0.04); lg.add(s); });
  // elde tutulan blok
  const held = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.2, 0.2), mat(0xffffff)); held.position.set(0, -0.55, -0.1); armR.add(held);
  g.userData = { legL, legR, armL, armR, head, body, hat, held };
  // hazır karakter (Kenney Blocky Characters, CC0): yüklenince basit gövde gizlenir, eldeki eşya modelin eline geçer
  const proc = [...g.children];
  const hand = new THREE.Group(); // eldeki blok / silah
  const mh = modelInto(g, HERO_MODELS[PCOLORS.indexOf(color)] || 'bc-red', { height: 1.72, anim: 'idle' }, (m) => {
    proc.forEach((o) => (o.visible = false));
    m.rotation.y = Math.PI;
    const h = attachTo(m, 'arm-right', hand); if (!h) { armR.add(hand); }
    held.position.set(0, -0.05, 0.08); hand.add(held);
  });
  armR.add(hand); hand.position.set(0, -0.55, -0.1); held.position.set(0, 0, 0); hand.add(held);
  let swingCd = 0;
  g.userData.hand = hand;
  g.userData.anim = (dt, moving, swinging) => {
    const m = mh.userData.model?.userData; if (!m) return false;
    swingCd -= dt;
    if (swinging && swingCd <= 0) { swingCd = 0.4; m.once('attack-melee-right', moving ? 'walk' : 'idle', 0.05); }
    else if (swingCd <= 0) m.play(moving ? 'walk' : 'idle');
    m.update(dt * (moving ? 1.5 : 1));
    return true;
  };
  return g;
}
const HERO_MODELS = ['bc-red', 'bc-blue', 'bc-green', 'bc-yellow'];

export default {
  id: 'voxel', title: 'Blok Dünyası 3D', emoji: '⛏️', color: '#5cb85c',
  desc: 'Keşfet, kaz, inşa et! Online arkadaşlarınla birlikte',
  sandbox: true, landscape: true, online: { min: 1, max: 4 },
  target: (L) => 8 + (L - 1) * 5, // Hayatta Kal modunda seviye atlamak için yenilmesi gereken canavar
  create(host, api) {
    const S = create3D(host, { fov: 62, bg: 0x87ceeb, fog: [0xa9d6f5, 26, 50] });
    const { scene, camera, sun, hemi } = S;
    sun.shadow.mapSize.set(2048, 2048); Object.assign(sun.shadow.camera, { left: -18, right: 18, top: 18, bottom: -18, far: 80 });
    const ON = api.mp?.online, ME = ON ? ON.me : 0;
    const SAVE_KEY = 'oyunpark_world_v3';

    // ---------- sonsuz dünya: 16×16'lık parçalar (chunk) ----------
    // Dünya her yöne sınırsız; oyuncunun çevresindeki parçalar anında üretilir, uzaklaşınca bellekten atılır.
    const CS = 16, RD = 3;                         // parça boyu, görüş mesafesi (parça)
    const chunks = new Map();                      // "cx,cz" → Uint8Array(CS*HMAX*CS)
    const edits = new Map();                       // "cx,cz" → Map(yerelIndex → blok) oyuncunun değişiklikleri
    const ck = (cx, cz) => cx + ',' + cz;
    const lidx = (x, y, z) => x + CS * (z + CS * y);
    let worldSeed = 1;
    // tohumlu tamsayı karması + yumuşak değer gürültüsü
    function h2(x, z, s) { let h = (x * 374761393 + z * 668265263 + s * 2246822519) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }
    function vnoise(x, z, s) {
      const ix = Math.floor(x), iz = Math.floor(z), fx = x - ix, fz = z - iz;
      const u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz);
      const a = h2(ix, iz, s), b = h2(ix + 1, iz, s), c = h2(ix, iz + 1, s), d = h2(ix + 1, iz + 1, s);
      return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
    }
    function heightAt(x, z) {
      const S0 = worldSeed;
      let h = 3.2 + vnoise(x / 40, z / 40, S0) * 7 + vnoise(x / 14, z / 14, S0 + 7) * 3.2;
      const m = vnoise(x / 70, z / 70, S0 + 13); h += Math.max(0, m - 0.55) * 26;      // yer yer dağlar
      return Math.max(1, Math.min(HMAX - 7, Math.floor(h)));
    }
    function genChunk(cx, cz) {
      const a = new Uint8Array(CS * HMAX * CS), x0 = cx * CS, z0 = cz * CS;
      for (let lx = 0; lx < CS; lx++) for (let lz = 0; lz < CS; lz++) {
        const x = x0 + lx, z = z0 + lz, h = heightAt(x, z);
        for (let y = 0; y <= h; y++) a[lidx(lx, y, lz)] = y === h ? (h <= WATER ? 4 : h > 11 ? 10 : 1) : y > h - 3 ? 2 : 3;
        for (let y = h + 1; y <= WATER; y++) a[lidx(lx, y, lz)] = 11;
        // taşın içinde altın damarı
        for (let y = 1; y < Math.min(6, h - 2); y++) if (h2(x * 3 + y, z * 7 - y, worldSeed + 99) < 0.012) a[lidx(lx, y, lz)] = 9;
      }
      // ağaçlar: komşu sütunlardan taşan yapraklar da yazılsın diye kenarın 2 blok dışına da bakılır
      for (let x = x0 - 2; x < x0 + CS + 2; x++) for (let z = z0 - 2; z < z0 + CS + 2; z++) {
        if (h2(x, z, worldSeed + 31) > 0.012) continue;
        const y = heightAt(x, z); if (y <= WATER || y > 11) continue;
        const put = (bx, by, bz, t, onlyEmpty) => { const lx = bx - x0, lz = bz - z0; if (lx < 0 || lz < 0 || lx >= CS || lz >= CS || by >= HMAX) return; const i = lidx(lx, by, lz); if (!onlyEmpty || !a[i]) a[i] = t; };
        for (let k = 1; k <= 4; k++) put(x, y + k, z, 5);
        for (let dx = -2; dx <= 2; dx++) for (let dz = -2; dz <= 2; dz++) for (let dy = 3; dy <= 5; dy++) {
          if (Math.abs(dx) + Math.abs(dz) + (dy === 5 ? 2 : 0) > 3 || (dx === 0 && dz === 0 && dy < 5)) continue;
          put(x + dx, y + dy, z + dz, 6, true);
        }
      }
      const e = edits.get(ck(cx, cz)); if (e) for (const [i, t] of e) a[i] = t;
      return a;
    }
    function chunkData(cx, cz) { const k = ck(cx, cz); let c = chunks.get(k); if (!c) { c = genChunk(cx, cz); chunks.set(k, c); } return c; }
    const inB = (x, y, z) => y >= 0 && y < HMAX;
    const get = (x, y, z) => { if (y < 0 || y >= HMAX) return 0; const cx = Math.floor(x / CS), cz = Math.floor(z / CS); return chunkData(cx, cz)[lidx(x - cx * CS, y, z - cz * CS)]; };
    const solid = (x, y, z) => { if (y < 0) return true; if (y >= HMAX) return false; const t = get(x, y, z); return t !== 0 && t !== 11; };
    function setRaw(x, y, z, t) {
      const cx = Math.floor(x / CS), cz = Math.floor(z / CS), k = ck(cx, cz), i = lidx(x - cx * CS, y, z - cz * CS);
      chunkData(cx, cz)[i] = t;
      let e = edits.get(k); if (!e) { e = new Map(); edits.set(k, e); } e.set(i, t);
      // parçanın ve kenardaysa komşusunun görüntüsü yenilensin
      markDirty(cx, cz); const lx = x - cx * CS, lz = z - cz * CS;
      if (lx === 0) markDirty(cx - 1, cz); if (lx === CS - 1) markDirty(cx + 1, cz); if (lz === 0) markDirty(cx, cz - 1); if (lz === CS - 1) markDirty(cx, cz + 1);
    }
    const geo = new THREE.BoxGeometry(1, 1, 1);
    const mats = BLOCKS.map((b, i) => {
      if (!b) return null;
      const o = { roughness: 0.9, transparent: !!(b.glass || b.water), opacity: b.water ? 0.72 : b.glass ? 0.6 : 1, depthWrite: !b.water };
      const side = new THREE.MeshStandardMaterial({ map: blockTexture(b.side, i, false), ...o });
      const top = new THREE.MeshStandardMaterial({ map: blockTexture(b.top, i, true), ...o });
      return [side, side, top, side, side, side];
    });
    // Kenney Voxel Pack dokulu küpler (kv-blocks.glb, CC0): yüklenince bütün parçalar bu görünümle yeniden çizilir
    const BLOCK_NODES = [null, 'b1-grass', 'b2-dirt', 'b3-stone', 'b4-sand', 'b5-wood', 'b6-leaves', 'b7-brick', 'b8-glass', 'b9-gold', 'b10-snow', 'b11-water'];
    const geos = [];
    loadModel('kv-blocks').then((g) => {
      BLOCK_NODES.forEach((n, t) => {
        if (!n) return; const o = g.scene.getObjectByName(n); if (!o?.isMesh) return;
        const b = BLOCKS[t], m = o.material.clone();
        if (m.map) { m.map.magFilter = THREE.NearestFilter; m.map.minFilter = THREE.NearestFilter; m.map.generateMipmaps = false; m.map.needsUpdate = true; }
        m.roughness = 0.95; m.metalness = 0;
        if (b.glass) { m.transparent = true; m.alphaTest = 0.1; }
        if (b.water) { m.transparent = true; m.opacity = 0.72; m.depthWrite = false; }
        geos[t] = o.geometry; mats[t] = m;
      });
      for (const k of views.keys()) dirtySet.add(k);
      setHeld();
    }).catch(() => {});
    const dummy = new THREE.Object3D();
    const W = (x) => x - SIZE / 2 + 0.5; // dünya → sahne koordinatı
    const views = new Map();                       // "cx,cz" → Group (çizilmiş parça)
    const dirtySet = new Set();
    const waterMeshes = new Set();
    function markDirty(cx, cz) { const k = ck(cx, cz); if (views.has(k)) dirtySet.add(k); }
    function buildView(cx, cz) {
      const k = ck(cx, cz), old = views.get(k);
      if (old) { scene.remove(old); old.children.forEach((m) => { waterMeshes.delete(m); m.dispose?.(); }); }
      const a = chunkData(cx, cz), x0 = cx * CS, z0 = cz * CS, lists = BLOCKS.map(() => []);
      const open = (v) => !v || BLOCKS[v].glass || BLOCKS[v].water;
      for (let y = 0; y < HMAX; y++) for (let lz = 0; lz < CS; lz++) for (let lx = 0; lx < CS; lx++) {
        const t = a[lidx(lx, y, lz)]; if (!t) continue;
        const x = x0 + lx, z = z0 + lz;
        const inner = lx > 0 && lx < CS - 1 && lz > 0 && lz < CS - 1;
        const g = inner ? (dx, dy, dz) => (y + dy < 0 || y + dy >= HMAX ? 0 : a[lidx(lx + dx, y + dy, lz + dz)]) : (dx, dy, dz) => get(x + dx, y + dy, z + dz);
        if (t === 11 ? g(0, 1, 0) !== 11 : (open(g(1, 0, 0)) || open(g(-1, 0, 0)) || open(g(0, 1, 0)) || open(g(0, 0, 1)) || open(g(0, 0, -1)) || (y > 0 && open(g(0, -1, 0))))) lists[t].push([x, y, z]);
      }
      const grp = new THREE.Group();
      lists.forEach((list, t) => {
        if (!t || !list.length) return;
        const m = new THREE.InstancedMesh(geos[t] || geo, mats[t], list.length);
        list.forEach(([x, y, z], i) => { dummy.position.set(W(x), y + 0.5, W(z)); dummy.updateMatrix(); m.setMatrixAt(i, dummy.matrix); });
        m.castShadow = !BLOCKS[t].water && !BLOCKS[t].glass; m.receiveShadow = true;
        if (t === 11) waterMeshes.add(m);
        grp.add(m);
      });
      scene.add(grp); views.set(k, grp);
    }
    // oyuncunun çevresindeki parçaları çiz, uzaktakileri kaldır (karede en fazla birkaç parça → takılma olmaz)
    let lastPC = '';
    function updateChunks(px, pz, budget = 2) {
      const pcx = Math.floor(px / CS), pcz = Math.floor(pz / CS);
      const want = [];
      for (let dx = -RD; dx <= RD; dx++) for (let dz = -RD; dz <= RD; dz++) if (dx * dx + dz * dz <= RD * RD + 1) want.push([pcx + dx, pcz + dz, dx * dx + dz * dz]);
      want.sort((p, q) => p[2] - q[2]);
      let built = 0;
      for (const [cx, cz] of want) { const k = ck(cx, cz); if (!views.has(k)) { if (built >= budget) break; buildView(cx, cz); built++; } }
      for (const k of [...dirtySet]) { if (built >= budget + 2) break; dirtySet.delete(k); const [cx, cz] = k.split(',').map(Number); buildView(cx, cz); built++; }
      const key = pcx + ',' + pcz;
      if (key !== lastPC) {
        lastPC = key;
        for (const [k, grp] of views) { const [cx, cz] = k.split(',').map(Number); if (Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) > RD + 1) { scene.remove(grp); grp.children.forEach((m) => { waterMeshes.delete(m); m.dispose?.(); }); views.delete(k); dirtySet.delete(k); } }
        // değiştirilmemiş uzak parçaların verisi bellekten atılır (gerekirse yeniden üretilir)
        for (const k of chunks.keys()) { const [cx, cz] = k.split(',').map(Number); if (Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) > RD + 4) chunks.delete(k); }
      }
    }
    function resetWorld() {
      for (const grp of views.values()) scene.remove(grp);
      views.clear(); chunks.clear(); dirtySet.clear(); waterMeshes.clear(); lastPC = '';
    }
    let dirty = false;

    // ---------- oyuncu ----------
    const hero = buildHero(PCOLORS[ME]); scene.add(hero);
    const P = { x: SIZE / 2, y: 15, z: SIZE / 2, vx: 0, vy: 0, vz: 0, yaw: 0, onGround: false, inWater: false, walk: 0 };
    const PW = 0.3, PH = 1.75; // yarı genişlik, boy
    let camYaw = Math.PI, camPitch = 0.35, firstPerson = false, creative = false;
    function collides(x, y, z) {
      for (let bx = Math.floor(x - PW); bx <= Math.floor(x + PW); bx++) for (let bz = Math.floor(z - PW); bz <= Math.floor(z + PW); bz++) for (let by = Math.floor(y); by <= Math.floor(y + PH - 0.01); by++) if (solid(bx, by, bz)) return true;
      return false;
    }
    function spawnPoint(cx0 = SIZE / 2, cz0 = SIZE / 2) {
      // verilen noktaya en yakın, su seviyesinin üstünde çimenli bir kara noktası (gerekirse uzağa kadar arar)
      for (let r = 0; r < 200; r += 2) {
        let best = null;
        for (let x = Math.floor(cx0 - r); x <= cx0 + r; x++) for (let z = Math.floor(cz0 - r); z <= cz0 + r; z++) {
          if (r > 0 && Math.abs(x - cx0) < r - 2 && Math.abs(z - cz0) < r - 2) continue;
          let y = HMAX - 1; while (y > 0 && !get(x, y, z)) y--;
          const t = get(x, y, z);
          if ((t !== 1 && t !== 10) || y <= WATER + 1 || get(x, y + 1, z) || get(x, y + 2, z)) continue;
          let crowded = false; for (let dx = -1; dx <= 1 && !crowded; dx++) for (let dz = -1; dz <= 1 && !crowded; dz++) for (let dy = 1; dy <= 3; dy++) if (solid(x + dx, y + dy, z + dz)) { crowded = true; break; }
          if (crowded) continue; // ağaç dibinde doğmasın (kamera sıkışmasın)
          const sc = Math.hypot(x - cx0, z - cz0) - y * 0.3;
          if (!best || sc < best.sc) best = { sc, x: x + 0.5, y: y + 1.01, z: z + 0.5 };
        }
        if (best) return best;
      }
      return { x: cx0 + 0.5, y: HMAX - 2, z: cz0 + 0.5 };
    }
    function moveAxis(axis, d) {
      const old = P[axis]; P[axis] += d;
      if (collides(P.x, P.y, P.z)) {
        // tek bloğa otomatik tırmanma (yerdeyken yatay engelde)
        if (axis !== 'y' && P.onGround && !collides(P.x, P.y + 1.05, P.z) && !collides(P.x - (axis === 'x' ? d : 0), P.y + 1.05, P.z - (axis === 'z' ? d : 0))) { P.y += 1.05; P.vy = 0; return; }
        P[axis] = old;
        if (axis === 'y') { if (d < 0) P.onGround = true; P.vy = 0; }
      }
    }

    // ---------- arayüz ----------
    const ui = document.createElement('div'); ui.className = 'mc-ui';
    ui.innerHTML = `
      <div class="mc-top"><div class="mc-quest"></div>
        <button class="mc-btn sm" data-cam title="Kamera">👁️</button>
        <button class="mc-btn sm" data-creative title="Yaratıcı mod">∞</button>
        <button class="mc-btn sm" data-craft title="Üretim">🛠️</button>
        ${ON ? '' : '<button class="mc-btn sm" data-new title="Yeni dünya">🌍</button>'}</div>
      <div class="mc-hearts"></div>
      <div class="mc-hurt"></div>
      <div class="mc-banner"></div>
      <div class="mc-left"><button class="mc-btn mid" data-weapon>✊<small>El</small></button><button class="mc-btn mid" data-potion hidden>🧪<small>0</small></button></div>
      <div class="mc-cross">+</div>
      <div class="mc-break"><i></i></div>
      <div class="mc-stick"><i></i></div>
      <div class="mc-right"><button class="mc-btn big" data-jump>⤒<small>Zıpla</small></button>
        <button class="mc-btn big red" data-mine>⛏️<small>Kır</small></button>
        <button class="mc-btn big green" data-place>🧱<small>Koy</small></button>
        <button class="mc-btn big gold" data-attack hidden>⚔️<small>Vur</small></button></div>
      <div class="mc-craft" hidden><div class="mc-craft-box"><h3>🛠️ Üretim — blokları birleştir</h3><div class="mc-recipes"></div><button class="btn small" data-craft-x>Kapat</button></div></div>
      <div class="mc-modes" hidden><div class="mc-modes-box"></div></div>
      <div class="mc-hot">${HOTBAR.map((t) => `<button data-t="${t}" style="--b:${BLOCKS[t].top};--s:${BLOCKS[t].side}"><i></i><b class="cnt"></b></button>`).join('')}</div>
      <div class="mc-name"></div>`;
    host.appendChild(ui);
    const $u = (s) => ui.querySelector(s);
    let sel = 5;
    // elde: savaşta seçili silah (Kenney Mini Arena kılıç / KayKit yay, CC0), değilse seçili blok
    const weaponTpl = {};
    const WMODEL = { wsword: ['ma-sword', 0xb07040], ssword: ['ma-sword', 0x9aa5b1], gsword: ['ma-sword', 0xffd23f], bow: ['kw-bow', null] };
    Object.entries(WMODEL).forEach(([k, [n, tint]]) => model(n, { size: k === 'bow' ? 0.8 : 0.95, ...(tint ? { tint } : {}), ...(k === 'gsword' ? { glow: 0xffb703 } : {}) }).then((m) => { weaponTpl[k] = m; setHeld(); }).catch(() => {}));
    let heldW = null;
    function setHeld() {
      const held = hero.userData.held, hand = hero.userData.hand;
      const showW = combat() && weapon !== 'hand' && weaponTpl[weapon];
      if (heldW) { hand.remove(heldW); heldW = null; }
      if (showW) {
        heldW = weaponTpl[weapon].clone(true);
        heldW.rotation.set(weapon === 'bow' ? 0 : Math.PI / 2, weapon === 'bow' ? Math.PI / 2 : 0, 0);
        heldW.position.set(0, -0.05, weapon === 'bow' ? 0.05 : 0.1);
        hand.add(heldW); held.visible = false; return;
      }
      held.geometry = geos[sel] || held.userData.boxGeo || held.geometry; held.userData.boxGeo ||= held.geometry;
      held.material = geos[sel] ? mats[sel] : new THREE.MeshStandardMaterial({ color: BLOCKS[sel].top });
      held.scale.setScalar(geos[sel] ? 0.24 : 1);
      held.visible = creative || (inv[sel] || 0) > 0;
    }
    const inv = { ...START_INV };
    const stats = { placed: 0, broken: 0, byType: {}, minedBy: {}, maxHeight: 0, quest: 0 };
    function refreshUi() {
      ui.querySelectorAll('[data-t]').forEach((b) => {
        const t = +b.dataset.t, n = inv[t] || 0;
        b.classList.toggle('on', t === sel); b.classList.toggle('empty', !creative && !n);
        b.querySelector('.cnt').textContent = creative ? '∞' : n || '';
      });
      $u('[data-creative]').classList.toggle('on', creative);
      $u('[data-cam]').textContent = firstPerson ? '👤' : '👁️';
      const q = QUESTS[stats.quest];
      $u('.mc-quest').textContent = ON ? `🌐 ${api.mp.names.length} kişi aynı dünyada` : q ? `🎯 ${q.text} · +${q.reward}🪙` : '🏆 Tüm görevler tamam!';
      $u('.mc-name').textContent = BLOCKS[sel].name;
      setHeld();
      if (typeof refreshCombat === 'function') refreshCombat();
    }
    ui.querySelectorAll('[data-t]').forEach((b) => b.addEventListener('pointerdown', (e) => { e.stopPropagation(); sel = +b.dataset.t; api.sfx.click(); refreshUi(); }));
    // ================= SAVAŞ =================
    let gmode = 'build';                 // build | survival | arena
    let pending = 0, waveId = 0, hp = 10, hurtT = 0, protT = 0, atkCd = 0, kills = 0, wave = 0, waveT = 0, weapon = 'hand';
    const owned = { hand: true };
    const mons = [], arrows = [];
    const ko = [0, 0, 0, 0];
    const combat = () => gmode !== 'build';
    if (import.meta.env.DEV || location.search.includes('debug')) window.__vox = { mons, get P() { return P; }, attack: () => attack(), set: (x, y, z, t) => setBlock(x, y, z, t), get: (x, y, z) => get(x, y, z), save: () => save(), get info() { return { chunks: chunks.size, views: views.size, edits: edits.size, x: P.x, y: P.y, z: P.z }; }, get avatars() { return avatars; }, set hp(v) { hp = v; protT = 0; refreshUi(); }, get ko() { return ko; }, gold() { owned.gsword = true; owned.bow = true; weapon = 'gsword'; refreshUi(); }, spawn: (k) => spawnMonster(k), weapon: (w) => { weapon = w; refreshUi(); }, dir: () => { const d = new THREE.Vector3(); camera.getWorldDirection(d); return [d.x, d.y, d.z, atkCd, weapon, gmode, hp]; } };
    const arrowGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.7, 6), arrowMat = mat(0x9c6644);
    let arrowTpl = null; // KayKit ok modeli, uzun ekseni +Y'ye çevrilir (uçuş yönü)
    model('kw-arrow', { size: 0.8 }).then((m) => {
      const b = new THREE.Box3().setFromObject(m), sz = new THREE.Vector3(); b.getSize(sz);
      const g = new THREE.Group(); m.position.y -= sz.y / 2;
      if (sz.z > sz.y && sz.z > sz.x) m.rotation.x = Math.PI / 2; else if (sz.x > sz.y) m.rotation.z = -Math.PI / 2;
      g.add(m); arrowTpl = g;
    }).catch(() => {});
    function refreshCombat() {
      $u('.mc-hearts').hidden = !combat();
      $u('.mc-hearts').innerHTML = Array.from({ length: 10 }, (_, i) => `<i class="${i < hp ? 'on' : ''}">♥</i>`).join('');
      $u('[data-attack]').hidden = !combat();
      $u('[data-creative]').hidden = combat();
      const w = WEAPONS[weapon];
      $u('[data-weapon]').innerHTML = `${w.icon}<small>${w.ranged ? `${inv.arrows || 0} ok` : w.name}</small>`;
      const pb = $u('[data-potion]'); pb.hidden = !(inv.potion > 0); pb.innerHTML = `🧪<small>${inv.potion || 0}</small>`;
      $u('[data-attack]').innerHTML = w.ranged ? '🏹<small>At</small>' : '⚔️<small>Vur</small>';
      if (gmode === 'survival') { $u('.mc-quest').textContent = `⚔️ Dalga ${wave} · Kalan ${mons.length} · Yenilen ${kills}`; api.setHud({ score: kills, scoreLabel: 'Yenilen', extra: `Dalga ${wave}` }); }
      if (gmode === 'arena') { const names = api.mp.names; $u('.mc-quest').textContent = '🏟️ ' + names.map((n, i) => `${n} ${ko[i]}`).join(' · ') + ' (5 kazanır)'; }
    }
    // --- üretim (birleştirme) ---
    function renderCraft() {
      $u('.mc-recipes').innerHTML = RECIPES.map((r, i) => {
        const can = Object.entries(r.need).every(([t, n]) => (inv[t] || 0) >= n);
        const have = r.give !== 'arrows' && r.give !== 'potion' && owned[r.give];
        const needs = Object.entries(r.need).map(([t, n]) => `<span class="${(inv[t] || 0) >= n ? 'ok' : ''}" style="--b:${BLOCKS[t].top}"><i></i>${n} ${BLOCKS[t].name}</span>`).join('');
        return `<div class="rec ${can && !have ? 'can' : ''}"><b>${r.icon} ${r.text}</b><div class="needs">${needs}</div><button class="btn small" data-rec="${i}" ${can && !have ? '' : 'disabled'}>${have ? '✓ Var' : 'Yap'}</button></div>`;
      }).join('');
      ui.querySelectorAll('[data-rec]').forEach((b) => b.addEventListener('pointerdown', (e) => {
        e.stopPropagation();
        const r = RECIPES[+b.dataset.rec];
        Object.entries(r.need).forEach(([t, n]) => (inv[t] -= n));
        if (r.give === 'arrows') inv.arrows = (inv.arrows || 0) + r.n;
        else if (r.give === 'potion') inv.potion = (inv.potion || 0) + 1;
        else { owned[r.give] = true; weapon = r.give; }
        api.sfx.win(); api.haptic('medium'); refreshUi(); renderCraft();
      }));
    }
    $u('[data-craft]').addEventListener('pointerdown', (e) => { e.stopPropagation(); renderCraft(); $u('.mc-craft').hidden = false; api.sfx.click(); });
    $u('[data-craft-x]').addEventListener('pointerdown', (e) => { e.stopPropagation(); $u('.mc-craft').hidden = true; });
    $u('[data-weapon]').addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      const list = Object.keys(WEAPONS).filter((k) => owned[k]);
      weapon = list[(list.indexOf(weapon) + 1) % list.length]; api.sfx.click(); refreshUi();
    });
    $u('[data-potion]').addEventListener('pointerdown', (e) => {
      e.stopPropagation(); if (!(inv.potion > 0) || hp >= 10) return;
      inv.potion--; hp = Math.min(10, hp + 6); api.sfx.power(); S.popText(new THREE.Vector3(W(P.x), P.y + 2.2, W(P.z)), '+6 ♥', '#ff4d6d'); refreshUi();
    });
    // --- mod seçimi ---
    function showModes() {
      const box = $u('.mc-modes-box'); $u('.mc-modes').hidden = false;
      if (ON && ME !== 0) { box.innerHTML = '<h3>⏳ Kurucu modu seçiyor…</h3>'; return; }
      const opts = ON
        ? [['build', '🏗️', 'Birlikte İnşa', 'Aynı dünyada birlikte kazın ve inşa edin'], ['arena', '🏟️', 'Arena', 'Silah yap, arkadaşlarını yen! 5 nakavt kazanır']]
        : [['build', '🏗️', 'İnşa ve Keşif', 'Serbestçe kaz, inşa et, görevleri tamamla'], ['survival', '⚔️', 'Hayatta Kal', 'Canavar dalgalarına karşı dayan! Silah üret, savun']];
      box.innerHTML = '<h3>Mod seç</h3>' + opts.map(([k, ic, t, d]) => `<button class="mode-opt" data-gm="${k}"><span>${ic}</span><b>${t}</b><small>${d}</small></button>`).join('');
      box.querySelectorAll('[data-gm]').forEach((b) => b.addEventListener('pointerdown', (e) => { e.stopPropagation(); setMode(b.dataset.gm); if (ON) ON.send({ mode: b.dataset.gm }); }));
    }
    function setMode(m) {
      gmode = m; $u('.mc-modes').hidden = true;
      hp = 10; kills = 0; wave = 0; waveT = null; pending = 0; waveId++; ko.fill(0); protT = 2;
      arrows.splice(0).forEach((a) => scene.remove(a.m));
      mons.splice(0).forEach((mo) => scene.remove(mo.mesh));
      if (combat()) {
        creative = false;
        // savaşa hazır başlangıç: biraz tahta, taş ve yaprak
        inv[5] = Math.max(inv[5] || 0, 8); inv[3] = Math.max(inv[3] || 0, 4); inv[6] = Math.max(inv[6] || 0, 4);
        banner(m === 'survival' ? '⚔️ Hayatta Kal! İlk dalga 6 sn sonra — 🛠️ ile silah yap' : '🏟️ Arena! 🛠️ ile silah yap, arkadaşlarını yen');
      }
      api.sfx.power(); refreshUi();
    }
    let bannerT = 0;
    function banner(text) { const b = $u('.mc-banner'); b.textContent = text; b.classList.add('on'); bannerT = 3.2; }
    function hurt(n, srcX, srcZ, by = null) {
      if (protT > 0 || hp <= 0) return;
      hp -= n; hurtT = 0.35; api.sfx.wrong(); api.haptic('heavy');
      if (srcX !== undefined) { const dx = P.x - srcX, dz = P.z - srcZ, d = Math.hypot(dx, dz) || 1; P.vx += (dx / d) * 6; P.vz += (dz / d) * 6; P.vy = 5; }
      if (hp <= 0) {
        hp = 0;
        if (gmode === 'survival') {
          api.sfx.lose();
          setTimeout(() => api.gameOver({ score: kills, coins: Math.floor(kills / 2) + wave, canContinue: true, title: `Canavarlar kazandı! Dalga ${wave}` }), 600);
        } else if (gmode === 'arena') {
          if (by !== null) { ko[by]++; ON.send({ ko: { by } }); checkArenaWin(by); }
          Object.assign(P, spawnPoint(), { vx: 0, vy: 0, vz: 0 }); hp = 10; protT = 2.5; banner('Nakavt oldun! Yeniden doğdun');
        }
      }
      refreshUi();
    }
    function checkArenaWin(by) { if (ko[by] >= 5) { gmode = 'done'; api.sfx.win(); setTimeout(() => api.gameOver({ winner: by }), 900); } }
    // --- canavarlar ---
    function spawnMonster(kind) {
      for (let tries = 0; tries < 20; tries++) {
        const a = Math.random() * Math.PI * 2, d = 11 + Math.random() * 7;
        const x = P.x + Math.cos(a) * d, z = P.z + Math.sin(a) * d;
        let y = HMAX - 1; while (y > 0 && !solid(Math.floor(x), y, Math.floor(z))) y--;
        if (get(Math.floor(x), y + 1, Math.floor(z)) === 11) continue;
        const M = MONSTERS[kind], hpMul = 1 + (api.level - 1) * 0.15 + wave * 0.06;
        const mesh = buildMonster(kind); scene.add(mesh);
        mons.push({ kind, x, y: y + 1, z, vy: 0, hp: Math.round(M.hp * hpMul), mesh, atkT: 1, hop: Math.random() * 6, hitT: 0 });
        S.burst(new THREE.Vector3(W(x) - 0.5, y + 1.5, W(z) - 0.5), M.color, 10, 3, 0.8);
        return;
      }
    }
    function nextWave() {
      wave++;
      const L = api.level, n = Math.round(3 + wave * 1.5 + (L - 1) * 0.8); pending = n;
      for (let i = 0; i < n; i++) {
        const r = Math.random();
        const kind = wave >= 3 && r < Math.min(0.35, 0.1 + wave * 0.03 + L * 0.02) ? 'ghost' : wave >= 2 && r < Math.min(0.6, 0.35 + wave * 0.03) ? 'rock' : 'jelly';
        const id = waveId;
        setTimeout(() => { if (id !== waveId) return; pending--; if (gmode === 'survival') spawnMonster(kind); refreshCombat(); }, i * 450);
      }
      banner(`🌙 Dalga ${wave}! ${n} canavar geliyor`); api.sfx.power();
    }
    function killMonster(mo) {
      const M = MONSTERS[mo.kind];
      S.burst(new THREE.Vector3(W(mo.x) - 0.5, mo.y + 0.6, W(mo.z) - 0.5), M.color, 18, 5, 0.9);
      S.burst(new THREE.Vector3(W(mo.x) - 0.5, mo.y + 0.6, W(mo.z) - 0.5), 0xffd60a, 8, 4, 0.6);
      scene.remove(mo.mesh); mons.splice(mons.indexOf(mo), 1); kills++; api.sfx.pop();
      // ganimet
      let loot = '';
      if (mo.kind === 'jelly' && Math.random() < 0.5) { inv.arrows = (inv.arrows || 0) + 2; loot = '+2 ok'; }
      if (mo.kind === 'rock') { inv[Math.random() < 0.4 ? 9 : 3] = (inv[Math.random() < 0.4 ? 9 : 3] || 0) + 1; inv[3] = (inv[3] || 0) + 1; loot = '+taş'; }
      if (mo.kind === 'ghost' && Math.random() < 0.25) { inv.potion = (inv.potion || 0) + 1; loot = '+🧪'; }
      S.popText(new THREE.Vector3(W(mo.x) - 0.5, mo.y + 1.4, W(mo.z) - 0.5), `${M.name} yenildi! ${loot}`, '#fff');
      refreshUi();
    }
    function hitMonster(mo, dmg, fromX, fromZ) {
      mo.hp -= dmg; mo.hitT = 0.25; api.sfx.brick(); api.haptic('light');
      const dx = mo.x - fromX, dz = mo.z - fromZ, d = Math.hypot(dx, dz) || 1; mo.x += (dx / d) * 0.8; mo.z += (dz / d) * 0.8; mo.vy = 4;
      if (mo.hp <= 0) killMonster(mo);
    }
    function entityBlocked(x, y, z, w, h) {
      for (let bx = Math.floor(x - w); bx <= Math.floor(x + w); bx++) for (let bz = Math.floor(z - w); bz <= Math.floor(z + w); bz++) for (let by = Math.floor(y); by <= Math.floor(y + h - 0.01); by++) if (solid(bx, by, bz)) return true;
      return false;
    }
    function updateMonsters(dt, time) {
      const spMul = 1 + (api.level - 1) * 0.06;
      for (const mo of [...mons]) {
        const M = MONSTERS[mo.kind];
        const dx = P.x - mo.x, dz = P.z - mo.z, d = Math.hypot(dx, dz) || 1;
        const sp = M.speed * spMul * dt;
        if (M.fly) {
          mo.x += (dx / d) * sp; mo.z += (dz / d) * sp; mo.y += ((P.y + 0.8 + Math.sin(time * 2 + mo.hop) * 0.4) - mo.y) * Math.min(1, dt * 1.5);
        } else {
          const nx = mo.x + (dx / d) * sp, nz = mo.z + (dz / d) * sp, w = M.r * 0.7, h = M.r * 1.6;
          let blocked = false;
          if (!entityBlocked(nx, mo.y, mo.z, w, h)) mo.x = nx; else blocked = true;
          if (!entityBlocked(mo.x, mo.y, nz, w, h)) mo.z = nz; else blocked = true;
          const grounded = entityBlocked(mo.x, mo.y - 0.05, mo.z, w, 0.05);
          if (grounded && (blocked || (mo.kind === 'jelly' && Math.sin(time * 4 + mo.hop) > 0.95))) mo.vy = 8.2;
          // takılırsa (yüksek duvar, çukur) oyuncunun biraz uzağına yeniden belirir
          mo.stuck = blocked && grounded ? (mo.stuck || 0) + dt : 0;
          if (mo.stuck > 2.5) { mo.stuck = 0; for (let t = 0; t < 12; t++) { const a = Math.random() * 6.283, r = 6 + Math.random() * 4, x = P.x + Math.cos(a) * r, z = P.z + Math.sin(a) * r; let y = HMAX - 1; while (y > 0 && !solid(Math.floor(x), y, Math.floor(z))) y--; if (get(Math.floor(x), y + 1, Math.floor(z)) === 11) continue; mo.x = x; mo.z = z; mo.y = y + 1; mo.vy = 0; S.burst(new THREE.Vector3(W(x) - 0.5, y + 1.5, W(z) - 0.5), M.color, 8, 3, 0.6); break; } }
          mo.vy -= 20 * dt;
          const ny = mo.y + mo.vy * dt;
          if (mo.vy < 0 && entityBlocked(mo.x, ny, mo.z, w, 0.05)) { mo.y = Math.floor(ny) + 1; mo.vy = 0; } else if (mo.vy > 0 && entityBlocked(mo.x, ny + h, mo.z, w, 0.05)) mo.vy = 0; else mo.y = ny;
          if (mo.y < -3) { scene.remove(mo.mesh); mons.splice(mons.indexOf(mo), 1); continue; }
        }
        mo.atkT -= dt; if (mo.hitT > 0) mo.hitT -= dt;
        const dist3 = Math.hypot(dx, dz, P.y + 0.8 - (mo.y + M.r));
        if (dist3 < M.r + 0.7 && mo.atkT <= 0) { mo.atkT = 1.2; hurt(M.dmg, mo.x, mo.z); }
        mo.mesh.position.set(W(mo.x) - 0.5, mo.y, W(mo.z) - 0.5);
        mo.mesh.rotation.y = Math.atan2(-dx, -dz);
        const hit = mo.hitT > 0; if (hit !== mo.flashed) { mo.flashed = hit; mo.mesh.userData.flash(hit); }
        mo.mesh.userData.update(dt * (M.fly ? 1 : 1.4));
      }
    }
    // --- saldırı ---
    function attack() {
      if (!combat() || atkCd > 0 || gmode === 'done') return;
      const w = WEAPONS[weapon];
      const dir = new THREE.Vector3(); camera.getWorldDirection(dir);
      swing = 0.35;
      if (w.ranged) {
        if (!(inv.arrows > 0)) { api.sfx.wrong(); banner('Ok kalmadı — 🛠️ ile ok yap'); return; }
        inv.arrows--; atkCd = 0.55;
        const o = new THREE.Vector3(P.x, P.y + 1.45, P.z).addScaledVector(dir, 0.6);
        shootArrow(o, dir, true);
        if (ON) ON.send({ arrow: [o.x, o.y, o.z, dir.x, dir.y, dir.z].map((v) => Math.round(v * 100) / 100) });
        api.sfx.swap(); refreshUi(); return;
      }
      atkCd = 0.45; api.sfx.tap(); if (ON) ON.send({ swing: 1 });
      const fx = dir.x, fz = dir.z, fl = Math.hypot(fx, fz) || 1;
      let best = null, bd = 99;
      const consider = (x, y, z, obj, isAv) => {
        const dx = x - P.x, dz = z - P.z, dy = y - (P.y + 0.9), d = Math.hypot(dx, dz, dy);
        if (d > w.reach + 0.5) return;
        const cos = (dx * fx + dz * fz) / ((Math.hypot(dx, dz) || 1) * fl);
        if (cos < 0.55) return;
        if (d < bd) { bd = d; best = { obj, isAv }; }
      };
      mons.forEach((mo) => consider(mo.x, mo.y + 0.5, mo.z, mo, false));
      if (gmode === 'arena') for (const k in avatars) consider(avatars[k].x, avatars[k].y + 0.9, avatars[k].z, +k, true);
      if (!best) return;
      if (best.isAv) { ON.send({ pvp: { to: best.obj, dmg: w.dmg } }); const a = avatars[best.obj]; S.burst(new THREE.Vector3(W(a.x) - 0.5, a.y + 1, W(a.z) - 0.5), 0xffffff, 8, 3, 0.6); api.sfx.brick(); }
      else hitMonster(best.obj, w.dmg, P.x, P.z);
    }
    function shootArrow(o, dir, mine) {
      const m = arrowTpl ? arrowTpl.clone(true) : new THREE.Mesh(arrowGeo, arrowMat); scene.add(m);
      arrows.push({ m, x: o.x, y: o.y, z: o.z, vx: dir.x * 24, vy: dir.y * 24, vz: dir.z * 24, life: 3, mine });
    }
    function updateArrows(dt) {
      for (const a of [...arrows]) {
        a.vy -= 7 * dt; a.x += a.vx * dt; a.y += a.vy * dt; a.z += a.vz * dt; a.life -= dt;
        a.m.position.set(W(a.x) - 0.5, a.y, W(a.z) - 0.5);
        a.m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(a.vx, a.vy, a.vz).normalize());
        let done = a.life <= 0 || solid(Math.floor(a.x), Math.floor(a.y), Math.floor(a.z));
        if (!done && a.mine) {
          for (const mo of mons) { if (Math.hypot(a.x - mo.x, a.y - (mo.y + MONSTERS[mo.kind].r), a.z - mo.z) < MONSTERS[mo.kind].r + 0.25) { hitMonster(mo, WEAPONS.bow.dmg, a.x - a.vx * 0.05, a.z - a.vz * 0.05); done = true; break; } }
          if (!done && gmode === 'arena') for (const k in avatars) { const av = avatars[k]; if (Math.hypot(a.x - av.x, a.y - (av.y + 0.9), a.z - av.z) < 0.6) { ON.send({ pvp: { to: +k, dmg: WEAPONS.bow.dmg } }); done = true; api.sfx.brick(); break; } }
        }
        if (done) { scene.remove(a.m); arrows.splice(arrows.indexOf(a), 1); }
      }
    }

    $u('[data-cam]').addEventListener('pointerdown', (e) => { e.stopPropagation(); firstPerson = !firstPerson; api.sfx.click(); refreshUi(); });
    $u('[data-creative]').addEventListener('pointerdown', (e) => { e.stopPropagation(); creative = !creative; api.sfx.click(); S.popText(new THREE.Vector3(W(P.x), P.y + 2.2, W(P.z)), creative ? 'Yaratıcı mod: sınırsız blok' : 'Hayatta kalma: kırdığını kullan', '#fff'); refreshUi(); });
    const nb = $u('[data-new]'); let newArm = 0;
    if (nb) nb.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      if (Date.now() - newArm < 2500) { start(true); newArm = 0; nb.textContent = '🌍'; return; }
      newArm = Date.now(); nb.textContent = 'Emin?'; setTimeout(() => (nb.textContent = '🌍'), 2500);
    });

    // ---------- kontroller ----------
    const stick = { id: null, ox: 0, oy: 0, x: 0, y: 0 };
    const look = { id: null, lx: 0, ly: 0, sx: 0, sy: 0, t: 0, moved: 0 };
    let jumpHeld = false, mineHeld = false, mineByHold = false;
    const stickEl = $u('.mc-stick');
    const btnHold = (sel_, on, off) => {
      const b = $u(sel_);
      b.addEventListener('pointerdown', (e) => { e.stopPropagation(); e.preventDefault(); b.classList.add('down'); on(); });
      ['pointerup', 'pointercancel', 'pointerleave'].forEach((ev) => b.addEventListener(ev, () => { b.classList.remove('down'); off?.(); }));
    };
    btnHold('[data-jump]', () => (jumpHeld = true), () => (jumpHeld = false));
    btnHold('[data-mine]', () => (mineHeld = true), () => (mineHeld = false));
    btnHold('[data-place]', () => place());
    let attackHeld = false;
    btnHold('[data-attack]', () => { attackHeld = true; attack(); }, () => (attackHeld = false));
    S.el.addEventListener('pointerdown', (e) => {
      const r = S.el.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      if (x < r.width * 0.45 && y > r.height * 0.45 && stick.id === null) {
        stick.id = e.pointerId; stick.ox = x; stick.oy = y; stick.x = 0; stick.y = 0;
        stickEl.style.left = x + 'px'; stickEl.style.top = y + 'px'; stickEl.classList.add('on');
      } else if (look.id === null) {
        look.id = e.pointerId; look.lx = e.clientX; look.ly = e.clientY; look.sx = e.clientX; look.sy = e.clientY; look.t = performance.now(); look.moved = 0;
      }
    });
    S.el.addEventListener('pointermove', (e) => {
      if (e.pointerId === stick.id) {
        const r = S.el.getBoundingClientRect(); let dx = e.clientX - r.left - stick.ox, dy = e.clientY - r.top - stick.oy;
        const d = Math.hypot(dx, dy), max = 55; if (d > max) { dx *= max / d; dy *= max / d; }
        stick.x = dx / max; stick.y = dy / max; stickEl.firstElementChild.style.transform = `translate(${dx}px,${dy}px)`;
      } else if (e.pointerId === look.id) {
        const dx = e.clientX - look.lx, dy = e.clientY - look.ly; look.lx = e.clientX; look.ly = e.clientY;
        look.moved += Math.abs(dx) + Math.abs(dy);
        camYaw -= dx * 0.008; camPitch = Math.max(-1.1, Math.min(1.3, camPitch + dy * 0.006));
        if (look.moved > 12) mineByHold = false;
      }
    });
    const endPtr = (e) => {
      if (e.pointerId === stick.id) { stick.id = null; stick.x = stick.y = 0; stickEl.classList.remove('on'); stickEl.firstElementChild.style.transform = ''; }
      if (e.pointerId === look.id) {
        // kısa dokunuş = koy, basılı tutma = kır (bakış sürüklemesi değilse)
        if (look.moved < 12 && performance.now() - look.t < 300 && !mineByHold) place();
        look.id = null; mineByHold = false;
      }
    };
    S.el.addEventListener('pointerup', endPtr); S.el.addEventListener('pointercancel', endPtr);
    const keys = {};
    const kd = (e) => { keys[e.key.toLowerCase()] = true; if (e.key === ' ') jumpHeld = true; if (e.key.toLowerCase() === 'e') place(); if (e.key.toLowerCase() === 'q') mineHeld = true; if (e.key.toLowerCase() === 'f') attackHeld = true; if (e.key.toLowerCase() === 'r') $u('[data-weapon]').dispatchEvent(new Event('pointerdown')); if (/^[0-9]$/.test(e.key)) { sel = HOTBAR[(+e.key + 9) % 10]; refreshUi(); } };
    const ku = (e) => { keys[e.key.toLowerCase()] = false; if (e.key === ' ') jumpHeld = false; if (e.key.toLowerCase() === 'q') mineHeld = false; if (e.key.toLowerCase() === 'f') attackHeld = false; };
    window.addEventListener('keydown', kd); window.addEventListener('keyup', ku);

    // ---------- hedefleme (ekran ortasından ışın, voxel DDA) ----------
    const REACH = 6;
    function target() {
      const dir = new THREE.Vector3(); camera.getWorldDirection(dir);
      const o = camera.position.clone();
      // sahne → dünya koordinatı
      let ox = o.x + SIZE / 2, oy = o.y, oz = o.z + SIZE / 2;
      let x = Math.floor(ox), y = Math.floor(oy), z = Math.floor(oz);
      const sx = Math.sign(dir.x), sy = Math.sign(dir.y), sz = Math.sign(dir.z);
      const tdx = Math.abs(1 / dir.x), tdy = Math.abs(1 / dir.y), tdz = Math.abs(1 / dir.z);
      let tmx = (sx > 0 ? x + 1 - ox : ox - x) * tdx, tmy = (sy > 0 ? y + 1 - oy : oy - y) * tdy, tmz = (sz > 0 ? z + 1 - oz : oz - z) * tdz;
      let n = [0, 0, 0], t = 0;
      const head = new THREE.Vector3(P.x, P.y + 1.5, P.z);
      for (let i = 0; i < 80; i++) {
        const b = get(x, y, z);
        const dist = Math.hypot(x + 0.5 - head.x, y + 0.5 - head.y, z + 0.5 - head.z);
        if (b && b !== 11 && dist <= REACH + 0.5 && t > 0.05) return { x, y, z, t: b, nx: n[0], ny: n[1], nz: n[2] };
        if (t > 30) break;
        if (tmx < tmy && tmx < tmz) { x += sx; t = tmx; tmx += tdx; n = [-sx, 0, 0]; }
        else if (tmy < tmz) { y += sy; t = tmy; tmy += tdy; n = [0, -sy, 0]; }
        else { z += sz; t = tmz; tmz += tdz; n = [0, 0, -sz]; }
      }
      return null;
    }
    const hl = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(1.01, 1.01, 1.01)), new THREE.LineBasicMaterial({ color: 0x111111 })); hl.visible = false; scene.add(hl);
    const crack = new THREE.Mesh(new THREE.BoxGeometry(1.02, 1.02, 1.02), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0 })); scene.add(crack);
    let tgt = null, mining = { key: '', p: 0 }, swing = 0;

    // ---------- blok değişimi ----------
    function setBlock(x, y, z, t, remote = false, who = null) {
      if (!inB(x, y, z)) return false;
      const prev = get(x, y, z); if (prev === t) return false;
      setRaw(x, y, z, t);
      const pos = new THREE.Vector3(W(x), y + 0.5, W(z));
      if (!t && prev) S.burst(pos, new THREE.Color(BLOCKS[prev].side).getHex(), 10, 3, 0.7);
      if (!remote) { if (ON) ON.send({ set: [x, y, z, t] }); else saveChange(x, y, z, t); }
      else if (who !== null && avatars[who]) avatars[who].swing = 0.3;
      return true;
    }
    function place() {
      if (!tgt) return;
      if (!creative && !(inv[sel] > 0)) { api.sfx.wrong(); S.popText(new THREE.Vector3(W(P.x), P.y + 2.2, W(P.z)), `${BLOCKS[sel].name} kalmadı — kazarak topla`, '#ffd60a'); return; }
      const x = tgt.x + tgt.nx, y = tgt.y + tgt.ny, z = tgt.z + tgt.nz;
      if (!inB(x, y, z) || (get(x, y, z) && get(x, y, z) !== 11)) return;
      // oyuncunun içine blok koyma
      if (x + 1 > P.x - PW && x < P.x + PW && z + 1 > P.z - PW && z < P.z + PW && y + 1 > P.y && y < P.y + PH) { api.sfx.wrong(); return; }
      setBlock(x, y, z, sel); swing = 0.3; api.sfx.tap(); api.haptic('light');
      if (!creative) inv[sel]--;
      stats.placed++; stats.byType[sel] = (stats.byType[sel] || 0) + 1;
      checkQuest(); refreshUi();
    }
    function mineStep(dt) {
      if (!tgt) { mining.p = 0; return; }
      const key = `${tgt.x},${tgt.y},${tgt.z}`;
      if (mining.key !== key) { mining.key = key; mining.p = 0; }
      const hard = creative ? 0.12 : BLOCKS[tgt.t].hard || 0.5;
      mining.p += dt / hard; swing = Math.max(swing, 0.25);
      if (Math.floor(mining.p * 4) !== Math.floor((mining.p - dt / hard) * 4)) api.sfx.click();
      if (mining.p >= 1) {
        if (tgt.y === 0) { mining.p = 0; api.sfx.wrong(); return; } // en alt katman kırılmaz
        const t = tgt.t, drop = BLOCKS[t].drop || t;
        setBlock(tgt.x, tgt.y, tgt.z, 0); api.sfx.brick(); api.haptic('medium');
        if (!creative && t !== 6) { inv[drop] = (inv[drop] || 0) + 1; S.popText(new THREE.Vector3(W(tgt.x), tgt.y + 1, W(tgt.z)), `+1 ${BLOCKS[drop].name}`, '#fff'); }
        stats.broken++; stats.minedBy[t] = (stats.minedBy[t] || 0) + 1;
        mining.p = 0; mining.key = ''; checkQuest(); refreshUi();
      }
    }
    function checkQuest() {
      if (ON) return;
      const q = QUESTS[stats.quest];
      if (q && q.check(stats)) { store.addCoins(q.reward); api.sfx.win(); S.popText(new THREE.Vector3(W(P.x), P.y + 2.6, W(P.z)), `Görev tamam! +${q.reward} 🪙`, '#ffd60a'); stats.quest++; save(); }
    }

    // ---------- kayıt ----------
    let saveT = 0;
    function saveChange() {} // değişiklikler setRaw içinde parça bazında tutulur
    function packEdits() { const o = {}; for (const [k, e] of edits) if (e.size) o[k] = [...e].flat(); return o; }
    function save() { if (ON) return; try { localStorage.setItem(SAVE_KEY, JSON.stringify({ v: 3, seed: worldSeed, edits: packEdits(), stats, inv, p: [P.x, P.y, P.z], creative })); } catch {} }
    function start(fresh = false) {
      let saved = null;
      edits.clear();
      if (ON) { worldSeed = hashCode(api.mp.room?.code || 'oda'); }
      else {
        try { saved = JSON.parse(localStorage.getItem(SAVE_KEY)); } catch {}
        if (saved && saved.v !== 3) saved = null; // eski 40×40 dünya kaydı → yeni sonsuz dünya
        if (saved && !fresh) { worldSeed = saved.seed; for (const k in saved.edits || {}) { const arr = saved.edits[k], m = new Map(); for (let i = 0; i < arr.length; i += 2) m.set(arr[i], arr[i + 1]); edits.set(k, m); } Object.assign(stats, saved.stats || {}); Object.keys(inv).forEach((k) => delete inv[k]); Object.assign(inv, saved.inv || START_INV); creative = !!saved.creative; }
        else { worldSeed = (Math.random() * 1e9) | 0; Object.assign(stats, { placed: 0, broken: 0, byType: {}, minedBy: {}, maxHeight: 0, quest: 0 }); Object.keys(inv).forEach((k) => delete inv[k]); Object.assign(inv, START_INV); }
      }
      resetWorld();
      const sp = saved && !fresh && saved.p ? { x: saved.p[0], y: saved.p[1], z: saved.p[2] } : spawnPoint();
      if (ON && ME > 0) {
        // diğer oyuncular kurucunun çevresinde, boş bir yerde doğar
        const ang = (ME / 4) * Math.PI * 2;
        for (let r = 2; r < 8; r++) {
          const x = sp.x + Math.cos(ang) * r, z = sp.z + Math.sin(ang) * r;
          let y = HMAX - 2; while (y > 0 && !solid(Math.floor(x), y - 1, Math.floor(z))) y--;
          if (!collides(x, y + 0.01, z)) { sp.x = x; sp.y = y + 0.01; sp.z = z; break; }
        }
      }
      camYaw = Math.PI;
      Object.assign(P, sp, { vx: 0, vy: 0, vz: 0 });
      updateChunks(P.x, P.z, 999); // başlangıçta çevre hemen hazır olsun
      refreshUi(); save();
      api.setHud({ score: ON ? '🌐' : stats.quest, scoreLabel: ON ? 'Online' : 'Görev', extra: 'Sol: yürü · Sağ: bak · Basılı tut: kır · Dokun: koy' });
    }

    // ---------- online: diğer oyuncular ----------
    const avatars = {};
    let sendT = 0, lastSent = '';
    ON?.on((m) => {
      if (m.set) { const [x, y, z, t] = m.set; setBlock(x, y, z, t, true, m.from ?? null); }
      if (m.mode && m.from !== ME) setMode(m.mode);
      if (m.pvp && m.pvp.to === ME && gmode === 'arena') { const a = avatars[m.from]; hurt(m.pvp.dmg, a?.x, a?.z, m.from); }
      if (m.ko && m.from !== ME && gmode === 'arena') { ko[m.ko.by]++; if (m.ko.by === ME) { api.sfx.win(); banner(`💥 ${api.mp.names[m.from] || 'Rakip'} nakavt!`); } refreshUi(); checkArenaWin(m.ko.by); }
      if (m.arrow && m.from !== ME) { const [x, y, z, dx, dy, dz] = m.arrow; shootArrow({ x, y, z }, { x: dx, y: dy, z: dz }, false); }
      if (m.swing && m.from !== ME && avatars[m.from]) avatars[m.from].swing = 0.35;
      if (m.pos && m.from !== undefined && m.from !== ME) {
        let a = avatars[m.from];
        if (!a) {
          a = avatars[m.from] = { mesh: buildHero(PCOLORS[m.from] || 0xffffff), x: m.pos[0], y: m.pos[1], z: m.pos[2], yaw: m.pos[3], tx: 0, ty: 0, tz: 0, tyaw: 0, swing: 0, walk: 0 };
          scene.add(a.mesh);
          const tag = document.createElement('div'); tag.className = 'mc-tag'; tag.textContent = api.mp.names[m.from] || ''; tag.style.background = '#' + (PCOLORS[m.from] || 0x888888).toString(16).padStart(6, '0'); ui.appendChild(tag); a.tag = tag;
        }
        [a.tx, a.ty, a.tz, a.tyaw] = m.pos;
      }
    });

    // ---------- döngü ----------
    let walkT = 0, hudTick = 0;
    const lp = S.loop((dt, time) => {
      // hareket girdisi (kameraya göre)
      let mx = stick.x, mz = stick.y;
      if (keys.w || keys.arrowup) mz = -1; if (keys.s || keys.arrowdown) mz = 1; if (keys.a || keys.arrowleft) mx = -1; if (keys.d || keys.arrowright) mx = 1;
      const len = Math.hypot(mx, mz); if (len > 1) { mx /= len; mz /= len; }
      const speed = P.inWater ? 2.6 : 4.6;
      const fx = -Math.sin(camYaw), fz = -Math.cos(camYaw), rx = Math.cos(camYaw), rz = -Math.sin(camYaw);
      const wx = (fx * -mz + rx * mx) * speed, wz = (fz * -mz + rz * mx) * speed;
      P.vx += (wx - P.vx) * Math.min(1, dt * 12); P.vz += (wz - P.vz) * Math.min(1, dt * 12);
      P.inWater = get(Math.floor(P.x), Math.floor(P.y + 0.4), Math.floor(P.z)) === 11;
      if (P.inWater) { P.vy -= 8 * dt; P.vy = Math.max(P.vy, -2.5); if (jumpHeld) P.vy = 3.2; }
      else { P.vy -= 26 * dt; if (jumpHeld && P.onGround) { P.vy = 8.4; api.sfx.tap(); } }
      P.onGround = false;
      const steps = 3;
      for (let i = 0; i < steps; i++) { moveAxis('x', P.vx * dt / steps); moveAxis('z', P.vz * dt / steps); moveAxis('y', P.vy * dt / steps); }
      if (P.y < -5) Object.assign(P, spawnPoint(), { vy: 0 });
      stats.maxHeight = Math.max(stats.maxHeight, Math.floor(P.y));
      // karakter görünümü
      const moving = Math.hypot(P.vx, P.vz) > 0.5;
      if (moving) P.yaw = Math.atan2(-P.vx, -P.vz);
      hero.position.set(W(P.x) - 0.5, P.y, W(P.z) - 0.5);
      let dy = P.yaw - hero.rotation.y; dy = Math.atan2(Math.sin(dy), Math.cos(dy)); hero.rotation.y += dy * Math.min(1, dt * 12);
      walkT += dt * (moving && P.onGround ? 10 : 0);
      const sw = moving ? Math.sin(walkT) * 0.8 : 0, u = hero.userData;
      u.legL.rotation.x = sw; u.legR.rotation.x = -sw; u.armL.rotation.x = -sw * 0.7;
      if (swing > 0) swing -= dt;
      u.armR.rotation.x = swing > 0 ? -1.2 - Math.sin(time * 30) * 0.6 : sw * 0.7;
      u.anim(dt, moving && P.onGround, swing > 0.25);
      // kamera
      const head = new THREE.Vector3(W(P.x) - 0.5, P.y + 1.55, W(P.z) - 0.5);
      const look3 = new THREE.Vector3(-Math.sin(camYaw) * Math.cos(camPitch), -Math.sin(camPitch), -Math.cos(camYaw) * Math.cos(camPitch));
      if (firstPerson) { camera.position.copy(head); camera.lookAt(head.clone().add(look3)); }
      else {
        // arkadan takip; arada blok varsa kamera yaklaşır
        let d = 4.6; const back = look3.clone().multiplyScalar(-1);
        for (let k = 0.3; k <= 4.6; k += 0.2) { const p = head.clone().addScaledVector(back, k); if (solid(Math.floor(p.x + SIZE / 2), Math.floor(p.y), Math.floor(p.z + SIZE / 2))) { d = Math.max(0.6, k - 0.3); break; } }
        const shoulder = new THREE.Vector3(Math.cos(camYaw), 0, -Math.sin(camYaw)).multiplyScalar(0.45);
        camera.position.copy(head).addScaledVector(back, d).add(shoulder).add(new THREE.Vector3(0, 0.25, 0));
        camera.lookAt(head.clone().add(shoulder).addScaledVector(look3, 4));
      }
      // hedef ve kırma
      tgt = target();
      hl.visible = !!tgt; crack.visible = !!tgt && mining.p > 0;
      if (tgt) { hl.position.set(W(tgt.x), tgt.y + 0.5, W(tgt.z)); crack.position.copy(hl.position); crack.material.opacity = Math.min(0.6, mining.p * 0.6); }
      // ekrana basılı tutunca kır (bakış sürüklemesi yoksa)
      if (look.id !== null && look.moved < 12 && performance.now() - look.t > 300) mineByHold = true;
      if (mineHeld || mineByHold) mineStep(dt); else mining.p = Math.max(0, mining.p - dt * 2);
      $u('.mc-break').style.opacity = mining.p > 0 ? 1 : 0; $u('.mc-break i').style.width = `${Math.min(1, mining.p) * 100}%`;
      // savaş
      if (atkCd > 0) atkCd -= dt; if (protT > 0) protT -= dt;
      if (attackHeld) attack();
      if (bannerT > 0) { bannerT -= dt; if (bannerT <= 0) $u('.mc-banner').classList.remove('on'); }
      if (hurtT > 0) hurtT -= dt; $u('.mc-hurt').style.opacity = hurtT > 0 ? hurtT * 2 : 0;
      hero.visible = !firstPerson && !(protT > 0 && combat() && Math.sin(time * 30) > 0);
      if (gmode === 'survival') {
        updateMonsters(dt, time);
        if (!mons.length && !pending && hp > 0) {
          if (waveT === null) { waveT = wave === 0 ? 6 : 10; if (wave > 0) { banner(`✅ Dalga ${wave} temizlendi! 10 sn mola — silah yap, iyileş`); api.sfx.coin(); hp = Math.min(10, hp + 2); refreshUi(); } }
          waveT -= dt; if (waveT <= 0) { waveT = null; nextWave(); }
        }
        if (Math.floor(time * 2) !== hudTick) { hudTick = Math.floor(time * 2); refreshCombat(); }
      }
      updateArrows(dt);
      // nişangah: menzilde düşman varsa kırmızı
      if (combat()) {
        const dir = new THREE.Vector3(); camera.getWorldDirection(dir);
        const w = WEAPONS[weapon], reach = w.ranged ? 30 : w.reach + 0.5;
        const onAim = (x, y, z) => { const dx = x - P.x, dy = y - (P.y + 1.45), dz = z - P.z, d = Math.hypot(dx, dy, dz); if (d > reach) return false; return (dx * dir.x + dy * dir.y + dz * dir.z) / d > (w.ranged ? 0.985 : 0.75); };
        let aim = mons.some((mo) => onAim(mo.x, mo.y + MONSTERS[mo.kind].r, mo.z));
        if (!aim && gmode === 'arena') for (const k in avatars) if (onAim(avatars[k].x, avatars[k].y + 0.9, avatars[k].z)) aim = true;
        $u('.mc-cross').classList.toggle('enemy', aim);
      } else $u('.mc-cross').classList.remove('enemy');
      // diğer oyuncular
      for (const k in avatars) {
        const a = avatars[k]; const ox = a.x, oz = a.z;
        a.x += (a.tx - a.x) * Math.min(1, dt * 8); a.y += (a.ty - a.y) * Math.min(1, dt * 8); a.z += (a.tz - a.z) * Math.min(1, dt * 8);
        a.mesh.position.set(W(a.x) - 0.5, a.y, W(a.z) - 0.5); a.mesh.rotation.y = a.tyaw;
        const mv = Math.hypot(a.x - ox, a.z - oz) / Math.max(dt, 0.001) > 0.5; a.walk += dt * (mv ? 10 : 0);
        const s2 = mv ? Math.sin(a.walk) * 0.8 : 0, au = a.mesh.userData; au.legL.rotation.x = s2; au.legR.rotation.x = -s2;
        if (a.swing > 0) a.swing -= dt; au.armR.rotation.x = a.swing > 0 ? -1.4 : s2 * 0.7;
        au.anim(dt, mv, a.swing > 0.2);
        const v = new THREE.Vector3(W(a.x) - 0.5, a.y + 2.2, W(a.z) - 0.5).project(camera);
        a.tag.style.display = v.z < 1 ? '' : 'none'; a.tag.style.left = `${(v.x + 1) / 2 * S.w}px`; a.tag.style.top = `${(1 - v.y) / 2 * S.h}px`;
      }
      // konum paylaşımı: hareket varsa saniyede en fazla 2 kez (maliyeti düşük tutmak için)
      if (ON) {
        sendT -= dt;
        const s = [P.x, P.y, P.z, P.yaw].map((v) => Math.round(v * 10) / 10);
        const key = s.join(',');
        if (sendT <= 0 && key !== lastSent) { ON.send({ pos: s }); lastSent = key; sendT = 0.5; }
      }
      // gün ışığı yavaşça döner (4 dakikalık gün)
      const day = (Math.sin(time * Math.PI * 2 / 240) + 1) / 2;
      scene.background.setRGB(0.25 + day * 0.28, 0.35 + day * 0.46, 0.55 + day * 0.37);
      scene.fog.color.copy(scene.background); sun.intensity = 0.4 + day * 1.2; hemi.intensity = 0.5 + day * 0.6;
      sun.position.set(head.x + 10, 25, head.z + 8); sun.target.position.copy(head);
      updateChunks(P.x, P.z);
      const wy = Math.sin(time * 1.5) * 0.03 - 0.06; for (const m of waterMeshes) m.position.y = wy;
      saveT -= dt; if (saveT <= 0) { save(); saveT = 5; }
      S.updateParts(dt, 0);
    });
    start(); showModes();
    return {
      pause: () => { save(); lp.pause(); }, resume: () => lp.resume(),
      restart() { const m = gmode; start(false); if (m === 'build') showModes(); else setMode(m === 'done' ? 'arena' : m); },
      continue() { hp = 10; protT = 3; mons.forEach((mo) => { const dx = mo.x - P.x, dz = mo.z - P.z, d = Math.hypot(dx, dz) || 1; if (d < 6) { mo.x += (dx / d) * 6; mo.z += (dz / d) * 6; } }); refreshUi(); lp.resume?.(); },
      destroy() { save(); window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku); ui.remove(); S.destroy(); },
    };
  },
};
