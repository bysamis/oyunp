// 🎨 Renk Avcısı 3D: yazının RENGİNE bas, anlamına değil
import { create3D, mat, THREE } from '../core/three-stage.js';
import { expert, expertSteps } from '../core/expert.js';
import { roundedBox } from '../core/board3d.js';

const COLS = [
  { n: 'KIRMIZI', c: '#ef233c' }, { n: 'MAVİ', c: '#3a86ff' }, { n: 'YEŞİL', c: '#2dc653' },
  { n: 'SARI', c: '#ffc300' }, { n: 'MOR', c: '#9d4edd' }, { n: 'TURUNCU', c: '#fb8500' },
];

function wordTex(text, color) {
  const cv = document.createElement('canvas'); cv.width = 1024; cv.height = 256; const c = cv.getContext('2d');
  c.fillStyle = '#ffffff'; c.fillRect(0, 0, 1024, 256);
  c.fillStyle = color; c.font = '900 150px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(text, 512, 138);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}
function labelTex(text) {
  const cv = document.createElement('canvas'); cv.width = 512; cv.height = 128; const c = cv.getContext('2d');
  c.fillStyle = '#fff'; c.font = '900 64px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.shadowColor = 'rgba(0,0,0,.4)'; c.shadowBlur = 8; c.fillText(text, 256, 68);
  const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export default {
  id: 'colortap', title: 'Renk Avcısı 3D', emoji: '🎨', color: '#ef233c',
  desc: 'Yazının rengine bas, anlamına değil!',
  expertFrom: 12,
  target: (L) => Math.round(150 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 45, bg: 0xf1f3f5 });
    const { scene, camera } = S;
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), mat(0xdee2e6)); floor.rotation.x = -Math.PI / 2; floor.position.y = -0.3; floor.receiveShadow = true; scene.add(floor);
    // tabela
    const sign = new THREE.Group(); scene.add(sign);
    const board = new THREE.Mesh(roundedBox(6.4, 0.3, 1.8, 0.2), mat(0x343a40)); board.rotation.x = Math.PI / 2; sign.add(board);
    const face = new THREE.Mesh(new THREE.PlaneGeometry(6, 1.5), new THREE.MeshBasicMaterial()); face.position.z = 0.32; sign.add(face);
    { const cv = document.createElement('canvas'); cv.width = 1024; cv.height = 128; const c = cv.getContext('2d'); c.fillStyle = '#495057'; c.font = '800 64px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('Yazının RENGİ hangisi?', 512, 66);
      const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; const q = new THREE.Mesh(new THREE.PlaneGeometry(5.6, 0.7), new THREE.MeshBasicMaterial({ map: t, transparent: true })); q.position.set(0, 1.3, 0.2); sign.add(q); }
    for (const s of [-1, 1]) { const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 4), mat(0x6c757d, { metalness: 0.6 })); post.position.set(s * 2.6, -2.5, -0.1); sign.add(post); }
    sign.position.set(0, 4.6, -3);
    const barBg = new THREE.Mesh(new THREE.BoxGeometry(5.6, 0.18, 0.18), mat(0xced4da)); barBg.position.set(0, 3.25, -2.9); scene.add(barBg);
    const bar = new THREE.Mesh(new THREE.BoxGeometry(5.6, 0.2, 0.2), mat(0x2dc653, { emissive: 0x2dc653, emissiveIntensity: 0.3 })); bar.position.set(0, 3.25, -2.85); scene.add(bar);
    const btnG = new THREE.Group(); scene.add(btnG);
    let buttons = [];
    let word, ink, opts, timer, maxT, score, streak, over, L, lives, shakeT = 0, n;
    function start() { L = api.level; n = L >= 3 ? 6 : 4; score = 0; streak = 0; over = false; lives = 3; next(); }
    function next() {
      const pool = COLS.slice(0, n);
      ink = pool[(Math.random() * n) | 0];
      do { word = pool[(Math.random() * n) | 0]; } while (word === ink && Math.random() < 0.85);
      opts = pool.slice().sort(() => Math.random() - 0.5);
      maxT = Math.max(0.75, 3 - L * 0.2 - streak * 0.04) / (1 + (expert(L, 11) - 1) * 0.5); timer = maxT;
      hud();
    }
    function hud() { api.setHud({ score, extra: `${'❤️'.repeat(lives)} · Seri ${streak}` }); }
    function wrong() {
      lives--; streak = 0; shakeT = 0.3; api.sfx.wrong(); api.haptic('medium');
      if (lives <= 0) { over = true; api.sfx.lose(); api.gameOver({ score, coins: Math.floor(score / 12), canContinue: true, title: 'Gözlerin kandı! 🎨' }); }
      else next();
    }
    function buildButtons() {
      btnG.clear(); buttons = [];
      const rows = n / 2;
      opts.forEach((o, i) => {
        const g = new THREE.Group(); g.position.set((i % 2 - 0.5) * 3.1, 0, ((i / 2) | 0) * 1.9 - (rows - 1) * 0.95 + 0.6);
        const base = new THREE.Mesh(roundedBox(2.9, 0.3, 1.7, 0.25), mat(0x495057)); base.position.y = -0.3; base.receiveShadow = true; g.add(base);
        const cap = new THREE.Mesh(roundedBox(2.7, 0.4, 1.5, 0.25), mat(new THREE.Color(o.c), { roughness: 0.3 })); cap.castShadow = true; g.add(cap);
        const label = L >= 2 ? COLS[(i + 2) % n].n : o.n;
        if (L < 5) { const lp2 = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.6), new THREE.MeshBasicMaterial({ map: labelTex(label), transparent: true, depthWrite: false })); lp2.rotation.x = -Math.PI / 2; lp2.position.y = 0.41; g.add(lp2); }
        btnG.add(g); buttons.push({ g, cap, o, press: 0 });
      });
    }
    const origNext = next;
    next = function () { origNext(); face.material.map = wordTex(word.n, ink.c); face.material.needsUpdate = true; buildButtons(); sign.userData.pop = 1; };
    S.el.addEventListener('pointerdown', (e) => {
      if (over) return;
      const hit = S.pick(e, buttons.map((b) => b.g)); if (!hit) return;
      let o = hit.object; while (o && !buttons.some((b) => b.g === o)) o = o.parent;
      const b = buttons.find((q) => q.g === o); if (!b) return;
      b.press = 1;
      const p = b.g.position.clone().setY(0.6);
      if (b.o === ink) {
        streak++; const pts = 10 + Math.min(streak, 20) + Math.round(timer * 5);
        score += pts; api.sfx.pop(); api.haptic('light'); S.popText(p, '+' + pts, '#fff'); S.burst(p, new THREE.Color(ink.c).getHex(), 10, 4, 0.6); next();
      } else wrong();
    });
    S.onResize(() => {
      const vfov = (camera.fov * Math.PI) / 180, a = S.w / S.h;
      const d = Math.max(9.5, (3.6) / (Math.tan(vfov / 2) * a));
      camera.position.set(0, d * 0.75, d * 0.8); camera.lookAt(0, 1.6, -0.6);
    });
    const lp = S.loop((dt, t) => {
      if (!over) { timer -= dt; if (timer <= 0) wrong(); }
      if (shakeT > 0) shakeT -= dt;
      sign.position.x = shakeT > 0 ? (Math.random() - 0.5) * 0.4 : 0;
      sign.userData.pop = Math.max(0, (sign.userData.pop || 0) - dt * 4);
      sign.scale.setScalar(1 + sign.userData.pop * 0.12);
      const k = Math.max(0, timer / maxT);
      bar.scale.x = Math.max(0.001, k); bar.position.x = -2.8 * (1 - k);
      bar.material.color.setHex(k < 0.3 ? 0xef233c : 0x2dc653); bar.material.emissive.setHex(k < 0.3 ? 0xef233c : 0x2dc653);
      buttons.forEach((b) => { b.press = Math.max(0, b.press - dt * 6); b.cap.position.y = -b.press * 0.15; });
      S.updateParts(dt, -0.3);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { lives = 1; over = false; next(); },
      restart() { start(); }, destroy() { S.destroy(); },
    };
  },
};
