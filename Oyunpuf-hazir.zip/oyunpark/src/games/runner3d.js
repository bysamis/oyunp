// 🏃 Sonsuz Koşu 3D: kaydır → şerit değiştir, yukarı → zıpla, aşağı → kay
import { create3D, mat, THREE } from '../core/three-stage.js';
import { touchpad } from '../core/touchpad.js';
import { modelInto } from '../core/assets.js';

const LANES = [-2.1, 0, 2.1];
const SPAWN_Z = -110;

export default {
  id: 'runner', title: 'Sonsuz Koşu 3D', emoji: '🏃', color: '#f77f00',
  desc: 'Koş, zıpla, kay! Engellerden kaç, altınları topla',
  target: (L) => Math.round(400 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 62, bg: 0x9ad1ff, fog: [0xbde0fe, 35, 110] });
    const { scene, camera, sun } = S;
    sun.shadow.camera.far = 80;
    // zemin
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(300, 300), mat(0x90be6d, { roughness: 1 })); ground.rotation.x = -Math.PI / 2; ground.position.z = -100; ground.receiveShadow = true; scene.add(ground);
    const track = new THREE.Mesh(new THREE.PlaneGeometry(7, 300), mat(0xd4a373, { roughness: 0.9 })); track.rotation.x = -Math.PI / 2; track.position.set(0, 0.01, -100); track.receiveShadow = true; scene.add(track);
    const deco = [];
    const sleeperGeo = new THREE.BoxGeometry(7, 0.06, 0.5), sleeperMat = mat(0xa47148);
    for (let i = 0; i < 60; i++) { const m = new THREE.Mesh(sleeperGeo, sleeperMat); m.position.set(0, 0.03, -i * 2.5); m.receiveShadow = true; scene.add(m); deco.push({ m, span: 150 }); }
    const bColors = [0xffadad, 0xffd6a5, 0xfdffb6, 0xcaffbf, 0x9bf6ff, 0xa0c4ff, 0xbdb2ff, 0xffc6ff];
    for (let i = 0; i < 26; i++) {
      const h = 4 + Math.random() * 9, side = i % 2 ? 1 : -1;
      const b = new THREE.Mesh(new THREE.BoxGeometry(4 + Math.random() * 2, h, 5), mat(bColors[i % bColors.length], { roughness: 0.8 }));
      b.position.set(side * (7.5 + Math.random() * 3), h / 2, -i * 6); b.castShadow = true; b.receiveShadow = true; scene.add(b);
      // pencereler
      for (let k = 0; k < Math.floor(h / 2); k++) { const w = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.8), new THREE.MeshBasicMaterial({ color: 0x5390d9 })); w.position.set(-side * 0.01 - side * (b.geometry.parameters.width / 2) + side * 0, -h / 2 + 1.4 + k * 2, 0); w.rotation.y = side > 0 ? -Math.PI / 2 : Math.PI / 2; b.add(w); }
      deco.push({ m: b, span: 156 });
    }

    // koşucu karakter
    const hero = new THREE.Group(); scene.add(hero);
    const skin = mat(0xffcb9a), shirt = mat(0xef233c), pants = mat(0x264653), shoe = mat(0xffffff);
    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.8, 0.45), shirt); torso.position.y = 1.15; torso.castShadow = true; hero.add(torso);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.33, 16, 12), skin); head.position.y = 1.85; head.castShadow = true; hero.add(head);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.35, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat(0x3a86ff)); cap.position.y = 1.9; hero.add(cap);
    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.05, 0.3), mat(0x3a86ff)); visor.position.set(0, 1.92, -0.35); hero.add(visor);
    const limb = (w, h, m, x, y) => { const p = new THREE.Group(); p.position.set(x, y, 0); const l = new THREE.Mesh(new THREE.BoxGeometry(w, h, w), m); l.position.y = -h / 2; l.castShadow = true; p.add(l); hero.add(p); return p; };
    const legL = limb(0.28, 0.75, pants, -0.2, 0.78), legR = limb(0.28, 0.75, pants, 0.2, 0.78);
    const armL = limb(0.2, 0.7, skin, -0.5, 1.5), armR = limb(0.2, 0.7, skin, 0.5, 1.5);
    [legL, legR].forEach((lg) => { const s = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.14, 0.42), shoe); s.position.set(0, -0.78, -0.06); lg.add(s); });
    // hazır karakter (Kenney Blocky Characters, CC0): yüklenince basit gövde gizlenir
    const procParts = [...hero.children];
    const heroM = modelInto(hero, 'bc-red', { height: 2.0, anim: 'sprint' }, () => procParts.forEach((o) => (o.visible = false)));
    heroM.rotation.y = Math.PI; // koşu yönü (kameradan uzağa)

    const coinGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.08, 20), coinMat = mat(0xffd60a, { metalness: 0.8, roughness: 0.2, emissive: 0x7a5c00, emissiveIntensity: 0.4 });
    function mkObstacle(kind) {
      const g = new THREE.Group();
      if (kind === 'low') { // zıplanacak bariyer
        const bar = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.3, 0.3), mat(0xffffff)); bar.position.y = 0.75; bar.castShadow = true; g.add(bar);
        for (let i = 0; i < 4; i++) { const s = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.31, 0.32), mat(0xef233c)); s.position.set(-0.7 + i * 0.47, 0.75, 0); g.add(s); }
        [-0.85, 0.85].forEach((x) => { const p = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.75, 0.12), mat(0x555555)); p.position.set(x, 0.375, 0); g.add(p); });
      } else if (kind === 'high') { // altından kayılacak
        const bar = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.6, 0.35), mat(0xffd60a)); bar.position.y = 1.65; bar.castShadow = true; g.add(bar);
        const stripe = new THREE.Mesh(new THREE.BoxGeometry(2.02, 0.15, 0.36), mat(0x222222)); stripe.position.y = 1.65; g.add(stripe);
        [-0.95, 0.95].forEach((x) => { const p = new THREE.Mesh(new THREE.BoxGeometry(0.14, 2.0, 0.14), mat(0x555555)); p.position.set(x, 1.0, 0); g.add(p); });
      } else { // duvar / vagon: şerit değiştirmek şart
        const col = [0x2a9d8f, 0xe76f51, 0x457b9d, 0x6a4c93][(Math.random() * 4) | 0];
        const box = new THREE.Mesh(new THREE.BoxGeometry(1.9, 2.6, 6), mat(col, { roughness: 0.5, metalness: 0.3 })); box.position.y = 1.4; box.castShadow = true; box.receiveShadow = true; g.add(box);
        const win = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.6, 5), mat(0xcaf0f8, { emissive: 0x335577, emissiveIntensity: 0.3 })); win.position.y = 1.9; g.add(win);
        const front = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.8, 0.05), mat(0x222222)); front.position.set(0, 1.9, 3.01); g.add(front);
      }
      scene.add(g); return g;
    }

    let L, lane, px, y, vy, slideT, objs, speed, maxSpeed, accel, dist, coins, spawnIn, state, invuln, shake, runT;
    function clearAll() { objs?.forEach((o) => scene.remove(o.m)); objs = []; }
    function start() {
      clearAll(); L = api.level;
      lane = 1; px = 0; y = 0; vy = 0; slideT = 0; runT = 0;
      speed = 14 + (L - 1) * 1.6; maxSpeed = 34 + L * 2.5; accel = 0.35 + L * 0.08;
      dist = 0; coins = 0; spawnIn = 1.2; state = 'play'; invuln = 0; shake = 0; hero.visible = true;
      scene.background.setHex(L >= 7 ? 0x22223b : L >= 4 ? 0xffb4a2 : 0x9ad1ff);
      scene.fog.color.setHex(L >= 7 ? 0x22223b : L >= 4 ? 0xffcdb2 : 0xbde0fe);
      hud();
    }
    function hud() { api.setHud({ score: Math.floor(dist), scoreLabel: 'Metre', extra: `🪙 ${coins} · ${Math.round(speed * 3.6)} km/s` }); }
    function spawn() {
      // her satırda en az bir geçilebilir şerit
      const safe = (Math.random() * 3) | 0;
      const hardness = Math.min(0.85, 0.25 + L * 0.06 + dist / 5000);
      for (let l = 0; l < 3; l++) {
        let kind = null;
        if (l === safe) { if (L >= 3 && Math.random() < hardness * 0.6) kind = Math.random() < 0.5 ? 'low' : 'high'; }
        else if (Math.random() < hardness) kind = Math.random() < 0.45 ? 'wall' : Math.random() < 0.5 ? 'low' : 'high';
        if (kind) {
          const m = mkObstacle(kind); m.position.set(LANES[l], 0, SPAWN_Z);
          objs.push({ kind, lane: l, m, len: kind === 'wall' ? 6 : 0.4 });
        }
      }
      // altınlar: güvenli şeritte (bariyer varsa üstünden kavisli)
      if (Math.random() < 0.7) {
        const hasLow = objs.some((o) => o.lane === safe && o.m.position.z === SPAWN_Z && o.kind === 'low');
        for (let i = 0; i < 6; i++) {
          const m = new THREE.Mesh(coinGeo, coinMat); m.rotation.x = Math.PI / 2;
          const z = SPAWN_Z + 6 - i * 2.2;
          m.position.set(LANES[safe], hasLow ? 1 + Math.sin((i / 5) * Math.PI) * 1.6 : 0.9, z); m.castShadow = true; scene.add(m);
          objs.push({ kind: 'coin', lane: safe, m, len: 0.6 });
        }
      }
      spawnIn = Math.max(0.42, 1.25 - L * 0.06 - dist / 6000) * (20 / Math.max(20, speed * 0.85));
    }
    function act(dir) {
      if (state !== 'play') return;
      if (dir === 'left' && lane > 0) { lane--; api.sfx.lane(); }
      if (dir === 'right' && lane < 2) { lane++; api.sfx.lane(); }
      if (dir === 'up' && y <= 0.01) { vy = 9.5; slideT = 0; api.sfx.tap(); }
      if (dir === 'down') { slideT = 0.75; if (y > 0) vy = -14; api.sfx.slide(); }
      api.haptic('light');
    }
    const pad = touchpad(host, {
      left: [{ id: 'left', icon: '◀' }, { id: 'right', icon: '▶' }],
      right: [{ id: 'down', icon: '⬇', label: 'Kay' }, { id: 'up', icon: '⬆', label: 'Zıpla', cls: 'jump', big: true }],
      onPress: (id) => act(id),
    });
    let down = null;
    S.el.addEventListener('pointerdown', (e) => { down = { x: e.clientX, y: e.clientY }; });
    S.el.addEventListener('pointerup', (e) => {
      if (!down) return; const dx = e.clientX - down.x, dy = e.clientY - down.y; down = null;
      if (Math.hypot(dx, dy) < 25) { const r = S.el.getBoundingClientRect(); act(e.clientX - r.left < r.width / 2 ? 'left' : 'right'); return; }
      if (Math.abs(dx) > Math.abs(dy)) act(dx > 0 ? 'right' : 'left'); else act(dy < 0 ? 'up' : 'down');
    });
    const onKey = (e) => { const m = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down', ' ': 'up' }[e.key]; if (m) act(m); };
    window.addEventListener('keydown', onKey);

    function crash() {
      state = 'over'; shake = 0.5; api.sfx.crash(); api.haptic('heavy');
      S.burst(new THREE.Vector3(px, 1.2, 0), 0xef233c, 18, 7); S.burst(new THREE.Vector3(px, 1.2, 0), 0xffd60a, 10, 6);
      hero.rotation.x = -Math.PI / 2; hero.position.y = 0.3;
      const m = Math.floor(dist);
      setTimeout(() => api.gameOver({ score: m, coins: coins + Math.floor(m / 50), canContinue: true, title: 'Çarptın! 💥' }), 800);
    }
    const lp = S.loop((dt, t) => {
      if (state === 'play') {
        speed = Math.min(maxSpeed, speed + accel * dt); dist += speed * dt;
        spawnIn -= dt; if (spawnIn <= 0) spawn();
        if (invuln > 0) invuln -= dt;
        px += (LANES[lane] - px) * Math.min(1, dt * 14);
        vy -= 30 * dt; y = Math.max(0, y + vy * dt); if (y === 0) vy = 0;
        if (slideT > 0) slideT -= dt;
        runT += dt * speed * 0.55;
        const sliding = slideT > 0 && y <= 0.01;
        for (let i = objs.length - 1; i >= 0; i--) {
          const o = objs[i];
          o.m.position.z += speed * dt;
          if (o.kind === 'coin') o.m.rotation.z += dt * 5;
          if (o.m.position.z > 10) { scene.remove(o.m); objs.splice(i, 1); continue; }
          if (Math.abs(LANES[o.lane] - px) > 1.0) continue;
          const dz = Math.abs(o.m.position.z);
          if (dz > o.len / 2 + 0.4) continue;
          if (o.kind === 'coin') { if (Math.abs(o.m.position.y - (y + 1)) < 1.3) { scene.remove(o.m); objs.splice(i, 1); coins++; api.sfx.coin(); } continue; }
          if (invuln > 0) continue;
          if (o.kind === 'low' && y > 0.85) continue;
          if (o.kind === 'high' && sliding) continue;
          crash(); break;
        }
        hero.position.set(px, y, 0);
        hero.rotation.set(sliding ? -1.1 : 0, 0, (LANES[lane] - px) * -0.15);
        if (sliding) hero.position.y = -0.35;
        const sw = y > 0 ? 0.3 : Math.sin(runT) * 0.9;
        legL.rotation.x = sw; legR.rotation.x = -sw; armL.rotation.x = -sw * 0.8; armR.rotation.x = sw * 0.8;
        const hm = heroM.userData.model;
        if (hm) { hm.userData.play(sliding ? 'sit' : y > 0.05 ? 'static' : 'sprint', 0.08); hm.userData.update(dt * (0.6 + speed / 25)); }
        hero.visible = !(invuln > 0 && Math.floor(t * 12) % 2);
        if ((t * 10 | 0) % 2 === 0) hud();
      }
      const mv = state === 'play' ? speed * dt : 0;
      for (const d of deco) { d.m.position.z += mv; if (d.m.position.z > 15) d.m.position.z -= d.span; }
      camera.position.set(px * 0.5, 4.2 + y * 0.3, 7.5);
      if (shake > 0) { shake -= dt; camera.position.x += (Math.random() - 0.5) * shake; }
      camera.lookAt(px * 0.4, 1.2, -6);
      sun.position.set(px - 6, 16, 6); sun.target.position.set(px, 0, -6);
      S.updateParts(dt);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { objs.filter((o) => o.m.position.z > -25).forEach((o) => { scene.remove(o.m); objs.splice(objs.indexOf(o), 1); }); hero.rotation.set(0, 0, 0); state = 'play'; invuln = 2.5; speed = Math.max(14, speed * 0.8); hud(); },
      restart() { hero.rotation.set(0, 0, 0); start(); },
      destroy() { window.removeEventListener('keydown', onKey); pad.destroy(); S.destroy(); },
    };
  },
};
