// 🧪 Top Sırala: topları tüplere renklerine göre diz
import { createStage, loop, roundRect, shade, particles } from '../core/canvas.js';

const COLORS = ['#ff4d6d', '#3a86ff', '#2dc653', '#ffd60a', '#9d4edd', '#ff9f1c', '#06d6a0', '#ff70a6', '#8d5524', '#adb5bd', '#1d3557', '#e9ff70'];

export default {
  id: 'ballsort', title: 'Top Sırala', emoji: '🧪', color: '#06d6a0',
  desc: 'Her tüpte tek renk kalsın!',
  winBased: true,
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let tubes, cap, nColors, sel, moves, undo, undoLeft, over, time, L, lift;

    function start() {
      L = api.level;
      nColors = Math.min(12, 3 + L);                 // 4, 5, 6 … 12 renk
      cap = L >= 7 ? 5 : 4;                          // 7. seviyeden sonra daha derin tüpler
      const empty = 2;
      // çözülmüş halden geriye doğru geçerli hamlelerle karıştır → her zaman çözülebilir
      tubes = Array.from({ length: nColors }, (_, i) => Array(cap).fill(i));
      for (let i = 0; i < empty; i++) tubes.push([]);
      let steps = 0, tries = 0;
      const target = 120 + nColors * 40;
      while (steps < target && tries < target * 20) {
        tries++;
        const b = (Math.random() * tubes.length) | 0, a = (Math.random() * tubes.length) | 0;
        if (a === b || !tubes[b].length || tubes[a].length >= cap) continue;
        const ball = tubes[b][tubes[b].length - 1];
        const below = tubes[b][tubes[b].length - 2];
        if (below !== undefined && below !== ball) continue; // ileri yönde geçerli olmalı
        tubes[a].push(tubes[b].pop()); steps++;
      }
      if (solved()) return start();
      sel = -1; moves = 0; undo = []; undoLeft = Math.max(0, 5 - L); over = false; time = 0; lift = 0;
      hud();
    }
    function hud() { api.setHud({ score: moves, scoreLabel: 'Hamle', extra: `${nColors} renk · ⏱ ${Math.floor(time)} sn` }); }
    const solved = () => tubes.every((t) => t.length === 0 || (t.length === cap && t.every((b) => b === t[0])));
    function rects() {
      const n = tubes.length, perRow = n > 7 ? Math.ceil(n / 2) : n, rows = Math.ceil(n / perRow);
      const tw = Math.min(56, (st.W - 20) / perRow - 10), ball = tw - 12, th = ball * cap + 24;
      const out = [];
      for (let i = 0; i < n; i++) {
        const row = (i / perRow) | 0, inRow = Math.min(perRow, n - row * perRow), col = i % perRow;
        const gapX = (st.W - inRow * tw) / (inRow + 1);
        const totalH = rows * th + (rows - 1) * 60;
        out.push({ x: gapX + col * (tw + gapX), y: (st.H - totalH) / 2 + row * (th + 60) + 30, w: tw, h: th, ball });
      }
      return out;
    }
    function canPour(a, b) {
      const A = tubes[a], B = tubes[b];
      if (!A.length || B.length >= cap) return false;
      return !B.length || B[B.length - 1] === A[A.length - 1];
    }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = st.point(e), R = rects();
      // geri al düğmesi
      if (p.y < 50 && p.x > st.W - 110) { doUndo(); return; }
      const i = R.findIndex((r) => p.x > r.x - 6 && p.x < r.x + r.w + 6 && p.y > r.y - 40 && p.y < r.y + r.h + 10);
      if (i < 0) { sel = -1; return; }
      if (sel < 0) { if (tubes[i].length) { sel = i; lift = 0; api.sfx.tap(); } return; }
      if (i === sel) { sel = -1; return; }
      if (canPour(sel, i)) {
        undo.push(tubes.map((t) => t.slice()));
        // aynı renkten üstteki tüm topları taşı
        const color = tubes[sel][tubes[sel].length - 1];
        while (tubes[sel].length && tubes[sel][tubes[sel].length - 1] === color && tubes[i].length < cap) tubes[i].push(tubes[sel].pop());
        moves++; api.sfx.slide(); api.haptic('light');
        const t = tubes[i];
        if (t.length === cap && t.every((b) => b === t[0])) { const r = R[i]; fx.burst(r.x + r.w / 2, r.y, COLORS[t[0]], 16, 160); api.sfx.coin(); }
        sel = -1; hud();
        if (solved()) {
          over = true; api.sfx.win();
          const score = Math.max(50, nColors * 120 - moves * 4 - Math.floor(time));
          setTimeout(() => api.gameOver({ score, coins: 8 + nColors * 2, win: true, title: 'Hepsi sıralandı! 🧪' }), 800);
        }
      } else { api.sfx.wrong(); sel = tubes[i].length ? i : -1; }
    });
    function doUndo() {
      if (!undo.length || undoLeft <= 0) { api.sfx.wrong(); return; }
      tubes = undo.pop(); undoLeft--; moves++; sel = -1; api.sfx.swap(); hud();
    }
    function update(dt) {
      if (!over) { const b = Math.floor(time); time += dt; if (Math.floor(time) !== b) hud(); }
      lift = Math.min(1, lift + dt * 8);
      fx.update(dt); draw();
    }
    function draw() {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H); g.addColorStop(0, '#2b2d42'); g.addColorStop(1, '#14213d');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      roundRect(c, st.W - 104, 10, 94, 34, 17); c.fillStyle = undoLeft && undo.length ? '#ffd60a' : 'rgba(255,255,255,.15)'; c.fill();
      c.fillStyle = '#14213d'; c.font = '800 14px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(`↩ Geri (${undoLeft})`, st.W - 57, 28);
      const R = rects();
      R.forEach((r, i) => {
        roundRect(c, r.x, r.y, r.w, r.h, r.w / 2); c.fillStyle = 'rgba(255,255,255,.08)'; c.fill();
        c.strokeStyle = sel === i ? '#ffd60a' : 'rgba(255,255,255,.55)'; c.lineWidth = 3; c.stroke();
        tubes[i].forEach((b, k) => {
          const top = k === tubes[i].length - 1 && sel === i;
          const cx = r.x + r.w / 2, cy = top ? r.y - r.ball * 0.6 - lift * 10 : r.y + r.h - 8 - r.ball / 2 - k * r.ball;
          const gr = c.createRadialGradient(cx - r.ball * 0.15, cy - r.ball * 0.2, 2, cx, cy, r.ball / 2);
          gr.addColorStop(0, shade(COLORS[b], 70)); gr.addColorStop(1, COLORS[b]);
          c.fillStyle = gr; c.beginPath(); c.arc(cx, cy, r.ball / 2 - 1, 0, 7); c.fill();
        });
      });
      c.textBaseline = 'alphabetic'; fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
