// 🏀 Basket Atışı 3D: topu yukarı doğru kaydırarak at; 45 saniyede en çok sayıyı yap
import { create3D, mat, THREE } from '../core/three-stage.js';
import { crowdStands } from '../core/crowd.js';
import { modelInto } from '../core/assets.js';

const RIM_Y = 3.05, RIM_R = 0.46, BALL_R = 0.24, HOOP_Z = -6, BOARD_Z = -6.65, G = 9.8;

export default {
  id: 'basket', title: 'Basket Atışı 3D', emoji: '🏀', color: '#f77f00',
  desc: 'Kaydırarak at, potaya sok! 45 saniye',
  target: (L) => Math.round(100 * Math.pow(1.3, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 55, bg: 0x22223b, fog: [0x22223b, 22, 45] });
    const { scene, camera } = S;
    camera.position.set(0, 2.3, 4.2); camera.lookAt(0, 2.6, -6);
    // parke zemin
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(20, 30), mat(0xd4a373, { roughness: 0.6 })); floor.rotation.x = -Math.PI / 2; floor.position.z = -5; floor.receiveShadow = true; scene.add(floor);
    for (let i = -9; i < 10; i++) { const l = new THREE.Mesh(new THREE.PlaneGeometry(0.03, 30), new THREE.MeshBasicMaterial({ color: 0xbc8a5f })); l.rotation.x = -Math.PI / 2; l.position.set(i, 0.002, -5); scene.add(l); }
    const arc = new THREE.Mesh(new THREE.RingGeometry(5.6, 5.7, 48, 1, Math.PI, Math.PI), new THREE.MeshBasicMaterial({ color: 0xffffff })); arc.rotation.x = -Math.PI / 2; arc.position.set(0, 0.003, HOOP_Z); scene.add(arc);
    const wall = new THREE.Mesh(new THREE.PlaneGeometry(40, 16), mat(0x3d405b)); wall.position.set(0, 8, -14.5); scene.add(wall);
    // tribün + seyirci (Kenney Blocky Characters, CC0), reklam panoları ve kupa
    const crowd = crowdStands(scene, { z: -9.6, width: 18, rows: 5, rowD: 1.0, rowH: 0.7, colors: [0xf77f00, 0x2b2d42, 0xffffff] });
    const adCv = document.createElement('canvas'); adCv.width = 512; adCv.height = 64; const ac = adCv.getContext('2d');
    ['#f77f00', '#3a86ff', '#ef233c', '#2dc653'].forEach((c, i) => { ac.fillStyle = c; ac.fillRect(i * 128, 0, 128, 64); ac.fillStyle = '#fff'; ac.font = '900 30px system-ui'; ac.textAlign = 'center'; ac.fillText(['Oyunpuf', '🏀 3D', 'SAYI!', 'Oyunpuf'][i], i * 128 + 64, 43); });
    const adTex = new THREE.CanvasTexture(adCv); adTex.colorSpace = THREE.SRGBColorSpace; adTex.wrapS = THREE.RepeatWrapping; adTex.repeat.set(4, 1);
    const ads = new THREE.Mesh(new THREE.BoxGeometry(22, 0.7, 0.2), new THREE.MeshBasicMaterial({ map: adTex })); ads.position.set(0, 0.35, -8.9); scene.add(ads);
    [-4.5, 4.5].forEach((x) => { const tr = modelInto(scene, 'ma-trophy', { height: 0.9 }); tr.position.set(x, 0.7, -8.9); });
    // spot ışıkları
    const spotL = new THREE.PointLight(0xfff1d0, 18, 18); spotL.position.set(0, 7, -3); scene.add(spotL);
    // pota (hareketli grup)
    const hoop = new THREE.Group(); scene.add(hoop);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 3.4), mat(0x6c757d, { metalness: 0.6 })); pole.position.set(0, 1.7, BOARD_Z - 0.5); pole.castShadow = true; hoop.add(pole);
    const board = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.1, 0.06), mat(0xffffff, { transparent: true, opacity: 0.85, roughness: 0.1 })); board.position.set(0, RIM_Y + 0.45, BOARD_Z); hoop.add(board);
    const sq = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.45), new THREE.MeshBasicMaterial({ color: 0xef233c, wireframe: true })); sq.position.set(0, RIM_Y + 0.25, BOARD_Z + 0.04); hoop.add(sq);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(RIM_R, 0.03, 8, 32), mat(0xff6d00, { metalness: 0.5 })); rim.rotation.x = Math.PI / 2; rim.position.set(0, RIM_Y, HOOP_Z); hoop.add(rim);
    const net = new THREE.Mesh(new THREE.CylinderGeometry(RIM_R, RIM_R * 0.6, 0.5, 16, 3, true), new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true })); net.position.set(0, RIM_Y - 0.25, HOOP_Z); hoop.add(net);
    // top
    const ballMat = mat(0xff7b00, { roughness: 0.7 });
    const ballM = new THREE.Mesh(new THREE.SphereGeometry(BALL_R, 24, 16), ballMat); ballM.castShadow = true; scene.add(ballM);
    const seam = new THREE.Mesh(new THREE.TorusGeometry(BALL_R * 1.01, 0.008, 4, 24), new THREE.MeshBasicMaterial({ color: 0x222222 })); ballM.add(seam);
    const seam2 = seam.clone(); seam2.rotation.y = Math.PI / 2; ballM.add(seam2);

    let L, score, timeLeft, over, streak, ball, flying, hoopX, hoopDir, startPos, shotTouched, scored, resetT, far;
    function start() {
      L = api.level; score = 0; timeLeft = 45; over = false; streak = 0; hoopX = 0; hoopDir = 1;
      newShot(); hud();
    }
    function hud() { api.setHud({ score, scoreLabel: 'Sayı', extra: `⏱ ${Math.ceil(timeLeft)} sn` + (streak >= 3 ? ' · 🔥 ATEŞ ×2' : streak ? ` · Seri ${streak}` : '') }); }
    function newShot() {
      // Zorluk: seviye arttıkça atış yeri değişir ve uzaklaşır
      const spread = Math.min(2.4, (L - 1) * 0.4);
      far = L >= 2 && Math.random() < Math.min(0.6, L * 0.08);
      startPos = new THREE.Vector3((Math.random() - 0.5) * spread * 2, 1.2, far ? 1.2 : 2.2 - Math.random() * Math.min(1, (L - 1) * 0.2));
      ball = { p: startPos.clone(), v: new THREE.Vector3() };
      flying = false; shotTouched = false; scored = false; resetT = 0;
      camera.position.set(startPos.x * 0.6, 2.9, startPos.z + 3.6); camera.lookAt(hoopX * 0.5, 2.4, HOOP_Z);
    }
    let sw = null;
    S.el.addEventListener('pointerdown', (e) => { if (!flying && !over) sw = { x: e.clientX, y: e.clientY, t: performance.now() }; });
    S.el.addEventListener('pointerup', (e) => {
      if (!sw || flying || over) return;
      const dx = e.clientX - sw.x, dy = sw.y - e.clientY; sw = null;
      if (dy < 30) return;
      const H = S.el.getBoundingClientRect().height;
      // kaydırma uzunluğu → mesafe, yatay → sağ/sol; ideal kaydırma ekran yüksekliğinin ~%40'ı
      const strength = dy / (H * 0.4);
      const err = 1 + (L - 1) * 0.08; // yüksek seviyede hata payı büyür (daha hassas atış gerekir)
      const target = new THREE.Vector3(hoopX + (dx / S.el.getBoundingClientRect().width) * 5 * err, RIM_Y, HOOP_Z + (1 - strength) * 3.2 * err);
      const tFly = 0.95;
      ball.v.set((target.x - ball.p.x) / tFly, (target.y - ball.p.y + 0.5 * G * tFly * tFly) / tFly + 0.35, (target.z - ball.p.z) / tFly);
      flying = true; api.sfx.swap(); api.haptic('light');
    });
    function made(swish) {
      scored = true; streak++;
      let pts = far ? 3 : 2; if (streak >= 3) pts *= 2;
      score += pts; api.sfx[swish ? 'coin' : 'pop'](); api.haptic('medium'); crowd.cheer(swish ? 2.2 : 1.4);
      S.burst(new THREE.Vector3(hoopX, RIM_Y, HOOP_Z), streak >= 3 ? 0xff6d00 : 0xffd60a, 16, 4);
      S.popText(new THREE.Vector3(hoopX, RIM_Y + 0.8, HOOP_Z), (swish ? 'Swish! ' : '') + '+' + pts, streak >= 3 ? '#ff6d00' : '#fff');
      hud();
    }
    const lp = S.loop((dt, t) => {
      if (!over) {
        const b = Math.ceil(timeLeft); timeLeft -= dt; if (Math.ceil(timeLeft) !== b) hud();
        if (timeLeft <= 0) { over = true; timeLeft = 0; api.sfx.win(); hud(); api.gameOver({ score, coins: Math.floor(score / 3), title: 'Süre doldu! 🏀' }); }
      }
      // pota seviye 3'ten itibaren hareket eder
      if (L >= 3) { const sp = 0.6 + (L - 3) * 0.3; hoopX += hoopDir * sp * dt; if (Math.abs(hoopX) > Math.min(2.2, 0.8 + L * 0.15)) hoopDir *= -1; }
      hoop.position.x = hoopX;
      if (flying) {
        const steps = 4;
        for (let i = 0; i < steps; i++) {
          const h = dt / steps, prevY = ball.p.y;
          ball.v.y -= G * h; ball.p.addScaledVector(ball.v, h);
          // pano
          if (ball.p.z < BOARD_Z + 0.03 + BALL_R && ball.v.z < 0 && Math.abs(ball.p.x - hoopX) < 0.9 && Math.abs(ball.p.y - (RIM_Y + 0.45)) < 0.55) { ball.p.z = BOARD_Z + 0.03 + BALL_R; ball.v.z = Math.abs(ball.v.z) * 0.55; shotTouched = true; api.sfx.click(); }
          // çember
          const rx = ball.p.x - hoopX, rz = ball.p.z - HOOP_Z, dh = Math.hypot(rx, rz);
          if (Math.abs(ball.p.y - RIM_Y) < BALL_R && Math.abs(dh - RIM_R) < BALL_R * 0.9) {
            const nx = rx / (dh || 1), nz = rz / (dh || 1), side = dh > RIM_R ? 1 : -1;
            const vn = ball.v.x * nx * side + ball.v.z * nz * side;
            if (vn < 0) { ball.v.x -= 1.6 * vn * nx * side; ball.v.z -= 1.6 * vn * nz * side; ball.v.y = Math.abs(ball.v.y) * 0.4; shotTouched = true; api.sfx.bounce(); }
          }
          // sayı: yukarıdan çemberin içinden geçti
          if (!scored && prevY >= RIM_Y && ball.p.y < RIM_Y && dh < RIM_R - BALL_R * 0.4 && ball.v.y < 0) made(!shotTouched);
          if (ball.p.y < BALL_R) { ball.p.y = BALL_R; ball.v.y = Math.abs(ball.v.y) * 0.55; ball.v.x *= 0.8; ball.v.z *= 0.8; }
        }
        resetT += dt;
        if (resetT > 2.6 || (resetT > 1.2 && ball.p.y < 0.5 && !scored && ball.v.length() < 2)) {
          if (!scored) { streak = 0; api.sfx.wrong(); hud(); }
          newShot();
        }
      }
      ballM.position.copy(ball.p); if (flying) { ballM.rotation.x -= dt * 10; }
      net.scale.y = 1 + (scored && resetT < 0.6 ? Math.sin(resetT * 20) * 0.15 : 0);
      S.updateParts(dt); crowd.update(dt);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { S.destroy(); } };
  },
};
