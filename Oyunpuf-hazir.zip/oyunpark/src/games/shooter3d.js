// 👾 Uzay Savunması 3D: gemini sürükle, otomatik ateş, dalgaları durdur
import { create3D, mat, THREE } from '../core/three-stage.js';
import { touchpad } from '../core/touchpad.js';

const XW = 5, ZFAR = -22, ZNEAR = 7;

export default {
  id: 'shooter', title: 'Uzay Savunması 3D', emoji: '👾', color: '#3c096c',
  desc: 'Gemini sürükle, uzaylıları vur!',
  target: (L) => Math.round(800 * Math.pow(1.4, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 55, bg: 0x05010f, fog: [0x05010f, 25, 45], shadows: false });
    const { scene, camera } = S;
    S.onResize(() => { const a = S.w / S.h, d = Math.max(10, 7 / a); camera.position.set(0, d * 0.85, d * 0.95); camera.lookAt(0, 0, -5); });
    S.hemi.intensity = 0.6;
    const starGeo = new THREE.BufferGeometry().setAttribute('position', new THREE.Float32BufferAttribute(Array.from({ length: 1500 }, (_, i) => (i % 3 === 0 ? (Math.random() - 0.5) * 60 : i % 3 === 1 ? -4 - Math.random() * 10 : -60 + Math.random() * 70)), 3));
    const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 0.12 })); scene.add(stars);
    const planet = new THREE.Mesh(new THREE.SphereGeometry(8, 32, 20), mat(0x7b2cbf, { roughness: 0.9, emissive: 0x240046, emissiveIntensity: 0.5 })); planet.position.set(-14, -10, -40); scene.add(planet);

    // gemi modeli
    const ship = new THREE.Group();
    const hull = new THREE.Mesh(new THREE.ConeGeometry(0.45, 1.8, 8), mat(0xe0e1dd, { metalness: 0.6, roughness: 0.3 })); hull.rotation.x = -Math.PI / 2; ship.add(hull);
    const wing = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.08, 0.7), mat(0x3a86ff, { metalness: 0.5 })); wing.position.z = 0.4; ship.add(wing);
    const cock = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 8), mat(0x80ffdb, { emissive: 0x80ffdb, emissiveIntensity: 0.8 })); cock.position.set(0, 0.2, -0.1); ship.add(cock);
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.8, 8), new THREE.MeshBasicMaterial({ color: 0xff9f1c })); flame.rotation.x = Math.PI / 2; flame.position.z = 1.2; ship.add(flame);
    scene.add(ship);
    const shipLight = new THREE.PointLight(0x80ffdb, 8, 6); ship.add(shipLight);

    const bulletGeo = new THREE.BoxGeometry(0.1, 0.1, 0.7), bulletMat = new THREE.MeshBasicMaterial({ color: 0x80ffdb });
    const eGeo = new THREE.SphereGeometry(0.16, 8, 6), eMat = new THREE.MeshBasicMaterial({ color: 0xff4d6d });
    function mkFoe(kind) {
      const g = new THREE.Group();
      const col = kind === 'tank' ? 0xff4d6d : kind === 'zig' ? 0xffd60a : 0x9d4edd;
      const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.5, 0.25, 16), mat(col, { metalness: 0.5, roughness: 0.3, emissive: col, emissiveIntensity: 0.2 })); g.add(disc);
      const dome = new THREE.Mesh(new THREE.SphereGeometry(0.38, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat(0x80ffdb, { transparent: true, opacity: 0.8, emissive: 0x80ffdb, emissiveIntensity: 0.4 })); dome.position.y = 0.1; g.add(dome);
      for (let i = 0; i < 6; i++) { const l = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 4), new THREE.MeshBasicMaterial({ color: 0xffffff })); const a = i * Math.PI / 3; l.position.set(Math.cos(a) * 0.62, -0.02, Math.sin(a) * 0.62); g.add(l); }
      if (kind === 'tank') g.scale.setScalar(1.45);
      scene.add(g); return g;
    }

    let me, bullets, foes, ebs, drops, score, wave, spawnIn, fireIn, over, L, lives, invuln, power;
    const diff = () => L + wave * 0.5;
    function clearAll() { [bullets, foes, ebs, drops].forEach((a) => a?.forEach((o) => scene.remove(o.m))); }
    function start() {
      clearAll(); L = api.level;
      me = { x: 0, z: 4 }; bullets = []; foes = []; ebs = []; drops = [];
      score = 0; wave = 1; spawnIn = 1; fireIn = 0; over = false; lives = 3; invuln = 0; power = 0; ship.visible = true; hud();
    }
    function hud() { api.setHud({ score, extra: `${'❤️'.repeat(Math.max(0, lives))} · Dalga ${wave}` }); }
    function spawn() {
      const d = diff(), r = Math.random();
      const kind = r < Math.min(0.3, d * 0.03) ? 'tank' : r < Math.min(0.55, 0.1 + d * 0.04) ? 'zig' : 'basic';
      const hp = kind === 'tank' ? 4 + Math.floor(d / 3) : kind === 'zig' ? 1 : 1 + Math.floor(d / 6);
      const m = mkFoe(kind);
      foes.push({ m, x: (Math.random() - 0.5) * (XW * 2 - 1.5), z: ZFAR, kind, hp, t: Math.random() * 6, vz: (1.8 + d * 0.28) * (kind === 'tank' ? 0.6 : 1), fire: 1 + Math.random() * 2, r: kind === 'tank' ? 1.0 : 0.7 });
      spawnIn = Math.max(0.22, 1.2 - d * 0.07);
    }
    let drag = null;
    S.el.addEventListener('pointerdown', (e) => { const p = S.rayPlaneY(e, 0); if (p) drag = { p, x: me.x, z: me.z }; });
    S.el.addEventListener('pointermove', (e) => {
      if (!drag) return; const p = S.rayPlaneY(e, 0); if (!p) return;
      me.x = Math.max(-XW, Math.min(XW, drag.x + (p.x - drag.p.x) * 1.2));
      me.z = Math.max(-1, Math.min(ZNEAR - 1, drag.z + (p.z - drag.p.z) * 1.2));
    });
    const up = () => (drag = null); window.addEventListener('pointerup', up);
    const pad = touchpad(host, { dpad: true });

    function hit() {
      if (invuln > 0) return;
      lives--; invuln = 2; power = 0; api.sfx.crash(); api.haptic('heavy'); S.burst(new THREE.Vector3(me.x, 0, me.z), 0xff9f1c, 24, 7); hud();
      if (lives <= 0) { over = true; ship.visible = false; api.sfx.lose(); setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 30), canContinue: true, title: 'Gemi düştü! 👾' }), 600); }
    }
    const lp = S.loop((dt, t) => {
      const pos = starGeo.attributes.position;
      for (let i = 0; i < pos.count; i++) { let z = pos.getZ(i) + dt * 6; if (z > 10) z -= 70; pos.setZ(i, z); }
      pos.needsUpdate = true;
      planet.rotation.y += dt * 0.05;
      if (!over) {
        const sp = 7 * dt;
        if (pad.held.left) me.x = Math.max(-XW, me.x - sp); if (pad.held.right) me.x = Math.min(XW, me.x + sp);
        if (pad.held.up) me.z = Math.max(-1, me.z - sp); if (pad.held.down) me.z = Math.min(ZNEAR - 1, me.z + sp);
        if (invuln > 0) invuln -= dt; if (power > 0) power -= dt;
        fireIn -= dt;
        if (fireIn <= 0) {
          fireIn = 0.22;
          (power > 0 ? [-0.25, 0, 0.25] : [0]).forEach((a) => { const m = new THREE.Mesh(bulletGeo, bulletMat); m.rotation.y = -a; scene.add(m); bullets.push({ m, x: me.x, z: me.z - 1, vx: Math.sin(a) * 21, vz: -Math.cos(a) * 21 }); });
          api.sfx.click();
        }
        spawnIn -= dt; if (spawnIn <= 0) spawn();
        bullets = bullets.filter((b) => { b.x += b.vx * dt; b.z += b.vz * dt; if (b.z < ZFAR - 2 || b.dead) { scene.remove(b.m); return false; } return true; });
        for (const f of foes) {
          f.t += dt; f.z += f.vz * dt;
          if (f.kind === 'zig') f.x += Math.sin(f.t * 3) * 4 * dt;
          f.fire -= dt;
          if (f.fire <= 0 && f.z > ZFAR + 2 && diff() >= 2) {
            f.fire = Math.max(0.8, 3 - diff() * 0.15) + Math.random();
            const a = Math.atan2(me.z - f.z, me.x - f.x), sp = 5.6 + diff() * 0.42;
            const m = new THREE.Mesh(eGeo, eMat); scene.add(m); ebs.push({ m, x: f.x, z: f.z, vx: Math.cos(a) * sp, vz: Math.sin(a) * sp });
          }
          for (const b of bullets) if (!b.dead && Math.abs(b.x - f.x) < f.r && Math.abs(b.z - f.z) < f.r) {
            b.dead = true; f.hp--; api.sfx.brick(); S.burst(new THREE.Vector3(f.x, 0, f.z), 0x80ffdb, 3, 3, 0.6);
            if (f.hp <= 0) {
              f.dead = true; score += f.kind === 'tank' ? 50 : f.kind === 'zig' ? 20 : 10;
              S.burst(new THREE.Vector3(f.x, 0, f.z), f.kind === 'tank' ? 0xff4d6d : f.kind === 'zig' ? 0xffd60a : 0x9d4edd, 16, 7);
              if (Math.random() < 0.08) {
                const kind = Math.random() < 0.5 ? 'power' : 'life', col = kind === 'power' ? 0xffd60a : 0xff70a6;
                const m = new THREE.Mesh(kind === 'power' ? new THREE.OctahedronGeometry(0.4) : new THREE.SphereGeometry(0.35, 12, 8), mat(col, { emissive: col, emissiveIntensity: 0.7 }));
                scene.add(m); drops.push({ m, x: f.x, z: f.z, kind });
              }
              hud();
            }
          }
          if (!f.dead && Math.hypot(f.x - me.x, f.z - me.z) < f.r + 0.6) { f.dead = true; hit(); }
          if (f.z > ZNEAR + 2) { f.dead = true; score = Math.max(0, score - 5); }
          f.m.position.set(f.x, Math.sin(f.t * 2) * 0.2, f.z); f.m.rotation.y += dt * 2;
        }
        foes = foes.filter((f) => { if (f.dead) scene.remove(f.m); return !f.dead; });
        ebs = ebs.filter((b) => {
          b.x += b.vx * dt; b.z += b.vz * dt; b.m.position.set(b.x, 0, b.z);
          if (Math.hypot(b.x - me.x, b.z - me.z) < 0.5) { hit(); scene.remove(b.m); return false; }
          if (b.z > ZNEAR + 3 || b.z < ZFAR - 3 || Math.abs(b.x) > XW + 4) { scene.remove(b.m); return false; }
          return true;
        });
        drops = drops.filter((d) => {
          d.z += 3 * dt; d.m.position.set(d.x, 0, d.z); d.m.rotation.y += dt * 3;
          if (Math.hypot(d.x - me.x, d.z - me.z) < 1) { api.sfx.power(); if (d.kind === 'power') power = 8; else { lives = Math.min(5, lives + 1); hud(); } scene.remove(d.m); return false; }
          if (d.z > ZNEAR + 2) { scene.remove(d.m); return false; }
          return true;
        });
        const w = 1 + Math.floor(score / 300);
        if (w !== wave) { wave = w; S.popText(new THREE.Vector3(0, 0, -4), `Dalga ${wave}!`, '#ffd60a'); api.sfx.win(); hud(); }
      }
      bullets.forEach((b) => b.m.position.set(b.x, 0, b.z));
      const tilt = drag ? 0 : 0;
      ship.position.x += (me.x - ship.position.x) * Math.min(1, dt * 15);
      ship.rotation.z = -(me.x - ship.position.x) * 0.5 + tilt;
      ship.position.z = me.z;
      ship.visible = !over && !(invuln > 0 && Math.floor(t * 12) % 2);
      flame.scale.y = 0.8 + Math.sin(t * 40) * 0.3;
      cock.material.color.setHex(power > 0 ? 0xffd60a : 0x80ffdb);
      S.updateParts(dt, -3);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { lives = 2; invuln = 3; foes.forEach((f) => scene.remove(f.m)); ebs.forEach((b) => scene.remove(b.m)); foes = []; ebs = []; over = false; hud(); },
      restart() { start(); },
      destroy() { window.removeEventListener('pointerup', up); pad.destroy(); S.destroy(); },
    };
  },
};
