// ➗ Hızlı Matematik: işlemi çöz, doğru cevaba bas
import { createStage, loop, roundRect, particles } from '../core/canvas.js';
import { expert, expertSteps } from '../core/expert.js';

export default {
  id: 'math', title: 'Hızlı Matematik', emoji: '➗', color: '#118ab2',
  desc: 'İşlemleri süre bitmeden çöz!',
  expertFrom: 13,
  target: (L) => Math.round(200 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let q, ans, opts, timer, maxT, score, streak, over, L, lives, solved;
    const ri = (a, b) => a + Math.floor(Math.random() * (b - a + 1));

    function start() { L = api.level; score = 0; streak = 0; over = false; lives = 3; solved = 0; next(); }
    function next() {
      const d = L + Math.floor(solved / 6); // oynadıkça zorlaşır
      const ops = d < 2 ? ['+'] : d < 3 ? ['+', '-'] : d < 5 ? ['+', '-', '×'] : ['+', '-', '×', '÷'];
      const op = ops[ri(0, ops.length - 1)];
      const m = Math.min(10 + d * 8, 200);
      let a, b;
      if (op === '+') { a = ri(1, m); b = ri(1, m); ans = a + b; }
      if (op === '-') { a = ri(1, m); b = ri(1, a); ans = a - b; }
      if (op === '×') { a = ri(2, Math.min(5 + d, 25)); b = ri(2, Math.min(5 + d, 15)); ans = a * b; }
      if (op === '÷') { b = ri(2, Math.min(4 + d, 15)); ans = ri(2, Math.min(4 + d, 20)); a = b * ans; }
      q = `${a} ${op} ${b}`;
      // üç işlem: seviye 7+ iki adımlı
      if (d >= 7 && Math.random() < 0.5) { const c = ri(1, 20); q = `${q} + ${c}`; ans += c; }
      const set = new Set([ans]);
      while (set.size < 4) { const off = ri(-Math.max(3, Math.ceil(ans * 0.15)), Math.max(3, Math.ceil(ans * 0.15))); if (off && ans + off >= 0) set.add(ans + off); }
      opts = [...set].sort(() => Math.random() - 0.5);
      maxT = Math.max(2.2, 7 - L * 0.4 - solved * 0.05) / (1 + (expert(L, 12) - 1) * 0.5); timer = maxT; hud();
    }
    function hud() { api.setHud({ score, extra: `${'❤️'.repeat(lives)} · Seri ${streak}` }); }
    const btn = (i) => { const w = Math.min(st.W - 32, 440), ox = (st.W - w) / 2, bw = (w - 12) / 2, bh = 84; return { x: ox + (i % 2) * (bw + 12), y: st.H * 0.5 + ((i / 2) | 0) * (bh + 12), w: bw, h: bh }; };
    function wrong() {
      lives--; streak = 0; api.sfx.wrong(); api.haptic('medium'); fx.text(st.W / 2, st.H * 0.3, `= ${ans}`, '#ef233c');
      if (lives <= 0) { over = true; api.sfx.lose(); api.gameOver({ score, coins: Math.floor(score / 12), canContinue: true, title: 'Hesap şaştı! ➗' }); }
      else next();
    }
    st.canvas.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = st.point(e);
      opts.forEach((v, i) => {
        const b = btn(i);
        if (p.x > b.x && p.x < b.x + b.w && p.y > b.y && p.y < b.y + b.h) {
          if (v === ans) {
            solved++; streak++; const pts = 10 + streak * 2 + Math.round(timer * 3);
            score += pts; api.sfx.coin(); fx.burst(b.x + b.w / 2, b.y + b.h / 2, '#ffd60a', 10); fx.text(b.x + b.w / 2, b.y, '+' + pts, '#fff'); next();
          } else wrong();
        }
      });
    });
    function update(dt) { if (!over) { timer -= dt; if (timer <= 0) wrong(); } fx.update(dt); draw(); }
    function draw() {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H); g.addColorStop(0, '#118ab2'); g.addColorStop(1, '#073b4c');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      roundRect(c, 20, st.H * 0.14, st.W - 40, st.H * 0.22, 24); c.fillStyle = 'rgba(255,255,255,.95)'; c.fill();
      c.fillStyle = '#073b4c'; c.font = `900 ${Math.min(52, st.W / (q.length * 0.62))}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(q + ' = ?', st.W / 2, st.H * 0.25);
      const w = st.W - 60; roundRect(c, 30, st.H * 0.4, w, 10, 5); c.fillStyle = 'rgba(255,255,255,.2)'; c.fill();
      roundRect(c, 30, st.H * 0.4, w * Math.max(0, timer / maxT), 10, 5); c.fillStyle = timer / maxT < 0.3 ? '#ef476f' : '#06d6a0'; c.fill();
      opts.forEach((v, i) => {
        const b = btn(i); roundRect(c, b.x, b.y, b.w, b.h, 18); c.fillStyle = '#ffd166'; c.fill();
        c.fillStyle = '#073b4c'; c.font = '900 30px system-ui'; c.fillText(v, b.x + b.w / 2, b.y + b.h / 2 + 2);
      });
      c.textBaseline = 'alphabetic'; fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), continue() { lives = 1; over = false; next(); }, restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
