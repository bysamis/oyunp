// 🔴 Dört Bağla: bilgisayara karşı 4'ü yan yana / çapraz diz
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

const C = 7, R = 6;

function winnerOf(b) {
  const dirs = [[0, 1], [1, 0], [1, 1], [1, -1]];
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) {
    const p = b[r][c]; if (!p) continue;
    for (const [dr, dc] of dirs) {
      const cells = [[r, c]];
      for (let k = 1; k < 4; k++) { const rr = r + dr * k, cc = c + dc * k; if (b[rr]?.[cc] !== p) break; cells.push([rr, cc]); }
      if (cells.length === 4) return { p, cells };
    }
  }
  return b[0].every(Boolean) ? { p: 'draw' } : null;
}
const dropRow = (b, c) => { for (let r = R - 1; r >= 0; r--) if (!b[r][c]) return r; return -1; };
function evalBoard(b) {
  let s = 0;
  const lines = [];
  for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) for (const [dr, dc] of [[0, 1], [1, 0], [1, 1], [1, -1]]) {
    const w = []; for (let k = 0; k < 4; k++) w.push(b[r + dr * k]?.[c + dc * k]);
    if (w.every((x) => x !== undefined)) lines.push(w);
  }
  for (const w of lines) {
    const a = w.filter((x) => x === 2).length, h = w.filter((x) => x === 1).length;
    if (a && h) continue;
    s += a === 3 ? 6 : a === 2 ? 2 : 0;
    s -= h === 3 ? 8 : h === 2 ? 2 : 0;
  }
  for (let r = 0; r < R; r++) if (b[r][3] === 2) s += 3; else if (b[r][3] === 1) s -= 3;
  return s;
}
function minimax(b, depth, alpha, beta, ai) {
  const w = winnerOf(b);
  if (w) return w.p === 2 ? 1000 + depth : w.p === 1 ? -1000 - depth : 0;
  if (depth === 0) return evalBoard(b);
  const order = [3, 2, 4, 1, 5, 0, 6];
  if (ai) {
    let best = -Infinity;
    for (const c of order) { const r = dropRow(b, c); if (r < 0) continue; b[r][c] = 2; best = Math.max(best, minimax(b, depth - 1, alpha, beta, false)); b[r][c] = 0; alpha = Math.max(alpha, best); if (alpha >= beta) break; }
    return best;
  }
  let best = Infinity;
  for (const c of order) { const r = dropRow(b, c); if (r < 0) continue; b[r][c] = 1; best = Math.min(best, minimax(b, depth - 1, alpha, beta, true)); b[r][c] = 0; beta = Math.min(beta, best); if (alpha >= beta) break; }
  return best;
}

export default {
  id: 'connect4', title: 'Dört Bağla', emoji: '🔴', color: '#ef233c',
  desc: 'Dört taşı yan yana diz, bilgisayarı yen!',
  winBased: true,
  players: { min: 2, max: 2 },
  online: { min: 2, max: 2 },
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let board, turn, result, falling, L, busy, hover, moves;

    const ON = api.mp?.online, inbox = [];
    ON?.on((m) => inbox.push(m));
    function start() {
      inbox.length = 0;
      L = api.level;
      board = Array.from({ length: R }, () => Array(C).fill(0));
      turn = 1; result = null; falling = null; busy = false; hover = 3; moves = 0;
      hud();
    }
    // Zorluk: arama derinliği 1 → 6, hata payı azalır
    const depth = () => Math.min(6, L);
    const mistake = () => Math.max(0, 0.35 - (L - 1) * 0.08);
    function hud() { api.setHud({ score: moves, scoreLabel: 'Hamle', scoreLabel: api.mp ? 'Hamle' : undefined, extra: result ? '' : ON ? (turn === ON.me + 1 ? `Senin sıran ${turn === 1 ? '🔴' : '🟡'}` : `${api.mp.names[turn - 1]} düşünüyor…`) : api.mp ? `Sıra: ${api.mp.names[turn - 1]} ${turn === 1 ? '🔴' : '🟡'}` : turn === 1 ? 'Senin sıran 🔴' : 'Bilgisayar düşünüyor… 🟡' }); }
    function geo() {
      const cs = Math.min((st.W - 24) / C, (st.H - 120) / R);
      return { cs, ox: (st.W - cs * C) / 2, oy: (st.H - cs * R) / 2 + 30 };
    }
    function drop(c, p) {
      const r = dropRow(board, c); if (r < 0) return false;
      falling = { r, c, p, y: -1, vy: 0 }; busy = true; api.sfx.tap();
      return true;
    }
    function land() {
      const { r, c, p } = falling; board[r][c] = p; falling = null; moves += p === 1 ? 1 : 0;
      api.haptic('light'); api.sfx.bounce();
      const w = winnerOf(board);
      if (w) return finish(w);
      turn = p === 1 ? 2 : 1; busy = false; hud();
      if (turn === 2 && !api.mp) setTimeout(aiMove, 350);
    }
    function aiMove() {
      const valid = [...Array(C).keys()].filter((c) => dropRow(board, c) >= 0);
      let col;
      if (Math.random() < mistake()) col = valid[(Math.random() * valid.length) | 0];
      else {
        let best = -Infinity;
        for (const c of [3, 2, 4, 1, 5, 0, 6]) {
          const r = dropRow(board, c); if (r < 0) continue;
          board[r][c] = 2; const s = minimax(board, depth() - 1, -Infinity, Infinity, false); board[r][c] = 0;
          if (s > best) { best = s; col = c; }
        }
      }
      drop(col, 2);
    }
    function finish(w) {
      result = w; busy = true; hud();
      const { cs, ox, oy } = geo();
      if (w.p === 1) { api.sfx.win(); w.cells.forEach(([r, c]) => fx.burst(ox + (c + 0.5) * cs, oy + (r + 0.5) * cs, '#ffd60a', 14, 200)); }
      else if (w.p === 2) api.sfx.lose(); else api.sfx.slide();
      const score = w.p === 1 ? Math.max(100, 500 - moves * 10) + L * 30 : w.p === 'draw' ? 80 : 0;
      if (api.mp) { setTimeout(() => api.gameOver({ winner: w.p === 'draw' ? -1 : w.p - 1 }), 1400); return; }
      setTimeout(() => api.gameOver({ score, coins: w.p === 1 ? 8 + L * 2 : w.p === 'draw' ? 3 : 1, win: w.p === 1, title: w.p === 1 ? 'Kazandın! 🔴' : w.p === 2 ? 'Bilgisayar kazandı 🟡' : 'Berabere 🤝' }), 1400);
    }
    st.canvas.addEventListener('pointermove', (e) => { const { cs, ox } = geo(); hover = Math.max(0, Math.min(C - 1, Math.floor((st.point(e).x - ox) / cs))); });
    st.canvas.addEventListener('pointerup', (e) => {
      if (busy || (turn !== 1 && !api.mp) || (ON && turn !== ON.me + 1)) return;
      const { cs, ox } = geo(); const c = Math.floor((st.point(e).x - ox) / cs);
      if (c >= 0 && c < C) { hover = c; if (!drop(c, api.mp ? turn : 1)) api.sfx.wrong(); else ON?.send({ c }); }
    });
    function update(dt) {
      if (ON && inbox.length && !busy && !result) { const mv = inbox.shift(); drop(mv.c, turn); }
      if (falling) {
        falling.vy += 40 * dt; falling.y += falling.vy * dt;
        if (falling.y >= falling.r) { falling.y = falling.r; land(); }
      }
      fx.update(dt); draw();
    }
    function disc(c, x, y, r, p) {
      const g = c.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r);
      g.addColorStop(0, p === 1 ? '#ff8fa3' : '#fff3b0'); g.addColorStop(1, p === 1 ? '#d00000' : '#f4a100');
      c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill();
      c.strokeStyle = 'rgba(0,0,0,.15)'; c.lineWidth = 3; c.beginPath(); c.arc(x, y, r * 0.7, 0, 7); c.stroke();
    }
    function draw() {
      const c = st.ctx, { cs, ox, oy } = geo();
      const g = c.createLinearGradient(0, 0, 0, st.H); g.addColorStop(0, '#caf0f8'); g.addColorStop(1, '#90e0ef');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      if (!busy && (turn === 1 || api.mp) && (!ON || turn === ON.me + 1)) disc(c, ox + (hover + 0.5) * cs, oy - cs * 0.6, cs * 0.4, api.mp ? turn : 1);
      for (let r = 0; r < R; r++) for (let col = 0; col < C; col++) if (board[r][col]) disc(c, ox + (col + 0.5) * cs, oy + (r + 0.5) * cs, cs * 0.4, board[r][col]);
      if (falling) disc(c, ox + (falling.c + 0.5) * cs, oy + (falling.y + 0.5) * cs, cs * 0.4, falling.p);
      // delikli mavi tahta
      c.save();
      c.beginPath(); roundRect(c, ox - 8, oy - 8, cs * C + 16, cs * R + 16, 18);
      for (let r = 0; r < R; r++) for (let col = 0; col < C; col++) { c.moveTo(ox + (col + 0.5) * cs + cs * 0.42, oy + (r + 0.5) * cs); c.arc(ox + (col + 0.5) * cs, oy + (r + 0.5) * cs, cs * 0.42, 0, Math.PI * 2, true); }
      c.fillStyle = '#0077b6'; c.fill('evenodd');
      c.restore();
      if (result?.cells) { c.strokeStyle = '#fff'; c.lineWidth = 6; c.beginPath(); result.cells.forEach(([r, col], i) => { const x = ox + (col + 0.5) * cs, y = oy + (r + 0.5) * cs; i ? c.lineTo(x, y) : c.moveTo(x, y); }); c.stroke(); }
      c.fillStyle = '#023e8a'; c.font = '800 13px system-ui'; c.textAlign = 'center';
      if (!api.mp) c.fillText(`Rakip gücü: ${'★'.repeat(Math.min(6, L))}${'☆'.repeat(Math.max(0, 6 - L))}`, st.W / 2, oy + cs * R + 34);
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
