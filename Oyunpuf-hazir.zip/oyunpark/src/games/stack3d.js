// 🏗️ Kule Yap 3D: kayan bloğu doğru anda bırak, kuleyi yükselt
import { create3D, mat, THREE } from '../core/three-stage.js';
import { modelInto } from '../core/assets.js';

export default {
  id: 'stack', title: 'Kule Yap 3D', emoji: '🏗️', color: '#e85d04',
  desc: 'Doğru anda dokun, en yüksek kuleyi yap!',
  target: (L) => 10 + (L - 1) * 6,
  create(host, api) {
    const S = create3D(host, { ortho: true, orthoSize: 7, bg: 0x9bd1ff });
    const { scene, camera, sun } = S;
    // dar ekranda kule tamamen görünsün
    S.onResize(() => { const a = S.w / S.h, sz = Math.max(7.5, 5.2 / a); Object.assign(camera, { left: -sz * a, right: sz * a, top: sz, bottom: -sz }); camera.updateProjectionMatrix(); });
    const H = 0.55;
    let blocks, cur, falling, score, over, perfect, L, camY, hue0;
    const boxGeo = new THREE.BoxGeometry(1, 1, 1);
    // dekor (Kenney, MIT): kulenin dibinde çimenli ada ve ağaçlar, etrafta bulutlar
    const island = modelInto(scene, 'platform-grass-large-round', { size: 9 }); island.position.set(0, -6.6, 0);
    [[-3.2, -2.4], [3.0, -2.8], [-2.8, 2.9], [3.4, 2.2]].forEach(([x, z]) => { const t = modelInto(scene, 'decoration-forest', { height: 2.2 }); t.position.set(x, -6.0, z); });
    const clouds = [];
    for (let i = 0; i < 14; i++) { const c = modelInto(scene, 'cloud', { size: 2 + Math.random() * 1.6 }); const a = Math.random() * 6.28, r = 7 + Math.random() * 5; c.position.set(Math.cos(a) * r - 4, -2 + i * 3.2, Math.sin(a) * r - 4); c.userData.v = 0.2 + Math.random() * 0.3; clouds.push(c); }

    function mkBlock(w, d, x, z, y, hue) {
      const m = new THREE.Mesh(boxGeo, mat(new THREE.Color().setHSL(hue / 360, 0.8, 0.55), { roughness: 0.45 }));
      m.scale.set(w, H, d); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true;
      scene.add(m); return { m, w, d, x, z, y, hue };
    }
    function clear() { blocks?.forEach((b) => scene.remove(b.m)); falling?.forEach((f) => scene.remove(f.m)); if (cur) scene.remove(cur.m); }
    function start() {
      clear();
      L = api.level; hue0 = Math.random() * 360;
      const w = 3 * Math.max(0.6, 1 - (L - 1) * 0.06);
      // taban
      const base = new THREE.Mesh(boxGeo, mat(new THREE.Color().setHSL(hue0 / 360, 0.35, 0.4))); base.scale.set(w, 6, w); base.position.y = -3 - H / 2; base.receiveShadow = true;
      scene.add(base);
      blocks = [{ m: base, w, d: w, x: 0, z: 0, y: -H, hue: hue0 }];
      falling = []; score = 0; over = false; perfect = 0; camY = 0;
      next(); hud();
    }
    function hud() { api.setHud({ score, scoreLabel: 'Kat', extra: perfect > 1 ? `Mükemmel ×${perfect} ✨` : 'Doğru anda dokun' }); }
    const speed = () => Math.min(5.5 + L * 0.35, 2 + L * 0.35 + score * (0.08 + L * 0.012));
    function next() {
      const top = blocks[blocks.length - 1];
      const axis = blocks.length % 2 ? 'x' : 'z';
      const hue = (top.hue + 9) % 360;
      cur = mkBlock(top.w, top.d, top.x, top.z, top.y + H, hue);
      cur.axis = axis; cur.dir = 1; cur.t = -6.5;
      cur[axis] = top[axis] + cur.t;
    }
    function drop() {
      if (over || !cur) return;
      const top = blocks[blocks.length - 1], ax = cur.axis, size = ax === 'x' ? 'w' : 'd';
      const delta = cur[ax] - top[ax];
      const overlap = top[size] - Math.abs(delta);
      if (overlap <= 0) {
        falling.push({ ...cur, vy: 0, rot: (Math.random() - 0.5) * 3 }); cur = null; over = true;
        api.sfx.lose(); api.haptic('heavy');
        setTimeout(() => api.gameOver({ score, coins: Math.floor(score * 1.5), canContinue: true, title: 'Kule bitti! 🏗️' }), 900);
        return;
      }
      const tol = Math.max(0.04, 0.13 - L * 0.009);
      if (Math.abs(delta) < tol) {
        perfect++; cur[ax] = top[ax]; api.sfx.combo(perfect);
        const grow = perfect >= 3 ? Math.min(0.15, 3 - cur[size]) : 0;
        cur[size] += Math.max(0, grow);
        S.popText(new THREE.Vector3(cur.x, cur.y + 0.6, cur.z), 'MÜKEMMEL!', '#ffd60a');
        // halka efekti
        const ring = new THREE.Mesh(new THREE.RingGeometry(0.1, 0.18, 32), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, side: THREE.DoubleSide }));
        ring.rotation.x = -Math.PI / 2; ring.position.set(cur.x, cur.y - H / 2 + 0.01, cur.z); ring.userData.t = 0; scene.add(ring); falling.push({ ring });
      } else {
        perfect = 0; api.sfx.brick();
        // taşan parça düşer
        const cutSize = Math.abs(delta);
        const cutPos = cur[ax] + Math.sign(delta) * (overlap / 2 + cutSize / 2) - Math.sign(delta) * 0;
        const piece = mkBlock(ax === 'x' ? cutSize : cur.w, ax === 'z' ? cutSize : cur.d, ax === 'x' ? top.x + Math.sign(delta) * (top.w / 2 + cutSize / 2) : cur.x, ax === 'z' ? top.z + Math.sign(delta) * (top.d / 2 + cutSize / 2) : cur.z, cur.y, cur.hue);
        void cutPos;
        falling.push({ ...piece, vy: 0, rot: (Math.random() - 0.5) * 4, ax });
        cur[size] = overlap;
        cur[ax] = top[ax] + delta / 2;
      }
      cur.m.scale.set(cur.w, H, cur.d); cur.m.position.set(cur.x, cur.y, cur.z);
      blocks.push(cur); api.haptic('light');
      score++; hud(); next();
    }
    S.el.addEventListener('pointerdown', drop);
    const onKey = (e) => { if (e.key === ' ') drop(); };
    window.addEventListener('keydown', onKey);

    const lp = S.loop((dt) => {
      if (cur && !over) {
        cur.t += cur.dir * speed() * dt;
        if (cur.t > 6.5) cur.dir = -1; if (cur.t < -6.5) cur.dir = 1;
        const top = blocks[blocks.length - 1];
        cur[cur.axis] = top[cur.axis] + cur.t;
        cur.m.position.set(cur.x, cur.y, cur.z);
      }
      falling = falling.filter((f) => {
        if (f.ring) { f.ring.userData.t += dt; f.ring.scale.setScalar(1 + f.ring.userData.t * 25); f.ring.material.opacity = 1 - f.ring.userData.t * 2; if (f.ring.userData.t > 0.5) { scene.remove(f.ring); return false; } return true; }
        f.vy -= 20 * dt; f.m.position.y += f.vy * dt;
        f.m.rotation[f.ax === 'z' ? 'x' : 'z'] += f.rot * dt;
        if (f.m.position.y < camY - 20) { scene.remove(f.m); return false; }
        return true;
      });
      const topY = (cur || blocks[blocks.length - 1]).y;
      camY += (topY - camY) * Math.min(1, dt * 4);
      camera.position.set(10, camY + 9, 10); camera.lookAt(0, camY - 1.5, 0);
      clouds.forEach((c) => { c.position.x += c.userData.v * dt; if (c.position.x > 10) c.position.x = -14; if (c.position.y < camY - 14) c.position.y += 45; });
      sun.position.set(-4, camY + 14, 6); sun.target.position.set(0, camY, 0);
      // gökyüzü rengi yükseldikçe değişir
      scene.background.setHSL(((hue0 + 180 + score * 4) % 360) / 360, 0.45, Math.max(0.15, 0.42 - score * 0.008));
    });

    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { over = false; next(); hud(); },
      restart() { start(); },
      destroy() { window.removeEventListener('keydown', onKey); S.destroy(); },
    };
  },
};
