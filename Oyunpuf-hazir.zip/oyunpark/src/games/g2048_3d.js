// 🔢 2048 3D: kaydır, aynı sayıları birleştir
import { create3D, mat, THREE } from '../core/three-stage.js';
import { expert, expertSteps } from '../core/expert.js';
import { boardKit, roundedBox, textTexture } from '../core/board3d.js';

const COLORS = { 2: '#eee4da', 4: '#ede0c8', 8: '#f2b179', 16: '#f59563', 32: '#f67c5f', 64: '#f65e3b', 128: '#edcf72', 256: '#edcc61', 512: '#edc850', 1024: '#edc53f', 2048: '#edc22e' };

export default {
  id: 'g2048', title: '2048 3D', emoji: '🔢', color: '#f59563',
  desc: 'Kaydır, aynı sayıları birleştir!',
  expertFrom: 8,
  target: (L) => Math.round(1000 * Math.pow(1.28, L - 1)), // daha dengeli: Sv.12 ≈ 15 bin puan
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0xfaedcd });
    const { scene } = S;
    const N = 4, CS = 1.15;
    const K = boardKit(S, N, N, { cell: CS, tilt: 0.36, height: 1.2 });
    const table = new THREE.Mesh(new THREE.CylinderGeometry(10, 10, 0.3, 48), mat(0xd4a373)); table.position.y = -0.65; table.receiveShadow = true; scene.add(table);
    const board = new THREE.Mesh(roundedBox(N * CS + 0.3, 0.4, N * CS + 0.3, 0.25), mat(0xbbada0)); board.position.y = -0.5; board.receiveShadow = true; board.castShadow = true; scene.add(board);
    const slotGeo = roundedBox(CS * 0.9, 0.05, CS * 0.9, 0.12);
    for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) { const s = new THREE.Mesh(slotGeo, mat(0xcdc1b4)); s.position.copy(K.pos(c, r, -0.1)); s.receiveShadow = true; scene.add(s); }
    const tileGroup = new THREE.Group(); scene.add(tileGroup);
    const tileGeo = roundedBox(CS * 0.86, 0.5, CS * 0.86, 0.14);
    const topGeo = new THREE.PlaneGeometry(CS * 0.8, CS * 0.8);
    const tileMats = {};
    const tmat = (v) => tileMats[v] || (tileMats[v] = mat(new THREE.Color(COLORS[v] || '#3c3a32'), { roughness: 0.35, emissive: v >= 128 ? new THREE.Color(COLORS[v] || '#3c3a32') : 0x000000, emissiveIntensity: v >= 128 ? 0.25 : 0 }));
    function meshFor(t) {
      const g = new THREE.Group();
      const body = new THREE.Mesh(tileGeo, tmat(t.v)); body.castShadow = true; body.receiveShadow = true; g.add(body);
      const top = new THREE.Mesh(topGeo, new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false })); top.rotation.x = -Math.PI / 2; top.position.y = 0.505; g.add(top);
      g.userData = { body, top, v: 0 };
      return g;
    }
    function setLook(t) {
      const u = t.m.userData; if (u.v === t.v) return; u.v = t.v;
      u.body.material = tmat(t.v);
      const fs = t.v < 100 ? '900 76px system-ui' : t.v < 1000 ? '900 60px system-ui' : '900 46px system-ui';
      u.top.material.map = textTexture(String(t.v), { color: t.v <= 4 ? '#776e65' : '#ffffff', font: fs }); u.top.material.needsUpdate = true;
    }
    let grid, tiles, score, over, won, idSeq;
    function start() {
      tileGroup.clear(); grid = Array.from({ length: N }, () => Array(N).fill(null)); tiles = []; score = 0; over = false; won = false; idSeq = 0;
      add(); add(); hud();
    }
    function add() {
      const empty = [];
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (!grid[r][c]) empty.push([r, c]);
      if (!empty.length) return;
      const [r, c] = empty[(Math.random() * empty.length) | 0];
      const t = { id: idSeq++, v: Math.random() < Math.max(0.5, 0.9 - (api.level - 1) * 0.07) ? 2 : 4, r, c, x: c, y: r, pop: 0, born: 0 };
      t.m = meshFor(t); tileGroup.add(t.m); setLook(t);
      grid[r][c] = t; tiles.push(t);
    }
    function hud() { api.setHud({ score, extra: `En büyük: ${Math.max(0, ...tiles.map((t) => t.v))}` }); }
    function move(dr, dc) {
      if (over) return;
      let moved = false, gained = 0;
      const merged = new Set();
      const order = [...Array(N).keys()];
      const rows = dr > 0 ? order.slice().reverse() : order;
      const cols = dc > 0 ? order.slice().reverse() : order;
      for (const r of rows) for (const c of cols) {
        const t = grid[r][c]; if (!t) continue;
        let nr = r, nc = c;
        while (true) {
          const tr = nr + dr, tc = nc + dc;
          if (tr < 0 || tr >= N || tc < 0 || tc >= N) break;
          const o = grid[tr][tc];
          if (!o) { nr = tr; nc = tc; continue; }
          if (o.v === t.v && !merged.has(o)) {
            grid[r][c] = null; o.v *= 2; o.pop = 1; merged.add(o); gained += o.v;
            t.r = tr; t.c = tc; t.dead = true; moved = true;
            if (o.v === 2048 && !won) { won = true; api.sfx.win(); }
          }
          break;
        }
        if (!t.dead && (nr !== r || nc !== c)) { grid[r][c] = null; grid[nr][nc] = t; t.r = nr; t.c = nc; moved = true; }
      }
      if (!moved) return;
      score += gained;
      setTimeout(() => { tiles = tiles.filter((t) => { if (t.dead) tileGroup.remove(t.m); return !t.dead; }); }, 110);
      if (gained) { api.sfx.pop(); api.haptic('light'); } else api.sfx.slide();
      add();
      if (api.level >= 3 && Math.random() < Math.min(0.45, (api.level - 2) * 0.1) + Math.min(0.2, expertSteps(api.level, 7) * 0.025)) add(); // zor seviyede fazladan taş
      hud();
      if (!canMove()) {
        over = true; api.sfx.lose();
        setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 80), canContinue: true }), 500);
      }
    }
    function canMove() {
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const t = grid[r][c]; if (!t) return true;
        if (c < N - 1 && grid[r][c + 1]?.v === t.v) return true;
        if (r < N - 1 && grid[r + 1][c]?.v === t.v) return true;
      }
      return false;
    }
    let down = null;
    S.el.addEventListener('pointerdown', (e) => (down = { x: e.clientX, y: e.clientY }));
    S.el.addEventListener('pointerup', (e) => {
      if (!down) return;
      const dx = e.clientX - down.x, dy = e.clientY - down.y; down = null;
      if (Math.hypot(dx, dy) < 20) return;
      Math.abs(dx) > Math.abs(dy) ? move(0, Math.sign(dx)) : move(Math.sign(dy), 0);
    });
    const onKey = (e) => { const k = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] }[e.key]; if (k) move(...k); };
    window.addEventListener('keydown', onKey);
    const lp = S.loop((dt) => {
      for (const t of tiles) {
        t.x += (t.c - t.x) * Math.min(1, dt * 20); t.y += (t.r - t.y) * Math.min(1, dt * 20);
        if (t.pop > 0) { t.pop = Math.max(0, t.pop - dt * 5); }
        t.born = Math.min(1, t.born + dt * 6);
        setLook(t);
        const s = (1 + t.pop * 0.18 * Math.sin(t.pop * Math.PI)) * t.born;
        const h = 1 + Math.log2(t.v) * 0.12; // büyük sayılar daha yüksek
        t.m.position.set((t.x - (N - 1) / 2) * CS, -0.1 + t.pop * 0.4, (t.y - (N - 1) / 2) * CS);
        t.m.scale.set(Math.max(0.01, s), Math.max(0.01, s * h), Math.max(0.01, s));
      }
      S.updateParts(dt, 0);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() {
        tiles.filter((t) => !t.dead).sort((a, b) => a.v - b.v).slice(0, 4).forEach((t) => { grid[t.r][t.c] = null; t.dead = true; tileGroup.remove(t.m); });
        tiles = tiles.filter((t) => !t.dead); over = false; hud();
      },
      restart() { start(); },
      destroy() { S.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
