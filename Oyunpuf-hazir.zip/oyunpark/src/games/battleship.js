// 🚢 Amiral Battı (online, 2 kişi): gemilerini yerleştir, sırayla atış yap; isabet edersen tekrar atarsın
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

const N = 8, SHIPS = [4, 3, 3, 2, 2];

function randomFleet() {
  const grid = Array.from({ length: N }, () => Array(N).fill(-1));
  const ships = [];
  SHIPS.forEach((len, id) => {
    for (let tries = 0; tries < 500; tries++) {
      const hor = Math.random() < 0.5, r = (Math.random() * (hor ? N : N - len + 1)) | 0, c = (Math.random() * (hor ? N - len + 1 : N)) | 0;
      const cells = Array.from({ length: len }, (_, k) => [r + (hor ? 0 : k), c + (hor ? k : 0)]);
      // gemiler birbirine değmesin
      if (cells.every(([a, b]) => { for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) { const v = grid[a + dr]?.[b + dc]; if (v !== undefined && v !== -1) return false; } return true; })) {
        cells.forEach(([a, b]) => (grid[a][b] = id)); ships.push({ id, cells, hits: 0 }); break;
      }
    }
  });
  return { grid, ships };
}

export default {
  id: 'battleship', title: 'Amiral Battı', emoji: '🚢', color: '#0077b6',
  desc: 'Gemileri yerleştir, rakibin filosunu batır!',
  onlineOnly: true, online: { min: 2, max: 2 },
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    const ON = api.mp?.online, me = ON?.me ?? 0, names = api.mp?.names || ['Sen', 'Rakip'];
    let fleet, myShots, enemyShots, phase, readyMe, readyThem, turn, pending, over, sunkCount, enemySunk, inbox = [];
    ON?.on((m) => inbox.push(m));

    function start() {
      fleet = randomFleet();
      myShots = Array.from({ length: N }, () => Array(N).fill(0));    // rakip tahtasına attıklarım: 0 boş, 1 ıska, 2 isabet, 3 batık
      enemyShots = Array.from({ length: N }, () => Array(N).fill(0)); // bana atılanlar
      phase = 'place'; readyMe = false; readyThem = false; turn = 0; pending = false; over = false; sunkCount = 0; enemySunk = 0; inbox.length = 0;
      hud();
    }
    function hud() {
      api.setHud({ score: `${enemySunk} - ${sunkCount}`, scoreLabel: 'Batan gemi', extra: phase === 'place' ? (readyMe ? 'Rakip hazırlanıyor…' : 'Gemilerini yerleştir') : turn === me ? '🎯 Senin sıran — rakip tahtaya ateş et' : `${names[1 - me]} ateş ediyor…` });
    }
    function geo() {
      const big = Math.min(st.W - 24, st.H * 0.52), small = Math.min(st.W * 0.5, st.H * 0.26);
      return { big, bx: (st.W - big) / 2, by: 30, small, sx: (st.W - small) / 2, sy: 30 + big + 46 };
    }
    function btns() { const g = geo(), w = Math.min(160, (st.W - 36) / 2); return { shuffle: { x: st.W / 2 - w - 6, y: g.sy + g.small + 14, w, h: 48 }, ready: { x: st.W / 2 + 6, y: g.sy + g.small + 14, w, h: 48 } }; }
    const inside = (p, b) => p.x > b.x && p.x < b.x + b.w && p.y > b.y && p.y < b.y + b.h;

    st.canvas.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = st.point(e), g = geo();
      if (phase === 'place' && !readyMe) {
        const B = btns();
        if (inside(p, B.shuffle)) { fleet = randomFleet(); api.sfx.swap(); }
        if (inside(p, B.ready)) { readyMe = true; ON?.send({ ready: true }); api.sfx.tap(); hud(); maybeStart(); }
        return;
      }
      if (phase !== 'battle' || turn !== me || pending) return;
      const cs = g.big / N, c = Math.floor((p.x - g.bx) / cs), r = Math.floor((p.y - g.by) / cs);
      if (r < 0 || r >= N || c < 0 || c >= N || myShots[r][c]) return;
      pending = true; myShots[r][c] = -1; ON?.send({ shot: [r, c] }); api.sfx.tap();
    });
    function maybeStart() { if (readyMe && readyThem) { phase = 'battle'; turn = 0; api.sfx.power(); hud(); } }
    function handle(m) {
      if (m.ready) { readyThem = true; maybeStart(); return true; }
      if (m.shot && phase === 'battle') {
        // rakip bana ateş etti: sonucu ben hesaplayıp geri bildiririm
        const [r, c] = m.shot, id = fleet.grid[r][c];
        let res = { r, c, hit: false };
        if (id >= 0 && enemyShots[r][c] === 0) {
          const ship = fleet.ships[id]; ship.hits++; enemyShots[r][c] = 2; res.hit = true;
          if (ship.hits === ship.cells.length) { sunkCount++; res.sunk = ship.cells; ship.cells.forEach(([a, b]) => (enemyShots[a][b] = 3)); }
          res.all = sunkCount === SHIPS.length;
          api.sfx.crash(); api.haptic('medium');
        } else { if (!enemyShots[r][c]) enemyShots[r][c] = 1; api.sfx.slide(); }
        ON?.send({ res });
        turn = res.hit ? 1 - me : me;
        if (res.all) { over = true; setTimeout(() => api.gameOver({ winner: 1 - me }), 1200); }
        hud(); return true;
      }
      if (m.res) {
        const { r, c, hit, sunk, all } = m.res, g = geo(), cs = g.big / N;
        myShots[r][c] = hit ? 2 : 1;
        if (sunk) { sunk.forEach(([a, b]) => (myShots[a][b] = 3)); enemySunk++; api.sfx.win(); }
        if (hit) { fx.burst(g.bx + (c + 0.5) * cs, g.by + (r + 0.5) * cs, '#ff9f1c', 18, 200); api.sfx.crash(); } else api.sfx.slide();
        pending = false; turn = hit ? me : 1 - me;
        if (all) { over = true; setTimeout(() => api.gameOver({ winner: me }), 1200); }
        hud(); return true;
      }
      return false;
    }
    function grid(c, x, y, size, cellFn) {
      const cs = size / N;
      roundRect(c, x - 4, y - 4, size + 8, size + 8, 10); c.fillStyle = '#023e8a'; c.fill();
      for (let r = 0; r < N; r++) for (let col = 0; col < N; col++) {
        c.fillStyle = (r + col) % 2 ? '#0096c7' : '#00a6d6'; c.fillRect(x + col * cs, y + r * cs, cs - 1, cs - 1);
        cellFn(r, col, x + col * cs, y + r * cs, cs);
      }
    }
    function update(dt, t) {
      while (inbox.length) { if (!handle(inbox[0])) break; inbox.shift(); }
      fx.update(dt); draw(t);
    }
    function draw(t) {
      const c = st.ctx, g = geo();
      c.fillStyle = '#03045e'; c.fillRect(0, 0, st.W, st.H);
      c.fillStyle = '#caf0f8'; c.font = '800 14px system-ui'; c.textAlign = 'center';
      c.fillText(phase === 'place' ? 'Rakibin denizi (oyun başlayınca)' : `${names[1 - me]} denizi — ateş et`, st.W / 2, 20);
      grid(c, g.bx, g.by, g.big, (r, col, x, y, cs) => {
        const v = myShots[r][col];
        if (v === 1) { c.fillStyle = '#fff'; c.beginPath(); c.arc(x + cs / 2, y + cs / 2, cs * 0.12, 0, 7); c.fill(); }
        if (v === 2 || v === 3) { c.fillStyle = v === 3 ? '#6a040f' : '#ef233c'; c.fillRect(x + 2, y + 2, cs - 5, cs - 5); c.fillStyle = '#ffd60a'; c.font = `900 ${cs * 0.5}px system-ui`; c.textBaseline = 'middle'; c.fillText('✕', x + cs / 2, y + cs / 2); c.textBaseline = 'alphabetic'; }
        if (v === -1) { c.strokeStyle = '#ffd60a'; c.lineWidth = 2; c.strokeRect(x + 3, y + 3, cs - 7, cs - 7); }
      });
      if (phase === 'battle' && turn === me && !pending) { c.strokeStyle = `rgba(255,214,10,${0.5 + Math.sin(t * 6) * 0.4})`; c.lineWidth = 4; c.strokeRect(g.bx - 6, g.by - 6, g.big + 12, g.big + 12); }
      c.fillStyle = '#caf0f8'; c.fillText('Senin filon', st.W / 2, g.sy - 10);
      grid(c, g.sx, g.sy, g.small, (r, col, x, y, cs) => {
        if (fleet.grid[r][col] >= 0) { c.fillStyle = '#adb5bd'; roundRect(c, x + 1, y + 1, cs - 3, cs - 3, 3); c.fill(); }
        const v = enemyShots[r][col];
        if (v === 1) { c.fillStyle = '#fff'; c.beginPath(); c.arc(x + cs / 2, y + cs / 2, cs * 0.14, 0, 7); c.fill(); }
        if (v >= 2) { c.fillStyle = v === 3 ? '#6a040f' : '#ef233c'; c.fillRect(x + 2, y + 2, cs - 5, cs - 5); }
      });
      if (phase === 'place') {
        const B = btns();
        [['shuffle', '🔀 Karıştır', '#48cae4'], ['ready', readyMe ? '✓ Hazırsın' : '✓ Hazırım', readyMe ? '#6c757d' : '#2dc653']].forEach(([k, txt, col]) => {
          const b = B[k]; roundRect(c, b.x, b.y, b.w, b.h, 14); c.fillStyle = readyMe && k === 'shuffle' ? '#495057' : col; c.fill();
          c.fillStyle = '#fff'; c.font = '800 16px system-ui'; c.textBaseline = 'middle'; c.fillText(txt, b.x + b.w / 2, b.y + b.h / 2); c.textBaseline = 'alphabetic';
        });
      }
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
