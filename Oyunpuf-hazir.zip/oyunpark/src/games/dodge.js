// ☄️ Kaç Kurtul: parmağınla topu sürükle, düşen ve seken göktaşlarından kaç
import { createStage, loop, particles } from '../core/canvas.js';

export default {
  id: 'dodge', title: 'Kaç Kurtul', emoji: '☄️', color: '#e63946',
  desc: 'Göktaşlarından kaç, ne kadar dayanabilirsin?',
  target: (L) => Math.round(300 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let me, rocks, gems, time, score, spawnIn, over, L, shield, gemsGot;
    const S = () => Math.min(st.W, 500) / 400;

    function start() {
      L = api.level; me = { x: st.W / 2, y: st.H * 0.75, r: 13 * S() };
      rocks = []; gems = []; time = 0; score = 0; spawnIn = 0.5; over = false; shield = 0; gemsGot = 0; hud();
    }
    function hud() { api.setHud({ score, extra: `⏱ ${Math.floor(time)} sn · 💎 ${gemsGot}` }); }
    function spawn() {
      const d = L + time / 12; // oynadıkça zorlaşır
      const r = (10 + Math.random() * (10 + d * 1.5)) * S();
      const kind = Math.random() < Math.min(0.4, d * 0.04) ? 'bounce' : Math.random() < Math.min(0.3, d * 0.03) ? 'homing' : 'fall';
      const sp = (110 + d * 22 + Math.random() * 60) * S();
      rocks.push({ x: Math.random() * st.W, y: -r, r, vx: kind === 'bounce' ? (Math.random() - 0.5) * sp : 0, vy: sp, kind, rot: 0 });
      if (Math.random() < 0.12) gems.push({ x: 20 + Math.random() * (st.W - 40), y: -10, vy: 120 * S() });
      spawnIn = Math.max(0.1, 0.7 - L * 0.05 - time * 0.008);
    }
    let drag = null;
    st.canvas.addEventListener('pointerdown', (e) => { drag = { p: st.point(e), x: me.x, y: me.y }; });
    st.canvas.addEventListener('pointermove', (e) => {
      if (!drag || over) return; const p = st.point(e);
      me.x = Math.max(me.r, Math.min(st.W - me.r, drag.x + p.x - drag.p.x));
      me.y = Math.max(me.r, Math.min(st.H - me.r, drag.y + p.y - drag.p.y));
    });
    const up = () => (drag = null);
    window.addEventListener('pointerup', up);

    function update(dt, t) {
      if (!over) {
        time += dt; const ns = Math.floor(time * 10) + gemsGot * 30;
        if (ns !== score) { score = ns; if ((t * 10 | 0) % 3 === 0) hud(); }
        if (shield > 0) shield -= dt;
        spawnIn -= dt; if (spawnIn <= 0) spawn();
        for (const r of rocks) {
          if (r.kind === 'homing') r.vx += Math.sign(me.x - r.x) * 60 * S() * dt;
          r.x += r.vx * dt; r.y += r.vy * dt; r.rot += dt * 2;
          if (r.kind === 'bounce' && (r.x < r.r || r.x > st.W - r.r)) r.vx *= -1;
          if (Math.hypot(r.x - me.x, r.y - me.y) < r.r + me.r * 0.8 && shield <= 0) {
            over = true; api.sfx.crash(); api.haptic('heavy'); fx.burst(me.x, me.y, '#ffd60a', 30, 260);
            setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 25) + gemsGot * 2, canContinue: true, title: 'Göktaşı çarptı! ☄️' }), 600);
          }
        }
        rocks = rocks.filter((r) => r.y < st.H + 50);
        for (const g of gems) {
          g.y += g.vy * dt;
          if (Math.hypot(g.x - me.x, g.y - me.y) < me.r + 12) { g.dead = true; gemsGot++; api.sfx.coin(); fx.text(g.x, g.y, '💎 +30', '#80ffdb'); hud(); }
        }
        gems = gems.filter((g) => !g.dead && g.y < st.H + 20);
      }
      fx.update(dt); draw(t);
    }
    function draw(t) {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H); g.addColorStop(0, '#03071e'); g.addColorStop(1, '#370617');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      for (const r of rocks) {
        c.save(); c.translate(r.x, r.y); c.rotate(r.rot);
        c.fillStyle = r.kind === 'homing' ? '#f72585' : r.kind === 'bounce' ? '#f48c06' : '#6c584c';
        c.beginPath();
        for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4, rr = r.r * (0.8 + ((i * 7) % 3) * 0.12); i ? c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr) : c.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); }
        c.closePath(); c.fill();
        c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.arc(r.r * 0.25, -r.r * 0.2, r.r * 0.25, 0, 7); c.fill();
        c.restore();
      }
      for (const gm of gems) { c.fillStyle = '#80ffdb'; c.beginPath(); c.moveTo(gm.x, gm.y - 10); c.lineTo(gm.x + 8, gm.y); c.lineTo(gm.x, gm.y + 10); c.lineTo(gm.x - 8, gm.y); c.fill(); }
      if (!over) {
        c.fillStyle = '#ffd60a'; c.shadowColor = '#ffd60a'; c.shadowBlur = 18;
        c.beginPath(); c.arc(me.x, me.y, me.r, 0, 7); c.fill(); c.shadowBlur = 0;
        if (shield > 0 && Math.floor(t * 10) % 2) { c.strokeStyle = '#80ffdb'; c.lineWidth = 3; c.beginPath(); c.arc(me.x, me.y, me.r + 8, 0, 7); c.stroke(); }
      }
      if (time < 3) { c.fillStyle = 'rgba(255,255,255,.7)'; c.font = '700 15px system-ui'; c.textAlign = 'center'; c.fillText('Parmağını kaydırarak topu hareket ettir', st.W / 2, st.H - 24); }
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { rocks = []; shield = 3; over = false; hud(); },
      restart() { start(); }, destroy() { lp.stop(); st.destroy(); window.removeEventListener('pointerup', up); },
    };
  },
};
