// 🔨 Köstebek Vur 3D (45 saniye)
import { create3D, mat, THREE } from '../core/three-stage.js';
import { expert, expertSteps } from '../core/expert.js';

export default {
  id: 'mole', title: 'Köstebek Vur 3D', emoji: '🔨', color: '#bc6c25',
  desc: 'Çıkan köstebeklere hızlıca vur!',
  expertFrom: 12,
  target: (L) => Math.round(300 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 48, bg: 0x8ecae6 });
    const { scene, camera } = S;
    S.onResize(() => { const a = S.w / S.h, d = Math.max(12, 8.2 / a); camera.position.set(0, d * 0.95, d * 0.62); camera.lookAt(0, 0, 0.6); });
    const GAME_TIME = 45;
    // çim zemin + çiçekler
    const ground = new THREE.Mesh(new THREE.CylinderGeometry(9, 9.5, 1, 40), mat(0x6aa84f, { roughness: 1 })); ground.position.y = -0.5; ground.receiveShadow = true; scene.add(ground);
    for (let i = 0; i < 40; i++) {
      const f = new THREE.Mesh(new THREE.SphereGeometry(0.08, 6, 4), mat([0xff70a6, 0xffd60a, 0xffffff][i % 3]));
      const a = Math.random() * 7, r = 4.5 + Math.random() * 4; f.position.set(Math.cos(a) * r, 0.05, Math.sin(a) * r); scene.add(f);
    }
    const cols = 3, rows = 4, holes = [];
    const dirt = mat(0x6b4423, { roughness: 1 }), dark = new THREE.MeshBasicMaterial({ color: 0x1a0f05 });
    const body = mat(0x8d5524, { roughness: 0.8 }), belly = mat(0xc68642), gold = mat(0xffc300, { metalness: 0.6, roughness: 0.25 }), goldBelly = mat(0xffe066, { metalness: 0.4 });
    for (let i = 0; i < cols * rows; i++) {
      const x = (i % cols - 1) * 2.3, z = (((i / cols) | 0) - 1.5) * 2.0;
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.17, 10, 24), dirt); ring.rotation.x = -Math.PI / 2; ring.position.set(x, 0.02, z); ring.receiveShadow = true; scene.add(ring);
      const hole = new THREE.Mesh(new THREE.CircleGeometry(0.6, 24), dark); hole.rotation.x = -Math.PI / 2; hole.position.set(x, 0.03, z); scene.add(hole);
      // köstebek modeli
      const m = new THREE.Group();
      const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.48, 1.0, 18), body); torso.position.y = 0.5; torso.castShadow = true; m.add(torso);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.44, 20, 14), body); head.position.y = 1.0; head.castShadow = true; m.add(head);
      const bel = new THREE.Mesh(new THREE.SphereGeometry(0.3, 14, 10), belly); bel.position.set(0, 0.95, 0.24); bel.scale.set(1, 0.8, 0.6); m.add(bel);
      const eyeM = new THREE.MeshBasicMaterial({ color: 0x000000 });
      [-0.16, 0.16].forEach((ex) => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), eyeM); e.position.set(ex, 1.15, 0.38); m.add(e); });
      const nose = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), mat(0xff8fab)); nose.position.set(0, 1.02, 0.46); m.add(nose);
      const crown = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.3, 5), mat(0xff006e, { metalness: 0.5 })); crown.position.y = 1.55; m.add(crown);
      // bomba modeli
      const bomb = new THREE.Group();
      const bb = new THREE.Mesh(new THREE.SphereGeometry(0.45, 20, 14), mat(0x22223b, { roughness: 0.3, metalness: 0.4 })); bb.position.y = 0.8; bb.castShadow = true; bomb.add(bb);
      const fuse = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.3), mat(0xbc6c25)); fuse.position.set(0.15, 1.3, 0); fuse.rotation.z = -0.4; bomb.add(fuse);
      const spark = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffd60a })); spark.position.set(0.25, 1.45, 0); bomb.add(spark);
      m.position.set(x, -1.6, z); bomb.position.set(x, -1.6, z);
      scene.add(m); scene.add(bomb);
      holes.push({ x, z, m, bomb, torso, head, crown, spark, up: 0, state: 'down', t: 0, stay: 1, kind: 'mole' });
    }
    // çekiç
    const hammer = new THREE.Group();
    const hh = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.9, 16), mat(0xd62828)); hh.rotation.z = Math.PI / 2; hammer.add(hh);
    const hs = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 1.6), mat(0x9c6644)); hs.position.y = 0.8; hammer.add(hs);
    hammer.visible = false; scene.add(hammer);
    let hamT = 0;

    let score, timeLeft, spawnIn, over, combo, L;
    function start() { L = api.level; score = 0; timeLeft = GAME_TIME; spawnIn = 0.6; over = false; combo = 0; holes.forEach((h) => { h.up = 0; h.state = 'down'; }); hud(); }
    function hud() { api.setHud({ score, extra: `⏱ ${Math.ceil(timeLeft)} sn · Kombo ×${Math.max(1, combo)}` }); }
    function spawn() {
      const free = holes.filter((h) => h.state === 'down');
      if (free.length) {
        const h = free[(Math.random() * free.length) | 0], el = GAME_TIME - timeLeft;
        h.state = 'rising'; h.t = 0;
        h.stay = Math.max(0.32, 1.3 - L * 0.1 - el * 0.018) / (1 + (expert(L, 11) - 1) * 0.5);
        h.kind = Math.random() < Math.min(0.3, 0.1 + L * 0.025) ? 'bomb' : Math.random() < 0.1 ? 'gold' : 'mole';
        const g = h.kind === 'gold';
        h.torso.material = g ? gold : body; h.head.material = g ? gold : body; h.crown.visible = g;
        h.m.children[2].material = g ? goldBelly : belly;
      }
      spawnIn = Math.max(0.18, 0.85 - L * 0.06 - (GAME_TIME - timeLeft) * 0.012) / (1 + (expert(L, 11) - 1) * 0.5);
    }
    S.el.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = S.rayPlaneY(e, 0.7); if (!p) return;
      hammer.visible = true; hammer.position.set(p.x + 0.5, 2.2, p.z); hamT = 0.25;
      let best = null, bd = 1.0;
      for (const h of holes) { const d = Math.hypot(p.x - h.x, p.z - h.z); if (d < bd && h.up > 0.4 && h.state !== 'hit') { best = h; bd = d; } }
      if (!best) { combo = 0; hud(); return; }
      const pos = new THREE.Vector3(best.x, 1.2, best.z);
      if (best.kind === 'bomb') { score = Math.max(0, score - 30); combo = 0; api.sfx.crash(); api.haptic('heavy'); S.burst(pos, 0x333333, 20, 7); S.popText(pos, '-30', '#ff4d6d'); }
      else {
        combo++; const pts = (best.kind === 'gold' ? 30 : 10) * Math.min(combo, 5);
        score += pts; api.sfx[best.kind === 'gold' ? 'coin' : 'pop'](); api.haptic('medium');
        S.burst(pos, best.kind === 'gold' ? 0xffd60a : 0xc68642, 12, 5); S.popText(pos, '+' + pts, best.kind === 'gold' ? '#ffd60a' : '#fff');
      }
      best.state = 'hit'; best.t = 0; hud();
    });
    const lp = S.loop((dt, t) => {
      if (!over) {
        const b = Math.ceil(timeLeft); timeLeft -= dt; if (Math.ceil(timeLeft) !== b) hud();
        if (timeLeft <= 0) { timeLeft = 0; over = true; api.sfx.win(); hud(); api.gameOver({ score, coins: Math.floor(score / 25), title: 'Süre doldu! ⏰' }); }
        spawnIn -= dt; if (spawnIn <= 0) spawn();
      }
      for (const h of holes) {
        h.t += dt;
        if (h.state === 'rising') { h.up = Math.min(1, h.up + dt * 7); if (h.up >= 1) { h.state = 'up'; h.t = 0; } }
        else if (h.state === 'up') { if (h.t > h.stay) { h.state = 'falling'; if (h.kind !== 'bomb') combo = 0; } }
        else if (h.state === 'falling' || (h.state === 'hit' && h.t > 0.2)) { h.up = Math.max(0, h.up - dt * 6); if (h.up <= 0) h.state = 'down'; }
        const y = -1.6 + h.up * 1.65;
        const isB = h.kind === 'bomb';
        h.m.position.y = isB ? -1.6 : y; h.bomb.position.y = isB ? y : -1.6;
        h.m.scale.y = h.state === 'hit' && !isB ? 0.6 : 1;
        h.m.rotation.y = Math.sin(t * 3 + h.x) * 0.2;
        h.spark.scale.setScalar(0.8 + Math.sin(t * 40) * 0.4);
      }
      if (hamT > 0) { hamT -= dt; hammer.rotation.z = -Math.PI / 2 * (1 - hamT / 0.25) + 0.6; if (hamT <= 0) hammer.visible = false; }
      S.updateParts(dt);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { S.destroy(); } };
  },
};
