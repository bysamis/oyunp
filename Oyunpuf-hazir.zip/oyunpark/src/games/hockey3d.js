// 🏒 Hava Hokeyi 3D: bilgisayara karşı ya da aynı telefonda arkadaşınla (uzak yarıya o dokunsun)
import { create3D, mat, THREE } from '../core/three-stage.js';

const W = 8, Lz = 14, GOAL = 3.0, WIN = 5;

export default {
  id: 'hockey', title: 'Hava Hokeyi 3D', emoji: '🏒', color: '#00b4d8',
  desc: 'Bilgisayara ya da arkadaşına gol at! İlk 5 kazanır',
  winBased: true,
  players: { min: 2, max: 2 },
  create(host, api) {
    const S = create3D(host, { fov: 50, bg: 0x0b1d3a, fog: [0x0b1d3a, 30, 70] });
    const { scene, camera } = S;
    S.onResize(() => { const a = S.w / S.h, d = Math.max(13, 9.5 / a); camera.position.set(0, d * 0.95, d * 0.7); camera.lookAt(0, 0, 0.8); });
    // masa
    const table = new THREE.Mesh(new THREE.BoxGeometry(W, 0.4, Lz), mat(0xe0fbfc, { roughness: 0.15, metalness: 0.05 }));
    table.position.y = -0.2; table.receiveShadow = true; scene.add(table);
    const lineMat = new THREE.MeshBasicMaterial({ color: 0x48cae4 });
    const mid = new THREE.Mesh(new THREE.BoxGeometry(W, 0.01, 0.08), lineMat); mid.position.y = 0.01; scene.add(mid);
    const circle = new THREE.Mesh(new THREE.RingGeometry(1.1, 1.18, 48), lineMat); circle.rotation.x = -Math.PI / 2; circle.position.y = 0.011; scene.add(circle);
    [-1, 1].forEach((s) => { const a = new THREE.Mesh(new THREE.RingGeometry(1.9, 1.98, 48, 1, 0, Math.PI), lineMat); a.rotation.x = -Math.PI / 2; a.rotation.z = s > 0 ? Math.PI : 0; a.position.set(0, 0.011, s * Lz / 2); scene.add(a); });
    const railMat = mat(0x0077b6, { roughness: 0.3, metalness: 0.3 });
    const rail = (w, d, x, z) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.6, d), railMat); m.position.set(x, 0.3, z); m.castShadow = true; scene.add(m); };
    rail(0.4, Lz + 0.8, -W / 2 - 0.2, 0); rail(0.4, Lz + 0.8, W / 2 + 0.2, 0);
    [-1, 1].forEach((s) => { const side = (W - GOAL) / 2; rail(side, 0.4, -W / 2 + side / 2, s * (Lz / 2 + 0.2)); rail(side, 0.4, W / 2 - side / 2, s * (Lz / 2 + 0.2)); });
    const goalMat = mat(0x023e8a); [-1, 1].forEach((s) => { const g = new THREE.Mesh(new THREE.BoxGeometry(GOAL, 0.05, 0.9), goalMat); g.position.set(0, -0.05, s * (Lz / 2 + 0.45)); scene.add(g); });

    function mkPaddle(col) {
      const g = new THREE.Group();
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.66, 0.22, 32), mat(col, { roughness: 0.3 })); base.position.y = 0.11; base.castShadow = true; g.add(base);
      const knob = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.32, 0.45, 24), mat(col, { roughness: 0.3 })); knob.position.y = 0.42; knob.castShadow = true; g.add(knob);
      const top = new THREE.Mesh(new THREE.SphereGeometry(0.3, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), mat(0xffffff, { roughness: 0.3 })); top.position.y = 0.64; g.add(top);
      scene.add(g); return g;
    }
    const meM = mkPaddle(0x2dc653), cpuM = mkPaddle(0xef233c);
    const puckM = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.14, 32), mat(0x212529, { roughness: 0.4 })); puckM.castShadow = true; scene.add(puckM);
    const glow = new THREE.PointLight(0xffd60a, 0, 6); scene.add(glow);

    let me, cpu, puck, sMe, sCpu, over, pause, L, twoP;
    const R = 0.64, PR = 0.34;
    const cpuSpeed = () => 5.2 + L * 1.4;
    const cpuSmart = () => Math.min(1, 0.2 + L * 0.12);
    function start() {
      L = api.level; twoP = !!api.mp;
      if (twoP) { cpuM.children[0].material.color.setHex(0x3a86ff); cpuM.children[1].material.color.setHex(0x3a86ff); }
      me = { x: 0, z: 5, vx: 0, vz: 0 }; cpu = { x: 0, z: -5, vx: 0, vz: 0 };
      sMe = 0; sCpu = 0; over = false; resetPuck(1); hud();
    }
    function resetPuck(toward) { puck = { x: 0, z: toward * 0.8, vx: 0, vz: 0 }; pause = 0.7; }
    function hud() { api.setHud({ score: `${sMe} - ${sCpu}`, scoreLabel: api.mp ? `${api.mp.names[0]} · ${api.mp.names[1]}` : twoP ? 'Yakın · Uzak' : 'Sen · CPU', extra: twoP ? (api.mp ? `İlk ${WIN} gol · ${api.mp.names[1]} uzak taraftan oynar` : '👥 2 kişilik mod') : `İlk ${WIN} gol kazanır` }); }
    function onPtr(e) {
      const p = S.rayPlaneY(e, 0.1); if (!p) return;
      if (p.z < -0.2) { if (!twoP) { twoP = true; cpuM.children[0].material.color.setHex(0x3a86ff); cpuM.children[1].material.color.setHex(0x3a86ff); hud(); } cpu.tx = p.x; cpu.tz = p.z; }
      else { me.tx = p.x; me.tz = p.z; }
    }
    S.el.addEventListener('pointerdown', onPtr);
    S.el.addEventListener('pointermove', (e) => { if (e.buttons || e.pointerType === 'touch') onPtr(e); });

    function movePaddle(p, tx, tz, zMin, zMax, dt, maxSp = Infinity) {
      if (tx === undefined) return;
      tx = Math.max(-W / 2 + R, Math.min(W / 2 - R, tx)); tz = Math.max(zMin + R, Math.min(zMax - R, tz));
      let dx = tx - p.x, dz = tz - p.z; const d = Math.hypot(dx, dz), step = maxSp * dt;
      if (d > step) { dx *= step / d; dz *= step / d; }
      p.vx = dx / Math.max(dt, 0.001); p.vz = dz / Math.max(dt, 0.001); p.x += dx; p.z += dz;
    }
    function collide(p) {
      const dx = puck.x - p.x, dz = puck.z - p.z, d = Math.hypot(dx, dz), min = PR + R;
      if (d < min && d > 0) {
        const nx = dx / d, nz = dz / d; puck.x = p.x + nx * min; puck.z = p.z + nz * min;
        const rel = (puck.vx - p.vx) * nx + (puck.vz - p.vz) * nz;
        if (rel < 0) { puck.vx -= 1.9 * rel * nx; puck.vz -= 1.9 * rel * nz; }
        const sp = Math.hypot(puck.vx, puck.vz), max = 26 + L * 1.2;
        if (sp > max) { puck.vx *= max / sp; puck.vz *= max / sp; }
        api.sfx.bounce(); api.haptic('light');
      }
    }
    function goal(mine) {
      mine ? sMe++ : sCpu++;
      S.burst(new THREE.Vector3(0, 0.5, mine ? -Lz / 2 : Lz / 2), mine ? 0x2dc653 : 0xff4d6d, 30, 9);
      glow.position.set(0, 1.5, mine ? -Lz / 2 : Lz / 2); glow.intensity = 30;
      api.sfx[mine ? 'coin' : 'wrong'](); api.haptic('heavy'); hud();
      if (sMe >= WIN || sCpu >= WIN) {
        over = true; const won = sMe > sCpu; won ? api.sfx.win() : api.sfx.lose();
        if (api.mp) { setTimeout(() => api.gameOver({ winner: won ? 0 : 1 }), 700); return; }
        setTimeout(() => api.gameOver({ score: twoP ? 0 : sMe * 60 + (won ? 200 + L * 30 : 0), coins: twoP ? 2 : won ? 8 + L * 2 : sMe, win: won && !twoP, title: twoP ? (won ? 'Yakındaki oyuncu kazandı! 🏆' : 'Uzaktaki oyuncu kazandı! 🏆') : won ? 'Maçı kazandın! 🏒' : 'Bilgisayar kazandı 🤖' }), 700);
      } else resetPuck(mine ? -1 : 1);
    }
    const lp = S.loop((dt) => {
      if (!over) {
        movePaddle(me, me.tx, me.tz, 0, Lz / 2, dt);
        if (twoP) movePaddle(cpu, cpu.tx, cpu.tz, -Lz / 2, 0, dt);
        else {
          let tx = 0, tz = -Lz / 2 + 1.4;
          if (puck.z < 0 || puck.vz < 0) {
            tx = puck.x + puck.vx * cpuSmart() * 0.25;
            tz = puck.z < 0 ? puck.z - PR * 1.5 : Math.min(-Lz * 0.2, puck.z);
            if (puck.z < cpu.z) { tz = -Lz / 2 + 1; tx = puck.x + (puck.x < 0 ? 0.6 : -0.6); }
          }
          movePaddle(cpu, tx, tz, -Lz / 2, 0, dt, cpuSpeed());
        }
        if (pause > 0) pause -= dt;
        else {
          const sub = 3;
          for (let i = 0; i < sub && !over; i++) {
            const h = dt / sub;
            puck.x += puck.vx * h; puck.z += puck.vz * h;
            if (puck.x < -W / 2 + PR) { puck.x = -W / 2 + PR; puck.vx = Math.abs(puck.vx); api.sfx.click(); }
            if (puck.x > W / 2 - PR) { puck.x = W / 2 - PR; puck.vx = -Math.abs(puck.vx); api.sfx.click(); }
            const inGoal = Math.abs(puck.x) < GOAL / 2 - PR * 0.3;
            if (puck.z < -Lz / 2 + PR && !inGoal) { puck.z = -Lz / 2 + PR; puck.vz = Math.abs(puck.vz); api.sfx.click(); }
            if (puck.z > Lz / 2 - PR && !inGoal) { puck.z = Lz / 2 - PR; puck.vz = -Math.abs(puck.vz); api.sfx.click(); }
            if (puck.z < -Lz / 2 - PR) goal(true); else if (puck.z > Lz / 2 + PR) goal(false);
            collide(me); collide(cpu);
          }
          puck.vx *= Math.pow(0.6, dt); puck.vz *= Math.pow(0.6, dt);
        }
      }
      meM.position.set(me.x, 0, me.z); cpuM.position.set(cpu.x, 0, cpu.z);
      puckM.position.set(puck.x, 0.07, puck.z);
      glow.intensity = Math.max(0, glow.intensity - dt * 40);
      S.updateParts(dt);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { S.destroy(); } };
  },
};
