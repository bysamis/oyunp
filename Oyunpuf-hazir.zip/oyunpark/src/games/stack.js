// 🏗️ Kule Yap (kayan bloğu doğru anda bırak)
import { createStage, loop, particles } from '../core/canvas.js';

export default {
  id: 'stack', title: 'Kule Yap', emoji: '🏗️', color: '#e85d04',
  desc: 'Doğru anda dokun, en yüksek kuleyi yap!',
  target: (L) => 10 + (L - 1) * 6,
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let blocks, cur, falling, score, over, camY, perfect, bh, L;

    function start() {
      L = api.level; bh = Math.max(22, st.H / 22);
      const w = Math.min(st.W * 0.6, 260) * Math.max(0.6, 1 - (L - 1) * 0.06);
      blocks = [{ x: (st.W - w) / 2, w, y: st.H - bh * 3, hue: 20 }];
      falling = []; score = 0; over = false; camY = 0; perfect = 0;
      next(); hud();
    }
    function hud() { api.setHud({ score, scoreLabel: 'Kat', extra: perfect > 1 ? `Mükemmel ×${perfect} ✨` : 'Doğru anda dokun' }); }
    function next() {
      const top = blocks[blocks.length - 1];
      const fromLeft = blocks.length % 2 === 0;
      cur = { x: fromLeft ? -top.w : st.W, w: top.w, y: top.y - bh, hue: (top.hue + 12) % 360, dir: fromLeft ? 1 : -1, sp: Math.min(460 + L * 30, 170 + L * 30 + score * (7 + L)) };
    }
    function drop() {
      if (over) return;
      const top = blocks[blocks.length - 1];
      const left = Math.max(cur.x, top.x), right = Math.min(cur.x + cur.w, top.x + top.w);
      const ov = right - left;
      if (ov <= 0) {
        falling.push({ ...cur, vy: 0 }); cur = null; over = true;
        api.sfx.lose(); api.haptic('heavy');
        setTimeout(() => api.gameOver({ score, coins: Math.floor(score * 1.5), canContinue: true, title: 'Kule bitti! 🏗️' }), 800);
        return;
      }
      if (Math.abs(cur.x - top.x) < Math.max(2, 6 - L * 0.6)) {
        // mükemmel yerleşim: kesme yok, küçük büyüme
        perfect++; cur.x = top.x; api.sfx.combo(perfect); fx.text(st.W / 2, cur.y - camY - 10, 'MÜKEMMEL!', '#ffd60a');
        const grow = perfect >= 3 ? Math.min(12, st.W * 0.8 - cur.w) : 0;
        blocks.push({ x: cur.x - grow / 2, w: cur.w + grow, y: cur.y, hue: cur.hue });
      } else {
        perfect = 0; api.sfx.brick();
        // kesilen parça düşer
        if (cur.x < top.x) falling.push({ x: cur.x, w: top.x - cur.x, y: cur.y, hue: cur.hue, vy: 0 });
        else falling.push({ x: right, w: cur.x + cur.w - right, y: cur.y, hue: cur.hue, vy: 0 });
        blocks.push({ x: left, w: ov, y: cur.y, hue: cur.hue });
      }
      api.haptic('light');
      fx.burst(st.W / 2, cur.y - camY, `hsl(${cur.hue},80%,60%)`, 6, 80);
      score++; hud(); next();
    }
    st.canvas.addEventListener('pointerdown', drop);
    const onKey = (e) => { if (e.key === ' ') drop(); };
    window.addEventListener('keydown', onKey);

    function update(dt) {
      if (cur) {
        cur.x += cur.dir * cur.sp * dt;
        if (cur.x > st.W - cur.w * 0.2 && cur.dir > 0) cur.dir = -1;
        if (cur.x < -cur.w * 0.8 && cur.dir < 0) cur.dir = 1;
      }
      for (let i = falling.length - 1; i >= 0; i--) { const f = falling[i]; f.vy += 900 * dt; f.y += f.vy * dt; if (f.y - camY > st.H + 100) falling.splice(i, 1); }
      const topY = (cur || blocks[blocks.length - 1]).y;
      const targetCam = Math.min(0, topY - st.H * 0.45);
      camY += (targetCam - camY) * Math.min(1, dt * 5);
      fx.update(dt); draw();
    }
    function block(c, b) {
      const y = b.y - camY;
      c.fillStyle = `hsl(${b.hue},75%,55%)`; c.fillRect(b.x, y, b.w, bh);
      c.fillStyle = `hsl(${b.hue},75%,68%)`; c.fillRect(b.x, y, b.w, bh * 0.25);
      c.fillStyle = `hsl(${b.hue},70%,42%)`; c.fillRect(b.x, y + bh * 0.8, b.w, bh * 0.2);
    }
    function draw() {
      const c = st.ctx;
      const h = (score * 6) % 360;
      const g = c.createLinearGradient(0, 0, 0, st.H);
      g.addColorStop(0, `hsl(${200 + h * 0.2},70%,${Math.max(20, 75 - score)}%)`); g.addColorStop(1, '#ffe8d6');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      // zemin
      c.fillStyle = '#6a994e'; c.fillRect(0, st.H - bh * 2 - camY, st.W, st.H);
      for (const b of blocks) block(c, b);
      for (const f of falling) block(c, f);
      if (cur) block(c, cur);
      fx.draw(c);
    }

    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { over = false; falling.length = 0; next(); hud(); },
      restart() { start(); },
      destroy() { lp.stop(); st.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
