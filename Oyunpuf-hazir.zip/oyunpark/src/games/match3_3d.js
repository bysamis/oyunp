// 🍬 Şeker Patlat 3D: 3 aynı şekeri yan yana getir, patlat (4'lü = bomba)
import { create3D, mat, THREE } from '../core/three-stage.js';
import { expert, expertSteps } from '../core/expert.js';
import { boardKit, roundedBox } from '../core/board3d.js';

const N = 8;
const TYPES = [
  { color: '#ff4d6d', shape: 'circle' },
  { color: '#ff9f1c', shape: 'square' },
  { color: '#ffd60a', shape: 'star' },
  { color: '#2dc653', shape: 'leaf' },
  { color: '#3a86ff', shape: 'diamond' },
  { color: '#b15cff', shape: 'heart' },
];
const START_MOVES = 25;

function shapeGeo(shape) {
  const ext = (sh) => { const g = new THREE.ExtrudeGeometry(sh, { depth: 0.22, bevelEnabled: true, bevelThickness: 0.1, bevelSize: 0.06, bevelSegments: 3, curveSegments: 12 }); g.center(); g.rotateX(-Math.PI / 2); return g; };
  const r = 0.36;
  switch (shape) {
    case 'circle': { const g = new THREE.SphereGeometry(r, 24, 16); g.scale(1, 0.8, 1); return g; }
    case 'square': return (() => { const g = roundedBox(r * 1.75, r * 1.1, r * 1.75, r * 0.4); g.translate(0, -r * 0.55, 0); return g; })();
    case 'diamond': { const g = new THREE.OctahedronGeometry(r * 1.15, 0); g.scale(0.85, 0.75, 1.1); return g; }
    case 'star': { const s = new THREE.Shape(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + (i * Math.PI) / 5, rr = i % 2 ? r * 0.5 : r * 1.1; i ? s.lineTo(Math.cos(a) * rr, -Math.sin(a) * rr) : s.moveTo(Math.cos(a) * rr, -Math.sin(a) * rr); } return ext(s); }
    case 'leaf': { const s = new THREE.Shape(); s.moveTo(0, r * 1.05); s.quadraticCurveTo(r * 1.3, 0, 0, -r * 1.05); s.quadraticCurveTo(-r * 1.3, 0, 0, r * 1.05); return ext(s); }
    case 'heart': { const s = new THREE.Shape(); s.moveTo(0, -r * 0.9); s.bezierCurveTo(-r * 1.4, 0, -r * 0.7, r * 1.1, 0, r * 0.45); s.bezierCurveTo(r * 0.7, r * 1.1, r * 1.4, 0, 0, -r * 0.9); return ext(s); }
  }
}

export default {
  id: 'match3', title: 'Şeker Patlat 3D', emoji: '🍬', color: '#ff4d6d',
  desc: "3 aynı şekeri yan yana getir, patlat!",
  expertFrom: 9,
  target: (L) => Math.round(600 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0xc77dff });
    const { scene } = S;
    const K = boardKit(S, N, N, { tilt: 0.32, height: 0.6 });
    const cell = 1, ox = -N / 2, oy = -N / 2, st = { W: 0 };
    const fx = {
      burst: (x, y, col, n, p) => S.burst(new THREE.Vector3(x, 0.5, y), new THREE.Color(col).getHex(), Math.min(n, 16), 5, 0.5),
      text: (x, y, t, col) => S.popText(new THREE.Vector3(x, 0.8, y), t, col),
    };
    // tahta
    const frame = new THREE.Mesh(roundedBox(N + 0.7, 0.5, N + 0.7, 0.35), mat(0xff70a6, { roughness: 0.4 })); frame.position.y = -0.75; frame.receiveShadow = true; frame.castShadow = true; scene.add(frame);
    const tiles = new THREE.InstancedMesh(roundedBox(0.94, 0.12, 0.94, 0.12), mat(0xffffff, { roughness: 0.6 }), N * N); tiles.receiveShadow = true;
    const m4 = new THREE.Matrix4(), colr = new THREE.Color();
    for (let r = 0, i = 0; r < N; r++) for (let c = 0; c < N; c++, i++) { m4.makeTranslation(K.x(c), -0.3, K.z(r)); tiles.setMatrixAt(i, m4); tiles.setColorAt(i, colr.setHex((r + c) % 2 ? 0xffd6ff : 0xffeefa)); }
    scene.add(tiles);
    const geos = TYPES.map((T) => shapeGeo(T.shape));
    const mats = TYPES.map((T) => mat(new THREE.Color(T.color), { roughness: 0.18, metalness: 0.05, emissive: new THREE.Color(T.color), emissiveIntensity: 0.08 }));
    const bombRingGeo = new THREE.TorusGeometry(0.42, 0.05, 8, 32), bombMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const candyGroup = new THREE.Group(); scene.add(candyGroup);
    const selRing = new THREE.Mesh(new THREE.RingGeometry(0.44, 0.5, 32), new THREE.MeshBasicMaterial({ color: 0xffffff })); selRing.rotation.x = -Math.PI / 2; scene.add(selRing);
    let grid, score, moves, combo, phase, pending, sel, drag, idSeq = 0, over;
    const meshes = new Map();
    function meshFor(tile) {
      let m = meshes.get(tile.id);
      if (!m) {
        m = new THREE.Group();
        const body = new THREE.Mesh(geos[tile.type], mats[tile.type]); body.castShadow = true; m.add(body);
        const ring = new THREE.Mesh(bombRingGeo, bombMat); ring.rotation.x = Math.PI / 2; ring.visible = false; m.add(ring);
        m.userData = { ring, seen: 0 };
        candyGroup.add(m); meshes.set(tile.id, m);
      }
      return m;
    }
    let nTypes = 5;
    const rnd = () => (Math.random() * nTypes) | 0;
    const mk = (type, r, c, fromY) => ({ id: idSeq++, type, x: c, y: fromY ?? r, scale: 1, dying: false, bomb: false });

    function fill() {
      grid = [];
      for (let r = 0; r < N; r++) {
        grid.push([]);
        for (let c = 0; c < N; c++) {
          let t;
          do { t = rnd(); } while (
            (c >= 2 && grid[r][c - 1].type === t && grid[r][c - 2].type === t) ||
            (r >= 2 && grid[r - 1][c].type === t && grid[r - 2][c].type === t)
          );
          grid[r].push(mk(t, r, c, r - N - 1));
        }
      }
      if (!hasMoves()) fill();
    }

    function start() {
      nTypes = api.level >= 2 ? 6 : 5;
      score = 0; moves = Math.round(Math.max(10, START_MOVES + 1 - api.level * 2) / (1 + (expert(api.level, 8) - 1) * 0.5)); // uzman: hamle azalır combo = 0; over = false;
      fill(); phase = 'fall'; sel = null; pending = null; hud();
    }
    function hud() { api.setHud({ score, extra: `Hamle: ${moves}` }); }

    // Eşleşmeleri bul: { set: Set<tile>, runs: [[{r,c}...]] }
    function findMatches() {
      const set = new Set(); const runs = [];
      const scan = (get) => {
        for (let a = 0; a < N; a++) {
          let len = 1;
          for (let b = 1; b <= N; b++) {
            const cur = b < N ? get(a, b) : null, prev = get(a, b - 1);
            if (cur && prev && cur.t.type === prev.t.type) len++;
            else {
              if (len >= 3) {
                const run = [];
                for (let k = b - len; k < b; k++) { const g = get(a, k); set.add(g.t); run.push(g); }
                runs.push(run);
              }
              len = 1;
            }
          }
        }
      };
      scan((r, c) => grid[r][c] && { t: grid[r][c], r, c });
      scan((c, r) => grid[r][c] && { t: grid[r][c], r, c });
      return { set, runs };
    }

    function wouldMatch(r1, c1, r2, c2) {
      swapCells(r1, c1, r2, c2);
      const m = findMatches().set.size > 0;
      swapCells(r1, c1, r2, c2);
      return m;
    }
    function hasMoves() {
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        if (c < N - 1 && wouldMatch(r, c, r, c + 1)) return true;
        if (r < N - 1 && wouldMatch(r, c, r + 1, c)) return true;
      }
      return false;
    }
    function swapCells(r1, c1, r2, c2) {
      const t = grid[r1][c1]; grid[r1][c1] = grid[r2][c2]; grid[r2][c2] = t;
    }

    function trySwap(r1, c1, r2, c2) {
      if (phase !== 'idle' || over) return;
      if (r2 < 0 || r2 >= N || c2 < 0 || c2 >= N) return;
      swapCells(r1, c1, r2, c2);
      pending = { r1, c1, r2, c2 };
      phase = 'swap';
      api.sfx.swap();
    }

    function posOf(tile) {
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (grid[r][c] === tile) return { r, c };
      return null;
    }

    function resolve(m) {
      combo++;
      const kill = new Set(m.set);
      // 4+ eşleşmeden bomba oluştur
      const keep = new Set();
      for (const run of m.runs) {
        if (run.length >= 4) {
          let pick = run[Math.floor(run.length / 2)];
          if (pending) {
            const p = run.find((g) => (g.r === pending.r1 && g.c === pending.c1) || (g.r === pending.r2 && g.c === pending.c2));
            if (p) pick = p;
          }
          if (!pick.t.bomb) keep.add(pick.t);
        }
      }
      // Bombaları patlat (zincirleme)
      const queue = [...kill].filter((t) => t.bomb);
      while (queue.length) {
        const b = queue.pop(); const p = posOf(b); if (!p) continue;
        fx.burst(ox + (p.c + 0.5) * cell, oy + (p.r + 0.5) * cell, '#ffffff', 24, 260);
        api.sfx.crash(); api.haptic('heavy');
        for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
          const t = grid[p.r + dr]?.[p.c + dc];
          if (t && !kill.has(t)) { kill.add(t); if (t.bomb) queue.push(t); }
        }
      }
      keep.forEach((t) => { kill.delete(t); t.bomb = true; t.scale = 1.4; });
      const pts = kill.size * 10 * combo;
      score += pts;
      for (const t of kill) {
        t.dying = true;
        const p = posOf(t);
        if (p) fx.burst(ox + (p.c + 0.5) * cell, oy + (p.r + 0.5) * cell, TYPES[t.type].color, 6, 120);
      }
      const cen = posOf([...kill][0]);
      if (cen) fx.text(ox + (cen.c + 0.5) * cell, oy + cen.r * cell, combo > 1 ? `+${pts} ×${combo}` : `+${pts}`, '#fff');
      if (combo > 1) api.sfx.combo(combo); else api.sfx.pop();
      api.haptic('light');
      phase = 'clear';
      hud();
    }

    function gravity() {
      for (let c = 0; c < N; c++) {
        let write = N - 1;
        for (let r = N - 1; r >= 0; r--) {
          const t = grid[r][c];
          if (t && !t.dying) { grid[r][c] = null; grid[write][c] = t; write--; }
          else if (t) grid[r][c] = null;
        }
        let spawn = 1;
        for (let r = write; r >= 0; r--) { grid[r][c] = mk(rnd(), r, c, -spawn); spawn++; }
      }
    }

    function shuffle() {
      const all = grid.flat();
      do {
        for (let i = all.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [all[i], all[j]] = [all[j], all[i]]; }
        for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) grid[r][c] = all[r * N + c];
      } while (findMatches().set.size > 0 || !hasMoves());
      fx.text(st.W / 2, oy + cell * 4, 'Karıştırıldı!', '#ffd60a');
      phase = 'shuffle';
    }

    function onSettle() {
      if (phase === 'swap') {
        const m = findMatches();
        if (m.set.size === 0) {
          const { r1, c1, r2, c2 } = pending;
          swapCells(r1, c1, r2, c2); pending = null; phase = 'back'; api.sfx.wrong();
        } else { moves--; combo = 0; hud(); resolve(m); pending = null; }
      } else if (phase === 'clear') {
        gravity(); phase = 'fall';
      } else if (phase === 'fall' || phase === 'shuffle' || phase === 'back') {
        const m = findMatches();
        if (m.set.size && phase !== 'back') { resolve(m); return; }
        phase = 'idle';
        if (moves <= 0 && !over) {
          over = true;
          api.sfx.win();
          api.gameOver({ score, coins: Math.floor(score / 60), canContinue: true, title: 'Hamleler bitti!' });
        } else if (!hasMoves()) shuffle();
      }
    }

    // Girdi: kaydır ya da iki komşuya sırayla dokun
    const onDown = (e) => { const at = K.cellAt(e, 0); if (!at) return; drag = { r: at.r, c: at.c, x: e.clientX, y: e.clientY, moved: false }; };
    const onMove = (e) => {
      if (!drag || drag.moved) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (Math.hypot(dx, dy) > 18) {
        drag.moved = true; sel = null;
        if (Math.abs(dx) > Math.abs(dy)) trySwap(drag.r, drag.c, drag.r, drag.c + Math.sign(dx));
        else trySwap(drag.r, drag.c, drag.r + Math.sign(dy), drag.c);
      }
    };
    const onUp = () => {
      if (drag && !drag.moved) {
        if (sel && Math.abs(sel.r - drag.r) + Math.abs(sel.c - drag.c) === 1) { trySwap(sel.r, sel.c, drag.r, drag.c); sel = null; }
        else { sel = { r: drag.r, c: drag.c }; api.sfx.click(); }
      }
      drag = null;
    };
    S.el.addEventListener('pointerdown', onDown);
    S.el.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    let frameId = 0;
    const lp = S.loop((dt, t) => {
      let busy = false;
      const sp = 12 * dt;
      frameId++;
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const tile = grid[r][c]; if (!tile) continue;
        if (tile.dying) { tile.scale -= dt * 6; if (tile.scale > 0) busy = true; }
        else {
          if (tile.scale > 1) tile.scale = Math.max(1, tile.scale - dt * 2);
          const dx = c - tile.x, dy = r - tile.y;
          if (Math.abs(dx) > 0.001 || Math.abs(dy) > 0.001) {
            busy = true;
            tile.x += Math.sign(dx) * Math.min(Math.abs(dx), sp);
            tile.y += Math.sign(dy) * Math.min(Math.abs(dy), sp * (dy > 0 ? 1.3 : 1));
          }
        }
        // 3D görünüm
        const m = meshFor(tile); m.userData.seen = frameId;
        const s = Math.max(0.001, tile.scale);
        const isSel = sel && sel.r === r && sel.c === c;
        m.position.set(K.x(tile.x), tile.y < 0 ? -tile.y * 0.3 : 0 + (isSel ? 0.15 + Math.sin(t * 10) * 0.06 : 0), K.z(tile.y));
        m.visible = tile.y > -0.6;
        m.scale.setScalar(s);
        m.rotation.y = isSel ? t * 3 : tile.bomb ? t * 2 : 0;
        m.userData.ring.visible = tile.bomb; if (tile.bomb) m.userData.ring.rotation.z = t * 4;
      }
      // artık ızgarada olmayan şekerleri kaldır
      for (const [id, m] of meshes) if (m.userData.seen !== frameId) { candyGroup.remove(m); meshes.delete(id); }
      selRing.visible = !!sel; if (sel) selRing.position.copy(K.pos(sel.c, sel.r, -0.2));
      if (!busy && phase !== 'idle') onSettle();
      S.updateParts(dt, -0.3);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { moves += 5; over = false; hud(); },
      restart() { start(); },
      destroy() { S.destroy(); window.removeEventListener('pointerup', onUp); },
    };
  },
};
