// 🧺 Meyve Yakala: sepeti kaydır, meyveleri yakala, bombalardan kaç
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

const FRUITS = [['#ef233c', 'apple'], ['#ffc300', 'banana'], ['#fb8500', 'orange'], ['#7209b7', 'grape'], ['#2dc653', 'pear']];

export default {
  id: 'catcher', title: 'Meyve Yakala', emoji: '🧺', color: '#fb8500',
  desc: 'Meyveleri yakala, bombalardan kaç!',
  target: (L) => Math.round(300 * Math.pow(1.38, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host);
    let basket, items, score, missed, spawnIn, elapsed, over, L, combo;
    const S = () => st.W / 400;

    function start() { L = api.level; basket = { x: st.W / 2, w: Math.max(60, 110 - L * 5) * S() }; items = []; score = 0; missed = 0; spawnIn = 0.5; elapsed = 0; over = false; combo = 0; hud(); }
    function hud() { api.setHud({ score, extra: `Kaçan: ${missed}/5 · Kombo ${combo}` }); }
    function spawn() {
      const bomb = Math.random() < Math.min(0.35, 0.12 + L * 0.025 + elapsed * 0.002);
      const gold = !bomb && Math.random() < 0.06;
      items.push({ x: 20 + Math.random() * (st.W - 40), y: -20, vy: (140 + L * 22 + elapsed * (3 + L * 0.6)) * S(), vx: L >= 4 ? (Math.random() - 0.5) * 80 * S() : 0, rot: 0, bomb, gold, f: FRUITS[(Math.random() * FRUITS.length) | 0] });
      spawnIn = Math.max(0.2, 0.8 - L * 0.05 - elapsed * 0.01);
    }
    const move = (e) => { basket.x = Math.max(basket.w / 2, Math.min(st.W - basket.w / 2, st.point(e).x)); };
    st.canvas.addEventListener('pointerdown', move);
    st.canvas.addEventListener('pointermove', move);
    const onKey = (e) => { if (e.key === 'ArrowLeft') basket.x -= 30; if (e.key === 'ArrowRight') basket.x += 30; };
    window.addEventListener('keydown', onKey);

    function end(title) { over = true; api.sfx.lose(); api.gameOver({ score, coins: Math.floor(score / 25), canContinue: true, title }); }
    function update(dt, t) {
      if (!over) {
        elapsed += dt; spawnIn -= dt; if (spawnIn <= 0) spawn();
        const by = st.H - 70;
        for (const it of items) {
          it.y += it.vy * dt; it.x += it.vx * dt; it.rot += dt * 3;
          if (it.x < 15 || it.x > st.W - 15) it.vx *= -1;
          if (it.y > by - 10 && it.y < by + 20 && Math.abs(it.x - basket.x) < basket.w / 2) {
            it.dead = true;
            if (it.bomb) { fx.burst(it.x, it.y, '#333', 30, 250); api.sfx.crash(); api.haptic('heavy'); end('Bomba yakaladın! 💣'); return draw(t); }
            combo++; const pts = (it.gold ? 50 : 10) + Math.min(combo, 15);
            score += pts; api.sfx[it.gold ? 'coin' : 'pop'](); api.haptic('light'); fx.text(it.x, by - 30, '+' + pts, it.gold ? '#ffd60a' : '#fff'); fx.burst(it.x, by, it.f[0], 8); hud();
          } else if (it.y > st.H + 20) {
            it.dead = true;
            if (!it.bomb) { missed++; combo = 0; api.sfx.wrong(); hud(); if (missed >= 5) { end('Çok meyve kaçtı! 🍎'); return draw(t); } }
          }
        }
        items = items.filter((i) => !i.dead);
      }
      fx.update(dt); draw(t);
    }
    function draw() {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H); g.addColorStop(0, '#ffe5b4'); g.addColorStop(1, '#ffb4a2');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      c.fillStyle = '#6a994e'; c.fillRect(0, st.H - 40, st.W, 40);
      for (const it of items) {
        c.save(); c.translate(it.x, it.y); c.rotate(it.rot * 0.3);
        if (it.bomb) {
          c.fillStyle = '#212529'; c.beginPath(); c.arc(0, 0, 16, 0, 7); c.fill();
          c.fillStyle = '#ff4d6d'; c.beginPath(); c.arc(8, -16, 4, 0, 7); c.fill();
          c.fillStyle = '#fff'; c.font = '900 14px system-ui'; c.textAlign = 'center'; c.fillText('✕', 0, 5);
        } else {
          c.fillStyle = it.gold ? '#ffd60a' : it.f[0];
          if (it.f[1] === 'banana' && !it.gold) { c.beginPath(); c.arc(0, -10, 18, 0.3, Math.PI - 0.3); c.arc(0, -16, 16, Math.PI - 0.4, 0.4, true); c.fill(); }
          else if (it.f[1] === 'grape' && !it.gold) { [[0, -6], [-7, 0], [7, 0], [-4, 8], [4, 8], [0, 14]].forEach(([x, y]) => { c.beginPath(); c.arc(x, y - 4, 6.5, 0, 7); c.fill(); }); }
          else { c.beginPath(); c.arc(0, 0, 15, 0, 7); c.fill(); c.fillStyle = '#2d6a4f'; c.beginPath(); c.ellipse(4, -15, 6, 3, -0.5, 0, 7); c.fill(); }
          c.fillStyle = 'rgba(255,255,255,.45)'; c.beginPath(); c.arc(-5, -5, 4, 0, 7); c.fill();
        }
        c.restore();
      }
      // sepet
      const by = st.H - 70, w = basket.w;
      c.fillStyle = '#9c6644'; roundRect(c, basket.x - w / 2, by, w, 34, 10); c.fill();
      c.strokeStyle = '#7f5539'; c.lineWidth = 2;
      for (let i = 1; i < 6; i++) { c.beginPath(); c.moveTo(basket.x - w / 2 + (w / 6) * i, by + 3); c.lineTo(basket.x - w / 2 + (w / 6) * i, by + 31); c.stroke(); }
      c.fillStyle = '#b08968'; roundRect(c, basket.x - w / 2 - 4, by - 4, w + 8, 10, 5); c.fill();
      fx.draw(c);
    }
    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { missed = Math.min(missed, 3); items = []; over = false; hud(); },
      restart() { start(); }, destroy() { lp.stop(); st.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
