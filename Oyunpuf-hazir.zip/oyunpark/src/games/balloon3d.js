// 🎈 Balon Patlat 3D: balonlar uçup gitmeden dokun ve patlat
import { create3D, mat, THREE } from '../core/three-stage.js';

const COLS = [0xff4d6d, 0xff9f1c, 0xffd60a, 0x2dc653, 0x3a86ff, 0xb15cff, 0xff70a6];
const H = 15, FW = 8;

export default {
  id: 'balloon', title: 'Balon Patlat 3D', emoji: '🎈', color: '#ff70a6',
  desc: 'Balonlar uçmadan dokun ve patlat!',
  target: (L) => Math.round(250 * Math.pow(1.4, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 50, bg: 0x8ecae6, fog: [0xbde0fe, 30, 70] });
    const { scene, camera } = S;
    // şenlik alanı: çimen, tepeler, bayraklar
    const grass = new THREE.Mesh(new THREE.PlaneGeometry(120, 80), mat(0x80b918)); grass.rotation.x = -Math.PI / 2; grass.position.set(0, -1, -20); grass.receiveShadow = true; scene.add(grass);
    for (let i = 0; i < 7; i++) { const h = new THREE.Mesh(new THREE.SphereGeometry(8 + Math.random() * 6, 16, 10), mat(0x55a630)); h.position.set(-30 + i * 10, -6, -35 - Math.random() * 10); scene.add(h); }
    const tent = new THREE.Group(); tent.position.set(-6, -1, -12); scene.add(tent);
    const tb = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.4, 2.2, 12), mat(0xffffff)); tb.position.y = 1.1; tent.add(tb);
    const tr = new THREE.Mesh(new THREE.ConeGeometry(2.8, 2, 12), mat(0xef233c)); tr.position.y = 3.2; tent.add(tr);
    const cloudMat = new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 0.5 });
    const clouds = [];
    for (let i = 0; i < 6; i++) { const c = new THREE.Group(); for (let k = 0; k < 4; k++) { const b = new THREE.Mesh(new THREE.SphereGeometry(0.9 + Math.random() * 0.6, 12, 8), cloudMat); b.position.set(k * 1.1, Math.random() * 0.4, 0); c.add(b); } c.position.set(-15 + i * 6, 6 + Math.random() * 8, -18); scene.add(c); clouds.push(c); }

    const bGroup = new THREE.Group(); scene.add(bGroup);
    const knotGeo = new THREE.ConeGeometry(0.08, 0.15, 8);
    function makeBalloon(b) {
      const g = new THREE.Group();
      const color = b.kind === 'gold' ? 0xffc300 : b.kind === 'bomb' ? 0x2b2d42 : b.color;
      const m = new THREE.Mesh(new THREE.SphereGeometry(b.r, 22, 16), mat(color, { roughness: 0.15, metalness: b.kind === 'gold' ? 0.6 : 0.05, emissive: b.kind === 'gold' ? 0x7a5c00 : 0x000000 }));
      m.scale.set(1, 1.18, 1); m.castShadow = true; g.add(m);
      const knot = new THREE.Mesh(knotGeo, m.material); knot.position.y = -b.r * 1.18 - 0.05; g.add(knot);
      const pts = []; for (let i = 0; i <= 10; i++) pts.push(new THREE.Vector3(Math.sin(i * 0.9) * 0.08, -b.r * 1.18 - 0.1 - i * 0.12, 0));
      g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0x555555 })));
      if (b.kind === 'bomb') {
        const fuse = new THREE.Mesh(new THREE.TorusGeometry(b.r * 0.55, 0.05, 6, 16), mat(0xff4d6d, { emissive: 0xff0000, emissiveIntensity: 0.6 })); fuse.rotation.x = Math.PI / 2; fuse.position.y = b.r * 0.3; g.add(fuse);
        const sk = new THREE.Mesh(new THREE.CircleGeometry(b.r * 0.35, 16), new THREE.MeshBasicMaterial({ color: 0xffffff })); sk.position.z = b.r * 1.01; g.add(sk);
      }
      if (b.kind === 'gold') { const st = new THREE.Mesh(new THREE.OctahedronGeometry(b.r * 0.3), new THREE.MeshBasicMaterial({ color: 0xffffff })); st.position.z = b.r * 0.98; g.add(st); }
      const hl = new THREE.Mesh(new THREE.SphereGeometry(b.r * 0.18, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7 })); hl.position.set(-b.r * 0.4, b.r * 0.5, b.r * 0.75); g.add(hl);
      g.userData.ball = m;
      return g;
    }

    let balloons, score, missed, spawnIn, elapsed, over, streak, L;
    function start() { L = api.level; bGroup.clear(); balloons = []; score = 0; missed = 0; spawnIn = 0; elapsed = 0; over = false; streak = 0; hud(); }
    function hud() { api.setHud({ score, extra: `${'❤️'.repeat(3 - missed)}${'🤍'.repeat(missed)}  ·  Seri ${streak}` }); }
    function spawn() {
      const r = (Math.max(15, 26 - L * 1.4) + Math.random() * 14) / 50 * 1.35;
      const special = Math.random();
      const b = {
        x: (Math.random() - 0.5) * (FW - r * 2), y: -1.5, z: (Math.random() - 0.5) * 1.5, r,
        vy: (70 + L * 16 + Math.random() * 40 + elapsed * (2.2 + L * 0.5)) / 50,
        sway: Math.random() * 6, color: COLS[(Math.random() * COLS.length) | 0],
        kind: special < 0.06 ? 'gold' : special < Math.max(0.08, 0.12 - L * 0.01) ? 'bomb' : 'normal',
      };
      b.g = makeBalloon(b); bGroup.add(b.g); balloons.push(b);
      spawnIn = Math.max(0.16, 0.95 - L * 0.07 - elapsed * 0.012);
    }
    function pop(b, i) {
      balloons.splice(i, 1); bGroup.remove(b.g);
      const p = new THREE.Vector3(b.x, b.y, b.z);
      if (b.kind === 'bomb') {
        api.sfx.crash(); api.haptic('heavy');
        for (const o of balloons) { score += 5; S.burst(new THREE.Vector3(o.x, o.y, o.z), o.color, 10, 5, 0.7); bGroup.remove(o.g); }
        S.popText(p, 'BUM! 💥', '#fff'); balloons.length = 0;
      } else {
        streak++;
        const pts = (b.kind === 'gold' ? 50 : 10) + Math.min(streak, 20);
        score += pts; api.sfx.pop(); api.haptic('light'); if (b.kind === 'gold') api.sfx.coin();
        S.popText(p, '+' + pts, b.kind === 'gold' ? '#ffd60a' : '#fff');
      }
      S.burst(p, b.kind === 'gold' ? 0xffd60a : b.kind === 'bomb' ? 0x2b2d42 : b.color, 16, 6, 0.8);
      hud();
    }
    S.el.addEventListener('pointerdown', (e) => {
      if (over) return;
      const hit = S.pick(e, balloons.map((b) => b.g.userData.ball));
      let idx = hit ? balloons.findIndex((b) => b.g.userData.ball === hit.object) : -1;
      if (idx < 0) {
        // parmak toleransı: ekranda en yakın balon
        const r = S.el.getBoundingClientRect(); let best = 1e9;
        balloons.forEach((b, i) => {
          const v = new THREE.Vector3(b.x, b.y, b.z).project(camera);
          const d = Math.hypot(r.left + (v.x + 1) / 2 * r.width - e.clientX, r.top + (1 - v.y) / 2 * r.height - e.clientY);
          const rad = (b.r / (camera.position.z - b.z)) * r.height * 1.4;
          if (d < rad + 14 && d < best) { best = d; idx = i; }
        });
      }
      if (idx >= 0) pop(balloons[idx], idx); else { streak = 0; hud(); }
    });
    S.onResize(() => {
      const vfov = (camera.fov * Math.PI) / 180, a = S.w / S.h;
      const d = Math.max((H / 2) / Math.tan(vfov / 2), (FW / 2 + 0.5) / (Math.tan(vfov / 2) * a));
      camera.position.set(0, H / 2 - 1.5, d); camera.lookAt(0, H / 2 - 1.5, 0);
    });

    const lp = S.loop((dt, t) => {
      if (!over) {
        elapsed += dt; spawnIn -= dt; if (spawnIn <= 0) spawn();
        const top = H;
        for (let i = balloons.length - 1; i >= 0; i--) {
          const b = balloons[i];
          b.y += b.vy * dt; b.x += Math.sin(t * 2 + b.sway) * 0.4 * dt;
          if (b.y > top) {
            balloons.splice(i, 1); bGroup.remove(b.g);
            if (b.kind !== 'bomb') {
              missed++; streak = 0; api.sfx.wrong(); api.haptic('medium'); hud();
              if (missed >= 3) { over = true; api.sfx.lose(); api.gameOver({ score, coins: Math.floor(score / 30), canContinue: true, title: 'Balonlar kaçtı! 🎈' }); }
            }
          }
        }
      }
      for (const b of balloons) { b.g.position.set(b.x, b.y, b.z); b.g.rotation.z = Math.sin(t * 2 + b.sway) * 0.12; b.g.rotation.y = Math.sin(t + b.sway) * 0.3; }
      clouds.forEach((c) => { c.position.x += dt * 0.4; if (c.position.x > 20) c.position.x = -20; });
      S.updateParts(dt, -1);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { missed = 2; over = false; bGroup.clear(); balloons.length = 0; hud(); },
      restart() { start(); },
      destroy() { S.destroy(); },
    };
  },
};
