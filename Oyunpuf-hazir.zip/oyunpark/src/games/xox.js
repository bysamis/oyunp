// ❌⭕ XOX (bilgisayara karşı, 5 turluk maç)
import { createStage, loop, roundRect, particles } from '../core/canvas.js';

const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const winner = (b) => { for (const l of LINES) if (b[l[0]] && b[l[0]] === b[l[1]] && b[l[0]] === b[l[2]]) return { p: b[l[0]], line: l }; return b.every(Boolean) ? { p: 'draw' } : null; };

function minimax(b, me, turn, depth = 0) {
  const w = winner(b);
  if (w) return { s: w.p === me ? 10 - depth : w.p === 'draw' ? 0 : depth - 10 };
  let best = { s: turn === me ? -99 : 99, i: -1 };
  for (let i = 0; i < 9; i++) if (!b[i]) {
    b[i] = turn; const r = minimax(b, me, turn === 'X' ? 'O' : 'X', depth + 1); b[i] = null;
    if (turn === me ? r.s > best.s : r.s < best.s) best = { s: r.s, i };
  }
  return best;
}

export default {
  id: 'xox', title: 'XOX', emoji: '⭕', color: '#4361ee',
  desc: 'Bilgisayarı yenebilir misin? 5 tur!',
  winBased: true,
  players: { min: 2, max: 2 },
  online: { min: 2, max: 2 },
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    let board, anim, round, wins, losses, draws, turn, result, size, ox, oy, busy, score;
    const ROUNDS = 5;

    function layout() { size = Math.min(st.W - 40, st.H - 120, 420); ox = (st.W - size) / 2; oy = (st.H - size) / 2 + 20; }
    function newRound() {
      board = Array(9).fill(null); anim = Array(9).fill(0); result = null; busy = false;
      turn = round % 2 ? 'O' : 'X'; // sırayla başlar
      hud();
      if (turn === 'O' && !api.mp) aiMove();
    }
    function start() { inbox.length = 0; layout(); round = 0; wins = 0; losses = 0; draws = 0; score = 0; newRound(); }
    const N1 = () => api.mp ? api.mp.names[0] : '🙂', N2 = () => api.mp ? api.mp.names[1] : '🤖';
    function hud() { api.setHud({ score: api.mp ? `${wins} - ${losses}` : score, scoreLabel: api.mp ? 'Skor' : undefined, extra: `Tur ${round + 1}/${ROUNDS} · ${N1()} ${wins} - ${losses} ${N2()} · Berabere ${draws}` }); }

    // online: X = odayı kuran (0), O = katılan (1). Rakibin hamleleri kuyruktan sırayla işlenir.
    const ON = api.mp?.online, mySym = ON ? (ON.me === 0 ? 'X' : 'O') : null, inbox = [];
    ON?.on((m) => inbox.push(m));
    function play(i, p) {
      board[i] = p; anim[i] = 0.01; api.sfx[p === 'X' ? 'tap' : 'click']();
      const w = winner(board);
      if (w) { finish(w); return true; }
      turn = p === 'X' ? 'O' : 'X';
      return false;
    }
    function aiMove() {
      busy = true;
      setTimeout(() => {
        // biraz hata payı: kolay rakip olsun, %30 rastgele hamle
        const empty = board.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0);
        const mistake = Math.max(0.05, 0.45 - (api.level - 1) * 0.1);
        const i = Math.random() < mistake ? empty[(Math.random() * empty.length) | 0] : minimax(board.slice(), 'O', 'O').i;
        play(i, 'O'); busy = false;
      }, 450);
    }
    function finish(w) {
      result = w; busy = true;
      if (w.p === 'X') { wins++; score += 100; api.sfx.win(); api.haptic('heavy'); fx.burst(st.W / 2, oy + size / 2, '#ffd60a', 40, 260); }
      else if (w.p === 'O') { losses++; api.sfx.lose(); }
      else { draws++; score += 30; api.sfx.slide(); }
      hud();
      setTimeout(() => {
        round++;
        if (round >= ROUNDS) {
          if (api.mp) api.gameOver({ winner: wins > losses ? 0 : losses > wins ? 1 : -1 });
          else api.gameOver({ score, coins: wins * 8 + draws * 2, win: wins > losses, title: wins > losses ? 'Maçı kazandın! 🏆' : wins === losses ? 'Berabere! 🤝' : 'Bilgisayar kazandı 🤖' });
        } else newRound();
      }, 1300);
    }

    st.canvas.addEventListener('pointerdown', (e) => {
      if (busy || (turn !== 'X' && !api.mp) || (ON && turn !== mySym)) return;
      const p = st.point(e), cs = size / 3;
      const c = Math.floor((p.x - ox) / cs), r = Math.floor((p.y - oy) / cs);
      if (c < 0 || c > 2 || r < 0 || r > 2) return;
      const i = r * 3 + c;
      if (board[i]) return;
      api.haptic('light');
      if (api.mp) { play(i, turn); ON?.send({ c: i }); } else if (!play(i, 'X')) aiMove();
    });

    function update(dt, t) {
      while (ON && inbox.length && !busy) { const mv = inbox.shift(); if (mv.c !== undefined && !board[mv.c]) play(mv.c, turn); }
      for (let i = 0; i < 9; i++) if (anim[i] > 0 && anim[i] < 1) anim[i] = Math.min(1, anim[i] + dt * 5);
      fx.update(dt); draw(t);
    }
    function draw(t) {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H);
      g.addColorStop(0, '#4361ee'); g.addColorStop(1, '#7209b7');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      c.fillStyle = '#fff'; c.font = '800 18px system-ui'; c.textAlign = 'center';
      c.fillText(result ? (result.p === 'X' ? (api.mp ? `${N1()} kazandı! 🎉` : 'Kazandın! 🎉') : result.p === 'O' ? (api.mp ? `${N2()} kazandı! 🎉` : 'Bilgisayar kazandı') : 'Berabere') : ON ? (turn === mySym ? `Senin sıran (${mySym})` : `${turn === 'X' ? N1() : N2()} düşünüyor…`) : api.mp ? `Sıra: ${turn === 'X' ? N1() + ' (X)' : N2() + ' (O)'}` : turn === 'X' ? 'Senin sıran (X)' : 'Bilgisayar düşünüyor…', st.W / 2, oy - 24);
      roundRect(c, ox - 10, oy - 10, size + 20, size + 20, 24); c.fillStyle = 'rgba(255,255,255,.15)'; c.fill();
      const cs = size / 3;
      c.strokeStyle = 'rgba(255,255,255,.85)'; c.lineWidth = 6; c.lineCap = 'round';
      for (let i = 1; i < 3; i++) {
        c.beginPath(); c.moveTo(ox + i * cs, oy + 10); c.lineTo(ox + i * cs, oy + size - 10); c.stroke();
        c.beginPath(); c.moveTo(ox + 10, oy + i * cs); c.lineTo(ox + size - 10, oy + i * cs); c.stroke();
      }
      for (let i = 0; i < 9; i++) {
        if (!board[i]) continue;
        const x = ox + (i % 3 + 0.5) * cs, y = oy + ((i / 3 | 0) + 0.5) * cs, r = cs * 0.3, a = anim[i];
        c.lineWidth = cs * 0.1;
        if (board[i] === 'X') {
          c.strokeStyle = '#ffd60a';
          c.beginPath(); c.moveTo(x - r, y - r); c.lineTo(x - r + 2 * r * Math.min(1, a * 2), y - r + 2 * r * Math.min(1, a * 2)); c.stroke();
          if (a > 0.5) { const k = (a - 0.5) * 2; c.beginPath(); c.moveTo(x + r, y - r); c.lineTo(x + r - 2 * r * k, y - r + 2 * r * k); c.stroke(); }
        } else {
          c.strokeStyle = '#4cc9f0'; c.beginPath(); c.arc(x, y, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * a); c.stroke();
        }
      }
      if (result?.line) {
        const [a, , b] = result.line;
        const p = (i) => [ox + (i % 3 + 0.5) * cs, oy + ((i / 3 | 0) + 0.5) * cs];
        c.strokeStyle = '#fff'; c.lineWidth = 10; c.beginPath(); c.moveTo(...p(a)); c.lineTo(...p(b)); c.stroke();
      }
      fx.draw(c);
    }

    start();
    const lp = loop(update);
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { lp.stop(); st.destroy(); } };
  },
};
