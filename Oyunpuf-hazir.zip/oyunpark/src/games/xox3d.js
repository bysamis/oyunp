// ⭕ XOX 3D: 5 turluk maç — bilgisayara, arkadaşına ya da online rakibe karşı
import { create3D, mat, THREE } from '../core/three-stage.js';
import { boardKit, roundedBox } from '../core/board3d.js';

const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const winner = (b) => { for (const l of LINES) if (b[l[0]] && b[l[0]] === b[l[1]] && b[l[0]] === b[l[2]]) return { p: b[l[0]], line: l }; return b.every(Boolean) ? { p: 'draw' } : null; };
function minimax(b, me, turn, depth = 0) {
  const w = winner(b);
  if (w) return { s: w.p === me ? 10 - depth : w.p === 'draw' ? 0 : depth - 10 };
  let best = { s: turn === me ? -99 : 99, i: -1 };
  for (let i = 0; i < 9; i++) if (!b[i]) {
    b[i] = turn; const r = minimax(b, me, turn === 'X' ? 'O' : 'X', depth + 1); b[i] = null;
    if (turn === me ? r.s > best.s : r.s < best.s) best = { s: r.s, i };
  }
  return best;
}

export default {
  id: 'xox', title: 'XOX 3D', emoji: '⭕', color: '#4361ee',
  desc: 'Bilgisayarı yenebilir misin? 5 tur!',
  winBased: true, players: { min: 2, max: 2 }, online: { min: 2, max: 2 },
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0x4361ee });
    const { scene } = S;
    const CS = 1.6;
    const K = boardKit(S, 3, 3, { cell: CS, tilt: 0.42, height: 1, extraTop: 0.6, extraBottom: 0.6 });
    // masa ve tahta
    const table = new THREE.Mesh(new THREE.CylinderGeometry(9, 9, 0.4, 48), mat(0x7209b7, { roughness: 0.7 })); table.position.y = -0.5; table.receiveShadow = true; scene.add(table);
    const board = new THREE.Mesh(roundedBox(3 * CS + 0.5, 0.35, 3 * CS + 0.5, 0.3), mat(0xf8f9fa, { roughness: 0.4 })); board.position.y = -0.33; board.receiveShadow = true; board.castShadow = true; scene.add(board);
    const lineMat = mat(0x4361ee);
    for (let i = 1; i < 3; i++) {
      const a = new THREE.Mesh(roundedBox(0.12, 0.12, 3 * CS - 0.2, 0.05), lineMat); a.position.set(K.x(i) - CS / 2, 0, 0); scene.add(a);
      const b = new THREE.Mesh(roundedBox(3 * CS - 0.2, 0.12, 0.12, 0.05), lineMat); b.position.set(0, 0, K.z(i) - CS / 2); scene.add(b);
    }
    const xMat = mat(0xef233c, { roughness: 0.3 }), oMat = mat(0x3a86ff, { roughness: 0.3 });
    function piece(p) {
      const g = new THREE.Group();
      if (p === 'X') { for (const s of [-1, 1]) { const bar = new THREE.Mesh(roundedBox(1.2, 0.32, 0.3, 0.12), xMat); bar.rotation.y = s * Math.PI / 4; bar.castShadow = true; g.add(bar); } }
      else { const t = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.15, 14, 32), oMat); t.rotation.x = Math.PI / 2; t.position.y = 0.16; t.castShadow = true; g.add(t); }
      return g;
    }
    const pieces = new THREE.Group(); scene.add(pieces);
    const winBar = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 1, 12), mat(0xffd60a, { emissive: 0xffd60a, emissiveIntensity: 0.8 })); winBar.visible = false; scene.add(winBar);
    const hover = new THREE.Mesh(roundedBox(CS * 0.9, 0.02, CS * 0.9, 0.2), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.35 })); hover.visible = false; scene.add(hover);

    let boardS, meshes, round, wins, losses, draws, turn, result, busy, score;
    const ROUNDS = 5;
    function newRound() {
      boardS = Array(9).fill(null); meshes = Array(9).fill(null); pieces.clear(); result = null; busy = false; winBar.visible = false;
      turn = round % 2 ? 'O' : 'X';
      hud();
      if (turn === 'O' && !api.mp) aiMove();
    }
    function start() { inbox.length = 0; round = 0; wins = 0; losses = 0; draws = 0; score = 0; newRound(); }
    const N1 = () => api.mp ? api.mp.names[0] : '🙂', N2 = () => api.mp ? api.mp.names[1] : '🤖';
    function hud() { api.setHud({ score: api.mp ? `${wins} - ${losses}` : score, scoreLabel: api.mp ? 'Skor' : undefined, extra: `Tur ${round + 1}/${ROUNDS} · ${N1()} ${wins} - ${losses} ${N2()} · Berabere ${draws}` }); }
    const ON = api.mp?.online, mySym = ON ? (ON.me === 0 ? 'X' : 'O') : null, inbox = [];
    ON?.on((m) => inbox.push(m));
    function play(i, p) {
      boardS[i] = p; api.sfx[p === 'X' ? 'tap' : 'click']();
      const m = piece(p); m.position.copy(K.pos(i % 3, (i / 3) | 0, 2.5)); m.userData.t = 0; pieces.add(m); meshes[i] = m;
      const w = winner(boardS);
      if (w) { finish(w); return true; }
      turn = p === 'X' ? 'O' : 'X';
      return false;
    }
    function aiMove() {
      busy = true;
      setTimeout(() => {
        const empty = boardS.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0);
        const mistake = Math.max(0.14, 0.45 - (api.level - 1) * 0.08); // Sv.5+ hâlâ zor ama yenilebilir
        const i = Math.random() < mistake ? empty[(Math.random() * empty.length) | 0] : minimax(boardS.slice(), 'O', 'O').i;
        play(i, 'O'); busy = false;
      }, 450);
    }
    function finish(w) {
      result = w; busy = true;
      if (w.line) {
        const a = K.pos(w.line[0] % 3, (w.line[0] / 3) | 0, 0.35), b = K.pos(w.line[2] % 3, (w.line[2] / 3) | 0, 0.35);
        winBar.position.copy(a).add(b).multiplyScalar(0.5); winBar.scale.set(1, a.distanceTo(b) + 1.2, 1);
        winBar.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), b.clone().sub(a).normalize()); winBar.visible = true;
        w.line.forEach((i) => S.burst(K.pos(i % 3, (i / 3) | 0, 0.4), w.p === 'X' ? 0xef233c : 0x3a86ff, 10, 5, 0.6));
      }
      if (w.p === 'X') { wins++; score += 100; api.sfx.win(); api.haptic('heavy'); S.burst(new THREE.Vector3(0, 1, 0), 0xffd60a, 40, 8); }
      else if (w.p === 'O') { losses++; api.sfx.lose(); }
      else { draws++; score += 30; api.sfx.slide(); }
      hud();
      setTimeout(() => {
        round++;
        if (round >= ROUNDS) {
          if (api.mp) api.gameOver({ winner: wins > losses ? 0 : losses > wins ? 1 : -1 });
          else api.gameOver({ score, coins: wins * 8 + draws * 2, win: wins > losses || (wins >= 1 && losses === 0), title: wins > losses ? 'Maçı kazandın! 🏆' : wins === losses ? 'Berabere! 🤝' : 'Bilgisayar kazandı 🤖' });
        } else newRound();
      }, 1300);
    }
    S.el.addEventListener('pointermove', (e) => { const c = K.cellAt(e); hover.visible = !!c && !busy && !boardS[c.r * 3 + c.c]; if (c) hover.position.copy(K.pos(c.c, c.r, 0.02)); });
    S.el.addEventListener('pointerdown', (e) => {
      if (busy || (turn !== 'X' && !api.mp) || (ON && turn !== mySym)) return;
      const c = K.cellAt(e); if (!c) return;
      const i = c.r * 3 + c.c;
      if (boardS[i]) return;
      api.haptic('light'); hover.visible = false;
      if (api.mp) { play(i, turn); ON?.send({ c: i }); } else if (!play(i, 'X')) aiMove();
    });
    const lp = S.loop((dt, t) => {
      while (ON && inbox.length && !busy) { const mv = inbox.shift(); if (mv.c !== undefined && !boardS[mv.c]) play(mv.c, turn); }
      for (const m of pieces.children) {
        m.userData.t += dt;
        const k = Math.min(1, m.userData.t * 4);
        m.position.y = Math.max(0, 2.5 * (1 - k * k)) + (k >= 1 ? 0 : 0);
        const s = k < 1 ? 1 : 1 + Math.max(0, 0.15 - (m.userData.t - 0.25) * 0.6) * Math.sin((m.userData.t - 0.25) * 30);
        m.scale.set(s, 1 / s, s);
      }
      if (result?.line) result.line.forEach((i) => { const m = meshes[i]; if (m) m.rotation.y = Math.sin(t * 6) * 0.3; });
      winBar.material.emissiveIntensity = 0.6 + Math.sin(t * 8) * 0.3;
      S.updateParts(dt, 0);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { S.destroy(); } };
  },
};
