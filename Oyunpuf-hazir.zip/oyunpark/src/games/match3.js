// 🍬 Şeker Patlat (3'lü eşleştirme)
import { createStage, loop, roundRect, shade, particles } from '../core/canvas.js';

const N = 8;
const TYPES = [
  { color: '#ff4d6d', shape: 'circle' },
  { color: '#ff9f1c', shape: 'square' },
  { color: '#ffd60a', shape: 'star' },
  { color: '#2dc653', shape: 'leaf' },
  { color: '#3a86ff', shape: 'diamond' },
  { color: '#b15cff', shape: 'heart' },
];
const START_MOVES = 25;

export default {
  id: 'match3', title: 'Şeker Patlat', emoji: '🍬', color: '#ff4d6d',
  desc: "3 aynı şekeri yan yana getir, patlat!",
  target: (L) => Math.round(600 * Math.pow(1.35, L - 1)),
  create(host, api) {
    const fx = particles();
    const st = createStage(host, { onResize: () => layout() });
    let grid, cell, ox, oy, score, moves, combo, phase, pending, sel, drag, idSeq = 0, over;

    function layout() {
      const size = Math.min(st.W - 16, st.H - 40, 560);
      cell = size / N;
      ox = (st.W - size) / 2;
      oy = Math.max(12, (st.H - size) / 2 - 10);
    }

    let nTypes = 5;
    const rnd = () => (Math.random() * nTypes) | 0;
    const mk = (type, r, c, fromY) => ({ id: idSeq++, type, x: c, y: fromY ?? r, scale: 1, dying: false, bomb: false });

    function fill() {
      grid = [];
      for (let r = 0; r < N; r++) {
        grid.push([]);
        for (let c = 0; c < N; c++) {
          let t;
          do { t = rnd(); } while (
            (c >= 2 && grid[r][c - 1].type === t && grid[r][c - 2].type === t) ||
            (r >= 2 && grid[r - 1][c].type === t && grid[r - 2][c].type === t)
          );
          grid[r].push(mk(t, r, c, r - N - 1));
        }
      }
      if (!hasMoves()) fill();
    }

    function start() {
      nTypes = api.level >= 2 ? 6 : 5;
      layout(); score = 0; moves = Math.max(10, START_MOVES + 1 - api.level * 2); combo = 0; over = false;
      fill(); phase = 'fall'; sel = null; pending = null; hud();
    }
    function hud() { api.setHud({ score, extra: `Hamle: ${moves}` }); }

    // Eşleşmeleri bul: { set: Set<tile>, runs: [[{r,c}...]] }
    function findMatches() {
      const set = new Set(); const runs = [];
      const scan = (get) => {
        for (let a = 0; a < N; a++) {
          let len = 1;
          for (let b = 1; b <= N; b++) {
            const cur = b < N ? get(a, b) : null, prev = get(a, b - 1);
            if (cur && prev && cur.t.type === prev.t.type) len++;
            else {
              if (len >= 3) {
                const run = [];
                for (let k = b - len; k < b; k++) { const g = get(a, k); set.add(g.t); run.push(g); }
                runs.push(run);
              }
              len = 1;
            }
          }
        }
      };
      scan((r, c) => grid[r][c] && { t: grid[r][c], r, c });
      scan((c, r) => grid[r][c] && { t: grid[r][c], r, c });
      return { set, runs };
    }

    function wouldMatch(r1, c1, r2, c2) {
      swapCells(r1, c1, r2, c2);
      const m = findMatches().set.size > 0;
      swapCells(r1, c1, r2, c2);
      return m;
    }
    function hasMoves() {
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        if (c < N - 1 && wouldMatch(r, c, r, c + 1)) return true;
        if (r < N - 1 && wouldMatch(r, c, r + 1, c)) return true;
      }
      return false;
    }
    function swapCells(r1, c1, r2, c2) {
      const t = grid[r1][c1]; grid[r1][c1] = grid[r2][c2]; grid[r2][c2] = t;
    }

    function trySwap(r1, c1, r2, c2) {
      if (phase !== 'idle' || over) return;
      if (r2 < 0 || r2 >= N || c2 < 0 || c2 >= N) return;
      swapCells(r1, c1, r2, c2);
      pending = { r1, c1, r2, c2 };
      phase = 'swap';
      api.sfx.swap();
    }

    function posOf(tile) {
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (grid[r][c] === tile) return { r, c };
      return null;
    }

    function resolve(m) {
      combo++;
      const kill = new Set(m.set);
      // 4+ eşleşmeden bomba oluştur
      const keep = new Set();
      for (const run of m.runs) {
        if (run.length >= 4) {
          let pick = run[Math.floor(run.length / 2)];
          if (pending) {
            const p = run.find((g) => (g.r === pending.r1 && g.c === pending.c1) || (g.r === pending.r2 && g.c === pending.c2));
            if (p) pick = p;
          }
          if (!pick.t.bomb) keep.add(pick.t);
        }
      }
      // Bombaları patlat (zincirleme)
      const queue = [...kill].filter((t) => t.bomb);
      while (queue.length) {
        const b = queue.pop(); const p = posOf(b); if (!p) continue;
        fx.burst(ox + (p.c + 0.5) * cell, oy + (p.r + 0.5) * cell, '#ffffff', 24, 260);
        api.sfx.crash(); api.haptic('heavy');
        for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
          const t = grid[p.r + dr]?.[p.c + dc];
          if (t && !kill.has(t)) { kill.add(t); if (t.bomb) queue.push(t); }
        }
      }
      keep.forEach((t) => { kill.delete(t); t.bomb = true; t.scale = 1.4; });
      const pts = kill.size * 10 * combo;
      score += pts;
      for (const t of kill) {
        t.dying = true;
        const p = posOf(t);
        if (p) fx.burst(ox + (p.c + 0.5) * cell, oy + (p.r + 0.5) * cell, TYPES[t.type].color, 6, 120);
      }
      const cen = posOf([...kill][0]);
      if (cen) fx.text(ox + (cen.c + 0.5) * cell, oy + cen.r * cell, combo > 1 ? `+${pts} ×${combo}` : `+${pts}`, '#fff');
      if (combo > 1) api.sfx.combo(combo); else api.sfx.pop();
      api.haptic('light');
      phase = 'clear';
      hud();
    }

    function gravity() {
      for (let c = 0; c < N; c++) {
        let write = N - 1;
        for (let r = N - 1; r >= 0; r--) {
          const t = grid[r][c];
          if (t && !t.dying) { grid[r][c] = null; grid[write][c] = t; write--; }
          else if (t) grid[r][c] = null;
        }
        let spawn = 1;
        for (let r = write; r >= 0; r--) { grid[r][c] = mk(rnd(), r, c, -spawn); spawn++; }
      }
    }

    function shuffle() {
      const all = grid.flat();
      do {
        for (let i = all.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [all[i], all[j]] = [all[j], all[i]]; }
        for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) grid[r][c] = all[r * N + c];
      } while (findMatches().set.size > 0 || !hasMoves());
      fx.text(st.W / 2, oy + cell * 4, 'Karıştırıldı!', '#ffd60a');
      phase = 'shuffle';
    }

    function onSettle() {
      if (phase === 'swap') {
        const m = findMatches();
        if (m.set.size === 0) {
          const { r1, c1, r2, c2 } = pending;
          swapCells(r1, c1, r2, c2); pending = null; phase = 'back'; api.sfx.wrong();
        } else { moves--; combo = 0; hud(); resolve(m); pending = null; }
      } else if (phase === 'clear') {
        gravity(); phase = 'fall';
      } else if (phase === 'fall' || phase === 'shuffle' || phase === 'back') {
        const m = findMatches();
        if (m.set.size && phase !== 'back') { resolve(m); return; }
        phase = 'idle';
        if (moves <= 0 && !over) {
          over = true;
          api.sfx.win();
          api.gameOver({ score, coins: Math.floor(score / 60), canContinue: true, title: 'Hamleler bitti!' });
        } else if (!hasMoves()) shuffle();
      }
    }

    // Girdi
    const cellAt = (p) => {
      const c = Math.floor((p.x - ox) / cell), r = Math.floor((p.y - oy) / cell);
      return r >= 0 && r < N && c >= 0 && c < N ? { r, c } : null;
    };
    const onDown = (e) => {
      const p = st.point(e); const at = cellAt(p);
      if (!at) return;
      drag = { ...at, x: p.x, y: p.y, moved: false };
    };
    const onMove = (e) => {
      if (!drag || drag.moved) return;
      const p = st.point(e);
      const dx = p.x - drag.x, dy = p.y - drag.y;
      if (Math.hypot(dx, dy) > cell * 0.35) {
        drag.moved = true; sel = null;
        if (Math.abs(dx) > Math.abs(dy)) trySwap(drag.r, drag.c, drag.r, drag.c + Math.sign(dx));
        else trySwap(drag.r, drag.c, drag.r + Math.sign(dy), drag.c);
      }
    };
    const onUp = () => {
      if (drag && !drag.moved) {
        if (sel && Math.abs(sel.r - drag.r) + Math.abs(sel.c - drag.c) === 1) {
          trySwap(sel.r, sel.c, drag.r, drag.c); sel = null;
        } else { sel = { r: drag.r, c: drag.c }; api.sfx.click(); }
      }
      drag = null;
    };
    st.canvas.addEventListener('pointerdown', onDown);
    st.canvas.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);

    function update(dt, t) {
      let busy = false;
      const sp = 12 * dt;
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const tile = grid[r][c]; if (!tile) continue;
        if (tile.dying) { tile.scale -= dt * 6; if (tile.scale > 0) busy = true; continue; }
        if (tile.scale > 1) { tile.scale = Math.max(1, tile.scale - dt * 2); }
        const dx = c - tile.x, dy = r - tile.y;
        if (Math.abs(dx) > 0.001 || Math.abs(dy) > 0.001) {
          busy = true;
          tile.x += Math.sign(dx) * Math.min(Math.abs(dx), sp);
          tile.y += Math.sign(dy) * Math.min(Math.abs(dy), sp * (dy > 0 ? 1.3 : 1));
        }
      }
      if (!busy && phase !== 'idle') onSettle();
      fx.update(dt);
      draw(t);
    }

    function drawCandy(c, tile, cx, cy, s, t) {
      const ty = TYPES[tile.type];
      const r = s * 0.38 * Math.max(0, tile.scale);
      if (r <= 0) return;
      c.save(); c.translate(cx, cy);
      const g = c.createRadialGradient(-r * 0.3, -r * 0.35, r * 0.1, 0, 0, r * 1.2);
      g.addColorStop(0, shade(ty.color, 80)); g.addColorStop(0.6, ty.color); g.addColorStop(1, shade(ty.color, -60));
      c.fillStyle = g;
      c.beginPath();
      switch (ty.shape) {
        case 'circle': c.arc(0, 0, r, 0, Math.PI * 2); break;
        case 'square': roundRect(c, -r * 0.9, -r * 0.9, r * 1.8, r * 1.8, r * 0.45); break;
        case 'diamond': c.moveTo(0, -r * 1.1); c.lineTo(r, 0); c.lineTo(0, r * 1.1); c.lineTo(-r, 0); c.closePath(); break;
        case 'leaf': c.moveTo(0, -r * 1.05); c.quadraticCurveTo(r * 1.3, 0, 0, r * 1.05); c.quadraticCurveTo(-r * 1.3, 0, 0, -r * 1.05); break;
        case 'star':
          for (let i = 0; i < 10; i++) {
            const a = -Math.PI / 2 + (i * Math.PI) / 5, rr = i % 2 ? r * 0.5 : r * 1.1;
            i ? c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr) : c.moveTo(Math.cos(a) * rr, Math.sin(a) * rr);
          }
          c.closePath(); break;
        case 'heart':
          c.moveTo(0, r * 0.95);
          c.bezierCurveTo(-r * 1.4, -r * 0.1, -r * 0.6, -r * 1.2, 0, -r * 0.45);
          c.bezierCurveTo(r * 0.6, -r * 1.2, r * 1.4, -r * 0.1, 0, r * 0.95); break;
      }
      c.fill();
      c.fillStyle = 'rgba(255,255,255,.55)';
      c.beginPath(); c.ellipse(-r * 0.3, -r * 0.4, r * 0.28, r * 0.16, -0.6, 0, Math.PI * 2); c.fill();
      if (tile.bomb) {
        c.strokeStyle = `rgba(255,255,255,${0.6 + Math.sin(t * 8) * 0.4})`; c.lineWidth = 3;
        c.beginPath(); c.arc(0, 0, r * 1.15, 0, Math.PI * 2); c.stroke();
        c.fillStyle = '#fff'; c.font = `800 ${r * 0.9}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle';
        c.fillText('✦', 0, 1);
      }
      c.restore();
    }

    function draw(t) {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H);
      g.addColorStop(0, '#ff9ecf'); g.addColorStop(1, '#a663cc');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      // tahta
      roundRect(c, ox - 6, oy - 6, cell * N + 12, cell * N + 12, 18);
      c.fillStyle = 'rgba(40,10,70,.35)'; c.fill();
      for (let r = 0; r < N; r++) for (let col = 0; col < N; col++) {
        c.fillStyle = (r + col) % 2 ? 'rgba(255,255,255,.10)' : 'rgba(255,255,255,.18)';
        c.fillRect(ox + col * cell, oy + r * cell, cell, cell);
      }
      if (sel) {
        c.strokeStyle = '#fff'; c.lineWidth = 3;
        roundRect(c, ox + sel.c * cell + 2, oy + sel.r * cell + 2, cell - 4, cell - 4, 10); c.stroke();
      }
      c.save();
      c.beginPath(); c.rect(ox - 6, oy - 6, cell * N + 12, cell * N + 12); c.clip();
      for (let r = 0; r < N; r++) for (let col = 0; col < N; col++) {
        const tile = grid[r][col]; if (!tile) continue;
        const bob = sel && sel.r === r && sel.c === col ? Math.sin(t * 10) * 2 : 0;
        drawCandy(c, tile, ox + (tile.x + 0.5) * cell, oy + (tile.y + 0.5) * cell + bob, cell, t);
      }
      c.restore();
      fx.draw(c);
    }

    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { moves += 5; over = false; hud(); },
      restart() { start(); },
      destroy() { lp.stop(); st.destroy(); window.removeEventListener('pointerup', onUp); },
    };
  },
};
