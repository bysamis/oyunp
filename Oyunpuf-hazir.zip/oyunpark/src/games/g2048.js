// 🔢 2048
import { createStage, loop, roundRect } from '../core/canvas.js';

const COLORS = { 2: '#eee4da', 4: '#ede0c8', 8: '#f2b179', 16: '#f59563', 32: '#f67c5f', 64: '#f65e3b', 128: '#edcf72', 256: '#edcc61', 512: '#edc850', 1024: '#edc53f', 2048: '#edc22e' };

export default {
  id: 'g2048', title: '2048', emoji: '🔢', color: '#f59563',
  desc: 'Kaydır, aynı sayıları birleştir!',
  target: (L) => Math.round(1000 * Math.pow(1.5, L - 1)),
  create(host, api) {
    const st = createStage(host, { onResize: () => layout() });
    const N = 4;
    let grid, tiles, score, size, ox, oy, over, won, idSeq;

    function layout() { size = Math.min(st.W - 24, st.H - 40, 480); ox = (st.W - size) / 2; oy = (st.H - size) / 2; }
    function start() {
      layout(); grid = Array.from({ length: N }, () => Array(N).fill(null)); tiles = []; score = 0; over = false; won = false; idSeq = 0;
      add(); add(); hud();
    }
    function hud() { api.setHud({ score, extra: `En büyük: ${Math.max(0, ...tiles.map((t) => t.v))}` }); }
    function add() {
      const empty = [];
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (!grid[r][c]) empty.push([r, c]);
      if (!empty.length) return;
      const [r, c] = empty[(Math.random() * empty.length) | 0];
      const t = { id: idSeq++, v: Math.random() < Math.max(0.5, 0.9 - (api.level - 1) * 0.07) ? 2 : 4, r, c, x: c, y: r, pop: 0 };
      grid[r][c] = t; tiles.push(t);
    }
    function move(dr, dc) {
      if (over) return;
      let moved = false, gained = 0;
      const merged = new Set();
      const order = [...Array(N).keys()];
      const rows = dr > 0 ? order.slice().reverse() : order;
      const cols = dc > 0 ? order.slice().reverse() : order;
      for (const r of rows) for (const c of cols) {
        const t = grid[r][c]; if (!t) continue;
        let nr = r, nc = c;
        while (true) {
          const tr = nr + dr, tc = nc + dc;
          if (tr < 0 || tr >= N || tc < 0 || tc >= N) break;
          const o = grid[tr][tc];
          if (!o) { nr = tr; nc = tc; continue; }
          if (o.v === t.v && !merged.has(o)) {
            grid[r][c] = null; o.v *= 2; o.pop = 1; merged.add(o); gained += o.v;
            t.r = tr; t.c = tc; t.dead = true; moved = true;
            if (o.v === 2048 && !won) { won = true; api.sfx.win(); }
          }
          break;
        }
        if (!t.dead && (nr !== r || nc !== c)) { grid[r][c] = null; grid[nr][nc] = t; t.r = nr; t.c = nc; moved = true; }
      }
      if (!moved) return;
      score += gained;
      setTimeout(() => { tiles = tiles.filter((t) => !t.dead); }, 110);
      if (gained) { api.sfx.pop(); api.haptic('light'); } else api.sfx.slide();
      add();
      if (api.level >= 3 && Math.random() < Math.min(0.45, (api.level - 2) * 0.1)) add(); // zor seviyede fazladan taş
      hud();
      if (!canMove()) {
        over = true; api.sfx.lose();
        setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 80), canContinue: true }), 500);
      }
    }
    function canMove() {
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const t = grid[r][c]; if (!t) return true;
        if (c < N - 1 && grid[r][c + 1]?.v === t.v) return true;
        if (r < N - 1 && grid[r + 1][c]?.v === t.v) return true;
      }
      return false;
    }
    let down = null;
    st.canvas.addEventListener('pointerdown', (e) => (down = st.point(e)));
    st.canvas.addEventListener('pointerup', (e) => {
      if (!down) return;
      const p = st.point(e), dx = p.x - down.x, dy = p.y - down.y; down = null;
      if (Math.hypot(dx, dy) < 20) return;
      Math.abs(dx) > Math.abs(dy) ? move(0, Math.sign(dx)) : move(Math.sign(dy), 0);
    });
    const onKey = (e) => {
      const k = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] }[e.key];
      if (k) move(...k);
    };
    window.addEventListener('keydown', onKey);

    function update(dt) {
      for (const t of tiles) {
        t.x += (t.c - t.x) * Math.min(1, dt * 20); t.y += (t.r - t.y) * Math.min(1, dt * 20);
        if (t.pop > 0) t.pop = Math.max(0, t.pop - dt * 5);
      }
      draw();
    }
    function draw() {
      const c = st.ctx;
      c.fillStyle = '#faf8ef'; c.fillRect(0, 0, st.W, st.H);
      roundRect(c, ox, oy, size, size, 16); c.fillStyle = '#bbada0'; c.fill();
      const gap = size * 0.03, cs = (size - gap * (N + 1)) / N;
      for (let r = 0; r < N; r++) for (let col = 0; col < N; col++) {
        roundRect(c, ox + gap + col * (cs + gap), oy + gap + r * (cs + gap), cs, cs, 10); c.fillStyle = '#cdc1b4'; c.fill();
      }
      for (const t of tiles) {
        const s = 1 + t.pop * 0.15 * Math.sin(t.pop * Math.PI);
        const x = ox + gap + t.x * (cs + gap) + cs / 2, y = oy + gap + t.y * (cs + gap) + cs / 2;
        c.save(); c.translate(x, y); c.scale(s, s);
        roundRect(c, -cs / 2, -cs / 2, cs, cs, 10); c.fillStyle = COLORS[t.v] || '#3c3a32'; c.fill();
        c.fillStyle = t.v <= 4 ? '#776e65' : '#fff';
        const fs = cs * (t.v < 100 ? 0.45 : t.v < 1000 ? 0.38 : 0.3);
        c.font = `900 ${fs}px system-ui`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(t.v, 0, 2);
        c.restore();
      }
    }

    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() {
        // en küçük 4 taşı kaldırarak yer aç
        tiles.filter((t) => !t.dead).sort((a, b) => a.v - b.v).slice(0, 4).forEach((t) => { grid[t.r][t.c] = null; t.dead = true; });
        tiles = tiles.filter((t) => !t.dead); over = false; hud();
      },
      restart() { start(); },
      destroy() { lp.stop(); st.destroy(); window.removeEventListener('keydown', onKey); },
    };
  },
};
