// 💣 Mayın Tarlası 3D: mayınlara basmadan tüm kareleri aç (basılı tut = bayrak)
import { create3D, mat, THREE } from '../core/three-stage.js';
import { expert, expertSteps } from '../core/expert.js';
import { boardKit, roundedBox, textTexture } from '../core/board3d.js';

const NUMC = ['', '#3a86ff', '#2dc653', '#ff4d6d', '#7209b7', '#e85d04', '#118ab2', '#000', '#555'];

export default {
  id: 'mines', title: 'Mayın Tarlası 3D', emoji: '💣', color: '#6c757d',
  desc: 'Mayınlara basmadan tüm kareleri aç!',
  expertFrom: 10,
  winBased: true,
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0x40916c });
    const { scene } = S;
    const field = new THREE.Group(); scene.add(field);
    const btn = document.createElement('button');
    btn.className = 'mines-flag'; btn.style.cssText = 'position:absolute;left:50%;top:10px;transform:translateX(-50%);z-index:5;border:0;border-radius:20px;padding:8px 18px;font:800 15px system-ui;color:#fff;background:#adb5bd;box-shadow:0 3px 0 rgba(0,0,0,.2)';
    host.appendChild(btn);
    const syncBtn = () => { btn.textContent = flagMode ? '🚩 Bayrak modu AÇIK' : '⛏️ Kazma modu (bayrak: basılı tut)'; btn.style.background = flagMode ? '#ff4d6d' : '#6c757d'; };
    btn.addEventListener('pointerdown', (e) => { e.stopPropagation(); flagMode = !flagMode; api.sfx.click(); syncBtn(); });
    const grassGeo = roundedBox(0.94, 0.4, 0.94, 0.1), dirtGeo = new THREE.BoxGeometry(0.98, 0.1, 0.98);
    const grassMats = [mat(0x74c69d), mat(0x95d5b2)], dirtMats = [mat(0xddb892), mat(0xe6ccb2)];
    const numGeo = new THREE.PlaneGeometry(0.8, 0.8);
    function flagMesh() {
      const g = new THREE.Group();
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.7), mat(0x495057)); pole.position.y = 0.35; g.add(pole);
      const sh = new THREE.Shape(); sh.moveTo(0, 0); sh.lineTo(0.35, -0.12); sh.lineTo(0, -0.25);
      const fl = new THREE.Mesh(new THREE.ShapeGeometry(sh), new THREE.MeshStandardMaterial({ color: 0xef233c, side: THREE.DoubleSide })); fl.position.y = 0.68; g.add(fl);
      g.traverse((o) => { if (o.isMesh) o.castShadow = true; });
      return g;
    }
    function mineMesh() {
      const g = new THREE.Group();
      const b = new THREE.Mesh(new THREE.SphereGeometry(0.25, 14, 10), mat(0x212529, { metalness: 0.5, roughness: 0.3 })); g.add(b);
      for (let i = 0; i < 8; i++) { const sp = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.18, 6), b.material); const v = new THREE.Vector3().randomDirection(); sp.position.copy(v.multiplyScalar(0.27)); sp.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), v.clone().normalize()); g.add(sp); }
      const r = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff0000 })); r.position.y = 0.27; g.add(r);
      return g;
    }
    let C, R, M, cells, first, flagMode, opened, over, time, L, K;
    function build() {
      field.clear();
      K = boardKit(S, C, R, { tilt: 0.3, height: 0.5, extraTop: 0.6 });
      const base = new THREE.Mesh(roundedBox(C + 0.5, 0.5, R + 0.5, 0.25), mat(0x7f5539)); base.position.y = -0.6; base.receiveShadow = true; field.add(base);
      cells.forEach((x, i) => {
        const c = i % C, r = (i / C) | 0, g = new THREE.Group(); g.position.copy(K.pos(c, r, 0));
        const dirt = new THREE.Mesh(dirtGeo, dirtMats[(r + c) % 2]); dirt.position.y = -0.1; dirt.receiveShadow = true; g.add(dirt);
        const grass = new THREE.Mesh(grassGeo, grassMats[(r + c) % 2]); grass.position.y = -0.1; grass.castShadow = true; grass.receiveShadow = true; g.add(grass);
        field.add(g); x.g = g; x.grass = grass; x.flagM = null; x.extra = null;
      });
    }
    function start() {
      L = api.level;
      C = Math.min(12, 8 + Math.floor((L - 1) / 2)); R = Math.min(16, 10 + (L - 1));
      M = Math.round(C * R * Math.min(0.22, 0.11 + L * 0.012) * (1 + (expert(L, 9) - 1) * 0.45)); // uzman: mayın yoğunluğu %28'e kadar çıkar
      cells = Array.from({ length: R * C }, () => ({ mine: false, n: 0, open: false, flag: false, anim: 0 }));
      first = true; flagMode = false; opened = 0; over = false; time = 0;
      build(); hud(); syncBtn();
    }
    const at = (r, c) => (r >= 0 && r < R && c >= 0 && c < C ? cells[r * C + c] : null);
    const nbrs = (r, c) => { const o = []; for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) if (dr || dc) { const x = at(r + dr, c + dc); if (x) o.push([r + dr, c + dc, x]); } return o; };
    function plant(sr, sc) {
      let k = 0;
      while (k < M) {
        const r = (Math.random() * R) | 0, c = (Math.random() * C) | 0;
        if (Math.abs(r - sr) <= 1 && Math.abs(c - sc) <= 1) continue;
        const x = at(r, c); if (x.mine) continue; x.mine = true; k++;
      }
      for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) at(r, c).n = nbrs(r, c).filter(([, , x]) => x.mine).length;
    }
    function hud() {
      const flags = cells.filter((x) => x.flag).length;
      api.setHud({ score: M - flags, scoreLabel: '💣', extra: `⏱ ${Math.floor(time)} sn · ${C}×${R}` });
    }
    function reveal(r, c) {
      const stack = [[r, c]];
      while (stack.length) {
        const [rr, cc] = stack.pop(); const x = at(rr, cc);
        if (!x || x.open || x.flag) continue;
        x.open = true; x.anim = 0.01; opened++;
        if (x.n === 0 && !x.mine) nbrs(rr, cc).forEach(([a, b]) => stack.push([a, b]));
      }
    }
    function tap(r, c, longPress) {
      const x = at(r, c); if (!x || over) return;
      if (flagMode || longPress) { if (!x.open) { x.flag = !x.flag; api.sfx.click(); api.haptic('light'); hud(); } return; }
      if (x.flag) return;
      if (first) { plant(r, c); first = false; }
      if (x.open) { // akor: etrafındaki bayrak sayısı tutuyorsa komşuları aç
        const f = nbrs(r, c).filter(([, , y]) => y.flag).length;
        if (f === x.n) nbrs(r, c).forEach(([a, b, y]) => { if (!y.flag && !y.open) { if (y.mine) boom(a, b); else reveal(a, b); } });
      } else if (x.mine) { boom(r, c); return; }
      else { reveal(r, c); api.sfx.pop(); }
      if (!over && opened === R * C - M) win();
    }
    function boom(r, c) {
      over = true;
      cells.forEach((x) => { if (x.mine) { x.open = true; x.anim = 0.01; } });
      S.burst(K.pos(c, r, 0.5), 0xff4d6d, 40, 8); S.burst(K.pos(c, r, 0.5), 0x333333, 20, 6);
      api.sfx.crash(); api.haptic('heavy');
      setTimeout(() => api.gameOver({ score: opened * 2, coins: Math.floor(opened / 6), title: 'Mayına bastın! 💥' }), 900);
    }
    function win() {
      over = true; api.sfx.win();
      for (let i = 0; i < 6; i++) S.burst(new THREE.Vector3((Math.random() - 0.5) * C, 0.6, (Math.random() - 0.5) * R), 0xffd60a, 14, 5);
      const score = Math.max(100, M * 40 - Math.floor(time) * 2);
      setTimeout(() => api.gameOver({ score, coins: 15 + M, win: true, title: 'Tarlayı temizledin! 🏆' }), 600);
    }
    let pressT = null, pressCell = null;
    S.el.addEventListener('pointerdown', (e) => {
      const cell = K.cellAt(e, 0); if (!cell) return;
      pressCell = cell;
      pressT = setTimeout(() => { pressT = null; tap(cell.r, cell.c, true); pressCell = null; }, 420);
    });
    S.el.addEventListener('pointerup', () => {
      if (pressT && pressCell) { clearTimeout(pressT); tap(pressCell.r, pressCell.c, false); }
      pressT = null; pressCell = null;
    });
    function sync(x, i, dt, t) {
      const c = i % C, r = (i / C) | 0;
      // bayrak
      if (x.flag && !x.flagM && !x.open) { x.flagM = flagMesh(); x.flagM.position.y = 0.3; x.g.add(x.flagM); }
      if ((!x.flag || x.open) && x.flagM) { x.g.remove(x.flagM); x.flagM = null; }
      if (x.flagM) x.flagM.rotation.y = Math.sin(t * 2 + i) * 0.2;
      if (x.open) {
        if (x.anim > 0 && x.anim < 1) x.anim = Math.min(1, x.anim + dt * 6);
        const k = x.anim || 1;
        x.grass.position.y = -0.1 + k * 0.8; x.grass.scale.setScalar(Math.max(0.001, 1 - k));
        if (k >= 1) x.grass.visible = false;
        if (!x.extra) {
          if (x.mine) { x.extra = mineMesh(); x.extra.position.y = 0.2; }
          else if (x.n) { x.extra = new THREE.Mesh(numGeo, new THREE.MeshBasicMaterial({ map: textTexture(String(x.n), { color: NUMC[x.n] }), transparent: true, depthWrite: false })); x.extra.rotation.x = -Math.PI / 2; x.extra.position.y = -0.04; }
          if (x.extra) x.g.add(x.extra);
        }
      }
    }
    const lp = S.loop((dt, t) => {
      if (!over && !first) { const b = Math.floor(time); time += dt; if (Math.floor(time) !== b) hud(); }
      cells.forEach((x, i) => sync(x, i, dt, t));
      S.updateParts(dt, -0.2);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { btn.remove(); S.destroy(); } };
  },
};
