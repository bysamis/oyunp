// 🎵 Renk Sırası 3D: yanan düğme sırasını ezberle ve tekrarla
import { create3D, mat, THREE } from '../core/three-stage.js';
import { roundedBox } from '../core/board3d.js';

const PADS = [
  { c: '#2dc653', f: 392 }, { c: '#ff4d6d', f: 330 }, { c: '#ffd60a', f: 262 }, { c: '#3a86ff', f: 196 },
  { c: '#9d4edd', f: 440 }, { c: '#ff9f1c', f: 494 },
];

export default {
  id: 'simon', title: 'Renk Sırası 3D', emoji: '🎵', color: '#9d4edd',
  desc: 'Yanan renk sırasını ezberle ve tekrarla!',
  target: (L) => 6 + (L - 1) * 2,
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0x240046 });
    const { scene, camera, hemi } = S;
    hemi.intensity = 0.6;
    const consoleG = new THREE.Group(); scene.add(consoleG);
    let seq, idx, phase, glow, showT, showI, score, nPads, L, over, inputTimer, buttons = [];
    function buildConsole() {
      consoleG.clear(); buttons = [];
      const rows = nPads / 2, W = 4.4, D = rows * 2.1 + 0.4;
      const body = new THREE.Mesh(roundedBox(W, 0.6, D, 0.4), mat(0x3c096c, { roughness: 0.4 })); body.position.y = -0.6; body.castShadow = true; body.receiveShadow = true; consoleG.add(body);
      for (let i = 0; i < nPads; i++) {
        const c = i % 2, r = (i / 2) | 0;
        const g = new THREE.Group(); g.position.set((c - 0.5) * 2.1, 0, (r - (rows - 1) / 2) * 2.1);
        const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1, 0.2, 36), mat(0x10002b)); ring.position.y = -0.2; g.add(ring);
        const col = new THREE.Color(PADS[i].c);
        const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.82, 0.86, 0.35, 36), mat(col, { roughness: 0.25, emissive: col, emissiveIntensity: 0.1 })); cap.castShadow = true; g.add(cap);
        const light = new THREE.PointLight(col, 0, 4); light.position.y = 0.8; g.add(light);
        consoleG.add(g); buttons.push({ g, cap, light });
      }
      fit(W, D);
    }
    let lastFit = [4.4, 4.6];
    function fit(W, D) {
      lastFit = [W, D];
      const vfov = (camera.fov * Math.PI) / 180, a = S.w / S.h;
      const d = Math.max((D / 2 + 0.8) / Math.tan(vfov / 2), (W / 2 + 0.6) / (Math.tan(vfov / 2) * a)) * 1.05;
      camera.position.set(0, d * 0.95, d * 0.35); camera.lookAt(0, 0, 0);
    }
    S.onResize(() => fit(...lastFit));
    function start() {
      L = api.level; nPads = L >= 4 ? 6 : 4;
      seq = []; score = 0; over = false; glow = Array(6).fill(0); buildConsole();
      nextRound();
    }
    const showGap = () => Math.max(0.18, 0.6 - L * 0.04 - seq.length * 0.012);
    function nextRound() {
      seq.push((Math.random() * nPads) | 0);
      idx = 0; phase = 'show'; showT = 0.7; showI = 0; hud();
    }
    function hud() { api.setHud({ score, scoreLabel: 'Tur', extra: phase === 'show' ? '👀 İzle…' : `👉 Sıra sende · ${idx}/${seq.length}` + (inputTimer < 99 ? ` · ⏱ ${Math.ceil(inputTimer)}` : '') }); }
    function flash(i) { glow[i] = 1; api.sfx.tap(); playTone(PADS[i].f); }
    let actx;
    function playTone(f) {
      try {
        actx = actx || new (window.AudioContext || window.webkitAudioContext)();
        const o = actx.createOscillator(), g = actx.createGain();
        o.frequency.value = f; o.type = 'triangle'; g.gain.setValueAtTime(0.25, actx.currentTime); g.gain.exponentialRampToValueAtTime(0.001, actx.currentTime + 0.35);
        o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + 0.4);
      } catch (e) {}
    }
    S.el.addEventListener('pointerdown', (e) => {
      if (phase !== 'input' || over) return;
      const hit = S.pick(e, buttons.map((b) => b.g)); if (!hit) return;
      const i = buttons.findIndex((b) => b.g === hit.object.parent); if (i < 0) return;
      flash(i); api.haptic('light');
      if (i !== seq[idx]) return fail();
      idx++; inputTimer = Math.max(1.6, 4 - L * 0.3);
      if (idx === seq.length) { score++; api.sfx.coin(); S.popText(new THREE.Vector3(0, 1, 0), '✓', '#fff'); phase = 'wait'; setTimeout(nextRound, 600); }
      hud();
    });
    function fail() {
      over = true; phase = 'over'; api.sfx.lose(); api.haptic('heavy');
      setTimeout(() => api.gameOver({ score, coins: score * 3, canContinue: true, title: 'Sıra karıştı! 🎵' }), 500);
    }
    function update(dt) {
      for (let i = 0; i < 6; i++) glow[i] = Math.max(0, glow[i] - dt * 3.5);
      if (phase === 'show') {
        showT -= dt;
        if (showT <= 0) {
          if (showI < seq.length) { flash(seq[showI]); showI++; showT = showGap(); }
          else { phase = 'input'; inputTimer = Math.max(1.6, 4 - L * 0.3); hud(); }
        }
      } else if (phase === 'input' && L >= 2) {
        const b = Math.ceil(inputTimer); inputTimer -= dt;
        if (Math.ceil(inputTimer) !== b) hud();
        if (inputTimer <= 0) fail();
      }
      buttons.forEach((b, i) => { const g = glow[i]; b.cap.material.emissiveIntensity = 0.1 + g * 1.2; b.light.intensity = g * 8; b.cap.position.y = -g * 0.12; });
      S.updateParts(dt, 0);
    }
    start();
    const lp = S.loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { over = false; idx = 0; phase = 'show'; showT = 0.8; showI = 0; hud(); },
      restart() { start(); }, destroy() { S.destroy(); },
    };
  },
};
