// 🎯 Hedef Vur 3D: atış poligonu — hedefler kaybolmadan vur, mavi ✕ hedeflere dokunma
import { create3D, mat, THREE } from '../core/three-stage.js';
import { expert, expertSteps } from '../core/expert.js';
import { textTexture } from '../core/board3d.js';

export default {
  id: 'reflex', title: 'Hedef Vur 3D', emoji: '🎯', color: '#d00000',
  desc: 'Hedefler kaybolmadan hepsini vur!',
  expertFrom: 14,
  target: (L) => Math.round(400 * Math.pow(1.4, L - 1)),
  create(host, api) {
    const S = create3D(host, { fov: 50, bg: 0x22223b });
    const { scene, camera } = S;
    // poligon: tahta duvar, zemin, lambalar
    const wall = new THREE.Mesh(new THREE.PlaneGeometry(60, 40), mat(0x9c6644, { roughness: 0.9 })); wall.position.z = -0.6; wall.receiveShadow = true; scene.add(wall);
    for (let y = -20; y < 20; y += 1.2) { const l = new THREE.Mesh(new THREE.BoxGeometry(60, 0.05, 0.05), mat(0x7f5539)); l.position.set(0, y, -0.55); scene.add(l); }
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(60, 30), mat(0x495057)); floor.rotation.x = -Math.PI / 2; floor.position.set(0, -8, 10); floor.receiveShadow = true; scene.add(floor);
    const spot = new THREE.SpotLight(0xfff1c1, 60, 40, 0.7, 0.5); spot.position.set(0, 4, 14); spot.target.position.set(0, 0, 0); scene.add(spot, spot.target);

    const discMats = { red: [mat(0xd00000), mat(0xffffff), mat(0xd00000), mat(0xffd60a)], blue: [mat(0x3a86ff), mat(0xffffff), mat(0x3a86ff), mat(0x3a86ff)] };
    const xMat = new THREE.MeshBasicMaterial({ map: textTexture('✕', { color: '#fff' }), transparent: true });
    function makeTarget(tg) {
      const g = new THREE.Group(), set = discMats[tg.decoy ? 'blue' : 'red'];
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 0.18, 32), mat(0xf8f9fa)); rim.rotation.x = Math.PI / 2; rim.castShadow = true; g.add(rim);
      [1, 0.75, 0.5, 0.22].forEach((k, i) => { const d = new THREE.Mesh(new THREE.CircleGeometry(k * 0.94, 32), set[i]); d.position.z = 0.091 + i * 0.002; g.add(d); });
      if (tg.decoy) { const x = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), xMat); x.position.z = 0.1; g.add(x); }
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.8), mat(0x6c757d, { metalness: 0.5 })); post.position.set(0, -1.3, -0.1); g.add(post);
      g.scale.setScalar(0.01);
      return g;
    }
    const tGroup = new THREE.Group(); scene.add(tGroup);
    let targets, score, lives, spawnIn, elapsed, over, L, streak, hw = 4, hh = 7;
    S.onResize(() => {
      camera.position.set(0, 0, 16); camera.lookAt(0, 0, 0);
      const vfov = (camera.fov * Math.PI) / 180; hh = Math.tan(vfov / 2) * 16; hw = hh * (S.w / S.h);
    });
    const unit = () => Math.min(hw * 2, 10) / 400; // eski piksel ölçüsü → birim
    function start() { L = api.level; tGroup.clear(); targets = []; score = 0; lives = 3; spawnIn = 0.3; elapsed = 0; over = false; streak = 0; hud(); }
    function hud() { api.setHud({ score, extra: `${'❤️'.repeat(lives)} · Seri ${streak}` }); }
    function spawn() {
      const u = unit();
      const r = Math.max(16, 42 - L * 2.5 - elapsed * 0.15) * u * 1.45;
      const life = Math.max(0.7, 2.4 - L * 0.15 - elapsed * 0.012) / (1 + (expert(L, 13) - 1) * 0.5);
      const moving = L >= 3 && Math.random() < Math.min(0.6, (L - 2) * 0.12);
      const decoy = L >= 2 && Math.random() < Math.min(0.25, 0.05 + L * 0.02);
      const tg = { x: (Math.random() * 2 - 1) * (hw - r - 0.2), y: (Math.random() * 2 - 1) * (hh - r - 0.6), r, life, t: 0, vx: moving ? (Math.random() - 0.5) * 220 * u : 0, vy: moving ? (Math.random() - 0.5) * 220 * u : 0, decoy };
      tg.g = makeTarget(tg); tGroup.add(tg.g); targets.push(tg);
      spawnIn = Math.max(0.25, 0.9 - L * 0.05 - elapsed * 0.01) / (1 + (expert(L, 13) - 1) * 0.5);
    }
    function lose() {
      lives--; streak = 0; api.sfx.wrong(); api.haptic('medium'); hud();
      if (lives <= 0 && !over) { over = true; api.sfx.lose(); api.gameOver({ score, coins: Math.floor(score / 25), canContinue: true, title: 'Hedefler kaçtı! 🎯' }); }
    }
    S.el.addEventListener('pointerdown', (e) => {
      if (over) return;
      const p = S.rayPlaneZ(e, 0.1); if (!p) return;
      for (let i = targets.length - 1; i >= 0; i--) {
        const tg = targets[i], k = 1 - tg.t / tg.life, rr = tg.r * Math.max(0.35, k);
        const d = Math.hypot(p.x - tg.x, p.y - tg.y);
        if (d < rr + 0.15) {
          targets.splice(i, 1); tGroup.remove(tg.g);
          const pos = new THREE.Vector3(tg.x, tg.y, 0.3);
          if (tg.decoy) { S.burst(pos, 0x3a86ff, 14, 5); lose(); return; }
          const center = d < rr * 0.3;
          streak++; const pts = 10 + Math.round(k * 20) + (center ? 15 : 0) + Math.min(streak, 15);
          score += pts; api.sfx.pop(); api.haptic('light');
          S.burst(pos, 0xff4d6d, 12, 5, 0.7); S.burst(pos, 0xffffff, 6, 4, 0.5);
          S.popText(pos, center ? `TAM! +${pts}` : `+${pts}`, center ? '#ffd60a' : '#fff'); hud();
          return;
        }
      }
      score = Math.max(0, score - 5); streak = 0; hud();
      // ıskalanan atış: duvarda delik izi
      const hole = new THREE.Mesh(new THREE.CircleGeometry(0.07, 10), new THREE.MeshBasicMaterial({ color: 0x1b1b1b })); hole.position.set(p.x, p.y, -0.54); scene.add(hole); setTimeout(() => scene.remove(hole), 1500);
    });
    const lp = S.loop((dt, t) => {
      if (!over) {
        elapsed += dt; spawnIn -= dt; if (spawnIn <= 0) spawn();
        for (let i = targets.length - 1; i >= 0; i--) {
          const tg = targets[i]; tg.t += dt; tg.x += tg.vx * dt; tg.y += tg.vy * dt;
          if (Math.abs(tg.x) > hw - tg.r) tg.vx *= -1; if (Math.abs(tg.y) > hh - tg.r - 0.4) tg.vy *= -1;
          if (tg.t >= tg.life) { targets.splice(i, 1); tGroup.remove(tg.g); if (!tg.decoy) lose(); }
        }
      }
      for (const tg of targets) {
        const k = Math.max(0.05, 1 - tg.t / tg.life), rr = tg.r * Math.max(0.35, k);
        const pop = Math.min(1, tg.t * 8);
        tg.g.position.set(tg.x, tg.y, 0); tg.g.scale.setScalar(rr * pop);
        tg.g.rotation.y = (1 - pop) * Math.PI * 0.5 + Math.sin(t * 3 + tg.x) * 0.08;
      }
      S.updateParts(dt, -8);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), continue() { lives = 2; tGroup.clear(); targets = []; over = false; hud(); }, restart() { start(); }, destroy() { S.destroy(); } };
  },
};
