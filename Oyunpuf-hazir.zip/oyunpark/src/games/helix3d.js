// 🌀 Sarmal Kule 3D: kuleyi parmağınla döndür, topu boşluklardan aşağı indir; kırmızıya değme!
import { create3D, mat, THREE } from '../core/three-stage.js';
import { touchpad } from '../core/touchpad.js';

const SEG = 12, GAP_Y = 3.2, RAD = 2.7;

export default {
  id: 'helix', title: 'Sarmal Kule 3D', emoji: '🌀', color: '#ff006e',
  desc: 'Kuleyi döndür, topu boşluklardan indir!',
  target: (L) => 15 + (L - 1) * 8,
  create(host, api) {
    const S = create3D(host, { fov: 50, bg: 0x2b2d42 });
    const { scene, camera, sun } = S;
    const tower = new THREE.Group(); scene.add(tower);
    const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.75, 400, 24), mat(0xf1faee, { roughness: 0.4 })); pillar.position.y = -190; tower.add(pillar);
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.38, 24, 16), mat(0xff006e, { roughness: 0.25, metalness: 0.2 })); ball.castShadow = true; scene.add(ball);
    const splats = [];
    const segGeo = new THREE.CylinderGeometry(RAD, RAD, 0.45, 6, 1, false, 0, (Math.PI * 2) / SEG);
    let floors, ballY, vy, rot, score, combo, over, L, theme, depthCount, nextFloorIdx;
    const themes = [[0x2b2d42, 0x8ecae6], [0x3d405b, 0xf2cc8f], [0x1d3557, 0xa8dadc], [0x22223b, 0xc9ada7], [0x003049, 0xfcbf49]];

    function mkFloor(idx) {
      const g = new THREE.Group(); g.position.y = -idx * GAP_Y; tower.add(g);
      const segs = [];
      // Zorluk: seviye arttıkça boşluk azalır, kırmızı bölüm artar, katlar kendi kendine döner
      const gaps = idx === 0 ? 2 : Math.max(1, 3 - Math.floor(L / 3) - (idx > 30 ? 1 : 0));
      const reds = idx < 2 ? 0 : Math.min(6, Math.floor((L - 1) * 0.6 + idx / 12) + (Math.random() < 0.5 ? 1 : 0));
      const start = (Math.random() * SEG) | 0;
      const types = Array(SEG).fill('n');
      for (let k = 0; k < gaps; k++) types[(start + k) % SEG] = 'gap';
      let placed = 0, guard = 0;
      while (placed < reds && guard++ < 50) { const i = (Math.random() * SEG) | 0; if (types[i] === 'n' && Math.abs(i - start) > 0) { types[i] = 'red'; placed++; } }
      types.forEach((ty, i) => {
        if (ty === 'gap') { segs.push(null); return; }
        const m = new THREE.Mesh(segGeo, ty === 'red' ? mat(0xef233c, { roughness: 0.4, emissive: 0x550000, emissiveIntensity: 0.4 }) : mat(theme[1], { roughness: 0.45 }));
        m.rotation.y = (i * Math.PI * 2) / SEG; m.castShadow = true; m.receiveShadow = true; g.add(m); segs.push({ m, ty });
      });
      const spin = L >= 4 && idx > 3 && Math.random() < Math.min(0.5, (L - 3) * 0.08) ? (Math.random() < 0.5 ? -1 : 1) * (0.5 + L * 0.08) : 0;
      return { g, segs, idx, spin, broken: false };
    }
    function clearAll() { floors?.forEach((f) => tower.remove(f.g)); splats.forEach((s) => tower.remove(s)); splats.length = 0; }
    function start() {
      clearAll(); L = api.level; theme = themes[(L - 1) % themes.length];
      scene.background.setHex(theme[0]);
      floors = []; nextFloorIdx = 0;
      for (let i = 0; i < 12; i++) floors.push(mkFloor(nextFloorIdx++));
      ballY = 1.6; vy = 0; rot = 0; score = 0; combo = 0; over = false; depthCount = 0; hud();
    }
    function hud() { api.setHud({ score, scoreLabel: 'Kat', extra: combo >= 3 ? '🔥 Ateş topu! Kırmızıyı da kırar' : 'Kuleyi sağa sola kaydır' }); }
    let dragX = null;
    S.el.addEventListener('pointerdown', (e) => { dragX = e.clientX; });
    S.el.addEventListener('pointermove', (e) => { if (dragX === null) return; rot += (e.clientX - dragX) * 0.012; dragX = e.clientX; });
    const up = () => (dragX = null); window.addEventListener('pointerup', up);
    const onKey = (e) => { if (e.key === 'ArrowLeft') rot -= 0.25; if (e.key === 'ArrowRight') rot += 0.25; };
    window.addEventListener('keydown', onKey);
    const pad = touchpad(host, { left: [{ id: 'left', icon: '⟲', big: true }], right: [{ id: 'right', icon: '⟳', big: true }] });

    function segUnderBall(f) {
      // top dünyada kameraya bakan tarafta (açı 0, +z yönünde)
      const total = rot + f.g.rotation.y;
      let a = (-total) % (Math.PI * 2); if (a < 0) a += Math.PI * 2;
      return Math.floor(a / ((Math.PI * 2) / SEG)) % SEG;
    }
    function breakFloor(f, fx = true) {
      f.broken = true;
      f.segs.forEach((s) => { if (!s) return; s.vel = new THREE.Vector3((Math.random() - 0.5) * 6, 2 + Math.random() * 3, (Math.random() - 0.5) * 6); });
      if (fx) S.burst(new THREE.Vector3(0, ball.position.y, 1.8), theme[1], 10, 5);
    }
    const lp = S.loop((dt, t) => {
      if (!over) {
        vy -= 28 * dt; const prevY = ballY; ballY += vy * dt;
        for (const f of floors) {
          if (f.broken) continue;
          const top = f.g.position.y + 0.225 + 0.38;
          if (prevY >= top && ballY < top) {
            const s = f.segs[segUnderBall(f)];
            if (!s) { score++; combo++; depthCount++; api.sfx.swap(); breakFloor(f, false); S.popText(new THREE.Vector3(0, top, 1.8), combo > 1 ? `+${combo}` : '+1', '#fff'); hud(); continue; }
            if (combo >= 3) { score++; depthCount++; api.sfx.crash(); api.haptic('heavy'); breakFloor(f); combo = 0; ballY = top; vy = 10.5; hud(); continue; }
            if (s.ty === 'red') {
              over = true; api.sfx.lose(); api.haptic('heavy'); S.burst(new THREE.Vector3(0, top, 1.8), 0xff006e, 24, 6);
              ball.visible = false;
              setTimeout(() => api.gameOver({ score, coins: Math.floor(score / 3), canContinue: true, title: 'Kırmızıya değdin! 🌀' }), 700);
              break;
            }
            ballY = top; vy = 10.5; combo = 0; api.sfx.bounce(); hud();
            // boya lekesi
            const sp = new THREE.Mesh(new THREE.CircleGeometry(0.32 + Math.random() * 0.12, 12), new THREE.MeshBasicMaterial({ color: 0xff006e }));
            sp.rotation.x = -Math.PI / 2; sp.position.set(Math.sin(-rot - f.g.rotation.y) * 1.8, top - 0.37, Math.cos(-rot - f.g.rotation.y) * 1.8); f.g.add(sp);
            break;
          }
        }
        // yeni katlar
        while (floors.length && floors[floors.length - 1].g.position.y > ballY - 30) floors.push(mkFloor(nextFloorIdx++));
        floors = floors.filter((f) => { if (f.g.position.y > ballY + 12) { tower.remove(f.g); return false; } return true; });
      }
      for (const f of floors) {
        if (f.spin) f.g.rotation.y += f.spin * dt;
        if (f.broken) f.segs.forEach((s) => { if (!s?.vel) return; s.vel.y -= 20 * dt; s.m.position.addScaledVector(s.vel, dt); s.m.rotation.x += dt * 4; s.m.scale.multiplyScalar(1 - dt * 1.5); });
      }
      if (pad.held.left) rot -= 3.2 * dt; if (pad.held.right) rot += 3.2 * dt;
      tower.rotation.y = rot;
      ball.position.set(0, ballY, 1.8);
      ball.scale.set(1, vy > 6 ? 0.85 : 1, 1);
      ball.material.color.setHex(combo >= 3 ? (Math.floor(t * 12) % 2 ? 0xffd60a : 0xff6d00) : 0xff006e);
      // kamera yalnızca aşağı iner
      const camTarget = ballY + 3.5;
      if (!camera.userData.init) { camera.position.y = camTarget; camera.userData.init = true; }
      else if (camTarget < camera.position.y) camera.position.y += (camTarget - camera.position.y) * Math.min(1, dt * 10);
      camera.position.x = 0; camera.position.z = 11.5; camera.lookAt(0, camera.position.y - 4.2, 0);
      sun.position.set(-5, camera.position.y + 10, 8); sun.target.position.set(0, camera.position.y - 4, 0);
      S.updateParts(dt, -1000);
    });
    start();
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { const f = floors.find((f) => !f.broken && f.g.position.y < ballY + 1); if (f) breakFloor(f); ball.visible = true; vy = 4; over = false; hud(); },
      restart() { ball.visible = true; camera.userData.init = false; start(); },
      destroy() { pad.destroy(); window.removeEventListener('pointerup', up); window.removeEventListener('keydown', onKey); S.destroy(); },
    };
  },
};
