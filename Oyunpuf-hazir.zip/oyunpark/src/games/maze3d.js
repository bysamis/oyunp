// 🌀 Labirent 3D: kaydır, top duvara kadar yuvarlansın; çıkıştaki bayrağa ulaş
import { create3D, mat, THREE } from '../core/three-stage.js';
import { touchpad } from '../core/touchpad.js';
import { expert, expertSteps } from '../core/expert.js';
import { boardKit, roundedBox } from '../core/board3d.js';
import { model, modelInto } from '../core/assets.js';

export default {
  id: 'maze', title: 'Labirent 3D', emoji: '🌀', color: '#f72585',
  desc: 'Kaydır, topu labirentten çıkar!',
  expertFrom: 10,
  winBased: true,
  create(host, api) {
    const S = create3D(host, { fov: 40, bg: 0x3a0ca3 });
    const { scene } = S;
    const world = new THREE.Group(); scene.add(world);
    const ball = new THREE.Mesh(new THREE.SphereGeometry(0.32, 24, 16), mat(0xf72585, { roughness: 0.2, metalness: 0.3 })); ball.castShadow = true; scene.add(ball);
    const trailMat = new THREE.MeshBasicMaterial({ color: 0xff8fab, transparent: true, opacity: 0.5 });
    let N, M, walls, pos, draw_, time, limit, over, L, stars, moves, trail, K, starMeshes = [], trailMeshes = new THREE.Group(); scene.add(trailMeshes);
    function gen() {
      // derinlik öncelikli arama ile kusursuz labirent
      walls = Array.from({ length: M * N }, () => [1, 1, 1, 1]); // üst, sağ, alt, sol
      const seen = new Set([0]); const stack = [0];
      while (stack.length) {
        const cur = stack[stack.length - 1], r = (cur / N) | 0, c = cur % N;
        const nb = [[-1, 0, 0, 2], [0, 1, 1, 3], [1, 0, 2, 0], [0, -1, 3, 1]]
          .map(([dr, dc, w, ow]) => [r + dr, c + dc, w, ow]).filter(([rr, cc]) => rr >= 0 && rr < M && cc >= 0 && cc < N && !seen.has(rr * N + cc));
        if (!nb.length) { stack.pop(); continue; }
        const [rr, cc, w, ow] = nb[(Math.random() * nb.length) | 0];
        walls[cur][w] = 0; walls[rr * N + cc][ow] = 0; seen.add(rr * N + cc); stack.push(rr * N + cc);
      }
      stars = [];
      for (let i = 0; i < 3; i++) stars.push({ r: (Math.random() * M) | 0, c: (Math.random() * N) | 0, got: false });
    }
    function build() {
      world.clear(); trailMeshes.clear(); starMeshes = [];
      K = boardKit(S, N, M, { tilt: 0.28, height: 0.8 });
      const floor = new THREE.Mesh(roundedBox(N + 0.6, 0.4, M + 0.6, 0.3), mat(0x4361ee)); floor.position.y = -0.4; floor.receiveShadow = true; world.add(floor);
      // duvar parçaları (tek InstancedMesh)
      const segs = [];
      for (let r = 0; r < M; r++) for (let c = 0; c < N; c++) {
        const w = walls[r * N + c], x = K.x(c), z = K.z(r);
        if (w[0]) segs.push([x, z - 0.5, true]);
        if (w[3]) segs.push([x - 0.5, z, false]);
        if (r === M - 1 && w[2]) segs.push([x, z + 0.5, true]);
        if (c === N - 1 && w[1]) segs.push([x + 0.5, z, false]);
      }
      const geo = new THREE.BoxGeometry(1.12, 0.6, 0.12);
      const im = new THREE.InstancedMesh(geo, mat(0xf8f9fa, { roughness: 0.4 }), segs.length); im.castShadow = true; im.receiveShadow = true;
      const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
      segs.forEach(([x, z, horiz], i) => { e.set(0, horiz ? 0 : Math.PI / 2, 0); q.setFromEuler(e); m4.compose(new THREE.Vector3(x, 0.3, z), q, new THREE.Vector3(1, 1, 1)); im.setMatrixAt(i, m4); });
      world.add(im);
      // başlangıç ve çıkış
      const startPad = new THREE.Mesh(new THREE.CircleGeometry(0.4, 24), new THREE.MeshBasicMaterial({ color: 0x4cc9f0 })); startPad.rotation.x = -Math.PI / 2; startPad.position.copy(K.pos(0, 0, 0.01)); world.add(startPad);
      const exitPad = new THREE.Mesh(new THREE.CircleGeometry(0.45, 24), new THREE.MeshBasicMaterial({ color: 0xffd60a })); exitPad.rotation.x = -Math.PI / 2; exitPad.position.copy(K.pos(N - 1, M - 1, 0.01)); world.add(exitPad);
      const flag = modelInto(world, 'flag', { height: 0.9 }); flag.position.copy(K.pos(N - 1, M - 1, 0)); flag.position.x += 0.15;
      // yıldızlar
      for (const s of stars) {
        const g = new THREE.Group(); g.position.copy(K.pos(s.c, s.r, 0.4));
        const shape = new THREE.Shape(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? 0.13 : 0.3; i ? shape.lineTo(Math.cos(a) * rr, Math.sin(a) * rr) : shape.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); }
        const st = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth: 0.08, bevelEnabled: true, bevelThickness: 0.03, bevelSize: 0.03, bevelSegments: 1 }), mat(0xffd60a, { emissive: 0xffb703, emissiveIntensity: 0.5, metalness: 0.4 }));
        st.position.z = -0.04; st.castShadow = true; const tiltG = new THREE.Group(); tiltG.rotation.x = -1.05; tiltG.add(st); g.add(tiltG); world.add(g); starMeshes.push({ s, g });
      }
    }
    function start() {
      L = api.level; N = Math.min(18, 6 + L * 2); M = Math.min(26, Math.round(N * 1.35));
      gen(); build();
      pos = { r: 0, c: 0 }; draw_ = { r: 0, c: 0 }; time = 0; moves = 0; over = false; trail = [];
      limit = L >= 2 ? Math.round(N * M * Math.max(0.12, 0.35 - L * 0.025) / expert(L, 9)) : Infinity; // uzman: süre kısalır
      hud();
    }
    function hud() { api.setHud({ score: Math.floor(time), scoreLabel: 'Saniye', extra: `${N}×${M}` + (limit < Infinity ? ` · Süre: ${Math.max(0, Math.ceil(limit - time))}` : '') + ` · ⭐ ${stars.filter((s) => s.got).length}/3` }); }
    // kaydırma yönünde, kavşağa kadar ilerle
    function go(dr, dc) {
      if (over) return;
      const w = dr === -1 ? 0 : dc === 1 ? 1 : dr === 1 ? 2 : 3;
      let moved = false;
      while (!walls[pos.r * N + pos.c][w]) {
        trail.push({ ...pos }); { const d = new THREE.Mesh(new THREE.CircleGeometry(0.12, 10), trailMat); d.rotation.x = -Math.PI / 2; d.position.copy(K.pos(pos.c, pos.r, 0.02)); trailMeshes.add(d); }
        pos = { r: pos.r + dr, c: pos.c + dc }; moved = true;
        const s = stars.find((s) => !s.got && s.r === pos.r && s.c === pos.c);
        if (s) { s.got = true; api.sfx.coin(); S.burst(K.pos(s.c, s.r, 0.5), 0xffd60a, 12, 4, 0.5); }
        const open = walls[pos.r * N + pos.c].filter((x) => !x).length;
        if (open > 2 || (pos.r === M - 1 && pos.c === N - 1)) break;
      }
      if (moved) { moves++; api.sfx.slide(); api.haptic('light'); hud(); }
      if (pos.r === M - 1 && pos.c === N - 1) win();
    }
    function win() {
      over = true; api.sfx.win(); S.burst(K.pos(N - 1, M - 1, 0.6), 0xffd60a, 40, 7);
      const got = stars.filter((s) => s.got).length;
      const score = Math.max(50, N * M * 3 - Math.floor(time) * 2 + got * 50);
      setTimeout(() => api.gameOver({ score, coins: 10 + L * 3 + got * 5, win: true, title: 'Çıkışı buldun! 🌀' }), 700);
    }
    let down = null;
    S.el.addEventListener('pointerdown', (e) => (down = { x: e.clientX, y: e.clientY }));
    S.el.addEventListener('pointerup', (e) => {
      if (!down) return; const dx = e.clientX - down.x, dy = e.clientY - down.y; down = null;
      if (Math.hypot(dx, dy) < 15) return;
      Math.abs(dx) > Math.abs(dy) ? go(0, Math.sign(dx)) : go(Math.sign(dy), 0);
    });
    const onKey = (e) => { const k = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] }[e.key]; if (k) go(...k); };
    window.addEventListener('keydown', onKey);
    const pad = touchpad(host, { dpad: true, onPress: (id) => ({ up: () => go(-1, 0), down: () => go(1, 0), left: () => go(0, -1), right: () => go(0, 1) })[id]() });
    let prevX = 0, prevZ = 0;
    const lp = S.loop((dt, t) => {
      if (!over) {
        const b = Math.floor(time); time += dt; if (Math.floor(time) !== b) hud();
        if (time >= limit) { over = true; api.sfx.lose(); api.gameOver({ score: moves, coins: 3, title: 'Süre doldu! ⏰' }); }
      }
      draw_.r += (pos.r - draw_.r) * Math.min(1, dt * 14); draw_.c += (pos.c - draw_.c) * Math.min(1, dt * 14);
      const x = K.x(draw_.c), z = K.z(draw_.r);
      ball.position.set(x, 0.32, z);
      // yuvarlanma
      ball.rotation.x += (z - prevZ) / 0.32; ball.rotation.z -= (x - prevX) / 0.32; prevX = x; prevZ = z;
      for (const { s, g } of starMeshes) { g.visible = !s.got; g.rotation.y = t * 2; g.position.y = 0.4 + Math.sin(t * 3 + s.c) * 0.06; }
      S.updateParts(dt, 0);
    });
    start();
    return { pause: () => lp.pause(), resume: () => lp.resume(), restart() { start(); }, destroy() { pad.destroy(); S.destroy(); window.removeEventListener('keydown', onKey); } };
  },
};
