// 🧱 Blok Kırma
import { createStage, loop, roundRect, shade, particles } from '../core/canvas.js';
import { store } from '../core/store.js';

const COLORS = ['#ff4d6d', '#ff9f1c', '#ffd60a', '#2dc653', '#3a86ff', '#9d4edd', '#ff70a6'];
export const BALL_SKINS = {
  white: { name: 'Klasik', color: '#ffffff', price: 0 },
  fire: { name: 'Ateş', color: '#ff7b00', price: 200 },
  neon: { name: 'Neon', color: '#39ff14', price: 300 },
  ice: { name: 'Buz', color: '#7ee8fa', price: 300 },
  rainbow: { name: 'Gökkuşağı', color: 'rainbow', price: 800 },
};

export default {
  id: 'breakout', title: 'Blok Kırma', emoji: '🧱', color: '#3a86ff',
  desc: 'Topu sektir, tüm blokları kır!',
  target: (L) => Math.round(400 * Math.pow(1.45, L - 1)),
  create(host, api) {
    const fx = particles();
    let paddle, balls, bricks, drops, lives, level, score, bonusCoins, wideT, state, flash = 0;
    const st = createStage(host, { onResize: () => layout() });
    const S = () => Math.min(st.W, 520) / 400; // ölçek

    function layout() {
      if (!paddle) return;
      paddle.y = st.H - 60 * S();
      paddle.h = 14 * S();
      paddle.x = Math.min(Math.max(paddle.x, paddle.w / 2), st.W - paddle.w / 2);
    }

    function baseW() { return 90 * S() * paddleScale() * (wideT > 0 ? 1.5 : 1); }
    function speed() { return (360 + Math.min(level, 25) * 24) * S(); }
    function paddleScale() { return Math.max(0.55, 1 - (level - 1) * 0.05); }

    function buildLevel() {
      bricks = [];
      const cols = 8;
      const rows = Math.min(4 + level, 10);
      const pad = 10, gap = 5;
      const top = 54 * S();
      const bw = (st.W - pad * 2 - gap * (cols - 1)) / cols;
      const bh = Math.min(24 * S(), bw * 0.5);
      const pattern = level % 4;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          if (pattern === 1 && (r + c) % 2 === 1 && r > 1) continue;              // dama
          if (pattern === 2 && Math.abs(c - 3.5) > rows - r + 0.5) continue;    // piramit
          if (pattern === 3 && (c === 3 || c === 4) && r % 3 === 1) continue;   // koridor
          const hp = level >= 6 && r < level - 6 ? 3 : level >= 3 && r < Math.min(level - 1, 6) ? 2 : 1;
          bricks.push({ x: pad + c * (bw + gap), y: top + r * (bh + gap), w: bw, h: bh, hp, max: hp, color: COLORS[r % COLORS.length] });
        }
      }
      drops = [];
      resetBall();
    }

    function resetBall() {
      paddle.w = baseW();
      balls = [{ x: paddle.x, y: paddle.y - 10 * S(), vx: 0, vy: 0, r: 7 * S(), stuck: true }];
      state = 'ready';
    }

    function launch() {
      for (const b of balls) if (b.stuck) {
        const a = (Math.random() - 0.5) * 0.6;
        b.vx = Math.sin(a) * speed(); b.vy = -Math.cos(a) * speed(); b.stuck = false;
      }
      state = 'play';
      api.sfx.tap();
    }

    function start() {
      paddle = { x: st.W / 2, y: 0, w: 90, h: 14 };
      layout();
      lives = 3; level = api.level; score = 0; bonusCoins = 0; wideT = 0;
      buildLevel();
      hud();
    }

    function hud() { api.setHud({ score, extra: `❤️ ${lives}  ·  Seviye ${level}` }); }

    // Kontroller
    const onMove = (e) => {
      const p = st.point(e);
      paddle.x = Math.min(Math.max(p.x, paddle.w / 2), st.W - paddle.w / 2);
    };
    const onDown = (e) => { onMove(e); };
    const onUp = () => { if (state === 'ready') launch(); };
    const onKey = (e) => {
      if (e.key === 'ArrowLeft') paddle.x = Math.max(paddle.w / 2, paddle.x - 30);
      if (e.key === 'ArrowRight') paddle.x = Math.min(st.W - paddle.w / 2, paddle.x + 30);
      if (e.key === ' ' && state === 'ready') launch();
    };
    st.canvas.addEventListener('pointerdown', onDown);
    st.canvas.addEventListener('pointermove', onMove);
    st.canvas.addEventListener('pointerup', onUp);
    window.addEventListener('keydown', onKey);

    function hitBrick(br, ball) {
      br.hp--;
      api.sfx.brick();
      api.haptic('light');
      if (br.hp <= 0) {
        score += 10 * level;
        fx.burst(br.x + br.w / 2, br.y + br.h / 2, br.color, 10);
        bricks.splice(bricks.indexOf(br), 1);
        if (Math.random() < 0.13) {
          const types = ['wide', 'multi', 'coin', 'coin'];
          drops.push({ x: br.x + br.w / 2, y: br.y + br.h / 2, type: types[(Math.random() * types.length) | 0] });
        }
      } else score += 5;
      hud();
    }

    function stepBall(b, dt) {
      const steps = 4;
      for (let i = 0; i < steps; i++) {
        const h = dt / steps;
        b.x += b.vx * h;
        if (b.x < b.r) { b.x = b.r; b.vx = Math.abs(b.vx); api.sfx.bounce(); }
        if (b.x > st.W - b.r) { b.x = st.W - b.r; b.vx = -Math.abs(b.vx); api.sfx.bounce(); }
        for (const br of bricks) {
          if (circleRect(b, br)) { b.vx = -b.vx; b.x += b.vx * h; hitBrick(br, b); break; }
        }
        b.y += b.vy * h;
        if (b.y < b.r) { b.y = b.r; b.vy = Math.abs(b.vy); api.sfx.bounce(); }
        for (const br of bricks) {
          if (circleRect(b, br)) { b.vy = -b.vy; b.y += b.vy * h; hitBrick(br, b); break; }
        }
        // raket
        if (b.vy > 0 && b.y + b.r >= paddle.y && b.y - b.r <= paddle.y + paddle.h &&
            b.x >= paddle.x - paddle.w / 2 - b.r && b.x <= paddle.x + paddle.w / 2 + b.r) {
          const rel = Math.max(-1, Math.min(1, (b.x - paddle.x) / (paddle.w / 2)));
          const ang = rel * 1.05;
          const sp = speed();
          b.vx = Math.sin(ang) * sp; b.vy = -Math.cos(ang) * sp;
          b.y = paddle.y - b.r;
          api.sfx.bounce();
        }
      }
    }

    function circleRect(b, r) {
      const cx = Math.max(r.x, Math.min(b.x, r.x + r.w));
      const cy = Math.max(r.y, Math.min(b.y, r.y + r.h));
      const dx = b.x - cx, dy = b.y - cy;
      return dx * dx + dy * dy < b.r * b.r;
    }

    function update(dt, t) {
      if (state === 'over') { draw(t); return; }
      if (wideT > 0) { wideT -= dt; }
      paddle.w += (baseW() - paddle.w) * Math.min(1, dt * 8);
      paddle.x = Math.min(Math.max(paddle.x, paddle.w / 2), st.W - paddle.w / 2);

      if (state === 'ready') {
        for (const b of balls) { b.x = paddle.x; b.y = paddle.y - b.r - 1; }
      } else if (state === 'play') {
        for (const b of balls) stepBall(b, dt);
        balls = balls.filter((b) => b.y < st.H + 20);
        if (balls.length === 0) {
          lives--; hud(); api.sfx.wrong(); api.haptic('medium'); flash = 0.4;
          if (lives <= 0) {
            state = 'over';
            api.sfx.lose();
            api.gameOver({ score, coins: Math.floor(score / 25) + bonusCoins, canContinue: true });
          } else resetBall();
        }
        if (bricks.length === 0) {
          level++; score += 100; api.sfx.win(); fx.text(st.W / 2, st.H / 2, `Seviye ${level}!`, '#ffd60a');
          buildLevel(); hud();
        }
      }
      // düşen güçlendiriciler
      for (let i = drops.length - 1; i >= 0; i--) {
        const d = drops[i];
        d.y += 150 * S() * dt;
        if (d.y > paddle.y - 8 && d.y < paddle.y + paddle.h + 8 && Math.abs(d.x - paddle.x) < paddle.w / 2 + 12) {
          drops.splice(i, 1); api.sfx.power();
          if (d.type === 'wide') { wideT = 12; fx.text(d.x, d.y - 20, 'Geniş!', '#7ee8fa'); }
          if (d.type === 'coin') { bonusCoins += 5; api.sfx.coin(); fx.text(d.x, d.y - 20, '+5 🪙', '#ffd60a'); }
          if (d.type === 'multi' && state === 'play') {
            const src = balls[0];
            for (let k = 0; k < 2; k++) {
              const a = (k ? 0.5 : -0.5);
              const sp = speed();
              balls.push({ x: src.x, y: src.y, r: src.r, vx: Math.sin(a) * sp, vy: -Math.cos(a) * sp, stuck: false });
            }
            fx.text(d.x, d.y - 20, '×3 Top!', '#ff70a6');
          }
        } else if (d.y > st.H + 20) drops.splice(i, 1);
      }
      fx.update(dt);
      if (flash > 0) flash -= dt;
      draw(t);
    }

    function draw(t) {
      const c = st.ctx;
      const g = c.createLinearGradient(0, 0, 0, st.H);
      g.addColorStop(0, '#1b1f4b'); g.addColorStop(1, '#3d1d6b');
      c.fillStyle = g; c.fillRect(0, 0, st.W, st.H);
      // yıldızlar
      c.fillStyle = 'rgba(255,255,255,.35)';
      for (let i = 0; i < 40; i++) {
        const x = (i * 97) % st.W, y = (i * 53 + t * 8 * (1 + (i % 3))) % st.H;
        c.fillRect(x, y, 2, 2);
      }
      for (const br of bricks) {
        const col = br.hp < br.max ? shade(br.color, -50) : br.color;
        roundRect(c, br.x, br.y, br.w, br.h, 6);
        const bg = c.createLinearGradient(0, br.y, 0, br.y + br.h);
        bg.addColorStop(0, shade(col, 40)); bg.addColorStop(1, col);
        c.fillStyle = bg; c.fill();
        c.fillStyle = 'rgba(255,255,255,.35)';
        roundRect(c, br.x + 3, br.y + 2, br.w - 6, br.h * 0.3, 4); c.fill();
        if (br.max > 1 && br.hp === br.max) {
          c.strokeStyle = 'rgba(255,255,255,.8)'; c.lineWidth = 2;
          roundRect(c, br.x + 1, br.y + 1, br.w - 2, br.h - 2, 6); c.stroke();
        }
      }
      // güçlendiriciler
      for (const d of drops) {
        const col = d.type === 'wide' ? '#7ee8fa' : d.type === 'multi' ? '#ff70a6' : '#ffd60a';
        roundRect(c, d.x - 18, d.y - 10, 36, 20, 10);
        c.fillStyle = col; c.fill();
        c.fillStyle = '#1b1f4b'; c.font = '800 12px system-ui'; c.textAlign = 'center'; c.textBaseline = 'middle';
        c.fillText(d.type === 'wide' ? '↔' : d.type === 'multi' ? '×3' : '$', d.x, d.y + 1);
      }
      // raket
      roundRect(c, paddle.x - paddle.w / 2, paddle.y, paddle.w, paddle.h, paddle.h / 2);
      const pg = c.createLinearGradient(0, paddle.y, 0, paddle.y + paddle.h);
      pg.addColorStop(0, '#ffffff'); pg.addColorStop(1, '#a0c4ff');
      c.fillStyle = pg; c.fill();
      // toplar
      const skin = BALL_SKINS[store.get().ballSkin] || BALL_SKINS.white;
      for (const b of balls) {
        c.fillStyle = skin.color === 'rainbow' ? `hsl(${(t * 300) % 360},100%,60%)` : skin.color;
        c.shadowColor = c.fillStyle; c.shadowBlur = 12;
        c.beginPath(); c.arc(b.x, b.y, b.r, 0, Math.PI * 2); c.fill();
        c.shadowBlur = 0;
      }
      if (state === 'ready') {
        c.fillStyle = 'rgba(255,255,255,.9)'; c.font = '700 18px system-ui'; c.textAlign = 'center';
        c.fillText('Başlatmak için dokun', st.W / 2, st.H * 0.62);
      }
      fx.draw(c);
      if (flash > 0) { c.fillStyle = `rgba(255,0,60,${flash * 0.5})`; c.fillRect(0, 0, st.W, st.H); }
    }

    start();
    const lp = loop(update);
    return {
      pause: () => lp.pause(), resume: () => lp.resume(),
      continue() { lives = 1; resetBall(); hud(); },
      restart() { start(); },
      destroy() {
        lp.stop(); st.destroy(); window.removeEventListener('keydown', onKey);
      },
    };
  },
};
