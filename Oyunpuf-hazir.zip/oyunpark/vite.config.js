import { defineConfig } from 'vite';
import { viteSingleFile } from 'vite-plugin-singlefile';
// SINGLE=1 → tek dosyalık web önizlemesi; normal build → Capacitor için dist/
export default defineConfig({
  base: './',
  plugins: process.env.SINGLE ? [viteSingleFile()] : [],
  build: { outDir: process.env.SINGLE ? 'preview' : 'dist', target: 'es2020', assetsInlineLimit: process.env.SINGLE ? 1e9 : 4096 },
});
