# Oyunpuf Gizlilik Politikası (taslak)

*Son güncelleme: 18 Kasım 2026* · Geliştirici: stzdijital · İletişim: stzdijital@gmail.com

**Topladığımız veriler.** Oyunpuf hesap oluşturmanı istemez. Adını, e-postanı, konumunu ya da fotoğraflarını toplamaz. Oyun ilerlemen (coinler, rekorlar, seviyeler) ve ilk açılışta seçtiğin doğum yılı yalnızca senin cihazında saklanır.

**Reklamlar.** Uygulamada Google AdMob reklamları gösterilir. AdMob cihazın reklam kimliğini ve genel cihaz bilgilerini kullanabilir. Doğum yılı 13 yaşın altını gösteren kullanıcılara yalnızca kişiselleştirilmemiş ve her yaşa uygun reklamlar gösterilir; bu kullanıcılar için reklam isteği "çocuklara yönelik" olarak işaretlenir. Avrupa ve Türkiye'deki kullanıcılardan kişiselleştirilmiş reklam için onay istenir. iOS'ta izleme yalnızca izin verirsen yapılır. Ayrıntılar: https://policies.google.com/technologies/ads

**Abonelik.** VIP aboneliği yalnızca Apple App Store veya Google Play üzerinden satın alınır ve yönetilir. Ödemeler mağaza tarafından işlenir; kart bilgilerine erişimimiz yoktur. Çocuk kullanıcılar için satın almadan önce ebeveyn onayı istenir.

**Online oyun.** "Arkadaşlarla Online" bölümünde Google Firebase kullanılır: anonim bir kimlik oluşturulur, oda kodu, oyuncu adı ve oyun hamleleri geçici olarak Firebase sunucularında tutulur. Serbest mesajlaşma yoktur.

**Ölçüm.** 13 yaş ve üzeri kullanıcılar için Firebase Analytics ile anonim kullanım olayları (ör. oyun bitişi) toplanır. 13 yaş altı için gönderilmez.

**Çocuklar.** Uygulama her yaşa uygundur. 13 yaş altındaki çocuklardan bilerek kişisel veri toplamayız (COPPA / KVKK).

**Verilerin silinmesi.** Ayarlar → "İlerlemeyi sıfırla" ile ya da uygulamayı silerek cihazdaki tüm verileri silebilirsin.

**İletişim.** Sorular için: stzdijital@gmail.com
