package com.oyunpuf.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
