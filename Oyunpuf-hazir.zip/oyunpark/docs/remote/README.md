# OyunPark — Uzaktan İçerik

Bu klasör sunucuya yüklenir. Uygulama her açılışta `config.json` dosyasını indirir. İmza doğruysa ayarları uygular ve yeni oyunları indirir. Bunlar için mağazaya yeni sürüm göndermeniz gerekmez.

## İlk kurulum (bir kez)

1. **İmza anahtarı üretin**
   - `node tools/remote-keygen.mjs` komutunu çalıştırın.
   - Gizli anahtar `tools/remote-private.jwk` dosyasına kaydedilir. Bu dosyayı kimseyle paylaşmayın; git'e de eklenmez. Bu dosya kaybolursa yayındaki uygulamalar yeni içeriği kabul etmez, düzeltmek için mağazaya yeni sürüm göndermek gerekir. Güvenli bir yerde yedekleyin.
   - Ekrana yazılan açık anahtarı `src/config.js` dosyasındaki `REMOTE_PUBLIC_KEY` alanına yapıştırın.
2. **Bir sunucu seçin**
   - Seçenekler: GitHub Pages, Firebase Hosting, Netlify veya Cloudflare Pages. Hepsinin ücretsiz planı yeterli.
   - Sunucu `Access-Control-Allow-Origin: *` başlığını göndermeli (CORS). GitHub Pages ve Netlify bunu varsayılan olarak yapar. Firebase Hosting'de `firebase.json` dosyasına bu başlığı eklemeniz gerekir.
3. **Adresi uygulamaya girin**
   - `config.json` dosyasının adresini `src/config.js` içindeki `REMOTE_CONFIG_URL` alanına yazın, örneğin `https://kullanici.github.io/oyunpark-icerik/config.json`.
   - Ardından uygulamayı derleyip mağazaya gönderin. Bu son mağaza gönderimi; bundan sonraki içerik güncellemeleri sunucudan yapılır.

## Her güncellemede

1. `remote/config.json` dosyasını düzenleyin. Yeni oyun ekleyecekseniz HTML dosyasını `remote/games/` klasörüne koyun.
2. `node tools/remote-publish.mjs` komutunu çalıştırın. Bu komut:
   - oyunların özetlerini (sha256) hesaplar,
   - sürüm numarasını bir artırır,
   - `config.sig` imza dosyasını üretir.
3. `remote/` klasörünün tamamını sunucuya yükleyin.

Değişiklikler, oyuncular uygulamayı açtığında veya internete yeniden bağlandığında gelir. İndirilen uzaktan oyunlar cihaza kaydedilir, bu yüzden sonrasında internetsiz de oynanır.

## config.json alanları

| Alan | Ne işe yarar | Sınırlar |
|---|---|---|
| `schema` | Biçim sürümü. Her zaman `1`. | — |
| `version` | Yayın sürümü. Komut otomatik artırır; uygulama daha eski bir sürümü kabul etmez. | — |
| `minAppVersion` | Bundan eski uygulama sürümlerine "Güncelle" penceresi çıkar. | örn. `"1.2.0"` |
| `updateUrl` | "Güncelle" düğmesinin açacağı mağaza adresi. | https |
| `adPolicy` | Reklam sıklığı. Alan adları `src/config.js` dosyasındaki `AD_POLICY` ile aynı (`every`, `dailyCap`, `minPlaySec`, `childDailyCap` …). | Her alanın güvenli bir aralığı var; aralık dışındaki değerler yok sayılır. |
| `economy.coinRate` | Bütün oyunlarda puanın coine dönüşme oranı. | 0,05–2 |
| `economy.dailyRewards` | 7 günlük ödül dizisi. | 7 sayı |
| `economy.wheelPrizes` / `wheelWeights` | Şans çarkı dilimleri ve dilimlerin çıkma olasılıkları. | 8'er sayı |
| `economy.expertStrength` | Uzman modunun gücü. 0 kapalı, 1 normal, 2 iki kat. | 0–2 |
| `events[]` | Belli tarihler arasında coin çarpanı, örneğin "Hafta sonu 2× coin". | `coinMultiplier` 1–5; `start` / `end` ISO tarih |
| `announcements[]` | Açılış ekranında duyuru. `game` alanı verilirse duyuruya dokununca o oyun açılır. Her duyuru oyuncuya bir kez gösterilir. | Aynı anda en fazla 1 duyuru görünür |
| `catalog.order` | Oyun listesinin sırası. Burada yazılan oyunlar başa gelir. | Oyun kimlikleri (id) |
| `catalog.hidden` | Bir oyunu uzaktan gizler. Sorunlu bir oyunu hemen kapatmak için kullanılır. | Oyun kimlikleri (id) |
| `catalog.badges` | Oyun kartında rozet, örneğin `"YENİ"` veya `"🔥"`. | En fazla 12 karakter |
| `games[]` | Uzaktan HTML5 mini oyunlar (aşağıda). | En fazla 50 |

Uygulamanın içindeki oyunların kimlikleri: `runner`, `voxel`, `penalty`, `billiards`, `balloon`, `match3`, `blockfit`, `ballsort`, `breakout`, `memory`, `xox`, `snake`, `catcher`, `mathGame`, `stack`, `arrows`, `helix`, `basket`, `ludo`, `racer`, `rocket`, `g2048`, `mole`, `simon`, `jumper`, `mines`, `colortap`, `shooter`, `maze`, `reflex`, `schulte`, `dodge`, `lights`, `connect4`, `checkers`, `pyramid`, `merge`, `puzzle`, `hockey` ve diğerleri. Tam liste için `src/games/` klasöründeki dosyalarda `id:` satırlarına bakın.

### Uzaktan oyun alanları

```json
{
  "id": "renk-zipla",            // küçük harf, rakam ve tire; uygulamada "r-renk-zipla" olarak görünür
  "title": "Renk Zıpla", "emoji": "🎨", "color": "#7b2cbf", "desc": "Kısa açıklama",
  "url": "games/renk-zipla.html", // config.json'a göre yol ya da https adresi
  "sha256": "",                   // remote-publish.mjs otomatik doldurur
  "age": 4,                       // yaş sınırı: oyuncu daha küçükse oyun listede görünmez
  "targetBase": 8, "targetGrowth": 1.25, // seviye hedefi = targetBase × targetGrowth^(seviye-1)
  "coinDiv": 1, "coinCap": 40,    // kazanılan coin = puan / coinDiv, en fazla coinCap
  "landscape": false,             // oyun yatay mı açılsın
  "minAppVersion": "1.0.0"        // bundan eski uygulamalarda oyun gösterilmez
}
```

## Uzaktan oyun yazmak

Oyun tek bir HTML dosyasıdır. Resimler ve sesler data-URL olarak dosyanın içine gömülür; dosya en fazla 3 MB olabilir. Uygulama dosyaya `window.OyunPark` adlı küçük bir arayüzü (SDK) otomatik ekler:

```js
const OP = await OyunPark.ready();   // OP.level: oyuncunun seviyesi, OP.child: 13 yaş altı mı
OyunPark.setHud({ score: 10, extra: 'Seviye ' + OP.level });
OyunPark.sfx('coin');                // tap, click, pop, coin, win, lose, wrong, bounce, brick, swap, crash, power, slide
OyunPark.gameOver({ score: 42, win: false, canContinue: true });
OyunPark.onPause(fn); OyunPark.onResume(fn); OyunPark.onRestart(fn); OyunPark.onContinue(fn);
```

Örnek oyun: `games/renk-zipla.html`. Zorluğu `OP.level` değerine göre artırın.

**Güvenlik kutusu (sandbox).** Uzaktan oyun ayrı bir kutuda çalışır:
- Uygulamanın verilerine, coinlere ve satın alımlara erişemez.
- İnternete bağlanamaz: dışarıya istek atamaz, dışarıdan resim de yükleyemez.
- Telefonun özelliklerini kullanamaz: titreşim, reklam, kamera ve benzerleri kapalıdır.
- Coin miktarını oyun değil uygulama hesaplar; oyun hile yapıp fazla coin veremez.

## Mağaza kuralları

- **Apple 4.7:** HTML5/JavaScript mini oyunlara izin verilir. Ek şartlar ve uygulamadaki karşılıkları:
  - Oyunlara telefonun yerel özellikleri açılmaz: titreşim, reklam, satın alma ve kamera kapalı (4.7.2).
  - Oyunların kişisel veriye ve internete erişimi yoktur (4.7.3).
  - Yaşı küçük oyuncudan yaş sınırı yüksek oyunlar gizlenir (4.7.5).
  - Her uzaktan oyunda "⚑ Bildir" bağlantısı vardır. Gelen şikâyetlere `SUPPORT_EMAIL` adresinden zamanında yanıt verin (4.7.1).
  - Oyun dizini uygulamanın içindeki listedir. Her oyun `?game=<id>` bağlantısıyla doğrudan açılabilir (4.7.4). Apple bu dizinde "universal link" de istiyor; kendi alan adınız olduğunda Apple'ın universal link kurulumunu (apple-app-site-association) yapın.
- **Google Play:** WebView içinde çalışan JavaScript'e izin verilir. Uygulama uzaktan yerel kod (dex, .so) indirmez.
- **İkisi için de geçerli:** Uygulamanın ana amacını uzaktan değiştirmeyin. Uzaktan oyunlar da mağaza içerik kurallarına uymak zorunda; sorumluluk sizde.
