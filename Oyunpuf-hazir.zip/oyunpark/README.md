# Oyunpuf — 39 mini oyun (iOS + Android)

Tek kod tabanı: **Vite + saf JavaScript (Canvas)**, mağazalar için **Capacitor 7** ile paketlenir.

## İçindekiler
- **36 mini oyun** (`src/games/`): Balon Patlat, Şeker Patlat, Blok Kırma, Hafıza Kartları, XOX, Yılan, Meyve Yakala, Hızlı Matematik, Kule Yap, Köstebek Vur, Renk Sırası, Hedef Vur, 2048, Renk Avcısı, Araba Yarışı, Zıpla Zıpla, Labirent, Sayı Avı, Kaç Kurtul, Zıpzıp Roket, Uzay Savunması, Işıkları Söndür, Mayın Tarlası, Yapboz, Blok Yerleştir, Top Sırala, Dört Bağla, Dama, Piramit Kart, Meyve Birleştir, Hava Hokeyi (2 kişilik destekli), Sonsuz Koşu, Sarmal Kule, Basket Atışı, Penaltı, Ok Fırlat.
- **3D oyunlar (Three.js, `src/core/three-stage.js`):** Blok Dünyası (kendi tasarımımız blok inşa/keşif oyunu: 3. şahıs karakter, hareket kolu, basılı tutarak kırma, envanter, yaratıcı mod, gece-gündüz, online birlikte oynama), Bilardo, Araba Yarışı, Sonsuz Koşu, Penaltı, Basket Atışı, Sarmal Kule, Kule Yap, Blok Kırma, Hava Hokeyi, Köstebek Vur, Uzay Savunması
- **Coin hızı:** `src/config.js` → `COIN_RATE` (şu an 0.4), seviye bonusu, bedava coin ve günlük ödüller tek yerden ayarlanır
- **Ortak coin cüzdanı:** her oyunda kazanılır; garaj, devam etme ve kilit açmada harcanır
- **Zorluk seviyeleri:** her oyunun kalıcı seviyesi var (Sv.1, Sv.2 …). Hedef puanı geçince bir sonraki seviye açılır ve oyun kalıcı olarak zorlaşır (hız, engel, süre, tahta boyutu, yapay zekâ…). Oyun içinde de oynadıkça zorlaşır. Hedefler `target(L)` ile her oyunun dosyasında tanımlı.
- **Bütün oyunlar ücretsiz ve açık.** Kilit yok (istenirse `src/config.js` → `GAME_UNLOCKS` ile eklenebilir).
- **Para kazanma (tek ödeme yöntemi: App Store / Google Play):**
  - AdMob reklamları: banner (menüler), geçiş (her 3 oyunda bir, en az 90 sn arayla), ödüllü (2 kat coin, devam et, bedava coin, günlük ödül, Şans Çarkı, Bonus Kasası)
  - **VIP abonelik** (haftalık / aylık / yıllık): reklamsız, ödüller reklam izlemeden, coinler 2 kat, günde 3 bedava çark, VIP görünümler
  - **Hoş geldin teklifi:** ilk 48 saat geri sayımlı VIP bandı (deneme süresi mağaza panelinden "intro offer" olarak tanımlanır)
  - **Bonus Kasası:** internetsizken kazanılan coinin yarısı ayrıca birikir, internet gelince reklamla açılır (çevrimdışı oyunu gelire çevirir)
  - **Reklam ön yükleme:** internet gelince ve uygulama öne gelince reklamlar önceden yüklenir
- **Mağaza kurallarına uyum:** ilk açılışta nötr yaş sorusu → 13 yaş altına çocuk uyumlu reklam (kişiselleştirme kapalı, içerik derecesi G) + satın almalarda ebeveyn kapısı; GDPR/KVKK onay formu; iOS izleme izni

## Tek / Çok kişilik
- Açılışta iki düğme var: **Tek Kişilik** (seviyeler, kilitler, coin) ve **Çok Kişilik** (2–4 kişi aynı telefonda).
- Çok kişilikte oyuncu sayısı ve isimler seçilir; liste yalnızca o sayıya uyan oyunları gösterir:
  - **Karşı karşıya:** Kızma Birader (2–4), Hızlı Parmak (2–4), Halat Çekme (2 / 4 takım), Hava Hokeyi, XOX, Dört Bağla, Dama (2)
  - **Sırayla oyna:** puanlı tüm oyunlar; herkes sırayla oynar, sonunda sıralama tablosu çıkar (tek kişilikte açılmış oyunlar)
- Bir oyunu çok kişiliğe açmak için oyun nesnesine `players: { min, max, allowed? }` ekle ve `api.mp` (oyuncu sayısı ve isimler) varken `api.gameOver({ winner })` çağır. Yalnızca çok kişilik oyunlar `mpOnly: true` ile işaretlenir.

## Ekran yönü
Her oyunun üst çubuğunda 🔄 düğmesi var: oyun dikey ↔ yatay arasında döner ve tercih o oyun için kaydedilir (`store.orient`). Varsayılan olarak `landscape: true` olan oyunlar (Blok Dünyası, Bilardo 3D) yatay açılır. Yön `@capacitor/screen-orientation` ile kilitlenir, menüye dönünce dikeye geri gelir. Tarayıcıda telefon dikey tutulursa "Telefonunu yan çevir" uyarısı çıkar.

## Reklam sıklığı (src/config.js → AD_POLICY)
Geçiş reklamı yalnızca oyun bitişinde ve şu kuralların hepsi sağlanırsa gösterilir: yeni oyuncuya ilk 5 oyunda hiç yok; normalde her 3 oyunda bir **ve** son reklamdan beri en az 2,5 dk gerçek oynama (duraklatma sayılmaz); iki reklam arası ≥ 90 sn; ödüllü reklam izleyene 3 dk yok; günde en fazla 12. İlk 2 gün her 4 oyunda bir / 4 dk; 13 yaş altı her 4 oyunda bir, günde en fazla 6; arkadaşlarla oynarken her 3 maçta bir. Günün 4. reklamından sonra bir kez "reklamsız oyna (VIP)" teklifi çıkar. Banner sadece menülerde, oyun içinde yok. VIP'te hiç reklam yok. Rakamları değiştirmek için yalnızca `AD_POLICY`'yi düzenleyin.

## Ekran düğmeleri (src/core/touchpad.js)
Hareketli oyunlarda dokunmatik tuşlar: Araba Yarışı (◀ ▶ şerit, ⚡ Gaz, 🛑 Fren — gazsız seyir hızı, gazla tam hız ve daha çok metre), Sonsuz Koşu (◀ ▶, Zıpla, Kay), Zıpla Zıpla / Meyve Yakala / Blok Kırma (◀ ▶, Fırlat), Sarmal Kule (⟲ ⟳), Kaç Kurtul / Uzay Savunması / Yılan / Labirent (4 yön). Çoklu dokunuş desteklenir (gaz + yön aynı anda). Kaydırma/sürükleme de çalışmaya devam eder. Ayarlar → "Ekran düğmeleri" ile kapatılabilir.

## Uzaktan içerik (uygulama güncellemeden)
`remote/` klasörü sunucuya yüklenir; uygulama açılışta `config.json`'u indirir, **imzasını doğrular** ve uygular: reklam sıklığı, coin oranı, günlük ödüller, çark, uzman modu gücü, zamanlı etkinlikler (2× coin), duyurular, oyun sıralama/gizleme/rozet ve **yeni HTML5 mini oyunlar** (güvenli kutuda, internetsiz de oynanır). Kurulum ve tüm alanlar: `remote/README.md`. Araçlar: `tools/remote-keygen.mjs` (bir kez), `tools/remote-publish.mjs` (her güncellemede). Kod: `src/core/remote.js`, `src/core/webgame.js`.

## Zorluk tavanı ve uzman modu
Seviye sınırı yoktur. Her oyunun normal zorluk artışı belli bir seviyede tavan yapar; o seviyeden sonra **uzman modu** (🔥, oyunun `expertFrom` alanı) başlar ve `src/core/expert.js` her seviyede biraz daha zorlaştırır (yumuşak artış, en fazla ~%60): Mayın Tarlası daha çok mayın, Labirent/Hafıza/Piramit/Renk Avcısı/Matematik daha az süre, Şeker Patlat daha az hamle, Yılan/Blok Yerleştir daha çok engel, Köstebek/Hedef Vur daha hızlı, Meyve Birleştir daha sık taş, Top Sırala daha derin tüpler, 2048 daha çok fazladan taş, Blok Kırma daha hızlı top. Hızı zaten sürekli artan aksiyon oyunlarında ve en iyi yapay zekâya ulaşan tahta oyunlarında uzman modu yoktur. XOX'ta Sv.5+ bilgisayar yenilebilir kalır (hata payı ≥%14; hiç kaybetmeden 1 tur kazanmak da seviye atlatır). 2048 hedef puanı daha dengeli (Sv.12 ≈ 15 bin).

## 3D oyunlar ve hazır modeller
Oyunların çoğu Three.js ile 3D'dir (ortak yardımcılar: `src/core/three-stage.js`, tahta oyunları için `src/core/board3d.js`).
Hazır 3D modeller `src/assets/models/` klasöründe (Kenney Starter Kit'lerinden, **MIT lisansı** — `LICENSE-kenney.md`). Dokular GLB içine gömülüdür; `src/core/assets.js` yükler ve önbelleğe alır (açılışta arka planda önden yüklenir). Kullanıldığı yerler: Zıpla Zıpla (karakter, para, çimen), Kaç Kurtul (karakter), Meyve Yakala / Yılan (para), Yılan (tuğla engeller), Labirent (bayrak), Araba Yarışı (kamyonlar).
Ek hazır asset'ler (hepsi **CC0**, ticari kullanım serbest; tam liste: `src/assets/models/CREDITS.md`):
- `bc-*` Kenney Blocky Characters → Blok Dünyası oyuncuları, Sonsuz Koşu koşucusu, Penaltı şutçu/kaleci/baraj, Penaltı ve Basket seyircileri (`src/core/crowd.js`)
- `kv-blocks` / `kv-grass` Kenney Voxel Pack dokuları → Blok Dünyası blokları (tek atlas, GLB içinde), Penaltı çimi
- `gy-*` Kenney Graveyard Kit → Blok Dünyası canavarları; `ma-*` Kenney Mini Arena → kılıçlar, kupa, bayrak; `kw-*` KayKit Fantasy Weapons → yay, ok
Kenney Weapon Pack (ateşli silahlar) 4+ yaş derecesi için bilinçli olarak kullanılmadı. Kale ağı ve top deseni kodla çizilir (CC0 kale modeli yok).
`src/core/assets.js`: `model()`, `modelInto()` (yüklenene kadar `fallback`), `once()` (tek seferlik animasyon), `attachTo()` (eşyayı karakterin eline bağlar), `stubFigure()`.
Ayarlar ekranında "🎨 Asset kredileri" bölümü vardır; MIT lisansı gereği kaldırmayın.

2D kalan oyunlar (yazı/sayı ağırlıklı): Hızlı Matematik, Sayı Avı, Yapboz, Piramit Kart, Hızlı Parmak, Halat Çekme, Taş Kağıt Makas, Amiral Battı.

## Blok Dünyası modları
- 🌍 **Sonsuz dünya**: dünya 16×16'lık parçalar halinde her yöne sınırsız üretilir (tepeler, göller, dağlar, karlı zirveler, ormanlar). Oyuncunun çevresindeki 3 parça çizilir, uzaktakiler bellekten atılır; sadece oyuncunun değiştirdiği bloklar kaydedilir (`oyunpark_world_v3`). Online'da dünya oda koduna göre herkeste aynı üretilir.
- 🏗️ **İnşa ve Keşif** — serbest kazma/inşa + görevler (yaratıcı mod açılabilir)
- ⚔️ **Hayatta Kal** — Zombi, İskelet ve Hayalet canavar dalgaları (Kenney Graveyard Kit modelleri); 10 kalp; dalgalar arası 10 sn mola. Seviye yükseldikçe canavar sayısı, canı ve hızı artar. Puan = yenilen canavar; hedef `8 + (Sv-1)*5`.
- 🏟️ **Arena (online)** — arkadaşlar silah üretip birbirine karşı savaşır, 5 nakavt yapan kazanır. Online'da kurucu modu seçer (Birlikte İnşa / Arena).
- 🛠️ **Üretim (birleştirme)**: Tahta Kılıç (3 tahta), Taş Kılıç (2 taş + 1 tahta), Altın Kılıç (3 altın + 1 tahta), Yay (3 tahta + 2 yaprak), 8 Ok (1 taş + 1 tahta), Can İksiri (3 yaprak + 1 altın, +6 kalp).
- 🎯 Nişangah, menzildeki bir düşmana bakınca kırmızıya döner. Kan/şiddet görseli yok: yenilen canavar ışıltıyla "puf" diye kaybolur.
- Klavye: F = vur, R = silah değiştir.

## Arkadaşlarla Online
- Açılışta üçüncü düğme: **🌐 Arkadaşlarla Online**. Biri oyun seçip oda kurar → 5 harfli kod çıkar → "Arkadaşına gönder" (WhatsApp vb.) → arkadaşı "Odaya katıl"dan kodu yazar.
- Online oyunlar: Kızma Birader (2–4), Blok Dünyası 3D (1–4, birlikte inşa), Bilardo 3D, Dört Bağla, XOX, Dama, Taş Kağıt Makas, Amiral Battı (2)
- Altyapı `src/online/net.js`: Firebase Firestore + anonim giriş. `src/config.js` → `FIREBASE_CONFIG` boşsa **deneme modu** çalışır (aynı cihazda iki tarayıcı sekmesi arasında).
- **Firebase'i bağlamak:** konsolda Firestore + Anonymous Authentication'ı aç, web uygulaması ekle, `firebaseConfig` nesnesini `FIREBASE_CONFIG`'e yapıştır. `firestore.rules` dosyasının içeriğini Firestore → Rules sekmesine yapıştırıp yayınla. Eski odaların otomatik silinmesi için Firestore → TTL bölümünde `rooms` koleksiyonu için `expireAt` alanını seç (TTL silmeleri Blaze planı ister).
- Bir oyunu online yapmak: oyuna `online: { min, max }` ekle; `api.mp.online` varken kendi hamlende `api.mp.online.send(veri)`, rakibin hamlesi için `api.mp.online.on(cb)` kullan. Oyuncu sırası `api.mp.online.me`.
- Online maçlarda serbest yazışma yok (çocuk güvenliği); sadece oyun hamleleri gider.

## Geliştirme
```bash
npm install
npm run dev          # tarayıcıda dene (reklam/satın alma burada test ekranıyla taklit edilir)
npm run build        # dist/ üretir
npx cap sync         # dist/'i android/ ve ios/ içine kopyalar
npx cap open android # Android Studio
npx cap open ios     # Xcode (Mac gerekir)
```

## Yayınlamadan önce yapılacaklar (sırayla)
1. **Paket adı:** `capacitor.config.json` → `appId` (ör. `com.oyunpuf.app`). Değiştirince `android/` ve `ios/` klasörlerini silip `npx cap add android && npx cap add ios` ile yeniden oluştur.
2. **AdMob** (admob.google.com): bir uygulama aç ve 3 reklam birimi oluştur (banner, geçiş, ödüllü). Bunu Android ve iOS için ayrı ayrı yap.
   - `src/config.js` → `ADMOB` kimliklerini değiştir, `TEST_ADS = false` yap
   - `android/app/src/main/AndroidManifest.xml` → `APPLICATION_ID`
   - `ios/App/App/Info.plist` → `GADApplicationIdentifier`
   - Google Play'de yayınlanan uygulamalar için AdMob'da `app-ads.txt` dosyasını sitende yayınla
3. **VIP abonelik:** App Store Connect'te bir abonelik grubu ("OyunPark VIP"), Google Play Console'da abonelikler oluştur. Kimlikler iki mağazada da aynı olmalı:
   `vip_weekly`, `vip_monthly`, `vip_yearly`. Yıllık plana "3 gün ücretsiz" deneme (intro offer) ekle — uygulamadaki hoş geldin bandı bunu söyler.
   Fiyatlar uygulamada mağazadan otomatik gelir (`src/config.js` → `VIP_PLANS` içindeki fiyatlar yalnızca yedek).
   Abonelik durumu sunucu olmadan, mağazanın cihaza bildirdiği işlemlerden hesaplanır ve telefonda saklanır (VIP internetsiz de çalışır).
   `TERMS_URL` ve `PRIVACY_URL` adreslerini kendi sayfalarınla değiştir (Apple abonelik ekranında bu iki link zorunlu).
4. **Gizlilik politikası:** `GIZLILIK.md` taslağını doldur, bir web sayfasında yayınla ve linki `src/main.js` içindeki `example.com/oyunpark/gizlilik` yerine yaz.
5. **iOS:** Xcode → Signing & Capabilities → Team seç, **In-App Purchase** yeteneğini ekle. Product → Archive → App Store Connect'e yükle.
6. **Android:** Android Studio → Build → Generate Signed App Bundle (.aab) → Play Console'a yükle. Keystore dosyasını kaybetme.

## Ölçüm (isteğe bağlı Firebase Analytics)
Olaylar (`app_open`, `game_end`, `vip_view`, `vip_buy_tap`, `vip_active`, `wheel_spin`, `chest_open`) her zaman cihazda sayılır. Firebase'e de göndermek için:
1. Firebase konsolunda proje aç, Android ve iOS uygulamalarını ekle; `google-services.json` → `android/app/`, `GoogleService-Info.plist` → `ios/App/App/`
2. `npm i @capacitor-firebase/analytics firebase && npx cap sync`
3. `src/core/analytics.js` → `FIREBASE_ENABLED = true`

## Mağaza formlarında dikkat
- **Google Play → Hedef kitle:** "13 yaş altı ve üstü (karma)" seç. Böylece Aileler politikası geçerli olur; AdMob, Aileler programı için sertifikalı bir reklam ağı. Reklam içeriği tercihi: "Herkes için uygun (G)".
- **Apple → Yaş derecesi:** 4+. **Kids kategorisini SEÇME**: Kids kategorisinde üçüncü taraf reklam neredeyse yasak. "Games › Family / Puzzle" kategorisini kullan.
- **Veri güvenliği / Gizlilik etiketleri:** reklam kimliği (AdMob) ve satın alma geçmişi toplanıyor (Firebase açılırsa uygulama kullanım verisi de). Hesap ya da kişisel veri toplanmıyor; ilerleme yalnızca cihazda tutuluyor.

## Yeni oyun eklemek
`src/games/` içine bir dosya ekle. Dosya `{ id, title, emoji, color, desc, target(L) | winBased, create(host, api) }` nesnesini dışa aktarmalı. `create`, `{ pause, resume, restart, destroy, continue? }` döndürür. Seviyeyi `api.level` ile oku. Sonra dosyayı `src/main.js` → `GAMES` listesine ekle.
